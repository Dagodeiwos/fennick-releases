# Fennick's Beast Core: changelog

All notable changes, newest first. Dates are month and year only.

## 1.8.0 (October 2026)
- Six roles instead of seven: Pet DPS is gone. Beast Mastery Hunters count as Ranged DPS and Demonology Warlocks as Shadow Magic DPS. A saved Pet DPS choice moves over by itself.
- Hybrid can now be chosen under Settings, "Role", not only detected.
- Survival Hunters can be Melee DPS as well as Ranged DPS. The equipped ranged weapon decides: with a bow, gun or crossbow it is Ranged DPS, without one Melee DPS.
- Guidepost's quest reward pick now takes its weapon types from the role too (see Guidepost 4.7.0).

## 1.7.0 (October 2026)
- Role detection for every Fennick add-on. Core reads how your talent points are spread over the three trees and what your gear adds (spell damage per school, bonus healing, defense, a shield) and names one of seven simple roles: Melee DPS, Ranged DPS, Magic DPS, Healing, Tank, Pet DPS or Hybrid, with a focus where the class has one (for example Shadow Magic DPS or Holy Magic Tank).
- New setting "Role": Automatic (shows what was detected) or any role your class can take. Your choice is saved per character.
- Gear advice now follows the role, including spell power for one school (a Fire mage values "+Fire spell damage" items; a Frost mage does not).
- For module authors (API 6): C:Role(), C:RoleLabel(), C:RoleWeights(), C:SetRoleFocus(key), C:OnRoleChanged(fn), C:ItemStats(link) and C:RoleItemScore(link). See API.md.

## 1.6.1 (October 2026)
- New shared helper C:Facing(): reads your facing safely and returns nothing during encounters, when the value is secret, or on an error (Forever 1.60.1 blocks minimap rotation to add-ons in encounters). Also C:MinimapRotates().
- The built-in waypoint arrow hides its pointer while your facing is hidden and keeps showing the distance; it comes back on its own after the encounter.
- Monster tooltip: reads only the NPC ID from creature IDs (the obfuscated server/spawn parts are ignored).

## 1.6.0 (October 2026)
- Map tooltips that say what is there: hover any Fennick pin or shaded area and one tooltip lists everything under the cursor, grouped by type ("Kobold Miner (group) x8", "Copper Vein x12", "Tin Vein x3"), with when it was last seen. Never more than 8 lines; hold Shift for "seen N times" and the age of each line. Used by Trailmarks on Blizzard's maps and by Cartographer. Settings: "Map tooltips: last seen" (on by default).
- /fennick report: opens a copy box with your client and Fennick versions, language, other map/guide add-ons, a short settings digest, the focused module and step number, and the last 20 Fennick errors (numbers stripped). Paste it into "Report text" on the GitHub bug form. Copy only; nothing is sent anywhere.
- Bug reports now point to github.com/Dagodeiwos/fennick-releases/issues (the support e-mail is gone).
- Tester mode (/fennick tester on): off by default. Shows debug lines and keeps the last 50 Fennick errors in your saved settings on this PC only (removed again when you switch it off). Never changes how anything plays.
- The shared map pin art (the 50 Fennick pins at 16 and 32 px, and the area shading texture) now lives once in Beast Core; Trailmarks and Cartographer use it from here (about 600 KB smaller install).
- Settings are grouped: Beast Core first, then one section per module. Each section shows its everyday rows (8 at most); the rest sit behind "More settings (n)", and every section ends with "? Help".
- /fennick <module> help prints a few lines of help for that module (for example /fennick trail help, /fennick map help); /fennick guide works like /fennick lvl.
- One shared look for Fennick panels and buttons (teal, gold, amber and cream), used by Cartographer and Trailmarks.
- Tester mode also shows the module version on the focus window title and adds "Copy result + report" to Fox Trials.
- Text cleanup also removes unit codes and internal find keys (for example "Creature-0-..." or "n3098") from anything Fennick shows or copies.
- The Fennick waypoint now shows in the map tooltip when you hover near it (Trailmarks on Blizzard's maps, Cartographer).
- Beast Core now holds the one copy of the Guidepost and small Trailmarks logos used by pickers (C:LogoPath).
- One copy box for the suite: Cartographer's "Share my pins" and Fox Trials results use the /fennick report box.
- Map tooltips show a "|" typed into a pin name or note as plain text (it can no longer turn into a colour or icon code).

## 1.5.1 (October 2026)
- Your own Blizzard map pin is never replaced or cleared: Core only updates a pin it placed itself, at exactly that spot.
- New hook point (C:OnReassess) so modules can follow the 1 s update without patching Core.
- Safety: Core refuses to register events this client forbids for add-ons (the combat log events), for every module, so no module can trigger a "blocked" warning that way.

## 1.5.0 (October 2026)
- Map pin broker for Fennick's Cartographer: modules publish map pins (C:PublishMapPins); the current waypoint is shown on Cartographer, else mirrored to Blizzard's map pin (never replacing your own). More translations filled in.

## 1.4.1 (October 2026)
- New in-game icon (window header, AddOns list). Cosmetic only.

## 1.4.0 (October 2026)
- Sound cue registry (C:RegisterCue / C:Cue): every cue has its own toggle under Sounds and starts off; nothing plays unless Sounds is also on. Plain-language message when a module needs a newer Beast Core (never "API n"). Setup's welcome page and `/beast help` list one line per installed module.

## 1.3.0 (October 2026)
- Multi-language: machine-translated text (labelled in Settings and setup) for German, French, Spanish, Italian, Portuguese (BR), Russian, Korean and Chinese (Simplified/Traditional); English text, fonts and slash commands unchanged; names from the game client by ID. Locale framework (fallback chain esMX->esES, ptPT->ptBR), Cinzel titles fall back to the client font on Russian/Korean/Chinese clients, self-sizing buttons.

## 1.2.0 (October 2026)
- API gate, Core-owned /fennick, view hash, schema with _unknown, shared events and idle clock, TomTom/Arrow/Edit Mode fixes, setup X = Skip, overflow tooltip, minimap click rules, realm dates, teal and gold look with icons, shared status colours.

Suite-wide notes: https://github.com/Dagodeiwos/fennick-releases/blob/main/CHANGELOG.md
