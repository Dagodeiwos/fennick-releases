# Fennick's Cartographer: changelog

All notable changes, newest first. Dates are month and year only.

## 1.2.0 (October 2026)
- Optional compatibility with OpenMap (MIT, by the OpenMap contributors; CurseForge project 1735937). Not required and not bundled. When OpenMap is installed, the map key and /fennick map open the game's world map (OpenMap's seamless view) instead of Cartographer's own window, and your pins, Trailmarks finds, travel routes and planned trip are drawn on OpenMap's view. Cartographer uses only OpenMap's public API (OpenMapAPI) and never hooks or changes its frames; if a future OpenMap changes that API, Cartographer switches the link off for the session and works as before. Without OpenMap nothing changes.
- New marker hook (CG:RegisterMarker) so extra map markers, such as a route start flag, appear on Cartographer's map and on OpenMap's view.

## 1.1.1 (October 2026)
- Rotating minimap: during encounters, when the game hides your facing, minimap pins are hidden instead of drawn in the wrong place; the map arrow keeps its last direction.
- Square minimap: Blizzard's minimap header buttons (reorganized in Forever 1.60.1) are found while playing instead of from a fixed list, so they are never gathered with other add-ons' buttons. Missing frames are fine.

## 1.1.0 (October 2026)
- Needs Fennick's Beast Core 1.6.
- Pin tooltips on the map and minimap list everything under the cursor: Trailmarks finds with counts and last seen, flight point and dock state, and your own pins with their notes (Beast Core's map tooltip; Shift for detail).
- "Share my pins" opens Beast Core's copy box (same copy-only text).
- The module logos in the pin picker now come from Beast Core (7 duplicate image files removed; the picker shows the same 58 icons).
- The pin and area art now comes from Beast Core (no duplicate files).
- Icon filters are a tree: the 15 map categories first; Trailmarks finds fold under one row and the specific ores and herbs under their type. A search box finds any filter by name.
- Settings: everyday rows first, the rest under "More settings"; /fennick map help. Panels and buttons use Beast Core's shared look.

## 1.0.1 (October 2026)
- Saved data is checked on load: damaged values are repaired, broken pins are dropped, and the data carries a version for future updates.
- Share text: "|" in names and notes no longer breaks the columns or shows raw color codes.
- Zone names: a map error no longer stops the window (shows "Unknown zone").
- Many changes at once now cause a single redraw.
- Minimap pins follow Core's new update hook instead of patching Core.
- The share box no longer grabs the keyboard by itself; panels accept only their own names.
- Map key binding and minimap hook are reviewed and allow-listed: both still wait until you leave combat.

## 1.0.0 (October 2026)
- First release. A detailed world map window (client map art and explored areas, smooth drag pan, wheel zoom on the cursor, zone drill-down, coordinates, you and your party, compass rose, pin search) that opens with the map key; Blizzard's map returns when Cartographer is off.
- Travel: 69 flight points and 278 flight paths from the 70532 datamine, ships, zeppelins and the tram as route lines in the Fennick route styles; "How do I get there?" trip planner that respects your known flight points.
- Questie-style icon filters (own code) for the world map and minimap separately, with Trailmarks' 47 entries, show/hide all, hide completed and low-level quests, icon size per map, minimap distance limit, per character or account-wide.
- Saved pins with name, note and any icon (50 pins + module icons), edit and delete; copy-only share text.
- Minimap: square by default (GetMinimapShape reports SQUARE for other add-ons; round is a setting), size, Fennick border, pins clipped and clamped to the edge, wheel zoom, coordinates, 16 px pins, optional button gathering.
- Source order: Fennick first (Cartographer, Trailmarks, Guidepost, Rest, Reputation, Merchant's Favor), Blizzard second, other add-ons third; every source pcall-guarded. The compass icon and pins through one icon table.

Suite-wide notes: https://github.com/Dagodeiwos/fennick-releases/blob/main/CHANGELOG.md
