local TR = (Fennick_BEAST and Fennick_BEAST.L) or setmetatable({ F = function(_, f, ...) local ok, s = pcall(string.format, f, ...); return ok and s or f end }, { __index = function(_, k) return k end })   -- l10n (Core C.L)
if not (Fennick_BEAST and (Fennick_BEAST.API or 1) >= 3) then
  if DEFAULT_CHAT_FRAME then DEFAULT_CHAT_FRAME:AddMessage(TR["|cff33ccffFennick:|r Fennick's Cartographer needs Fennick's Beast Core 1.2 or newer. Please update Beast Core."]) end
  return
end
-- registration, settings, the map key and events (last file). Never takes focus; /fennick map.
local C = Fennick_BEAST
local CG = Fennick_CARTOGRAPHER; if not CG then return end
local M = { key = "cartographer", label = TR["Cartographer"], priority = 86, minAPI = 5, needs = "1.6", icon = CG.ICONS.compass, summary = TR["world map and minimap with travel routes and pins"] }
function M:HasStep() return false end
function M:Finished() return true end
function M:View() return { title = TR["Cartographer"], line = TR:F("%d saved pins", #CG:DB().pins), guidance = { TR["/fennick map opens the map. /fennick map share copies your pins."] }, nav = false } end
function M:ApplyLook() pcall(CG.ApplyMapLook, CG); pcall(CG.ApplyMinimap, CG) end
local function onoff(v) return C:OnOff(v and true or false) end
function M:SettingsRows()
  local function tog(k, label, a) return { adv = a, function() return string.format(label, onoff(CG:O(k))) end, function() CG:SetO(k, not CG:O(k)); CG:Apply() end } end
  return {
    tog("enabled", TR["   Cartographer on (off: Blizzard map and minimap) %s"]),
    tog("mapKey", TR["   Open with the map key %s"]),
    { adv = true, function() return TR:F("   Map size: %d x %d", CG:O("width"), CG:O("height")) end, function() local w = CG:O("width") + 150; if w > 1500 then w = 600 end; CG:SetO("width", w); CG:SetO("height", math.floor(w * 0.69)); CG:Apply() end },
    { adv = true, function() return TR:F("   Map scale: %d%%", math.floor(CG:O("scale") * 100 + 0.5)) end, function() local s = CG:O("scale") + 0.1; if s > 1.51 then s = 0.7 end; CG:SetO("scale", s); CG:Apply() end },
    { adv = true, function() return TR:F("   Map opacity: %d%%", math.floor(CG:O("alpha") * 100 + 0.5)) end, function() local a = CG:O("alpha") + 0.1; if a > 1.001 then a = 0.6 end; CG:SetO("alpha", a); CG:Apply() end },
    tog("locked", TR["   Lock map position %s"], true),
    tog("fadeMove", TR["   Fade map while moving %s"], true),
    tog("routes", TR["   Travel routes %s"]),
    tog("routeFlight", TR["   Flight paths %s"], true), tog("routeShip", TR["   Ships %s"], true), tog("routeZeppelin", TR["   Zeppelins %s"], true), tog("routeTram", TR["   Tram %s"], true),
    tog("explored", TR["   Explored areas %s"], true), tog("party", TR["   Party members %s"], true), tog("coords", TR["   Coordinates %s"], true),
    tog("miniOn", TR["   Cartographer minimap %s"]),
    { function() return TR:F("   Minimap shape: %s", CG:O("miniShape") == "round" and TR["round"] or TR["square"]) end, function() CG:SetO("miniShape", CG:O("miniShape") == "round" and "square" or "round"); CG:Apply() end },
    { adv = true, function() return TR:F("   Minimap size: %d", CG:O("miniSize")) end, function() local s = CG:O("miniSize") + 20; if s > 240 then s = 120 end; CG:SetO("miniSize", s); CG:Apply() end },
    tog("miniZoomWheel", TR["   Minimap mouse-wheel zoom %s"], true), tog("miniCoords", TR["   Minimap coordinates %s"], true),
    tog("miniGather", TR["   Gather other add-ons' minimap buttons %s"], true),
    { function() return TR["   Filter world map icons"] end, function() CG:ToggleFilters("world") end },
    { function() return TR["   Filter minimap icons"] end, function() CG:ToggleFilters("mini") end },
    { function() return TR["   Share my pins (copy text)"] end, function() CG:ShowShare() end },
  }
end
function M:WhyLines() return { TR:F("Cartographer: %d saved pins, %s", #CG:DB().pins, CG:O("enabled") and TR["on"] or TR["off (Blizzard map in use)"]) } end
CG.module = C:RegisterModule(M)
if C.RegisterHelp then C:RegisterHelp("cartographer", { TR["Cartographer replaces the world map and minimap; Blizzard's map stays one click away."],
  TR["/fennick map opens it. Drag to pan, mouse wheel to zoom, left click a zone to open it, right click to go back."],
  TR["Shift-click a spot to plan a trip with flight paths, ships, zeppelins and the tram."],
  TR["/fennick map filter opens the icon filters; /fennick map share copies your pins."] }, "map") end
-- the map key: an override binding to our own (insecure) toggle button, set and cleared only out of combat.
-- Off, or Cartographer off: no override, so the key opens Blizzard's map as usual.
local toggle = CreateFrame("Button", "Fennick_CartographerToggle", UIParent); toggle:SetScript("OnClick", function() CG:ToggleMap() end)
CG.toggle = toggle
function CG:ApplyBinding()
  if C:InCombat() then C:Safe("cartographer binding", function() CG:ApplyBinding() end); return false end
  if ClearOverrideBindings then ClearOverrideBindings(toggle) end
  self.bound = nil
  if not (self:O("enabled") and self:O("mapKey") and SetOverrideBindingClick and GetBindingKey) then return false end
  if self.OpenMapPresent and self:OpenMapPresent() then return false end   -- OpenMap loaded: the map key stays the game's (OpenMap's view)
  local k1, k2 = GetBindingKey("TOGGLEWORLDMAP")
  for _, k in ipairs({ k1, k2 }) do if k then SetOverrideBindingClick(toggle, false, k, "Fennick_CartographerToggle"); self.bound = true end end
  return self.bound == true
end
-- Trailmarks draws on Cartographer while K.SetSourcePins exists; with Cartographer off we take it away so
-- Trailmarks falls back to Blizzard's maps on its own (no change to Trailmarks needed).
local setPins = CG.SetSourcePins
function CG:Apply()
  self.SetSourcePins = self:O("enabled") and setPins or nil
  if not self:O("enabled") then self.pushed = {} end
  pcall(self.ApplyBinding, self); pcall(self.ApplyMinimap, self); pcall(self.ApplyMapLook, self)
  if self.DrawOpenMap then pcall(self.DrawOpenMap, self) end
  if not self:O("enabled") and self.map.f then self.map.f:Hide() end
  self:Changed()
end
function CG:Redraw() if self.map.f and self.map.f:IsShown() then self.map.drawnVersion = nil end; if not C:InCombat() then pcall(self.DrawMinimap, self) end end
C:RegisterSlash("map", function(arg)
  arg = (arg or ""):lower()
  if arg:find("^share") then CG:ShowShare()
  elseif arg:find("^filter") then CG:ToggleFilters("world")
  elseif arg:find("^route") then CG:ShowRoutePanel()
  elseif not CG:O("enabled") then C:Print(TR["Cartographer is off: turn it on in /fennick settings."])
  else CG:ToggleMap() end
end, TR["Cartographer: /fennick map (share, filter, route)"])
local function miniUpdate(snapshot)
  if CG:MinimapActive() and not C:InCombat() then CG:DrawMinimap(snapshot) end
end
if not (C.RegisterMinimapUpdate and C:RegisterMinimapUpdate("cartographer",miniUpdate)) then
  if C.OnReassess then C:OnReassess(miniUpdate) end
end
local function ev(e)
  if e == "PLAYER_LOGIN" then CG:DB(); CG:Apply()
  elseif e == "TAXIMAP_OPENED" then if CG:RecordTaxi() > 0 then CG:ResetGraph(); CG:Changed() end
  elseif e == "ZONE_CHANGED_NEW_AREA" then CG:Changed()
  elseif e == "PLAYER_REGEN_DISABLED" then if CG.filterPanel then CG.filterPanel:Hide() end end
end
for _, e in ipairs({ "PLAYER_LOGIN", "TAXIMAP_OPENED", "ZONE_CHANGED_NEW_AREA", "PLAYER_REGEN_DISABLED" }) do C:On(e, ev) end
