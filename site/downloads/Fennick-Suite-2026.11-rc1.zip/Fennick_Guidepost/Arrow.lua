if not Fennick_GUIDE_ENGINE then return end   -- P1-1: Core.lua refused to load (Beast Core too old)
-- The waypoint arrow belongs to Fennick's Beast Core. Leveling asks for it as module "leveling";
-- the request only goes through while Leveling owns focus (C:Owner()).
local E = Fennick_GUIDE_ENGINE
local C = Fennick_BEAST
E.arrow = C.arrow
E.ArrowMode = function() local m, u = C:ArrowMode(); return m, u end
function E:ResetWaypoint() C:ResetWaypoint() end
function E:ArrowForget() C:ArrowForget() end
function E:ClearStrayWaypoints() return C:ClearStrayWaypoints() end
function E:ApplyArrow(urgent) C:ApplyArrow(urgent) end
function E:SetWaypoint(s, label, force, urgent) return C:SetWaypointFor("leveling", s, label, force, urgent) end
function E:ClearArrow() return C:ClearArrowFor("leveling") end
function E:CheckWaypoint(s)
  if self.disabled or self.escapeActive then return end
  local t = self:TargetPoint(s); if t then C:CheckWaypointFor("leveling", t, (s.logPoint and s.logPoint.label) or s.npc or s.mob or "") end
end
