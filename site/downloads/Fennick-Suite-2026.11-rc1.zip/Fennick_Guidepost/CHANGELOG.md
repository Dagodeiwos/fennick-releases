# Fennick's Guidepost: changelog

All notable changes, newest first. Dates are month and year only.

## 4.7.0 (October 2026)
- Needs Fennick's Beast Core 1.8 for the reward pick.
- The separate loadout setting is gone (setup page, settings button, picker and chat prompts). Your role from Beast Core now decides both the stats and the weapon types for the quest reward pick. The setup page and the settings button show the role and open the Beast Core settings; `/fennick lvl role` does the same.
- A loadout you had picked by hand becomes your role in Beast Core when your class has exactly one option for it (for example "1H + shield tank" on a Warrior becomes Melee Tank). Where it could mean more than one option (a caster Priest could be Holy or Shadow), the role stays Automatic. A role you already set is kept.

## 4.6.0 (October 2026)
- Works best with Fennick's Beast Core 1.7 (older Core versions keep the previous behaviour).
- The quest reward pick follows your role from Beast Core, including spell power for your focus school and bonus healing, not just weapon types. The line names the role it used, for example "Reward: Pick Ember Wand (for Fire Magic DPS (detected))".
- No loadout chosen still means no reward pick. A loadout you picked by hand keeps its own stat focus unless you also set a role in Beast Core settings; your loadout always decides which weapon types fit.

## 4.5.4 (October 2026)
- Quest mob checks work with Forever 1.60.1's obfuscated creature IDs (only the NPC ID is read).
- Forever 1.60.1 note: nameplates now have a shorter vertical range, so mobs far above or below you get no nameplate and are not seen until you are closer (no error; I don't change nameplate settings).

## 4.5.3 (October 2026)
- /fennick report includes the current step number (number only) when Guidepost has the focus.
- /fennick lvl help (or /fennick guide help) prints a few lines of help.

## 4.5.2 (October 2026)
- Current and next steps show as pins on Fennick's Cartographer when installed. More translations filled in.

## 4.5.1 (October 2026)
- Hunting loops use your own Fennick's Trailmarks finds when that optional add-on is installed and has at least 3 finds for the hunt. Otherwise nothing changes.

## 4.5.0 (October 2026)
- Questie is no longer needed for anything. The guide uses Blizzard's own quest log, quest tracking and map by default, with my built-in route data.
- New setting "Use Questie data when installed (optional)", off by default. All Questie use goes through one adapter that checks Questie is loaded and has the expected functions; if Questie is missing, changes or errors, the guide quietly switches back to the Blizzard default for the session.
- No Questie code or data is included in the add-on.

## 4.4.2 (October 2026)
- New in-game icon (window header, AddOns list). Cosmetic only.

## 4.4.1 (October 2026)
- The sleeping-bag reminder moved to Rest (one notification); Guidepost no longer shows its own line.

## 4.4.0 (October 2026)
- The PvP escape alert and the quest-step-done sound are now Beast Core sound cues, each with its own toggle (Settings → Sounds), all off by default. An old upgrade step no longer switches off Sounds for the whole suite. Background opacity and the minimap button are set only in Beast Core (/beast); Reset settings no longer touches them. One-line summary in setup. Profession hints unchanged (on by default, only for professions you trained or picked).

## 4.3.1 (October 2026)
- Renamed from the Fennick Leveling Guide to Fennick's Guidepost (display name, titles, Settings, setup, minimap tooltip, bindings). Folder `Fennick_Guidepost`, saved variables `Fennick_GuidepostDB`/`Fennick_GuidepostProfiles` (fresh data). Module key and slash commands unchanged. New icon.

## 4.3.0 (October 2026)
- Multi-language: machine-translated text (labelled in Settings and setup) for German, French, Spanish, Italian, Portuguese (BR), Russian, Korean and Chinese (Simplified/Traditional); English text, fonts and slash commands unchanged; names from the game client by ID. Step notes translated; hearth, inn bind and buying hints no longer depend on English text.

## 4.2.0 (October 2026)
- Progress keyed by stable step IDs (reloads, regenerated data and inserted steps no longer shift your place or skips), bounded saved tables, protected init, coalesced events, one rule for showing the window, settings duplicated in Core removed, hub index built out of combat, kills-to-level counts rested XP, unknown race uses your faction's route, reward pick waits for item data, item and spell IDs instead of English names.

## Earlier versions (as the Fennick Leveling Guide)

### 4.1.0
- **Re-pathing**: when bonuses (rested, food, bag, perks) put you ahead of the route, low-value steps drop out. +1 level: gap-fill grinds and extra hunting. +1.5: optional quests worth under 60% of the leg's XP per minute, or grey at turn-in. Hardcore needs 0.5 more. PvP trims contested-zone quests first. Below +0.5 everything comes back. Never trimmed: class quests, chain steps and anything a later quest needs, big turn-ins, chain-end (gear) quests, quests in your log, and steps you went Back to. Focus shows one line; `/fennick why` lists what was skipped and why. No next-zone jumps.
- **Boost prompts** (one line, no sound, never used for you): XP food before kill-heavy hunts when Well Fed is missing or under 3 min and you carry XP food for your level; Archmagister's Wisdom before Undead hunts; the sleeping bag at breaks. Quiet in combat, with an elite or boss targeted, on turn-in/travel steps, while escaping and in Hardcore contested zones.
- Every bind and hearth step on every route is checked against friendly innkeepers (75 binds, all friendly); text-only binds now carry the innkeeper's real location.
- Needs Core 1.1 (text size offset replaces the old font setting).

### 4.0.0
- Now a module of Fennick's Beast Core: the arrow, look, setup, settings, minimap button and frame moving come from Core.
- Optional cloth donations: on a capital visit already on your route, if you carry 60 of the cloth, a donation step appears (otherwise it is skipped). Never farm cloth for it.
- Tooltip lines XP per kill and kills to level.

### 3.11.0
- Library books: the route picks up cheap books along the way (towns and low camps), and you hand them in at your librarian (Garion Wendell, Stormwind / Owen Thadd, Undercity) when the route passes the city. The hand-in only shows if you have the book.
- Forever-new quests: 33 placements (accept, hunt with patrol, turn-in) where the XP per added minute beats the route. Hardcore skips contested zones and elites.
- Every race start route is evaluated equally.

### 3.10.0
- Forever loot-started quests: when a hunt's mob can drop a quest-starting item, a short "along the way" line says so. When the item lands in your bags you get one chat line and a Focus tip to right-click it (no sound). The turn-in step only shows if you actually got the quest.
- Added this build: Elmpaw's Head (Elwynn), Harvesting the Harvesters (Westfall), Baron Marinous (Darkshore). All three are solo for every class and in every ruleset. Elite or group drops are never routed.
-

### 3.9.0
- NPCs and mobs are matched by creature ID, so steps work on non-English clients.
- No missed-quest decisions until the quest log has loaded (status line "Retrieving quest log..."); re-checked after every loading screen.
- A failed escort or timed quest gets a step: abandon and take it again from the quest giver.
- Forever quest variants: only with strong evidence (none merged so far), and only when your quest log shows the same title and objectives. Setting: "Match Forever quest variants" (on).
- Hardcore: escort/timed quests are never auto-accepted (setting, on). Gold-cost quests are never auto-completed. `/fennick noauto` (target an NPC) adds or removes it from the don't-automate list; `/fennick noauto list`.
- Quest log full: one line telling you which quest to drop.
- Hearth steps complete with any hearth item (cast, then arrival at your bind location).
- If you remove the Fennick waypoint in TomTom, it stays off until the next step.
- Hardcore: one-line warning when a step is in a zone well above your level.
- `/fennick why`: what the current step is still waiting for, and which quest ID matched.
- `/fennick restore`: puts back Blizzard settings Fennick changed (instant quest text).
- Saved settings are checked at login; a broken part is reset on its own.

### 3.8.3
- '#completewith' background steps (e.g. Well Stones) no longer block the main step (cleanse the well). Use-item steps say 'Use <item>'.
- Buy steps complete on buying from the vendor or when bags hold the items. The text says why (mana drink, food, ammo).
- No sounds: TomTom waypoints are silent; own sounds only if you switch Sounds on.

### 3.8.2
- Hunt points checked against Questie Forever spawns; 135 off-target hunts re-pointed (incl. Wiry Swoop).
- Missed pickups: a short callback to the quest giver, or the quest's steps are skipped. Restored when you accept it.
- Skip/Back/jump rebuilds the arrow and patrol at once, also in combat.

### 3.8.1
- Fixed ADDON_ACTION_FORBIDDEN at login and on minimap left-click: the add-on no longer registers the combat log event, which this client forbids. Kill tracking and PvP hit detection use unit events instead. The on/off toggle no longer re-registers events. `/fennick debuglog` now shows the blocked function and what the add-on was doing.
- The focused view is the only view. The List view, its header button, setting and wizard page are gone; saved list choices move to focused. The list layout code is kept but switched off (E.FEATURE_LIST_VIEW = false).
- More room: width 400, padding 16, line spacing 4 (old saved defaults are updated), larger header line. Guidance lines wrap instead of being cut off, up to 3 lines; anything more is "(+n)" and in the hover tooltip. Watch-out items are kept first when space is short.

### 3.8
- PvP escape: the arrow switches to the escape route immediately, also in combat. The TomTom waypoint is swapped once, guarded, and the normal target comes back after combat; the built-in arrow switches immediately too.
- Patrol: one continuous loop with no point counter. The arrow first goes to the patrol point closest to you (on entering the step, after a reload, zone change, resurrect, branch/escape, or when you stray more than 2x the radius off the loop), then loops in the direction with the nearer next point. Loops are ordered at build as a shortest closed tour. The step completes only on its objectives.
- Focused view: only the current step, with live quest objectives, a thin separator and a Guidance section of up to 3 short lines (tips, plus Watch out items for HC/danger/escape, elites, contested zones). Hover the Guidance section for the full list.

### 3.7.1
- Patrols: the arrow moves to the next patrol point when you arrive within the Patrol arrival radius, once per arrival, and loops until your objectives are done. The step itself completes only on objectives. Points closer than 2x the radius are merged, and the patrol position survives reloads. `/fennick debug` logs each patrol arrival.
- Arrow: only one arrow is ever shown (TomTom or the built-in one). In combat an existing TomTom arrow stays as is; the built-in arrow is never shown on top of it. Leftover Fennick TomTom waypoints are removed on login.

### 3.7
- **Gear:** only the one-line quest reward pick is left. Vendor upgrade stops, weapon warnings, weapon-skill reminders and gear notes are gone.
- **Route data cleanup:**
  - Steps that could never show for your class are removed.
  - Turn-ins and objectives that came before their pickup are moved after it.
  - Duplicate pickups are removed.
  - Patrols are kept within 400 yd.
  - Quest and NPC steps use that quest's or NPC's real location where one is known. Otherwise the location shows as "approx.".
- **NPC checks:** vendor, trainer, flight, bank and stable steps now count only when you use the NPC named on the step.
- **Old settings:** settings from earlier versions are cleaned up when you log in.

### 3.5
- **Layout**: one constants table (`E.LAYOUT`) plus settings for window width, padding (14), step spacing (8), line spacing (3), font size. Every text line has an explicit width, its measured height, and the window resizes to fit. The header has its own padding and a divider line. The current step sits in a highlighted box. `/fennick layout` outlines every region in game so you can check spacing.
- **Interaction steps**: vendor, trainer, flight path, hearthstone, bank, stable, "talk to" and deathskip steps now say exactly what to do. They complete only after you do it: the merchant window is opened and closed, or the bought items are in your bags; the trainer window is closed or the spell is known; the flight map is opened; your bind location matches; and so on. Getting to the spot never completes them. Only plain "go to" steps with no NPC complete on arrival (within 15 yd).
- **Arrow**: every step you still need to do has a waypoint. If a step had no coordinates, it uses the nearest coordinate from the plan. Hunt steps use Questie spawn clusters when Questie is loaded, otherwise the plan's hotspots, as a 2-6 point patrol. The next patrol point comes up when you get within *Patrol arrival radius* (default 50 yd). The step itself still waits for your quest objectives. The waypoint is set again if TomTom drops it, after combat and after a zone change. If TomTom fails, the built-in arrow is used.

Suite-wide notes: https://github.com/Dagodeiwos/fennick-releases/blob/main/CHANGELOG.md
