local TR = (Fennick_BEAST and Fennick_BEAST.L) or setmetatable({ F = function(_, f, ...) local ok, s = pcall(string.format, f, ...); return ok and s or f end }, { __index = function(_, k) return k end })   -- l10n (Core C.L)
if not Fennick_GUIDE_ENGINE then return end   -- P1-1: Core.lua refused to load (Beast Core too old)
-- v3.9 safety layer (our own code): creature-ID matching, quest-log readiness gate, failed/timed quests,
-- Forever quest-ID variants (verified against the live quest log), Hardcore-safe automation, quest-log-full
-- hint, loading-screen re-validation, SavedVariables guards, API self-test, CVar restore, /fennick why.
local E = Fennick_GUIDE_ENGINE
local C = Fennick_BEAST

function E:StepKeyNow() if not self.db then return nil end; local _, s = self:Current(); return tostring(self.db.gi) .. ":" .. tostring(self:StepId(s) or self.db.step) end

-- ---------- 1. NPC / mob identity by creature ID (localization-proof), name only as fallback ----------
local function creatureId(unit)
  local g = UnitGUID and UnitGUID(unit); if not g then return end
  local kind, id = g:match("^(%a+)%-[^%-]+%-[^%-]+%-[^%-]+%-[^%-]+%-(%d+)")   -- 1.60.1: server/spawn fields are obfuscated; only the NPC ID (field 6) is read
  if kind == "Creature" or kind == "Vehicle" then return tonumber(id) end
end
E.CreatureId = function(_, unit) return creatureId(unit) end
-- true = this is the NPC, false = definitely another NPC, nil = can't tell (e.g. a non-English client with no ID)
function E:NpcIs(unit, name)
  if not name then return nil end
  name = name:gsub("^%+", "")
  local ids, id = self.NPCID and self.NPCID[name], creatureId(unit)
  if ids and id then for _, x in ipairs(ids) do if x == id then return true end end; return false end
  local who = UnitName and UnitName(unit); if not who then return nil end
  if who:lower() == name:lower() then return true end
  local loc = GetLocale and GetLocale() or "enUS"
  if loc ~= "enUS" and loc ~= "enGB" then return nil end
  return false
end

-- ---------- 2. quest-log readiness gate (no fixed timer) ----------
local function logCount()
  if C_QuestLog and C_QuestLog.GetNumQuestLogEntries then local a, b = C_QuestLog.GetNumQuestLogEntries(); return a or 0, b or a or 0 end
  if GetNumQuestLogEntries then local a, b = GetNumQuestLogEntries(); return a or 0, b or a or 0 end
  return 0, 0
end
function E:ArmLogGate(why)
  if FENNICK_SIM then return end
  self.questLogReady = false; self.logGate = { why = why, at = GetTime(), stable = 0 }
  self:Debug("quest log gate armed (" .. why .. "): no missed-quest decisions until the log has loaded")
end
function E:GateTick()
  local g = self.logGate; if not g then return end
  local n = logCount()
  if g.upd and n == g.n then g.stable = g.stable + 1 else g.stable = 0 end
  g.n = n
  local waited = GetTime() - g.at
  if (g.upd and g.stable >= 2 and waited >= 2) or waited >= 30 then
    self.logGate = nil; self.questLogReady = true
    self:Debug(string.format("quest log ready (%s, %d entries, %.0f s)", g.why, n, waited))
    if self.MissedCheck then pcall(self.MissedCheck, self) end
    if self.Refresh then self:Refresh() end
  end
end

-- ---------- 3. failed / timed / escort quests ----------
function E:QuestFailed(id)
  if C_QuestLog and C_QuestLog.IsFailed and C_QuestLog.IsFailed(id) then return true end
  local idx = GetQuestLogIndexByID and GetQuestLogIndexByID(id)
  if idx and idx > 0 and GetQuestLogTitle then local c = select(6, GetQuestLogTitle(idx)); if c == -1 then return true end end
  return false
end
function E:FailedCheck()
  local g, s = self:Current(); if not s or s.failq then return end
  self.db.failCb = self.db.failCb or {}
  local qs = {}; for _, q in ipairs(s.t or {}) do qs[#qs + 1] = q end; for _, c in ipairs(s.c or {}) do qs[#qs + 1] = c[1] end
  for _, q in ipairs(qs) do
    local live = self:LiveId(q)
    if self:QuestFailed(live) then
      local acc = self:AcceptStepFor(q)
      local cb = { failq = live, callback = true, npc = acc and acc.npc, z = acc and acc.z, x = acc and acc.x, y = acc and acc.y,
        n = TR:F("Quest failed: abandon %s and take it again%s.", self:QuestName(q), (acc and acc.npc and (TR:F(" from %s", acc.npc:gsub("^%+", ""))) or "")) }
      table.insert(g.steps, self.db.step, cb)
      self:Debug("quest " .. live .. " failed -> re-take step"); if self.Refresh then self:Refresh() end
      return true
    end
  end
end

-- ---------- 4. Forever quest-ID variants (build: strong evidence only; runtime: live log must match) ----------
local function logTitle(id)
  if C_QuestLog and C_QuestLog.GetTitleForQuestID then local t = C_QuestLog.GetTitleForQuestID(id); if t then return t end end
  if GetQuestLogIndexByID and GetQuestLogTitle then local i = GetQuestLogIndexByID(id); if i and i > 0 then return (GetQuestLogTitle(i)) end end
end
local function logObjectives(id)
  local out = {}
  local objs = C_QuestLog and C_QuestLog.GetQuestObjectives and C_QuestLog.GetQuestObjectives(id)
  if objs then for _, o in ipairs(objs) do out[#out + 1] = o.text end
  elseif GetQuestLogIndexByID and GetQuestLogLeaderBoard then
    local i = GetQuestLogIndexByID(id); if i and i > 0 then for n = 1, 10 do local t = GetQuestLogLeaderBoard(n, i); if not t then break end; out[#out + 1] = t end end
  end
  for k, t in ipairs(out) do out[k] = (t or ""):gsub(":%s*%d+%s*/%s*%d+", ""):gsub("%s+slain", ""):gsub("^%s+", ""):gsub("%s+$", ""):lower() end
  return out
end
function E:VariantVerified(p, v)
  local m = self.QMETA and self.QMETA[p]
  local why
  local title = logTitle(v)
  if not m or not m.t then why = TR:F("no metadata for %s", p)
  elseif not title then why = TR["not in the quest log"]
  elseif title:lower() ~= m.t:lower() then why = TR:F("title '%s' ~= '%s'", title, m.t)
  elseif m.o and #m.o > 0 then
    local live = logObjectives(v); local want = {}; for _, o in ipairs(m.o) do want[o] = true end
    if #live ~= #m.o then why = TR:F("objective count %s ~= %s", #live, #m.o)
    else for _, o in ipairs(live) do if not want[o] then why = TR:F("objective '%s' not expected", o); break end end end
  end
  if why then
    self.db.varRej = self.db.varRej or {}
    if self.db.varRej[v] ~= why then self.db.varRej[v] = why; self:Debug("variant " .. v .. " for " .. p .. " ignored: " .. why) end
    return false
  end
  return true
end
function E:LiveId(id)
  if not (self:O("variants") and self.VARIANTS and self.VARIANTS[id]) or self:OnQuest1(id) then return id end
  for _, v in ipairs(self.VARIANTS[id]) do
    if self:OnQuest1(v) and self:VariantVerified(id, v) then
      self.db.varSeen = self.db.varSeen or {}; self.db.varSeen[v] = id
      self.varMatch = self.varMatch or {}; if self.varMatch[id] ~= v then self.varMatch[id] = v; self:Debug("quest " .. id .. " matched by verified variant " .. v) end
      return v
    end
  end
  return id
end
-- "completed" history of a variant counts only if this character had that verified variant in its log
function E:VariantDone(id)
  if not (self:O("variants") and self.VARIANTS and self.VARIANTS[id]) then return false end
  for _, v in ipairs(self.VARIANTS[id]) do
    if self.db.varSeen and self.db.varSeen[v] == id and self:Done1(v) then return true end
  end
  return false
end

-- ---------- 5. automation guard: per-NPC list + Hardcore escort/timed + gold cost ----------
function E:NoAutoKey(unit)
  unit = unit or "npc"; local id = creatureId(unit); local n = UnitName and UnitName(unit)
  return id and (TR:F("id:%s", id)) or (n and (TR:F("name:%s", n:lower()))), n
end
function E:AutoBlocked(qid, unit)
  local k = self:NoAutoKey(unit)
  local list = self:O("noAuto") or {}
  if k and list[k] then return TR["on your don't-automate list"] end
  local m = qid and self.QMETA and self.QMETA[qid]
  if self.db.rules == "HC" and self:O("hcSafeAccept") and m and (m.esc or m.tm) then return m.esc and TR["escort quest (Hardcore): accept it yourself when ready"] or TR["timed quest (Hardcore): accept it yourself"] end
  return nil
end
function E:ToggleNoAuto()
  local k, n = self:NoAutoKey("target"); if not k then k, n = self:NoAutoKey("npc") end
  if not k then return self:Print(TR["target an NPC first"]) end
  self.db.opt.noAuto = self.db.opt.noAuto or {}
  if self.db.opt.noAuto[k] then self.db.opt.noAuto[k] = nil; self:Print(TR:F("%s: automation allowed again", (n or k)))
  else self.db.opt.noAuto[k] = n or k; self:Print(TR:F("%s: added to don't-automate (accept/turn-in/gossip by hand)", (n or k))) end
end

-- ---------- 6. quest log full ----------
function E:QuestLogFull()
  local _, n = logCount()
  local max = (C_QuestLog and C_QuestLog.GetMaxNumQuestsCanAccept and C_QuestLog.GetMaxNumQuestsCanAccept()) or MAX_QUESTLOG_QUESTS or 20
  return n >= max, n, max
end
local function logQuestIds()
  local ids = {}
  local total = logCount()
  for i = 1, total do
    local id
    if C_QuestLog and C_QuestLog.GetQuestIDForLogIndex then id = C_QuestLog.GetQuestIDForLogIndex(i)
    elseif GetQuestLogTitle then local _, _, _, hdr, _, _, _, qid = GetQuestLogTitle(i); if not hdr then id = qid end end
    if id and id > 0 then ids[#ids + 1] = id end
  end
  return ids
end
function E:DropSuggestion()
  local need = {}
  local g = self:Current()
  if g then for i = self.db.step, math.min(#g.steps, self.db.step + 25) do local s = g.steps[i]
    for _, q in ipairs(s.t or {}) do need[q] = true end; for _, c in ipairs(s.c or {}) do need[c[1]] = true end end end
  local best, bx
  for _, id in ipairs(logQuestIds()) do if not need[id] then local x = self.QXP and self.QXP[id] or 0; if not bx or x < bx then best, bx = id, x end end end
  return best
end

-- ---------- 7. loading screens, hearth ----------
E.HEARTH_SPELLS = { [8690] = true, [556] = true }   -- P2-20: Hearthstone, Astral Recall by spell ID only (any client language)
function E:IsHearthSpell(id)
  return (id and self.HEARTH_SPELLS[id]) and true or false   -- l10n fix: spell IDs only (no name matching)
end
function E:AtBindLocation()
  local b = GetBindLocation and GetBindLocation(); if not b then return false end; b = b:lower()
  for _, f in ipairs({ GetSubZoneText, GetMinimapZoneText, GetRealZoneText, GetZoneText }) do
    local z = f and f(); if z and z ~= "" and (z:lower() == b or z:lower():find(b, 1, true) or b:find(z:lower(), 1, true)) then return true end
  end
  return false
end

-- ---------- 10. SavedVariables guards ----------
E.SCHEMA = 3
local TABLES = { "opt", "pat", "met", "skipped", "missed", "cb", "blocked", "varSeen", "varRej", "failCb", "cvarOrig" }
function E:GuardDB(db)
  if type(db) ~= "table" then return end
  local fixed = {}
  for _, k in ipairs(TABLES) do if db[k] ~= nil and type(db[k]) ~= "table" then db[k] = nil; fixed[#fixed + 1] = k end end
  if type(db.pat) == "table" then for k, v in pairs(db.pat) do if type(v) ~= "table" or type(v.i) ~= "number" then db.pat[k] = nil; fixed[#fixed + 1] = TR:F("pat.%s", tostring(k)) end end end
  for _, k in ipairs({ "gi", "step" }) do if db[k] ~= nil and type(db[k]) ~= "number" then db[k] = nil; fixed[#fixed + 1] = k end end
  if db.opt and type(db.opt.minimap) ~= "table" then db.opt.minimap = nil end
  db.schema = self.SCHEMA
  if #fixed > 0 then self.guardFixed = fixed; if self.Debug then self:Debug("saved settings repaired: " .. table.concat(fixed, ", ")) end end
end

-- ---------- 11. bounded session state ----------
local adv = E.Advance
function E:Advance(...)
  local before = self.db and self.db.step
  local r = adv(self, ...)
  if self.db and self.db.step ~= before then self.killed = nil; self.arrowCleared = nil end
  return r
end
local sc = E.StepChanged
function E:StepChanged(...) self.killed = nil; self.arrowCleared = nil; return sc(self, ...) end

-- ---------- 12. API self-test ----------
E.API_NEEDED = { "C_QuestLog.IsQuestFlaggedCompleted", "C_QuestLog.IsOnQuest", "C_QuestLog.GetQuestObjectives", "C_QuestLog.IsComplete",
  "C_QuestLog.GetTitleForQuestID", "C_Map.GetBestMapForUnit", "C_Map.GetPlayerMapPosition", "C_Map.GetWorldPosFromMapPos",
  "GetItemCount", "UnitGUID", "GetQuestLogIndexByID", "GetQuestLogTitle", "GetQuestLogLeaderBoard", "GetBindLocation", "C_Timer.After" }
function E:ApiSelfTest()
  local miss = {}
  for _, path in ipairs(self.API_NEEDED) do
    local t = _G; for part in path:gmatch("[^%.]+") do t = type(t) == "table" and t[part] or nil end
    if type(t) ~= "function" then miss[#miss + 1] = path end
  end
  self.apiMissing = miss
  if #miss > 0 then self:Debug("API missing (fallbacks used): " .. table.concat(miss, ", ")) end
  return miss
end

-- ---------- 14. Blizzard settings we changed: remember + restore ----------
function E:RememberCVar(name)
  self.db.cvarOrig = self.db.cvarOrig or {}
  if self.db.cvarOrig[name] == nil and GetCVar then self.db.cvarOrig[name] = GetCVar(name) or "" end
end
function E:RestoreCVars()
  if self:InCombat() then return self:Print(TR["leave combat first"]) end
  local n = 0
  for k, v in pairs(self.db.cvarOrig or {}) do if SetCVar and pcall(SetCVar, k, v) then n = n + 1 end end
  self.db.cvarOrig = {}
  self:Print(n > 0 and (TR:F("restored %s Blizzard setting(s) to how they were before Fennick changed them", n)) or TR["no Blizzard settings were changed by Fennick"])
end

-- ---------- ideas: danger note, retrieving status, why ----------
-- Classic zone level ranges (uiMapID -> {min,max}); used for a one-line Hardcore danger note only.
E.ZLVL = { [1411]={1,10},[1412]={1,10},[1420]={1,10},[1426]={1,10},[1429]={1,10},[1438]={1,10},[1413]={10,25},[1421]={10,20},
  [1436]={10,20},[1432]={10,20},[1439]={10,20},[1442]={15,27},[1433]={15,25},[1431]={18,30},[1440]={18,30},[1424]={20,30},
  [1437]={20,30},[1441]={25,35},[1443]={30,40},[1417]={30,40},[1416]={30,40},[1434]={30,45},[1445]={35,45},[1418]={35,45},
  [1435]={35,45},[1444]={40,50},[1446]={40,50},[1425]={40,50},[1427]={43,50},[1447]={45,55},[1419]={45,55},[1449]={48,55},
  [1448]={48,55},[1428]={50,58},[1422]={51,58},[1423]={53,60},[1452]={55,60},[1451]={55,60} }
function E:ExtraWatch(s)
  local out = {}
  if s and s.z and self.db.rules == "HC" and self.ZLVL[s.z] then
    local lv = UnitLevel and UnitLevel("player") or 1; local r = self.ZLVL[s.z]
    if r[1] > lv + 2 then out[#out + 1] = TR:F("Zone level %d-%d (you are %d)", r[1], r[2], lv) end
  end
  return out
end
function E:ExtraTips(s)
  local out = {}
  if not self.questLogReady and self.logGate then out[#out + 1] = TR["Retrieving quest log..."] end
  if s and s.a then
    local missing = false; for _, q in ipairs(s.a) do if self:QuestAvailable(q) and not self:OnQuest1(self:LiveId(q)) and not self:Done1(q) then missing = true end end
    local full, n, max = self:QuestLogFull()
    if missing and full then local d = self:DropSuggestion(); out[#out + 1] = string.format("Quest log full (%d/%d)%s", n, max, d and (TR:F(": drop %s", self:QuestName(d))) or "") end
  end
  return out
end
function E:Why()
  local g, s = self:Current(); if not s then return { TR["no current step"] } end
  local L = { TR:F("step %d/%d of %s: %s", self.db.step, #g.steps, g.name, (self:StepText(s) or ""):gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")) }
  if not self.questLogReady then L[#L + 1] = TR["quest log: still loading (no missed-quest decisions yet)"] end
  local function q(id)
    local live = self:LiveId(id)
    return id .. (live ~= id and (TR:F(" (matched variant %s)", live)) or "") .. " " .. self:QuestName(id), live
  end
  for _, id in ipairs(s.a or {}) do local t, live = q(id); L[#L + 1] = TR:F("accept %s: %s", t, (self:OnQuest1(live) and TR["in log"] or self:Done1(id) and TR["already done"] or not self:QuestAvailable(id) and TR["not available to you"] or TR["NOT accepted"])) end
  for _, id in ipairs(s.t or {}) do local t = q(id); L[#L + 1] = TR:F("turn in %s: %s", t, (self:Done1(id) and TR["done"] or TR["NOT turned in"])) end
  for _, c in ipairs(s.c or {}) do local t, live = q(c[1])
    local st = self:Done1(c[1]) and TR["quest done"] or not self:OnQuest1(live) and TR["quest NOT in log"] or self:QuestFailed(live) and TR["quest FAILED"] or self:QuestComplete(live) and TR["quest complete"] or TR:F("objective %s not finished", c[2])
    L[#L + 1] = TR:F("objective %s: %s", t, st) end
  if s.cwid then local t = self:CwTarget(s); L[#L + 1] = TR:F("along the way: also done when its main step is done (%s)", (t and (self:StepDone(t) and TR["main step done"] or TR["main step not done"]) or TR["main step not on your route"])) end
  if s.act then local ad = self.ActDone and self:ActDone(s); L[#L + 1] = TR:F("interaction %s%s: %s", s.act, (s.npc and (TR:F(" with %s", s.npc:gsub("^%+", ""))) or ""), (ad and "done" or TR["NOT done"])) end
  if s.failq then L[#L + 1] = TR:F("failed quest %s: %s", s.failq, (self:QuestFailed(s.failq) and TR["still failed"] or TR["ok"])) end
  if self.arrowCleared then L[#L + 1] = TR["arrow: you removed the waypoint in TomTom (comes back on the next step)"] end
  if self.apiMissing and #self.apiMissing > 0 then L[#L + 1] = TR:F("API fallbacks: %s", table.concat(self.apiMissing, ", ")) end
  L[#L + 1] = TR:F("result: %s", (self:StepDone(s) and TR["step is done (will advance)"] or TR["step is NOT done"]))
  return L
end

-- ---------- events ----------
local f = CreateFrame("Frame")
E:Events(f, { "QUEST_LOG_UPDATE", "PLAYER_ENTERING_WORLD" })
f:SetScript("OnEvent", function(_, ev)
  if not E.db then return end
  if ev == "QUEST_LOG_UPDATE" then if E.logGate then E.logGate.upd = true end; return end
  if ev == "PLAYER_ENTERING_WORLD" then
    E:ArmLogGate("loading screen")
    E:Safe("loading screen", function() if E.ResetWaypoint then E:ResetWaypoint() end; if E.PatrolReenter then E:PatrolReenter("loading screen") end; if E.Refresh then E:Refresh() end end)
  end
end)
table.insert(E.initHooks, function()
  E:ApiSelfTest()
  if TomTom and TomTom.RemoveWaypoint and hooksecurefunc then
    hooksecurefunc(TomTom, "RemoveWaypoint", function(_, wp)
      if E.ownRemove or C.ownRemove or not wp then return end
      local _, uid = E.ArrowMode(); if wp == uid then E.arrowCleared = E:StepKeyNow(); E:ArrowForget(); E:Debug("you removed the Fennick waypoint in TomTom: not re-adding it until the step changes") end
    end)
  end
end)
C_Timer.NewTicker(1, function()
  if E.disabled or not E.db then return end
  E:GateTick()
  if E.questLogReady then pcall(E.FailedCheck, E) end
end)
