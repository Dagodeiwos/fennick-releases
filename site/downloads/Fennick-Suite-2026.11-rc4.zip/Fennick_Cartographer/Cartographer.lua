local TR = (Fennick_BEAST and Fennick_BEAST.L) or setmetatable({ F = function(_, f, ...) local ok, s = pcall(string.format, f, ...); return ok and s or f end }, { __index = function(_, k) return k end })   -- l10n (Core C.L)
if not (Fennick_BEAST and (Fennick_BEAST.API or 1) >= 3) then return end   -- file-top guard
-- Fennick's Cartographer: state, filters, saved pins, pin sources and the travel graph. Original code; no map libraries.
-- Source priority: Fennick (Cartographer's own data, user pins, Trailmarks, other Fennick modules) first, Blizzard second,
-- other add-ons third. Every outside call is existence-checked and pcall-guarded; a source that errors is off for the session.
local C = Fennick_BEAST
local CG = { sources = {}, pushed = {}, failed = {}, version = 0 }
Fennick_CARTOGRAPHER = CG
-- filter categories (world map and minimap keep separate settings)
CG.CATS = { "qavail", "qturnin", "qobj", "flight", "ship", "zeppelin", "portal", "inn", "vendor", "trainer", "ore", "herb", "chest", "user", "target" }
CG.CAT_LABEL = { qavail = TR["Quest givers (available)"], qturnin = TR["Quest turn-ins (complete)"], qobj = TR["Quest objectives"],
  flight = TR["Flight masters"], ship = TR["Ships"], zeppelin = TR["Zeppelins"], portal = TR["Portals and trams"], inn = TR["Innkeepers"],
  vendor = TR["Vendors"], trainer = TR["Trainers"], ore = TR["Ore"], herb = TR["Herbs"], chest = TR["Chests"], user = TR["My pins"], target = TR["Fennick waypoint"] }
CG.CAT_ICON = { qavail = "quest", qturnin = "quest", qobj = "quest", flight = "flight", ship = "ship", zeppelin = "zeppelin", portal = "portal",
  inn = "user", vendor = "user", trainer = "user", ore = "ore", herb = "herb", chest = "chest", user = "user", target = "logo_cartographer" }
local MAPDEF = { world = { scale = 1, hideDone = true, hideLow = true, all = true }, mini = { scale = 1, hideDone = true, hideLow = true, all = true, dist = 400 } }
CG.DEF = { enabled = true, mapKey = true, width = 900, height = 620, alpha = 0.92, scale = 1, locked = false, fadeMove = true, routes = true,
  routeFlight = true, routeShip = true, routeZeppelin = true, routeTram = true, explored = true, party = true, coords = true,
  miniOn = true, miniShape = "square", miniSize = 0, miniZoomWheel = true, miniGather = false, miniCoords = true }
-- saved data: Fennick_CartographerDB (account: user pins, account-wide filters, known flight points per character)
--             Fennick_CartographerCharDB (this character: options and filters)
local function deep(d) if type(d) ~= "table" then return d end; local t = {}; for k, v in pairs(d) do t[k] = deep(v) end; return t end
function CG:DB()
  Fennick_CartographerDB = type(Fennick_CartographerDB) == "table" and Fennick_CartographerDB or {}
  local a = Fennick_CartographerDB
  Fennick_CartographerCharDB = type(Fennick_CartographerCharDB) == "table" and Fennick_CartographerCharDB or {}
  local c = Fennick_CartographerCharDB
  if not self.migrated then self.migrated = true; self:Migrate(a, c) end
  for _, k in ipairs({ "pins", "filters", "taxi" }) do if type(a[k]) ~= "table" then a[k] = {} end end
  for _, k in ipairs({ "opt", "filters" }) do if type(c[k]) ~= "table" then c[k] = {} end end
  return a, c
end
-- saved-data schema (v1): corrupt values are replaced (type checks above); bad pin rows are dropped once per session
CG.DBV = 1
function CG:Migrate(a, c)
  if type(a.pins) == "table" then
    local keep = {}
    for _, p in ipairs(a.pins) do
      if type(p) == "table" and type(p.map) == "number" and type(p.x) == "number" and type(p.y) == "number" then
        if type(p.name) ~= "string" then p.name = TR["Pin"] end
        if p.note ~= nil and type(p.note) ~= "string" then p.note = nil end
        keep[#keep + 1] = p
      end
    end
    a.pins = keep
  end
  -- future versions: if (a.v or 0) < 2 then ... end
  a.v = self.DBV; c.v = self.DBV
end
function CG:IsActive() return self:O("enabled") == true end
function CG:O(k) local _, c = self:DB(); local v = c.opt[k]; if v == nil then return self.DEF[k] end; return v end
function CG:SetO(k, v) local _, c = self:DB(); c.opt[k] = v; self:Changed() end
-- many changes in one frame (e.g. several ApplyArrow calls) cause one redraw
function CG:Changed()
  self.version = self.version + 1
  if self.batching then return end
  if not (C_Timer and C_Timer.After) then if self.Redraw then pcall(self.Redraw, self) end; return end
  self.batching = true
  C_Timer.After(0, function() CG.batching = nil; if CG.Redraw then pcall(CG.Redraw, CG) end end)
end
-- filters: per character, or account-wide when the character chose that
function CG:AccountWide() local _, c = self:DB(); return c.accountWide == true end
function CG:SetAccountWide(on)
  local a, c = self:DB(); on = on and true or false
  if on and not next(a.filters) then a.filters = deep(c.filters) end   -- first switch copies this character's choice
  c.accountWide = on; self:Changed()
end
function CG:Filters(which)
  local a, c = self:DB(); local root = self:AccountWide() and a.filters or c.filters
  local f = root[which]; if type(f) ~= "table" then f = deep(MAPDEF[which] or MAPDEF.world); f.show = {}; root[which] = f end
  f.show = f.show or {}; for k, v in pairs(MAPDEF[which] or {}) do if f[k] == nil then f[k] = v end end
  return f
end
function CG:CatRaw(which, cat)
  local v = self:Filters(which).show[cat]
  if v == nil then
    if cat:find("^tm_") then local t = self:TMCat(cat:sub(4)); v = (t == nil) or (t.on ~= false) else v = true end
  end
  return v and true or false
end
function CG:CatOn(which, cat) return self:Filters(which).all ~= false and self:CatRaw(which, cat) end
function CG:SetCat(which, cat, on) self:Filters(which).show[cat] = on and true or false; self:Changed() end
function CG:ShowAll(which, on) local f = self:Filters(which); f.all = on and true or false; if on then for k in pairs(f.show) do f.show[k] = true end end; self:Changed() end
function CG:SetMapOpt(which, k, v) self:Filters(which)[k] = v; self:Changed() end
-- Trailmarks filter entries (its 47: six point types plus every specific ore and herb), read through its API only
function CG:TMApi() local T = _G.Fennick_TRAILMARKS; local A = type(T) == "table" and type(T.API) == "table" and T.API; return A or nil end
function CG:TMCats()
  if self.failed.trailmarks then return {} end
  local A = self:TMApi(); if not (A and type(A.Categories) == "function") then return {} end
  local ok, t = pcall(A.Categories); if ok and type(t) == "table" then return t end
  self.failed.trailmarks = true; return {}
end
function CG:TMCat(key) for _, e in ipairs(self:TMCats()) do if e.key == key then return e end end end
function CG:FilterEntries()
  local t = {}
  for _, k in ipairs(self.CATS) do t[#t + 1] = { key = k, label = self.CAT_LABEL[k], icon = self:Icon(self.CAT_ICON[k], 16) } end
  for _, e in ipairs(self:TMCats()) do t[#t + 1] = { key = "tm_" .. e.key, label = TR:F("Trailmarks: %s", e.label or ""), icon = e.icon, parent = e.parent and ("tm_" .. e.parent) } end
  return t
end
-- user pins: { map, x, y (0-1), name, note, icon key }; account-wide so every character sees them
function CG:AddPin(map, x, y, name, note, icon)
  if type(map) ~= "number" or type(x) ~= "number" or type(y) ~= "number" or x < 0 or x > 1 or y < 0 or y > 1 then return nil end
  name = (type(name) == "string" and name ~= "") and name:sub(1, 60) or TR["My pin"]
  local a = self:DB(); local p = { map = map, x = x, y = y, name = name, note = type(note) == "string" and note:sub(1, 200) or "", icon = self:IconKnown(icon) and icon or "user", t = time and time() or 0 }
  a.pins[#a.pins + 1] = p; self:Changed(); return #a.pins
end
function CG:EditPin(i, name, note, icon)
  local p = self:DB().pins[i]; if not p then return false end
  if type(name) == "string" and name ~= "" then p.name = name:sub(1, 60) end
  if type(note) == "string" then p.note = note:sub(1, 200) end
  if icon and self:IconKnown(icon) then p.icon = icon end
  self:Changed(); return true
end
function CG:DeletePin(i) local a = self:DB(); if not a.pins[i] then return false end; table.remove(a.pins, i); self:Changed(); return true end
function CG:Pins(map) local t = {}; for i, p in ipairs(self:DB().pins) do if p.map == map then t[#t + 1] = { i = i, p = p } end end; return t end
local function esc(s) return (tostring(s or ""):gsub("|", "/"):gsub("[\r\n]", " ")) end
-- share box text (copy only, no import): zone, x, y, name, note
function CG:ShareText()
  local out = {}
  for _, p in ipairs(self:DB().pins) do out[#out + 1] = string.format("%s | %.1f | %.1f | %s | %s", esc(self:ZoneName(p.map)), p.x * 100, p.y * 100, esc(p.name), esc(p.note)) end
  return table.concat(out, "\n"), #out
end
function CG:ZoneName(map)
  if not (map and C_Map and C_Map.GetMapInfo) then return TR["Unknown zone"] end
  local ok, i = pcall(C_Map.GetMapInfo, map); return (ok and type(i) == "table" and i.name) or TR["Unknown zone"]
end
-- pushed pins (Trailmarks' Cartographer adapter contract): SetSourcePins(source, list) / ClearSourcePins(source)
function CG:SetSourcePins(source, list) if type(source) == "string" and type(list) == "table" then self.pushed[source] = list; self.version = self.version + 1 end end
function CG:ClearSourcePins(source) self.pushed[source] = nil; self.version = self.version + 1 end
-- pin sources: rank 1 Fennick, 2 Blizzard, 3 other add-ons. fn(map) -> { { cat, name, x, y (0-1), note, icon, done, level } }
function CG:RegisterSource(key, rank, fn)
  if type(key) ~= "string" or type(fn) ~= "function" then return false end
  self.sources[key] = { rank = tonumber(rank) or 3, fn = fn }; return true
end
local TMKIND = { ore = "ore", herb = "herb", chest = "chest", mob = "qobj", object = "qobj", npc = "qavail" }
local function trailmarks(map)
  local A = CG:TMApi(); if not A then return {} end
  local out = {}
  local ok, list = pcall(A.DrawList, map)
  if not ok or type(list) ~= "table" then list = {} end
  for _, e in ipairs(list) do
    local sub = e.sub
    out[#out + 1] = { cat = TMKIND[e.kind] or "qobj", tm = e.kind, sub = sub, name = e.name, x = e.x, y = e.y, area = e.area, diameter = e.diameter, opacity = e.opacity, shade = e.shade, seen = e.seen, last = e.last, tip = e.tip,
      iconPath = e.icon or (A.PinFor and select(2, pcall(A.PinFor, e.kind, e.name, 32))) }
  end
  return out
end
local function own(map)
  local out = {}; local fac = UnitFactionGroup and UnitFactionGroup("player"); fac = fac and fac:sub(1, 1)
  for _, n in ipairs(CG.NODES or {}) do if n.z == map and (n.f == "N" or n.f == fac) then
    out[#out + 1] = { cat = "flight", name = n.n, x = n.x / 100, y = n.y / 100, note = CG:KnowsTaxi(n.id) and TR["Flight point (known)"] or TR["Flight point (not learned)"], dim = not CG:KnowsTaxi(n.id) } end end
  for _, l in ipairs(CG.LINKS or {}) do if l.f == "N" or l.f == fac then
    for _, e in ipairs({ l.a, l.b }) do if e[1] == map then
      out[#out + 1] = { cat = (l.k == "tram" and "portal") or l.k, name = l.n, x = e[2] / 100, y = e[3] / 100, note = l.v and TR["Dock"] or TR["Dock (approximate)"] } end end end end
  for _, r in ipairs(CG:Pins(map)) do local p = r.p; out[#out + 1] = { cat = "user", name = p.name, note = p.note, x = p.x, y = p.y, icon = p.icon, pin = r.i } end
  local w = C.Waypoint and C:Waypoint()
  if w and w.z == map then out[#out + 1] = { cat = "target", name = w.label or TR["Fennick waypoint"], x = w.x / 100, y = w.y / 100, icon = "logo_cartographer" } end
  return out
end
local function blizzard(map)
  local out = {}
  if C_TaxiMap and C_TaxiMap.GetTaxiNodesForMap then
    local ok, nodes = pcall(C_TaxiMap.GetTaxiNodesForMap, map)
    if ok and type(nodes) == "table" then for _, n in ipairs(nodes) do if n.position and n.name then
      out[#out + 1] = { cat = "flight", name = (n.name:gsub(",.*$", "")), x = n.position.x, y = n.position.y } end end end
  end
  return out
end
CG:RegisterSource("cartographer", 1, own)
CG:RegisterSource("trailmarks", 1, trailmarks)
CG:RegisterSource("fennick", 1, function(map) return C.MapPinsFor and C:MapPinsFor(map) or {} end)
CG:RegisterSource("blizzard", 2, blizzard)
-- the aggregate-tooltip entry for any drawn pin (Core C:MapTip): Trailmarks supplies its own (counts, sub labels,
-- merged-area names, last seen); every other pin is its name, note (flight/dock state, user note) and icon
function CG:TipEntry(e)
  if e.tip then return e.tip end
  return { kind = e.cat or "other", name = e.name, note = e.note, seen = 1, icon = self:IconFor(e, 16) }
end
-- one list for a map, filtered for "world" or "mini"; duplicates (same category within 1% of the map; names are never compared) keep the best-ranked source
function CG:Collect(map, which)
  local keys = {}; for k in pairs(self.sources) do keys[#keys + 1] = k end
  table.sort(keys, function(a, b) local ra, rb = self.sources[a].rank, self.sources[b].rank; if ra ~= rb then return ra < rb end; return a < b end)
  local f = self:Filters(which); local lvl = UnitLevel and UnitLevel("player") or 1; local out, cells = {}, {}
  for _, k in ipairs(keys) do if not self.failed[k] then
    local ok, list = pcall(self.sources[k].fn, map)
    if not ok then self.failed[k] = true; if C.Debug then C:Debug("cartographer source off: " .. k) end
    elseif type(list) == "table" then
      for _, p in ipairs(list) do
        local cat = p.cat; local show = cat and self:CatOn(which, cat)
        if show and p.tm then show = self:CatOn(which, "tm_" .. p.tm) and (not p.sub or self:CatOn(which, "tm_" .. p.sub)) end
        if show and f.hideDone and p.done then show = false end
        if show and f.hideLow and p.level and lvl - p.level >= 10 then show = false end
        if show and type(p.x) == "number" and type(p.y) == "number" and p.x >= 0 and p.x <= 1 and p.y >= 0 and p.y <= 1 then
          local ix, iy = math.floor(p.x * 100), math.floor(p.y * 100)
          local group = p.tm and (cat .. ":" .. p.tm .. ":" .. tostring(p.name) .. ":" .. tostring(p.area == true)) or cat
          local grid = cells[group]; if not grid then grid = {}; cells[group] = grid end
          local dup = false
          for dx = -1, 1 do
            for dy = -1, 1 do
              local bucket = grid[(ix + dx) * 103 + iy + dy]
              if bucket then for _, q in ipairs(bucket) do
                if math.abs(q.x-p.x) < 0.01 and math.abs(q.y-p.y) < 0.01 then dup = true; break end
              end end
              if dup then break end
            end
            if dup then break end
          end
          if not dup then
            local key = ix * 103 + iy
            local bucket = grid[key]; if not bucket then bucket = {}; grid[key] = bucket end
            bucket[#bucket+1] = p
            local copy = {}; for field, value in pairs(p) do copy[field] = value end
            copy.src = k; out[#out+1] = copy
          end
        end
        if #out >= 800 then return out end
      end
    end
  end end
  return out
end
function CG:Search(list, text)
  if type(text) ~= "string" or text == "" then return list end
  local q = text:lower(); local t = {}
  for _, p in ipairs(list) do if (p.name or ""):lower():find(q, 1, true) or (p.note or ""):lower():find(q, 1, true) then t[#t + 1] = p end end
  return t
end
-- known flight points: recorded per character by flight node ID when a flight master's map is open (the game's own
-- C_TaxiMap node list; IDs are internal only and never shown, nothing is matched by name)
function CG:CharKey() return (UnitGUID and UnitGUID("player")) or ((UnitName and UnitName("player") or "?") .. "-" .. (GetRealmName and GetRealmName() or "?")) end
local CONTINENTS = { 1414, 1415 }
function CG:RecordTaxi()
  if not (C_TaxiMap and C_TaxiMap.GetAllTaxiNodes) then return 0 end
  local a = self:DB(); local k = self:CharKey(); a.taxi[k] = a.taxi[k] or {}; local n = 0
  local maps = { C_Map and C_Map.GetBestMapForUnit and C_Map.GetBestMapForUnit("player") }
  for _, m in ipairs(CONTINENTS) do maps[#maps + 1] = m end
  for _, m in ipairs(maps) do
    local ok, list = pcall(C_TaxiMap.GetAllTaxiNodes, m)
    if ok and type(list) == "table" then for _, t in ipairs(list) do
      local st = t.state; local reach = (Enum and Enum.FlightPathState and (st == Enum.FlightPathState.Current or st == Enum.FlightPathState.Reachable)) or st == 0 or st == 1
      if t.nodeID and reach and not a.taxi[k][t.nodeID] then a.taxi[k][t.nodeID] = true; n = n + 1 end end end
  end
  return n
end
function CG:TaxiRecorded() local t = self:DB().taxi[self:CharKey()]; return t ~= nil and next(t) ~= nil end
function CG:KnowsTaxi(id) local t = self:DB().taxi[self:CharKey()]; if not t or not next(t) then return true end; return t[id] == true end
-- travel graph: flight paths (datamine), ships/zeppelins/tram, and ground legs on the same continent
CG.FLY, CG.WALK, CG.MOUNT = 30, 7.0, 11.2   -- yd/s; flight and mount speed are estimates (not in the datamine)
function CG:WorldPos(map, x, y, static)
  if C.MapWorldPosition then return C:MapWorldPosition(map,x,y,static) end
  if not (C_Map and C_Map.GetWorldPosFromMapPos and CreateVector2D) then return nil end
  local ok, c, v = pcall(C_Map.GetWorldPosFromMapPos, map, CreateVector2D(x, y))
  if ok and c and v then return c, v.x, v.y end
end
function CG:Graph()
  if self.graph then return self.graph end
  local fac = UnitFactionGroup and UnitFactionGroup("player"); fac = fac and fac:sub(1, 1)
  local V, E = {}, {}
  local function add(p) V[#V + 1] = p; E[#V] = {}; return #V end
  local function edge(a, b, s, kind, name) E[a][#E[a] + 1] = { b, s, kind, name } end
  local node = {}
  for i, n in ipairs(self.NODES or {}) do if (n.f == "N" or n.f == fac) and self:KnowsTaxi(n.id) then node[i] = add({ c = n.c, wx = n.wx, wy = n.wy, name = n.n, z = n.z, x = n.x, y = n.y, flight = true }) end end
  for _, t in ipairs(self.TAXI or {}) do local a, b = node[t[1]], node[t[2]]
    if a and b then edge(a, b, t[3] / self.FLY, "flight"); edge(b, a, t[3] / self.FLY, "flight") end end
  for _, l in ipairs(self.LINKS or {}) do if l.f == "N" or l.f == fac then
    local a = add({ c = l.a[4], wx = l.a[5], wy = l.a[6], name = l.n, z = l.a[1], x = l.a[2], y = l.a[3] })
    local b = add({ c = l.b[4], wx = l.b[5], wy = l.b[6], name = l.n, z = l.b[1], x = l.b[2], y = l.b[3] })
    edge(a, b, l.s, l.k, l.n); edge(b, a, l.s, l.k, l.n) end end
  self.graph = { V = V, E = E }; return self.graph
end
function CG:ResetGraph() self.graph = nil end
-- shortest trip from (map,x,y) to (map,x,y), 0-1 coordinates. Returns legs { kind, name, to, seconds } and total seconds.
function CG:Route(fm, fx, fy, tm, tx, ty)
  local c1, x1, y1 = self:WorldPos(fm, fx, fy); local c2, x2, y2 = self:WorldPos(tm, tx, ty)
  if not (c1 and c2) then return nil end
  local G = self:Graph(); local V = G.V; local n = #V; local S, T = n + 1, n + 2
  local pos = {}; for i, v in ipairs(V) do pos[i] = v end
  pos[S] = { c = c1, wx = x1, wy = y1, name = TR["You"] }; pos[T] = { c = c2, wx = x2, wy = y2, name = TR["Destination"], z = tm, x = tx * 100, y = ty * 100 }
  local speed = (UnitLevel and (UnitLevel("player") or 1) >= 40) and self.MOUNT or self.WALK
  local function ground(a, b) local p, q = pos[a], pos[b]; if p.c ~= q.c then return nil end; return math.sqrt((p.wx - q.wx) ^ 2 + (p.wy - q.wy) ^ 2) / speed end
  local dist, prev, via, done = { [S] = 0 }, {}, {}, {}
  for _ = 1, n + 2 do
    local u, best = nil, math.huge
    for i = 1, n + 2 do if not done[i] and dist[i] and dist[i] < best then u, best = i, dist[i] end end
    if not u or u == T then break end
    done[u] = true
    local function relax(v, s, kind, name) if s and (not dist[v] or best + s < dist[v]) then dist[v] = best + s; prev[v] = u; via[v] = { kind, name } end end
    if u <= n then for _, e in ipairs(G.E[u]) do relax(e[1], e[2], e[3], e[4]) end end
    for v = 1, n do if v ~= u then relax(v, ground(u, v), "walk") end end
    relax(T, ground(u, T), "walk")
  end
  if not dist[T] then return nil end
  local legs, v = {}, T
  while prev[v] do table.insert(legs, 1, { kind = via[v][1], name = via[v][2], to = pos[v].name, seconds = dist[v] - dist[prev[v]], z = pos[v].z, x = pos[v].x, y = pos[v].y }); v = prev[v] end
  -- drop legs under 5 s; merge walk legs that only hop between nearby points
  local out = {}
  for _, l in ipairs(legs) do local last = out[#out]
    if l.kind == "walk" and l.seconds < 5 and #legs > 1 then
    else
    if last and last.kind == l.kind and l.kind ~= "flight" and l.kind == "walk" then last.to, last.seconds, last.z, last.x, last.y = l.to, last.seconds + l.seconds, l.z, l.x, l.y
    elseif last and last.kind == "flight" and l.kind == "flight" then last.to, last.seconds, last.z, last.x, last.y = l.to, last.seconds + l.seconds, l.z, l.x, l.y
    else out[#out + 1] = l end end end
  return out, dist[T]
end
local function mins(s) return math.max(1, math.floor((s or 0) / 60 + 0.5)) end
function CG:RouteLines(legs)
  local t = {}
  for _, l in ipairs(legs or {}) do
    if l.kind == "flight" then t[#t + 1] = TR:F("Fly to %s (about %d min)", l.to, mins(l.seconds))
    elseif l.kind == "ship" then t[#t + 1] = TR:F("Take the ship %s (about %d min)", l.name or "", mins(l.seconds))
    elseif l.kind == "zeppelin" then t[#t + 1] = TR:F("Take the zeppelin %s (about %d min)", l.name or "", mins(l.seconds))
    elseif l.kind == "tram" then t[#t + 1] = TR:F("Take the tram (about %d min)", mins(l.seconds))
    else t[#t + 1] = TR:F("Travel to %s (about %d min)", l.to, mins(l.seconds)) end
  end
  if not self:TaxiRecorded() then t[#t + 1] = TR["Open any flight master once so only your known flight points are used."] end
  return t
end
