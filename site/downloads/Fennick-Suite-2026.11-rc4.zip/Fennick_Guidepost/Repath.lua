local TR = (Fennick_BEAST and Fennick_BEAST.L) or setmetatable({ F = function(_, f, ...) local ok, s = pcall(string.format, f, ...); return ok and s or f end }, { __index = function(_, k) return k end })   -- l10n (Core C.L)
if not Fennick_GUIDE_ENGINE then return end   -- P1-1: Core.lua refused to load (Beast Core too old)
-- v4.1 dynamic re-pathing: when bonuses put you ahead of the route's planned level, low-value steps are skipped.
-- Build-time tags (Data.lua): s.pl planned level; E.TQ[quest] = {questLevel, questXP, minutes, bandXPperMin, plannedLevel, contested}
-- only for quests that are NOT critical (class quests, chain prerequisites and breadcrumbs, big turn-ins, chain-end
-- (gear) quests, any quest on a step with travel/bind/train/buy/use/Forever elements); s.tg gap-fill/hub, s.th extra hunting.
-- Runtime rules (ahead = your level incl. progress - planned level):
--   >= 1.0  gap-fill grinds and extra hunting are skipped
--   >= 1.5  trimmable quests worth < 60% of the band's XP per minute (travel included) or grey at turn-in are skipped
--   Hardcore: every threshold +0.5; trimming only removes steps, so routing never gets riskier.
--   below 0.5 ahead everything comes back. Quests in your log, and steps you went Back to, are never trimmed.
local E = Fennick_GUIDE_ENGINE
E.REPATH = { gap = 1.0, side = 1.5, restore = 0.5, hc = 0.5, value = 0.6 }
function E.GreyLevel(pl) if pl <= 5 then return 0 elseif pl < 40 then return pl - math.floor(pl / 10) - 5 else return pl - math.floor(pl / 5) - 1 end end
function E.QuestXPAt(xp, ql, pl) local d = pl - ql; if d <= 5 then return xp end; local f = ({ [6] = 0.8, [7] = 0.6, [8] = 0.4, [9] = 0.2 })[math.floor(d)] or 0.1; return xp * f end
function E:LevelNow() local l = UnitLevel and UnitLevel("player") or 1; local x = UnitXP and UnitXP("player") or 0; local m = UnitXPMax and UnitXPMax("player") or 0; return l + (m > 0 and x / m or 0) end
local function st(self)
  local db = self.db
  if type(db.trim) ~= "table" or db.trimRules ~= db.rules then
    db.trim = {}
    db.trimRules = db.rules
  end
  if type(db.keep) ~= "table" then db.keep = {} end
  return db.trim, db.keep
end
local function extra(self) return (self.db and self.db.rules == "HC") and self.REPATH.hc or 0 end
-- Explicit content metadata includes prerequisite quests in the same category.
-- Unknown categories never imply forced eligibility.
function E:IsForcedContent(categories)
  if type(categories) == "string" then return self:ContentMode(categories) == "force" end
  if type(categories) == "table" then
    for _, category in ipairs(categories) do
      if self:ContentMode(category) == "force" then return true end
    end
  end
  return false
end
-- one quest: trimmed? returns reason or nil
function E:QuestTrim(q, levelNow)
  local t = self.TQ and self.TQ[q]; if not t or not self:O("repath") or not self.db then return end
  local trim, keep = st(self)
  if (self.ChainUnlocks and self.ChainUnlocks[q]) or self:OnQuest1(q) or self:Done1(q) or keep[q] or self:IsForcedContent(self.QuestContent and self.QuestContent[q]) then trim[q] = nil; return end
  if type(t[1]) ~= "number" or not (t[1] > 0) or type(t[5]) ~= "number" or not (t[5] > 0) then trim[q] = nil; return end
  local pl = levelNow or self:LevelNow()
  local ahead = pl - t[5]
  if ahead < self.REPATH.restore then trim[q] = nil; return end
  local need = self.REPATH.side + extra(self)
  local why
  if ahead >= need then
    if (t[1] or 0) <= self.GreyLevel(math.floor(pl)) then why = TR["grey at turn-in"]
    elseif type(t[2]) == "number" and t[2] > 0 and type(t[3]) == "number" and t[3] > 0 and type(t[4]) == "number" and t[4] > 0 and self.QuestXPAt(t[2], t[1], pl) / math.max(0.5, t[3]) < self.REPATH.value * t[4] then why = TR["low XP for the time"] end
  end
  if why then trim[q] = why; return why end
  return trim[q]       -- hysteresis: stays skipped until you fall below 0.5 ahead
end
local function skey(s) if not s._rk then s._rk = (s.id or "") .. "|" .. tostring(s.mob or "") .. "|" .. tostring(s.pl or "") .. "|" .. tostring(s.x or "") end; return s._rk end
E.RepathKey = skey
-- gap-fill / extra-hunting steps
function E:StepTrim(s, levelNow)
  if not (s and (s.tg or s.th)) or not self:O("repath") or not self.db then return end
  local trim, keep = st(self); local k = skey(s); if keep[k] or self:IsForcedContent(s.content) then trim[k] = nil; return end
  if type(s.pl) ~= "number" or s.pl <= 0 then return end
  local ahead = (levelNow or self:LevelNow()) - s.pl
  if ahead < self.REPATH.restore then trim[k] = nil; return end
  if ahead >= self.REPATH.gap + extra(self) then trim[k] = s.tg and "gap-fill" or TR["extra hunting"]; return trim[k] end
  return trim[k]
end
local baseAvail = E.QuestAvailable
function E:QuestAvailable(id) if self:QuestTrim(id) then return false end; return baseAvail(self, id) end
local baseDone = E.StepDone
function E:StepDone(s)
  if s and s.manualDone then return true end
  if s and (s.tg or s.th) and self:StepTrim(s) then return true end
  return baseDone(self, s)
end
-- Back: whatever you return to is yours to do (never trimmed again)
local baseBack = E.Back
function E:Back(...)
  if self.AtLevelCap and self:AtLevelCap() then return baseBack(self, ...) end
  local r = baseBack(self, ...)
  local _, s = self:Current()
  if s and self.db then local _, keep = st(self); keep[skey(s)] = true
    for _, k in ipairs({ "a", "t" }) do for _, q in ipairs(s[k] or {}) do keep[q] = true end end
    for _, c in ipairs(s.c or {}) do keep[c[1]] = true end end
  return r
end
-- trimmed steps still ahead in this guide (for the one-line message and /fennick why)
function E:TrimmedAhead()
  if self.AtLevelCap and self:AtLevelCap() then return {} end
  if not self.db or not self:O("repath") then return {} end
  local g = self.chain and self.chain[self.db.gi]; if not g then return {} end
  local out = {}
  local levelNow = self:LevelNow()
  for i = self.db.step or 1, #g.steps do
    local s = g.steps[i]; local why
    if s.tg or s.th then why = self:StepTrim(s, levelNow)
    else
      local qs, all = {}, true
      for _, k in ipairs({ "a", "t" }) do for _, q in ipairs(s[k] or {}) do qs[#qs + 1] = q end end
      for _, c in ipairs(s.c or {}) do qs[#qs + 1] = c[1] end
      if #qs > 0 and not (s.fly or s.home or s.hs or s.tr or s.act or s.buy or s.use) then
        for _, q in ipairs(qs) do local w = self:QuestTrim(q, levelNow); if not w then all = false; break end; why = why or w end
        if not all then why = nil end
      end
    end
    if why then out[#out + 1] = { s = s, why = why } end
  end
  return out
end
function E:RepathLine()
  if not self:O("repath") then return end
  local _, s = self:Current(); if not s then return end
  local list = self:TrimmedAhead(); if #list == 0 then return end
  local ahead = self:LevelNow() - (s.pl or self:LevelNow())
  if ahead < self.REPATH.gap then return end
  local step = list[1].s
  local q = step.a and step.a[1] or step.t and step.t[1] or step.c and step.c[1][1]
  if q then return TR:F("Passing %s: %s. /fennick why lists planned skips.", self:QuestName(q), list[1].why) end
  return TR:F("Ahead of the route (+%.1f levels): skipping %d low-value step%s; class, gear and chain quests kept.", ahead, #list, #list == 1 and "" or "s")
end
local baseTips = E.ExtraTips
function E:ExtraTips(s)
  local out = baseTips and baseTips(self, s) or {}
  local ok, l = pcall(self.RepathLine, self); if ok and l then table.insert(out, 1, l) end
  return out
end
local baseWhy = E.Why
function E:Why()
  local t = baseWhy and baseWhy(self) or {}
  local ok, list = pcall(self.TrimmedAhead, self)
  if ok and #list > 0 then
    t[#t + 1] = TR:F("Skipped because you are ahead of the route (%s):", #list)
    for i = 1, math.min(10, #list) do local x = list[i]; local s = x.s
      local q = (s.t and s.t[1]) or (s.a and s.a[1]) or (s.c and s.c[1] and s.c[1][1])
      t[#t + 1] = "  " .. (q and self:QuestName(q) or (s.mob and (TR:F("hunting %s", s.mob:gsub("^%+", ""))) or TR["level gap fill"])) .. " - " .. x.why end
  end
  return t
end
