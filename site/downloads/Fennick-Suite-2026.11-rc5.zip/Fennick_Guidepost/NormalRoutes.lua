-- Normal leveling opportunities. Quest history drives side trips; the ordinary step
-- remains the saved resume anchor while an optional step is displayed.
local E=Fennick_GUIDE_ENGINE
if not E then return end
local function point(z,x,y,npc,n) return {z=z,x=x,y=y,npc=npc,n=n} end
local barrens=point(1413,46.4,73.9,"Burned-Out Remains")
local westfall=point(1436,37.4,50.7,"Burned-Out Remains")
local litter=point(1442,40.8,52.6,"Pocket Litter","Take the trail near 50.9, 52.3 to the camp above Sun Rock Retreat.")
local mound=point(1442,39.6,49.8,"Mound of Dirt","Climb above the camp and jump to the dirt on the ledge.")
local figurine=point(1432,49.4,12.9,"Carved Figurine","Look on the north face of the dam.")
local bag=point(1417,22.5,24.1,"Messenger Bag","Climb the wall from the overturned cart on the Hillsbrad side at 87.3, 49.6.")
local function bagChain(horde)
  return {
    {horde and 79007 or 79008,horde and barrens or westfall,horde and westfall or barrens},
    {79192,horde and westfall or point(1413,46.4,73.8,"Nailed Plank"),litter},
    {79980,litter,mound},{79974,mound,figurine},{79975,figurine,bag},
    {79976,bag,point(1417,22.5,24.1,"Hastily Rolled-Up Satchel","Open the satchel below the hanging bag.")},
  }
end
local coastal=point(1436,25.9,47.8,"Captain's Footlocker")
local barrel=point(1436,40.5,47.8,"Broken Barrel")
local jug=point(1436,40.6,17,"Old Jug")
local sanders={
  {136,point(1436,25.9,47.8,nil,"Hunt Westfall coastal murlocs for Captain Sander's Treasure Map, then use the map."),coastal},
  {138,coastal,barrel},{139,barrel,jug},{140,jug,point(1436,26,16.9,"Locked Chest")},
}
local horror={{95328,point(1420,9.4,59.9,nil,"Loot the quest starter from the level 13 Whispering Horror in the Shadowvale cellar."),point(1458,49.1,14.6,"Father Lankester")}}
local hair={{86614,point(1432,45.7,43.3,"Discarded Fishing Toolbox","Accept the quest from the submerged toolbox. If it is absent, check 48.1,39.7 and the wreckage around 49–51,53–54."),point(1432,40.3,39.3,"Khara Deepwater")}}
local trips={
  bag={label="Cozy Sleeping Bag",level=14,item=211527},
  treasure={label="Captain Sander's Hidden Treasure",level=10,steps=sanders},
  horror={label="Whispering Horror Residue",level=7,side="Horde",steps=horror},
  hairclip={label="Silver of the Waves",level=13,side="Alliance",steps=hair},
}
local order={"bag","treasure","horror","hairclip"}
local titles={[79007]="... and that note you found",[79008]="... and that note you found",[79192]="Stepping Stones",
 [79980]="Scramble",[79974]="Wet Job",[79975]="Eagle's Fist",[79976]="This Must Be The Place",
 [86614]="Silver of the Waves",[95328]="Whispering Horror Residue"}
for _,row in ipairs(sanders) do titles[row[1]]=trips.treasure.label end
for q,p in pairs(E.NormalPickups or {}) do titles[q]=p[1] end
E:RegisterQuestNames(titles)
E.QuestContent=E.QuestContent or {}
for q,p in pairs(E.NormalPickups or {}) do
  if p[7]~="delivery" and p[7]~="hiddenQuest" then E.QuestContent[q]=E.QuestContent[q] or "dungeon" end
end
for _,q in ipairs({79007,79008,79192,79980,79974,79975,79976}) do E.QuestContent[q]="secret" end
for _,q in ipairs({136,138,139,140,95328,86614}) do E.QuestContent[q]="hiddenQuest" end
local function hiddenMode(self)
  local a,b=self:ContentMode("secret"),self:ContentMode("hiddenQuest")
  if a=="force" or b=="force" then return "force" end
  if a=="off" and b=="off" then return "off" end
  return "optimize"
end
local paths={Horde=bagChain(true),Alliance=bagChain(false)}
local function pending(self,key)
  local trip=trips[key]
  local faction=UnitFactionGroup("player")
  if not trip or self:ContentMode(key=="bag" and "secret" or "hiddenQuest")=="off" or self.db.rules~="Normal" or UnitLevel("player")<trip.level or (trip.side and trip.side~=faction)
      or (trip.item and GetItemCount and GetItemCount(trip.item,true)>0) then return end
  local rows=trip.steps or paths[faction]
  if not rows then return end
  local index=1
  for i,row in ipairs(rows) do
    if self.IsQuestDone(row[1]) then index=i+1
    elseif self.IsOnQuest(row[1]) then index=i end
  end
  local row=rows[index]
  if not row then return end
  local stage=self.IsOnQuest(row[1]) and "t" or "a"
  if row[1]==136 and stage=="a" and GetItemCount and GetItemCount(1357)>0 then
    return {normalTrip=key,gen=true,id="normal-treasure-map",a={136},fromBag=true,n="Use Captain Sander's Treasure Map in your bags to start the search."}
  end
  local p=row[stage=="t" and 3 or 2]
  return {normalTrip=key,gen=true,id="normal-"..key.."-"..stage..row[1],[stage]={row[1]},
    z=p.z,x=p.x,y=p.y,npc=p.npc,n=p.n}
end
local function pickupMode(self,p)
  if p[7]=="hiddenQuest" then return hiddenMode(self) end
  if p[7]=="delivery" then return "optimize" end
  return self:ContentMode("dungeon")
end
local restrictedRaces={
  [6365]={Orc=true,Troll=true},[6361]={Tauren=true},
  [6181]={Human=true},[6387]={Dwarf=true,Gnome=true},
}
local function pickupEligible(self,q,p,g)
  local _,class=UnitClass("player")
  if self.db.rules~="Normal" or pickupMode(self,p)=="off" or self.IsQuestDone(q) or self.IsOnQuest(q) or UnitLevel("player")<p[2] then return false end
  if restrictedRaces[q] and UnitRace and not restrictedRaces[q][select(2,UnitRace("player"))] then return false end
  if p[8]~="" and not ("/"..p[8].."/"):find("/"..class.."/",1,true) then return false end
  if p[7]=="delivery" then
    local future=false
    for i=self.db.step or 1,#g.steps do
      local npc=g.steps[i].npc
      if npc and npc:gsub("^%+","")==p[9] then future=true;break end
    end
    if not future then return false end
  end
  for _,pre in ipairs(p[10]) do if not self.IsQuestDone(pre) then return false end end
  return true
end
local function readyPoint(self,q,p)
  if p[11] and self.IsOnQuest(q) and self.QuestComplete and self:QuestComplete(q) and not self.IsQuestDone(q) then
    return {z=p[11][1],x=p[11][2],y=p[11][3],npc=p[9],t={q},normalTrip=q,gen=true,id="normal-handoff-"..q}
  end
end
local function pickup(self,g,q)
  for _,id in ipairs(self.NormalCandidates[g.sourceKey] or {}) do
    if id==q then
      local p=self.NormalPickups[q]
      local handoff=readyPoint(self,q,p)
      if handoff then return handoff end
      if pickupEligible(self,q,p,g) then
        return {a={q},id="normal-pickup-"..q,gen=true,normalTrip=q,z=p[3],x=p[4],y=p[5],npc=p[6],
                n="Pick up if offered. Skip to resume your route if the quest is unavailable."}
      end
    end
  end
end
local function zoneName(z)
  local info=C_Map and C_Map.GetMapInfo and C_Map.GetMapInfo(z)
  return info and info.name or ("map "..z)
end
local function nearby(a,b)
  if not a or not b or a.z~=b.z or not a.x or not b.x then return false end
  return (a.x-b.x)^2+((a.y-b.y)*2/3)^2<=4
end
function E:NormalTripTick(g,i)
  local current=g.steps[i]
  if not current then return end
  if not self.questLogReady then return end
  local mode=hiddenMode(self)
  if not self.db.bagIntroSeen and self:ContentMode("secret")=="optimize" and pending(self,"bag") then
    self.db.bagIntroSeen=true
    self:Print("Cozy Sleeping Bag is available. It gives a reusable experience bonus. The chain crosses continents. Use /fennick lvl secret bag to follow it now, or pick it up when the route passes the remains.")
  end
  local key=self.db.normalTrip
  local nextMain=current.normalTrip and g.steps[i+1] or current
  local bestScore=-1
  if not key and not self.db.pauseForcedTrips and self.db.rules=="Normal" and mode=="force" then
    for _,name in ipairs(order) do
      if self:ContentMode(name=="bag" and "secret" or "hiddenQuest")=="force" and not (self.db.tripDeferred and self.db.tripDeferred[name]) then
        local candidate=pending(self,name)
        if candidate then
          local score=(candidate.t and 100 or 0)+(nearby(nextMain,candidate) and 80 or 0)
              +(nextMain and nextMain.z==candidate.z and 40 or 0)+(name=="bag" and 20 or 0)
          if score>bestScore then bestScore,key=score,name end
        end
      end
    end
  end
  if self.db.rules=="Normal" and not self.db.normalTrip and not self.db.pauseForcedTrips and nextMain then
    for _,q in ipairs(self.NormalCandidates[g.sourceKey] or {}) do
      local p=self.NormalPickups[q]
      if pickupMode(self,p)~="off" and not (self.db.tripDeferred and self.db.tripDeferred[q]) and nearby(nextMain,readyPoint(self,q,p)) then
        key,bestScore=q,200
        break
      end
    end
  end
  if not self.db.normalTrip and bestScore<80 and not self.db.pauseForcedTrips and nextMain and self.db.rules=="Normal" and self:ContentMode("dungeon")=="force" then
    for _,q in ipairs(self.NormalCandidates[g.sourceKey] or {}) do
      local p=self.NormalPickups[q]
      if pickupMode(self,p)=="force" and nearby(nextMain,{z=p[3],x=p[4],y=p[5]}) and not (self.db.tripDeferred and self.db.tripDeferred[q]) and pickupEligible(self,q,p,g) then key=q;break end
    end
  end
  local row
  if type(key)=="number" then row=pickup(self,g,key)
  elseif key and mode~="off" then row=pending(self,key) end
  if current.normalTrip then
    if row and current.id==row.id then return end
    table.remove(g.steps,i)
  end
  if row then
    self.db.normalTrip=key
    if self.Unmiss then self:Unmiss(row.a and row.a[1] or row.t[1]) end
    table.insert(g.steps,i,row)
  elseif key then self.db.normalTrip=nil end
end
function E:ChooseTrip(key)
  if key=="stop" or key=="skip" then
    if key=="stop" then self.db.pauseForcedTrips=true end
    local _,s=self:Current()
    if s and s.normalTrip then
      self.db.tripDeferred=self.db.tripDeferred or {};self.db.tripDeferred[s.normalTrip]=true
    end
    self.db.normalTrip=nil;self:Advance();return
  end
  local q=tonumber(key)
  if q then
    local g=self:Current()
    if not g or not pickup(self,g,q) then self:Print("This pickup is unavailable on your current guide.");return end
    key=q
  end
  if q or (hiddenMode(self)~="off" and pending(self,key)) then
    self.db.pauseForcedTrips=nil
    self.db.normalTrip=key
    if self.db.tripDeferred then self.db.tripDeferred[key]=nil end
    self:Advance()
  else self:Print("Available Normal secret routes depend on faction, level and completion. Enable Secrets or Hidden quests in settings. Options: bag, treasure, horror, hairclip.") end
end
local curios={
    {1413,62.1,33.3,18,"Barrens speed set: check for Humar and Swiftmane on this pass. Two equipped pieces grant 5% movement speed in the Barrens and Stonetalon. Continue if the rares are absent."},
    {1413,59.6,8.3,16,"Takk the Leaper can drop the cloak for the Barrens speed set. Check the patrol while nearby."},
    {1437,36.6,36.7,30,"At night, look for the Nightveiled Rotheap along the river. Take Rotheap Innards to Rethiel at 56.4, 40.4 for Malignant Root.","Alliance"},
    {1416,62.3,42.6,25,"Strahnbrad Mystery starts from a Singed Note on Syndicate casters. Bring a mage to ignite both forge bellows at 59.8, 46.5. The area has level 34–36 enemies."},
  }
local dungeonSecrets={
  ["Shadowfang Keep"]="After Arugal, take the Black Tome from the table behind him. Use it at the Ambermill focus (Silverpine 63.4, 64.3) to prepare for Lyn the Ignored.",
  ["City of Dalaran"]="Bring a Dalaran Sewer Key and have one party member carry the Tome of Dalaran. After Atrexis, follow the sewer straight to the planked side room and use the tome on its purple rune.",
  ["Ruins of Lordaeron"]="For The Abandoned, approach the knight statue and clear three waves. For Viktor the Vile, activate the fireplace southwest of Lordamere Overlook and clear the waves.",
}
function E:NormalTips(g,s,all)
  local tips={}
  if self.db.rules~="Normal" or not s then return tips end
  if self:ContentMode("secret")~="off" and self:ContentMode("dungeon")~="off" and GetInstanceInfo then
    local name,kind=GetInstanceInfo()
    if kind=="party" and dungeonSecrets[name] then tips[#tips+1]=dungeonSecrets[name] end
  end
  if s.normalTrip then return {"Following "..(trips[s.normalTrip] and trips[s.normalTrip].label or self.NormalPickups[s.normalTrip][1])..". Use /fennick lvl secret stop to resume the main route."} end
  if hiddenMode(self)~="off" then
    for _,key in ipairs(order) do
      local row=pending(self,key)
      if row and row.fromBag then tips[#tips+1]=row.n.." /fennick lvl secret treasure"
      elseif row and (all or nearby(s,row)) then
        tips[#tips+1]=trips[key].label.." — "..(row.npc or row.n or "")..(" in %s (%.1f, %.1f). /fennick lvl secret "):format(zoneName(row.z),row.x,row.y)..key
      end
    end
  end
  if self:ContentMode("secret")~="off" then for _,c in ipairs(curios) do
    if UnitLevel("player")>=c[4] and (not c[6] or c[6]==UnitFactionGroup("player")) and nearby(s,{z=c[1],x=c[2],y=c[3]}) then tips[#tips+1]=c[5] end
  end end
  local mentioned={}
  for _,q in ipairs(self.NormalCandidates and self.NormalCandidates[g.sourceKey] or {}) do
    local p=self.NormalPickups[q]
    if p[7]~="hiddenQuest" and pickupEligible(self,q,p,g) and (all or nearby(s,{z=p[3],x=p[4],y=p[5]})) then
      local why=p[7]=="delivery" and ("later stop: "..p[9]) or ("prepares "..p[7])
      if self:ContentMode("secret")~="off" and dungeonSecrets[p[7]] and not mentioned[p[7]] then
        mentioned[p[7]]=true
        tips[#tips+1]=p[7]..": "..dungeonSecrets[p[7]]
      end
      tips[#tips+1]=("%s — %s in %s (%.1f, %.1f), %s. /fennick lvl secret %d"):format(p[1],p[6],zoneName(p[3]),p[4],p[5],why,q)
    end
  end
  return tips
end

-- Explain the actual offer being viewed, once per guide and quest per session.
local explained={}
function E:ExplainNormalOffer(q)
  if not q or self.db.rules~="Normal" then return end
  local g=self:Current()
  local decisions=g and self.NormalDecisions and self.NormalDecisions[g.sourceKey]
  local reason=decisions and decisions[q]
  if not reason then return end
  local key=g.sourceKey.."|"..q
  if explained[key] then return end
  local text
  if reason=="later" then
    for i=self.db.step or 1,#g.steps do
      for _,id in ipairs(g.steps[i].a or {}) do
        if id==q then
          if i>(self.db.step or 1) then text="Scheduled for a later pickup on this route." end
          break
        end
      end
      if text then break end
    end
  elseif reason=="repeatable" then text="Optional repeatable quest. The leveling route continues after this stop."
  elseif reason=="handoff" then text="Optional detour. This route has no later stop at its recorded turn-in."
  elseif reason=="objectives" then text="Optional quest. The remaining route does not cover every objective at a verified location." end
  if text then
    explained[key]=true
    self:Print((GetTitleText and GetTitleText() or self:QuestName(q))..": "..text)
  end
end
