local TR = (Fennick_BEAST and Fennick_BEAST.L) or setmetatable({ F = function(_, f, ...) local ok, s = pcall(string.format, f, ...); return ok and s or f end }, { __index = function(_, k) return k end })   -- l10n (Core C.L)
if not Fennick_GUIDE_ENGINE then return end   -- P1-1: Core.lua refused to load (Beast Core too old)
-- Guide window: header (addon, route, class, level, XP/h, ruleset button) with divider, the current step in a
-- highlighted box, a compact safety line (icon + tooltip) only when relevant, upcoming steps, notes,
-- progress bar, Back/Skip/Branch/Main. The focused view (the only user-facing view) shows the current step:
-- instruction, live quest objectives, a thin separator, then a "Guidance" section (tips + watch-out items)
-- of at most 3 wrapped lines. Focus is the only view.
-- Layout is computed top-down from one constants table. Every FontString gets an explicit width (so word wrap
-- and GetStringHeight are correct immediately, not on the next frame), line spacing, and its measured height;
-- the frame is resized to its content on every refresh.
local E = Fennick_GUIDE_ENGINE
local MAXSHOW = 10
local lastStep

local COLS = { normal = { accept = "|cff00ff00", ["do"] = "|cffffcc00", turnin = "|cff66ccff" },
  cb = { accept = "|cff3399ff", ["do"] = "|cffff9900", turnin = "|cffffffff" } }
function E:Col(k) return COLS[self:O("colorblind") and "cb" or "normal"][k] end

local zoneCache = {}
local function zoneName(z)
  if not z then return nil end
  if zoneCache[z] == nil then
    local info = C_Map and C_Map.GetMapInfo and C_Map.GetMapInfo(z); zoneCache[z] = info and info.name or false
  end
  return zoneCache[z] or nil
end
local function where(s)
  if not s.z then return "" end
  local zn = zoneName(s.z)
  return string.format("  |cff999999%s(%.0f, %.0f)%s|r", zn and (zn .. " ") or "", s.x, s.y, s.zf and TR[" approx."] or "")
end
local function qlist(ids) local t = {}; for _, q in ipairs(ids) do if E:QuestAvailable(q) then t[#t + 1] = E:QuestName(q) end end; return table.concat(t, ", ") end

-- One line: verb + target + location.
function E:StepText(s)
  local goal = self.locationGoals and self.locationGoals[s]
  if s.npc and goal and goal.c then
    if goal.c[1][1]==96604 and s.npc=="Brakk" then return TR["Sit at Brakk's campfire until you receive Boosted Rest for The Great Outdoors."] end
    return TR:F("Visit %s for %s", self:NpcName(s.npc), self:QuestName(goal.c[1][1]))
  end
  local t = self:StepText0(self:ActionView(s)); if t and s.cwid then t = TR:F("%s |cff999999(along the way)|r", t) end; return t
end
-- a plan note in the client's language (translation keyed by the English note), else the English note
function E:Note(n) if type(n) ~= "string" or self.EN_CLIENT then return n end; return self.L[n] end
-- display view of a step: NPC and mob names in the client's language (the step itself keeps the English plan names)
function E:Localized(s)
  if self.EN_CLIENT or type(s) ~= "table" then return s end
  return setmetatable({ npc = s.npc and self:NpcName(s.npc), mob = s.mob and self:NpcName(s.mob) }, { __index = s })
end
function E:StepText0(s)
  s = self:Localized(s)
  local parts, by = {}, s.npc and (s.t and TR:F(" to %s", s.npc) or TR:F(" from %s", s.npc)) or ""
  if s.t and qlist(s.t) ~= "" then parts[#parts + 1] = TR:F("%sTurn in|r %s", self:Col("turnin"), qlist(s.t)) end
  if s.a and qlist(s.a) ~= "" then parts[#parts + 1] = self:Col("accept") .. (#parts > 0 and "accept|r " or "Accept|r ") .. qlist(s.a) end
  if #parts > 0 then return table.concat(parts, "; ") .. by .. where(s) end
  if s.c then
    local seen, qs = {}, {}
    for _, c in ipairs(s.c) do if not seen[c[1]] then seen[c[1]] = 1; qs[#qs + 1] = self:QuestName(c[1]) end end
    local t = self:TargetPoint(s); local zn = t and C_Map and C_Map.GetMapInfo and C_Map.GetMapInfo(t.z); zn = zn and zn.name
    local around = zn and (TR:F(" around %s", zn)) or ""; local loop = t and t.loop
    return self:Col("do") .. (s.mob and TR:F("Hunt|r %s%s for ", s.mob:gsub("^%+", ""), around) or s.use and (TR:F("Use|r %s %sfor|r ", s.use, self:Col("do"))) or TR["Complete|r "]) .. table.concat(qs, ", ") .. (s.mob and "" or around) .. ((s.mob or loop) and "" or where(s))
  end
  local at = self:ActText(s); if at then return at .. where(s) end
  if s.tr then return TR:F("Train %s%s%s", (GetSpellInfo and GetSpellInfo(s.tr) or (TR:F("spell %s", s.tr))), (s.npc and (TR:F(" at %s", s.npc)) or ""), where(s)) end
  if s.home then return TR:F("Set your hearthstone%s in %s%s", (s.npc and (TR:F(" with %s", s.npc)) or ""), s.home, where(s)) end
  if s.fly then return TR:F("Fly to %s%s", s.fly, (s.npc and (" (" .. s.npc .. ")") or "")) end
  if s.hs then return TR["Use your hearthstone"] end
  if s.hub then return TR:F("Quest at %s (levels %s-%s)%s", (s.npc or "hub"), (s.lo or "?"), (s.hi or "?"), where(s)) end
  if s.lv then return TR:F("Grind to level %s%s%s", s.lv, (s.mob and (TR:F(" on %s", s.mob)) or ""), where(s)) end
  if s.mob then return TR:F("Hunt %s%s", s.mob, where(s)) end
  if s.npc then return TR:F("Visit %s%s", s.npc, where(s)) end
  return TR:F("Go to%s", (where(s) ~= "" and where(s) or TR[" the next waypoint"]))
end

-- notes that belong on the safety line instead of the body
local function isSafety(n) return n:find("^HARDCORE") or n:find("DANGER") or n:find("[Ss]afe road") or n:find("[Ee]scape") end
local function short(n, k) n = n:gsub("^HARDCORE DANGER:%s*", ""):gsub("^HARDCORE:%s*", ""); if #n > k then n = n:sub(1, k - 3) .. "..." end; return n end

-- Layout constants (pad / rowGap / lineSpacing / width are user settings; the rest are fixed ratios)
E.LAYOUT = { headerPad = 10, titleGap = 4, curPad = 10, safetyGap = 6, nextGap = 6, noteGap = 10,
  barH = 4, barGap = 10, btnH = 22, btnW = 70, btnGap = 6, iconW = 16, divider = 1,
  objGap = 5, sepMin = 6, sep = 1, guideHdrGap = 4, guideMax = 3 }
local function L(k) return E.LAYOUT[k] end
local function fs(parent, template, justify)
  local t = Fennick_BEAST:NewFS(parent, "OVERLAY", template or "GameFontHighlight"); t:SetJustifyH(justify or "LEFT"); t:SetJustifyV("TOP")
  t:SetWordWrap(true); if t.SetNonSpaceWrap then t:SetNonSpaceWrap(true) end
  return t
end

function E:InitUI()
  local f = CreateFrame("Frame", "Fennick_GuideFrame", UIParent, "BackdropTemplate")
  E.frame = f
  f:SetSize(self:O("width"), 200); f:SetPoint("RIGHT", UIParent, "RIGHT", -40, 60); f:SetMovable(true); f:EnableMouse(true); f:SetClampedToScreen(true)
  f:RegisterForDrag("LeftButton")
  f:SetScript("OnDragStart", function(self) if not E:O("lock") then self:StartMoving() end end)
  f:SetScript("OnDragStop", f.StopMovingOrSizing)
  -- header: tinted band + divider; text gets its own padding
  f.headerBg = f:CreateTexture(nil, "BORDER"); f.headerBg:SetColorTexture(0.15, 0.35, 0.6, 0.55)
  f.divider = f:CreateTexture(nil, "ARTWORK"); f.divider:SetColorTexture(1, 1, 1, 0.18)
  f.icon = f:CreateTexture(nil, "ARTWORK"); f.icon:SetSize(32, 32); f.icon:SetTexture("Interface\\AddOns\\Fennick_Guidepost\\Media\\Fennick_Guidepost")   -- UI-1 header icon
  f.title = fs(f, "GameFontNormal"); f.title:SetText(TR:F("%s's Guidepost", E.brand))
  f.sub = fs(f, "GameFontHighlightSmall")
  local rb = CreateFrame("Button", nil, f, "UIPanelButtonTemplate"); rb:SetSize(56, 20)
  rb:SetScript("OnClick", function() E:SetProfile("rules", E.db.rules == "HC" and "Normal" or "HC") end)
  rb:SetScript("OnEnter", function(self) GameTooltip:SetOwner(self, "ANCHOR_LEFT"); GameTooltip:AddLine(TR["Normal or Hardcore"]); GameTooltip:AddLine(TR["Click to cycle"], 0.6, 0.6, 0.6); GameTooltip:Show() end)
  rb:SetScript("OnLeave", function() GameTooltip:Hide() end)
  f.rulesBtn = rb; E.Skin:AddButton(rb, "guide")
  -- current step: subtle highlight box with inner padding
  f.curBg = f:CreateTexture(nil, "BACKGROUND", nil, 1); f.curBg:SetColorTexture(1, 1, 1, 0.07)
  f.curEdge = f:CreateTexture(nil, "ARTWORK"); f.curEdge:SetColorTexture(0.2, 0.7, 1, 0.9)
  f.lines = {}
  for i = 1, MAXSHOW do f.lines[i] = fs(f, i == 1 and "GameFontHighlight" or "GameFontDisableSmall") end
  -- compact safety line (icon + text) with a hover area covering it
  f.safetyIcon = f:CreateTexture(nil, "OVERLAY"); f.safetyIcon:SetTexture("Interface\\DialogFrame\\UI-Dialog-Icon-AlertNew")
  local sf = CreateFrame("Frame", nil, f); sf:EnableMouse(true); f.safety = sf
  sf.text = fs(f, "GameFontNormalSmall"); sf.text:SetTextColor(1, 0.55, 0.3)
  sf:SetScript("OnEnter", function(self) if type(self.full) ~= "table" then return end; GameTooltip:SetOwner(self, "ANCHOR_BOTTOMLEFT")
    for _, l in ipairs(self.full) do GameTooltip:AddLine(l, 1, 0.7, 0.4, true) end; GameTooltip:Show() end)
  sf:SetScript("OnLeave", function() GameTooltip:Hide() end)
  f.note = fs(f, "GameFontNormalSmall"); f.note:SetTextColor(0.85, 0.85, 0.6)
  -- focused mode: live objectives, separator, guidance (hover shows the full list)
  f.obj = fs(f, "GameFontHighlightSmall"); f.obj:SetTextColor(0.95, 0.95, 0.95)
  f.gsep = f:CreateTexture(nil, "ARTWORK"); f.gsep:SetColorTexture(1, 1, 1, 0.15); f.gsep:Hide()
  f.guideHdr = fs(f, "GameFontDisableSmall"); f.guideHdr:SetTextColor(0.6, 0.6, 0.6)
  f.guide = fs(f, "GameFontHighlight"); f.guide:SetTextColor(0.75, 0.8, 0.85)
  local gh = CreateFrame("Frame", nil, f); gh:EnableMouse(true); f.guideHover = gh
  gh:SetScript("OnEnter", function(self) if type(self.full) ~= "table" then return end; GameTooltip:SetOwner(self, "ANCHOR_BOTTOMLEFT")
    for _, l in ipairs(self.full) do GameTooltip:AddLine(l, 0.85, 0.85, 0.85, true) end; GameTooltip:Show() end)
  gh:SetScript("OnLeave", function() GameTooltip:Hide() end)
  f.escape = fs(f, "GameFontNormalLarge", "CENTER"); f.escape:SetPoint("BOTTOM", f, "TOP", 0, 4); f.escape:Hide()
  -- footer
  local function btn(txt, fn) local b = CreateFrame("Button", nil, f, "UIPanelButtonTemplate"); b:SetText(txt); b:SetScript("OnClick", fn); E.Skin:AddButton(b, "guide"); return b end
  f.footer = { btn(TR["Back"], function() E:Back() end), btn(TR["Skip"], function() E:Skip() end) }
  f.branchBtn = btn(TR["Branch"], function() E:TakeBranch() end); f.mainBtn = btn(TR["Main"], function() E:ReturnMain() end)
  f.branchBtn:Hide(); if not E.db.branch then f.mainBtn:Hide() end
  local bar = CreateFrame("StatusBar", "Fennick_ProgressBar", f); bar:SetMinMaxValues(0, 1); bar:SetStatusBarColor(0.2, 0.7, 1); f.bar = bar
  E.Skin:Add("guide", f); E.Skin:Add("progress", bar)
end

function E:ApplyLook()
  local f = self.frame; if not f then return end
  f:SetScale(self:O("scale")); self.Skin:Style(f)
  for _, k in ipairs({ "settings", "setup", "profs" }) do local x = self.Skin.frames[k]; if x then self.Skin:Style(x, math.max(0.85, self:O("alpha"))) end end
  if self:O("externalSkin") then return end
  local p = self.Skin.PRESETS[self:O("preset")] or self.Skin.PRESETS.default
  -- v4.1: Blizzard font objects (copied by Core, same face) with the shared text-size offset; the face never changes
  local C = Fennick_BEAST; C:RefreshFonts()
  local function fo(t, base) if t and t.SetFontObject then t:SetFontObject(C:FontObj(base)) end end
  for i, t in ipairs(f.lines) do fo(t, i == 1 and "GameFontHighlight" or "GameFontHighlightSmall") end
  C:TitleFS(f.title, "GameFontNormalLarge"); f.title:SetTextColor(p.title[1], p.title[2], p.title[3])
  fo(f.sub, "GameFontHighlightSmall"); fo(f.note, "GameFontHighlightSmall"); fo(f.safety.text, "GameFontHighlightSmall")
  fo(f.obj, "GameFontHighlightSmall"); fo(f.guide, "GameFontHighlight"); fo(f.guideHdr, "GameFontNormalSmall")   -- UI-1: guidance at body size
  local sc = p.sep or { 1, 1, 1, 0.15 }; f.gsep:SetColorTexture(sc[1], sc[2], sc[3], sc[4])
  -- UI-1 colours from the shared preset (teal header band, gold divider, focus card with amber accent, gold GUIDANCE label, cream text)
  local hb = p.header or { 0.15, 0.35, 0.6, 0.55 }; f.headerBg:SetColorTexture(hb[1], hb[2], hb[3], hb[4] or 1)
  f.headerBg:SetAlpha(self:O("preset") == "minimal" and 0 or 1)
  f.divider:SetColorTexture(sc[1], sc[2], sc[3], math.max(sc[4] or 0.18, 0.4))
  local cc = p.card or { 1, 1, 1, 0.07 }; f.curBg:SetColorTexture(cc[1], cc[2], cc[3], cc[4] or 1)
  local ac = p.accent or { 0.2, 0.7, 1 }; f.curEdge:SetColorTexture(ac[1], ac[2], ac[3], 1)
  local gh = p.guideHdr or { 0.6, 0.6, 0.6 }; f.guideHdr:SetTextColor(gh[1], gh[2], gh[3])
  if p.text then f.lines[1]:SetTextColor(p.text[1], p.text[2], p.text[3]); f.obj:SetTextColor(p.text[1], p.text[2], p.text[3]) end
  f.icon:SetShown(self:O("preset") ~= "minimal")
  if f.bar then self.Skin:StyleBar(f.bar) end
  if self.Refresh and self.chain then self:Refresh() end
end

-- place a FontString at (x, y) with explicit width; returns its height (0 and hidden when empty)
local function place(f, t, x, y, w)
  local txt = t:GetText()
  if not txt or txt == "" then t:Hide(); return 0 end
  t:ClearAllPoints(); t:SetWidth(w); t:SetPoint("TOPLEFT", f, "TOPLEFT", x, y)
  if t.SetSpacing then t:SetSpacing(E:O("lineSpacing")) end
  t:Show()
  return math.ceil(t:GetStringHeight() or 0)
end

-- Top-down layout; also used by the offline layout simulator. Returns the frame height.
function E:Layout()
  local f = self.frame
  local C = Fennick_BEAST; local W, PAD, GAP = C:Snap(self:O("width"), self.frame), C:Pad(self.frame), C:Snap(self:O("rowGap"), self.frame)
  local CW = W - 2 * PAD
  f:SetWidth(W)
  -- header
  local y = -L("headerPad")
  local rb = f.rulesBtn; rb:ClearAllPoints(); rb:SetPoint("TOPRIGHT", f, "TOPRIGHT", -PAD, y)
  local iconOn = f.icon and f.icon:IsShown(); local ix = iconOn and (32 + 8) or 0
  if iconOn then f.icon:ClearAllPoints(); f.icon:SetPoint("TOPLEFT", f, "TOPLEFT", PAD, y) end
  local tw = CW - rb:GetWidth() - 8 - ix
  y = y - place(f, f.title, PAD + ix, y, tw) - L("titleGap")
  y = y - place(f, f.sub, PAD + ix, y, tw)
  y = math.min(y, -L("headerPad") - rb:GetHeight(), iconOn and (-L("headerPad") - 32) or 0) - L("headerPad")
  f.headerBg:ClearAllPoints(); f.headerBg:SetPoint("TOPLEFT", f, "TOPLEFT", 4, -4); f.headerBg:SetPoint("BOTTOMRIGHT", f, "TOPRIGHT", -4, y)
  f.divider:ClearAllPoints(); f.divider:SetPoint("TOPLEFT", f, "TOPLEFT", 4, y); f.divider:SetPoint("BOTTOMRIGHT", f, "TOPRIGHT", -4, y - L("divider"))
  y = y - L("divider") - GAP
  -- current step box
  local cp = L("curPad"); local preset0 = self.Skin.PRESETS[self:O("preset")] or self.Skin.PRESETS.default
  local h = place(f, f.lines[1], PAD + cp, y - cp, CW - 2 * cp)
  local LY = {}; self.lastLayout = LY
  if h > 0 and f.obj:GetText() and f.obj:GetText() ~= "" then
    h = h + L("objGap"); local oh = place(f, f.obj, PAD + cp + 6, y - cp - h, CW - 2 * cp - 6); h = h + oh
    LY.objBottom = y - cp - h
  else f.obj:Hide() end
  if h > 0 then
    f.curBg:ClearAllPoints(); f.curBg:SetPoint("TOPLEFT", f, "TOPLEFT", PAD, y); f.curBg:SetPoint("BOTTOMRIGHT", f, "TOPRIGHT", -PAD, y - h - 2 * cp)
    local aw = Fennick_BEAST:Snap(preset0.accentW or 2, f, 1)   -- UI-1: amber 3 px accent bar
    f.curEdge:ClearAllPoints(); f.curEdge:SetPoint("TOPLEFT", f, "TOPLEFT", PAD, y); f.curEdge:SetPoint("BOTTOMRIGHT", f, "TOPLEFT", PAD + aw, y - h - 2 * cp)
    f.curBg:Show(); f.curEdge:Show(); y = y - h - 2 * cp
  else f.curBg:Hide(); f.curEdge:Hide() end
  -- safety line
  local st = f.safety.text
  if st:GetText() and st:GetText() ~= "" then
    y = y - L("safetyGap")
    local ih = L("iconW")
    f.safetyIcon:ClearAllPoints(); f.safetyIcon:SetSize(ih, ih); f.safetyIcon:SetPoint("TOPLEFT", f, "TOPLEFT", PAD, y); f.safetyIcon:Show()
    local sh = place(f, st, PAD + ih + 4, y, CW - ih - 4)
    local hh = math.max(sh, ih)
    f.safety:ClearAllPoints(); f.safety:SetPoint("TOPLEFT", f, "TOPLEFT", PAD, y); f.safety:SetPoint("BOTTOMRIGHT", f, "TOPRIGHT", -PAD, y - hh); f.safety:Show()
    y = y - hh
  else st:Hide(); f.safetyIcon:Hide(); f.safety:Hide() end
  -- focused mode: separator + guidance (gap from the style preset, never below sepMin)
  local preset = self.Skin.PRESETS[self:O("preset")] or self.Skin.PRESETS.default
  if f.guide:GetText() and f.guide:GetText() ~= "" then
    local sg = math.max(L("sepMin"), preset.sepGap or 0, GAP)
    y = y - sg; LY.sepTop = y; LY.sepGap = sg
    f.gsep:ClearAllPoints(); f.gsep:SetPoint("TOPLEFT", f, "TOPLEFT", PAD, y); f.gsep:SetPoint("BOTTOMRIGHT", f, "TOPRIGHT", -PAD, y - L("sep")); f.gsep:Show()
    y = y - L("sep") - sg; LY.sepBottom = y
    local top = y
    y = y - place(f, f.guideHdr, PAD, y, CW) - L("guideHdrGap")
    LY.guideTop = y
    y = y - place(f, f.guide, PAD, y, CW)
    f.guideHover:ClearAllPoints(); f.guideHover:SetPoint("TOPLEFT", f, "TOPLEFT", PAD, top); f.guideHover:SetPoint("BOTTOMRIGHT", f, "TOPRIGHT", -PAD, y); f.guideHover:Show()
  else f.gsep:Hide(); f.guideHdr:Hide(); f.guide:Hide(); f.guideHover:Hide() end
  -- upcoming steps
  local first = true
  for k = 2, MAXSHOW do
    if f.lines[k]:GetText() and f.lines[k]:GetText() ~= "" then
      y = y - (first and GAP or L("nextGap")); first = false
      y = y - place(f, f.lines[k], PAD, y, CW)
    else f.lines[k]:Hide() end
  end
  -- notes
  if f.note:GetText() and f.note:GetText() ~= "" then y = y - L("noteGap"); y = y - place(f, f.note, PAD, y, CW) else f.note:Hide() end
  -- progress bar + footer buttons
  y = y - L("barGap")
  f.bar:ClearAllPoints(); f.bar:SetPoint("TOPLEFT", f, "TOPLEFT", PAD, y); f.bar:SetPoint("BOTTOMRIGHT", f, "TOPRIGHT", -PAD, y - L("barH"))
  y = y - L("barH") - GAP
  local x = PAD
  for _, b in ipairs({ f.footer[1], f.footer[2], f.branchBtn, f.mainBtn }) do
    b:SetSize(L("btnW"), L("btnH")); b:ClearAllPoints(); b:SetPoint("TOPLEFT", f, "TOPLEFT", x, y)
    local bw = Fennick_BEAST.FitButton and Fennick_BEAST:FitButton(b, L("btnW")) or L("btnW")   -- l10n: self-sizing
    if b:IsShown() or b == f.footer[1] or b == f.footer[2] then x = x + bw + L("btnGap") end
  end
  y = y - L("btnH") - PAD
  f:SetHeight(-y)
  if self.layoutDebug then self:LayoutOverlay() end
  return -y
end

-- /fennick layout: outline every laid-out region in game (green = text, blue = boxes)
function E:LayoutOverlay()
  local f = self.frame
  f.dbg = f.dbg or {}
  local regs = { f.title, f.sub, f.lines[1], f.safety, f.note, f.bar, f.rulesBtn, f.curBg, f.footer[1], f.footer[2], f.obj, f.gsep, f.guideHdr, f.guide }
  for k = 2, MAXSHOW do regs[#regs + 1] = f.lines[k] end
  for i, r in ipairs(regs) do
    local o = f.dbg[i]
    if not o then o = CreateFrame("Frame", nil, f, "BackdropTemplate"); o:SetBackdrop({ edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 1 }); o:SetFrameLevel(f:GetFrameLevel() + 20); f.dbg[i] = o end
    o:ClearAllPoints(); o:SetAllPoints(r); o:SetBackdropBorderColor(r.GetText and 0.2 or 0.3, r.GetText and 1 or 0.5, r.GetText and 0.2 or 1, 0.9)
    o:SetShown(self.layoutDebug and r:IsShown() and true or false)
  end
end
function E:ToggleLayoutDebug()
  self.layoutDebug = not self.layoutDebug
  if self.frame then self:LayoutOverlay(); if self.layoutDebug then self:Layout() end end
  self:Print(TR:F("layout overlay %s", (self.layoutDebug and "ON" or TR["OFF"])))
end

-- Notes for a step position: info steps just before it + its own notes + reminders, split into body and
-- safety lines, de-duplicated. Profession-tagged notes only for this character's professions.
function E:NotesFor(g, step)
  local s, raw, i = g.steps[step], {}, step - 1
  local function ok(x) return not x.prof or self:HasProf(x.prof) end
  while i >= 1 and self:IsInfo(g.steps[i]) do if ok(g.steps[i]) then table.insert(raw, 1, g.steps[i].n) end; i = i - 1 end
  if s and ok(s) then if s.n then raw[#raw + 1] = s.n end; if s.n2 then raw[#raw + 1] = s.n2 end end
  if self.NormalTips then for _,tip in ipairs(self:NormalTips(g,s)) do raw[#raw+1]=tip end end
  if s and s.c and s.c[1][1]==825 and UnitLevel("player")<8 and not self.IsOnQuest(99048) and not self.IsQuestDone(99048) then
    raw[#raw+1]=TR["A Missing Hand opens at level 8. Collect the tools now. Guidepost checks the hut chain again on the next Razor Hill circuit."]
  end
  for _, fn in ipairs({ "Reminders", "ProfNotes" }) do local x = self[fn](self); if x ~= "" then raw[#raw + 1] = x end end
  local body, safety, seen = {}, {}, {}
  for _, n in ipairs(raw) do
    if n ~= "" and n ~= "Horde" and n ~= "Alliance" and not seen[n] then
      seen[n] = true
      if isSafety(n) then if self.db.rules ~= "PvE" or not n:find("^HARDCORE") then safety[#safety + 1] = n end else body[#body + 1] = n end
    end
  end
  if s and s.esc and self.db.rules == "PvP" then safety[#safety + 1] = TR:F("Escape route: %s", s.esc[1]) end
  return body, safety
end

-- live objectives of the step's quests ("Prairie Wolf Paw 3/7"), straight from the quest log
function E:ObjectiveText(s)
  if not (s.c and C_QuestLog and C_QuestLog.GetQuestObjectives) then return "" end
  local out = {}
  for _, c in ipairs(s.c) do
    if self:QuestAvailable(c[1]) then
      local o = C_QuestLog.GetQuestObjectives(c[1]); o = o and o[c[2]]
      if o then
        local txt = o.text and o.text ~= "" and o.text:gsub(":%s*", " ") or (o.numRequired and (TR:F("Objective %s %s/%s", c[2], (o.numFulfilled or 0), o.numRequired))) or (TR:F("Objective %s", c[2]))
        out[#out + 1] = (o.finished and "|cff66ff66" or "|cffdddddd") .. "- " .. txt .. "|r"
      end
    end
  end
  return table.concat(out, "\n")
end
-- Guidance: at most L("guideMax") short lines (tips from plan notes/data, then "Watch out" items);
-- returns the shown lines and the full list for the hover tooltip.
local WATCH = "|TInterface\\DialogFrame\\UI-Dialog-Icon-AlertNew:12:12:0:0:64:64:0:64:0:64:224:149:58|t "   -- UI-1: amber warning mark (FRIZQT has no ▲ glyph)
function E:Guidance(s, body, safety)
  local tips, watch = {}, {}
  for _, n in ipairs(body or {}) do tips[#tips + 1] = n end
  if s and s.pts and #s.pts > 1 and (s.c or s.mob) then tips[#tips + 1] = TR["Follow the arrow around the hunting loop."] end
  if s and s.zf then tips[#tips + 1] = TR["Location is approximate; check the map."] end
  if self.ExtraTips then for k, t in ipairs(self:ExtraTips(s)) do table.insert(tips, k, t) end end
  if self.ExtraWatch then for _, w in ipairs(self:ExtraWatch(s)) do watch[#watch + 1] = w end end
  for _, n in ipairs(safety or {}) do watch[#watch + 1] = (n:gsub("^HARDCORE DANGER:%s*", ""):gsub("^HARDCORE:%s*", "")) end
  for _, n in ipairs(body or {}) do if n:find("[Ee]lite") then watch[#watch + 1] = TR["Elite nearby"] end end
  if s and s.z and self.db.rules ~= "PvE" and self.CONTESTED and self.CONTESTED[s.z] then watch[#watch + 1] = TR["Contested zone: enemy players"] end
  if s and s.pts and self.db.rules == "HC" and (s.c or s.mob) then watch[#watch + 1] = TR["Pull one at a time; mobs patrol"] end
  local full, seen = {}, {}
  for _, t in ipairs(tips) do if not seen[t] then seen[t] = 1; full[#full + 1] = t end end
  local nt = #full
  for _, w in ipairs(watch) do if not seen[w] then seen[w] = 1; full[#full + 1] = TR:F("Watch out: %s", w) end end
  -- display order: tips, then watch-out items. Fit priority: the first watch-out item, then tips, then the rest.
  local function wl(t) return "|cffe0953a" .. WATCH .. t .. "|r" end
  local cand, prio = {}, {}
  -- l10n fix: notes are classified (safety, elite, watch-out) on the English plan text above; only now are they shown
  -- in the client's language (E:Note), so the matching never depends on translated text
  for i = 1, #full do
    if i <= nt then full[i] = E:Note(full[i]); cand[i] = full[i]
    else local w = E:Note((full[i]:gsub("^Watch out: ", ""))); cand[i] = wl(w); full[i] = E.L:F("Watch out: %s", w) end
  end
  if nt < #full then prio[1] = nt + 1 end
  for i = 1, nt do prio[#prio + 1] = i end
  for i = nt + 2, #full do prio[#prio + 1] = i end
  local lines = cand; self.guidePrio = prio
  return lines, full
end
-- Fit whole items into at most maxLines wrapped lines (measured with the real font at the real width; no
-- truncation). Items that don't fit are counted as "(+n)" and are in the hover tooltip.
function E:FitLines(t, items, maxLines, prio)
  local W = self:O("width") - 2 * self:O("pad")
  t:SetWidth(W); if t.SetSpacing then t:SetSpacing(self:O("lineSpacing")) end
  local function lines(txt) t:SetText(txt); local h = t:GetStringHeight() or 0; t:SetText("1"); local one = t:GetStringHeight() or 1
    return math.floor((h + self:O("lineSpacing")) / (one + self:O("lineSpacing")) + 0.5) end
  prio = prio or {}; if #prio == 0 then for i = 1, #items do prio[i] = i end end
  local pick = {}
  local function render(extra)
    local out = {}; for i = 1, #items do if pick[i] or i == extra then out[#out + 1] = items[i] end end
    local n = 0; for _ in pairs(pick) do n = n + 1 end; if extra then n = n + 1 end
    local txt = table.concat(out, "\n"); local rest = #items - n
    return rest > 0 and (txt .. " |cff777777(+" .. rest .. ")|r") or txt
  end
  for _, i in ipairs(prio) do if lines(render(i)) <= maxLines or next(pick) == nil then pick[i] = true end end   -- the top item always shows in full (wraps)
  local r = render(); t:SetText(r); return r
end

function E:Refresh()
  local f = self.frame; if not f or self.disabled then return end
  local SHOW = self:Focused() and 1 or math.max(1, math.min(MAXSHOW, self:O("steps")))
  if self.AtLevelCap and self:AtLevelCap() then
    local objective = self:ProgressionObjective()
    f.rulesBtn:SetText(self.db.rules)
    f.sub:SetText(TR["Endgame progression"])
    f.obj:SetText(objective and objective.label or TR["No eligible progression objective currently available"])
    f.guideHdr:SetText(""); f.guide:SetText(""); f.guideHover.full = nil
    f.safety.full = nil; f.safety.text:SetText(""); f.note:SetText(self.rewardHint or "")
    for k = 1, MAXSHOW do f.lines[k]:SetText("") end
    if f.bar then f.bar:SetValue(0) end
    if f.branchBtn and not self:InCombat() then f.branchBtn:Hide() end
    self:Layout()
    if objective then self:SetWaypoint(objective.point, objective.label) else self:ClearArrow() end
    return
  end
  local g, s = self:Current(); if not g then return end
  if s ~= lastStep then
    -- sound only when a QUEST step was completed (never on waypoint arrival); sounds are off by default
    if lastStep and (lastStep.a or lastStep.t or lastStep.c) then local C = Fennick_BEAST   -- M-N-4: Core cue, own toggle, off by default
      if C and C.Cue then C:Cue("stepDone") elseif self:O("sound") and PlaySound then pcall(PlaySound, (SOUNDKIT and SOUNDKIT.IG_QUEST_LIST_COMPLETE) or 618) end end
    lastStep = s
  end
  -- header
  f.rulesBtn:SetText(self.db.rules); if Fennick_BEAST.FitButton then Fennick_BEAST:FitButton(f.rulesBtn, 56) end
  if f.rulesBtn.fennickHC ~= (self.db.rules == "HC") then f.rulesBtn.fennickHC = (self.db.rules == "HC"); pcall(self.Skin.StyleButton, self.Skin, f.rulesBtn) end   -- red = HC badge only
  local sub = string.format("%s route  |  %s  |  L%d", self.db.route, self.db.class, UnitLevel("player") or 0)
  if self.StatsLine and self:O("stats") then local st = self:StatsLine(true); if st ~= "" then sub = sub .. "  |  " .. st end end
  f.sub:SetText(sub .. "\n" .. g.name .. "  " .. self.db.step .. "/" .. #g.steps)
  local body, safety = self:NotesFor(g, self.db.step)
  if self.rewardHint then table.insert(body, 1, self.rewardHint) end
  local focus = self:Focused()
  local hubPoint = s and s.hub and self.UpdateHubLogPoint and self:UpdateHubLogPoint(s)
  local view = self:ActionView(s)
  f.obj:SetText(hubPoint and hubPoint.label or (focus and s and self:ObjectiveText(view) or ""))
  if focus then
    local cand, full = self:Guidance(view, body, safety)
    f.guideHdr:SetText(#cand > 0 and (((self.Skin.PRESETS[self:O("preset")] or self.Skin.PRESETS.default).guideHdrText) or "Guidance") or ""); f.guide:SetText(self:FitLines(f.guide, cand, L("guideMax"), self.guidePrio)); f.guideHover.full = full
    body, safety = {}, {}
  else f.guideHdr:SetText(""); f.guide:SetText(""); f.guideHover.full = nil end
  f.safety.full = #safety > 0 and safety or nil
  f.safety.text:SetText(#safety > 0 and (short(safety[1], 90) .. (#safety > 1 and ("  (+" .. (#safety - 1) .. ")") or "")) or "")
  f.note:SetText(table.concat(body, "\n"))
  -- steps: current + upcoming, consecutive identical lines removed
  local shown, j, prev = 0, self.db.step, nil
  for k = 1, MAXSHOW do f.lines[k]:SetText("") end
  while shown < SHOW and g.steps[j] do
    if not self:IsInfo(g.steps[j]) and not (g.steps[j].prof and not self:HasProf(g.steps[j].prof)) then
      local txt = self:StepText(g.steps[j])
      if txt ~= prev then shown = shown + 1; f.lines[shown]:SetText((shown == 1 and "" or TR["|cff777777next:|r "]) .. txt); prev = txt end
    end
    j = j + 1
  end
  if f.bar then f.bar:SetValue(#g.steps > 0 and self.db.step / #g.steps or 0) end
  if f.branchBtn and not self:InCombat() then if self.db.rules == "PvP" and s and s.blk and self.ALT and self.ALT[s.blk] then f.branchBtn:Show() else f.branchBtn:Hide() end end
  self:Layout()
  if s and not self.escapeActive then self:SetWaypoint(self:TargetPoint(view), hubPoint and hubPoint.label or view.npc or view.mob or "", self.urgentArrow, self.urgentArrow) end
end
