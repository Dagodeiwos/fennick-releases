local TR = (Fennick_BEAST and Fennick_BEAST.L) or setmetatable({ F = function(_, f, ...) local ok, s = pcall(string.format, f, ...); return ok and s or f end }, { __index = function(_, k) return k end })   -- l10n (Core C.L)
if not (Fennick_BEAST and (Fennick_BEAST.API or 1) >= 3) then   -- P1-1 / K-2 file-top guard: Leveling calls Core before it registers
  if DEFAULT_CHAT_FRAME then DEFAULT_CHAT_FRAME:AddMessage(TR["|cff33ccffFennick:|r Fennick's Guidepost needs Fennick's Beast Core 1.2 or newer. Please update Beast Core."]) end
  return
end
-- Fennick Guide Engine: core (registry, filtering, step completion, events).
-- Original code. Version lives in the .toc.
local BRAND = "Fennick"
local E = { brand = BRAND, qnames = {}, initHooks = {} }
-- l10n: client language and names supplied by the game (by ID), English plan text only as the fallback
local GL = (GetLocale and GetLocale()) or "enUS"
E.EN_CLIENT = (GL == "enUS" or GL == "enGB")
E.L = (Fennick_BEAST and Fennick_BEAST.L) or setmetatable({ F = function(_, f, ...) local ok, s = pcall(string.format, f, ...); return ok and s or f end },
  { __index = function(_, k) return k end })
E.npcNames = {}
-- NPC/mob name in the client's language: Questie's (localized) NPC DB by the plan's NPC ID, else the English plan name
function E:NpcName(name)
  if type(name) ~= "string" then return name end
  local plus = name:find("^%+") and "+" or ""; local n = name:gsub("^%+", "")
  if self.EN_CLIENT then return name end
  local c = self.npcNames[n]; if c ~= nil then return c and (plus .. c) or name end
  local ids, db = self.NPCID and self.NPCID[n], (not (self.InCombat and self:InCombat())) and self.Questie and self:Questie()
  if not (ids and db) then return name end
  local v = self:QuestieCall(db.QueryNPCSingle, ids[1], "name")
  self.npcNames[n] = (type(v) == "string" and v ~= "") and v or false
  return self.npcNames[n] and (plus .. self.npcNames[n]) or name
end
_G[BRAND .. "_GUIDE_ENGINE"] = E

local _, playerClass = UnitClass("player")
local raceName, raceToken = UnitRace("player")
local TOKEN = { Scourge = "Undead", NightElf = "Night Elf" }
local playerRace = TOKEN[raceToken] or raceName or raceToken
local playerFaction = UnitFactionGroup("player")

-- Settings (per character, in Fennick_GuidepostDB.opt). Options.lua builds the panel; everything reads E:O(key).
E.DEFAULTS = { enabled = true, scale = 1, alpha = 0.75, lock = false, arrow = true, tomtom = true, steps = 5,
  width = 400, pad = 16, rowGap = 8, lineSpacing = 4, travelRadius = 15, patrolRadius = 50,
  autoAdvance = true, sound = false, blizzOptions = false, pvpCount = 3, pvpWindow = 120, rewardPick = true, profHints = true, repath = true, boostTips = true,
  trainerRem = true, questie = false, debug = false, autoAccept = false, autoTurnIn = false, variants = true, hcSafeAccept = true, noAuto = {}, autoGossip = false, routeOnly = true,
  dungeonMode = "optimize", secretMode = "optimize", hiddenQuestMode = "optimize",
  gearMode = "optimize", favorMode = "optimize", reputationMode = "optimize", unlockMode = "optimize", professionMode = "optimize", explorationMode = "optimize", raidPrepMode = "optimize",
  hideCombat = false, hideInstance = true, screenshot = false, stats = true,
  preset = "default", lsmBar = "Default", lsmBorder = "Default", lsmBackground = "Default", externalSkin = false }   -- M-P2-1: the minimap button is Core's
-- v4.0: look, arrow and sound settings live in Fennick's Beast Core (one setting for every Fennick module);
-- E.db.opt reads and writes them through to Fennick_CoreDB.
E.SHARED = { colorblind = true, arrow = true, tomtom = true, sound = true, preset = true, alpha = true, fontOffset = true, lsmBar = true,
  lsmBorder = true, lsmBackground = true, externalSkin = true, minimap = true }
function E:ShareOpt(o)
  local C = Fennick_BEAST; if not C or getmetatable(o) then return o end
  for k in pairs(self.SHARED) do local v = rawget(o, k); if v ~= nil then if C.db.opt[k] == nil or not C.loaded then C.db.opt[k] = v end; rawset(o, k, nil) end end
  return setmetatable(o, { __index = function(_, k) if E.SHARED[k] then return C:O(k) end end,
    __newindex = function(t, k, v) if E.SHARED[k] then C.db.opt[k] = v else rawset(t, k, v) end end })
end
function E:ApplyDefaults(o)
  for k, v in pairs(self.DEFAULTS) do
    if self.SHARED[k] then -- owned by Core
    else
    if rawget(o, k) == nil then if type(v) == "table" then o[k] = {}; for k2, v2 in pairs(v) do o[k][k2] = v2 end else o[k] = v end end
    end
  end
  return self:ShareOpt(o)
end
-- Saved-data migration: rename/delete keys from older versions so dead settings never linger.
E.RENAMED = { gearHints = "rewardPick" }
-- Dormant feature (intentional, exempt from the dead-code check): the list view (current + upcoming steps).
-- Focused view is the only user-facing view; set true to bring the list view back (opt.focus=false selects it).
function E:Focused() return true end   -- N-7: Focus is the only view (the dormant list view was removed)
E.DEAD_DB = { "profs", "copy", "export", "import" }
-- P2-4/P2-5: options are dropped ONLY by an explicit list here (never because a default disappeared); unknown keys go to db._unknown
E.DEAD_OPT = { "font" }   -- 4.2: text size is Core's fontOffset (Core 1.1+)
function E:Migrate(db)
  if self.GuardDB then self:GuardDB(db) end      -- v3.9: reset only a table of the wrong type, never the whole profile
  local o = db.opt or {}
  for old, new in pairs(self.RENAMED) do if o[old] ~= nil then if o[new] == nil then o[new] = o[old] end; o[old] = nil end end
  for _, k in ipairs(self.DEAD_OPT) do rawset(o, k, nil) end
  -- N-1: colorblind is shared with Beast Core (E.SHARED); an old Leveling value is carried over by the SHARED loop above
  db._unknown = type(db._unknown) == "table" and db._unknown or {}
  for k, v in pairs(o) do if self.DEFAULTS[k] == nil and not self.SHARED[k] then db._unknown[k] = v; rawset(o, k, nil) end end
  if not getmetatable(o) then self:ShareOpt(o) end
  if db.profs and not db.profChoice then db.profChoice = db.profs end              -- pre-3.4 saved choice
  for _, k in ipairs(self.DEAD_DB) do db[k] = nil end
  -- v3.8.1: the old (cramped) layout defaults saved by earlier versions move to the new defaults
  if o.width == 380 and o.pad == 14 then o.width, o.pad = nil, nil end
  if o.lineSpacing == 3 then o.lineSpacing = nil end
  db.opt = o
end
E.CONTENT_OPTIONS = { dungeon = "dungeonMode", secret = "secretMode", hiddenQuest = "hiddenQuestMode", gear = "gearMode", favor = "favorMode", reputation = "reputationMode", unlock = "unlockMode", profession = "professionMode", exploration = "explorationMode", raidPrep = "raidPrepMode" }
function E:ContentMode(category)
  local key = self.CONTENT_OPTIONS[category]
  if not key then return "off" end
  local v = self:O(key)
  if v == "off" or v == "force" or v == "optimize" then return v end
  return self.DEFAULTS[key]
end
function E:O(k) local o = self.db and self.db.opt; if o and o[k] ~= nil then return o[k] end; return self.DEFAULTS[k] end

-- Combat safety: anything that touches other add-ons (TomTom, Questie) or creates/focuses UI is deferred
-- while InCombatLockdown() and run once on PLAYER_REGEN_ENABLED. Debug mode logs every deferral.
E.queue = {}
function E:InCombat() return InCombatLockdown and InCombatLockdown() end
function E:Debug(msg)
  if not (self.db and self:O("debug")) then return end
  local line = date("%H:%M:%S") .. (self:InCombat() and " [combat] " or " ") .. msg
  self.db.debugLog = self.db.debugLog or {}
  table.insert(self.db.debugLog, line); if #self.db.debugLog > 200 then table.remove(self.db.debugLog, 1) end
  DEFAULT_CHAT_FRAME:AddMessage(TR:F("|cff999999Fennick debug: %s|r", line))
end
-- P1-14: protected like Core's C:Safe - one error never aborts login init, Edit Mode registration or the TomTom hook
function E:Safe(key, fn)
  if self:InCombat() then self.queue[key] = fn; self:Debug("deferred " .. key); return false end
  local ok, err = pcall(fn)
  if not ok then self:Debug("error " .. key .. ": " .. tostring(err)); if geterrorhandler then pcall(geterrorhandler(), err) end end
  return ok
end
function E:FlushQueue()
  local q = self.queue; self.queue = {}
  for k, fn in pairs(q) do self:Debug("run deferred " .. k); local ok, err = pcall(fn); if not ok then self:Debug("error " .. k .. ": " .. tostring(err)) end end
end

function E:Print(msg) DEFAULT_CHAT_FRAME:AddMessage("|cff33ccff" .. BRAND .. ":|r " .. tostring(msg)) end

-- Hardcore detection (Forever/Classic HC realms expose C_GameRules or IsHardcoreActive in some builds).
function E:IsHardcore()
  if C_GameRules and C_GameRules.IsHardcoreActive then return C_GameRules.IsHardcoreActive() end
  return true -- assume Hardcore rules: safest default
end

local function raceOk(gate)
  if not gate then return true end
  local neg = gate:sub(1, 1) == "!"
  local list = neg and gate:sub(2) or gate
  local hit = false
  for r in list:gmatch("[^/]+") do
    if r == playerRace or r == raceToken or playerRace:find(r, 1, true) or r:upper() == playerClass then hit = true end
  end
  if neg then return not hit end
  return hit
end

function E:RegisterQuestNames(t) for k, v in pairs(t) do self.qnames[k] = v end end
E.all = {}
function E:RegisterGuide(g) self.all[#self.all + 1] = g end
E.RULES = { "Normal", "HC" }

local function has(list, v) if not list then return false end for _, x in ipairs(list) do if x == v then return true end end return false end
E.has = has
local function normalRules(v) if v == "PvE" or v == "PvP" then return "Normal" end; return v end
local function routeRules(list, rules)
  if rules == "Normal" then return has(list, "Normal") or has(list, "PvE") or has(list, "PvP") end
  return has(list, rules)
end

function E:Profile()
  local db = self.db
  db.class = db.class or playerClass
  if not db.route then
    db.route = self.ROUTE and self.ROUTE[playerRace]
    if not db.route then   -- P2-14: unknown race -> a route of YOUR faction, and say so (pick another in /fennick setup)
      db.route = (playerFaction == "Alliance") and "Elwynn" or "Durotar"
      self.unknownRace = true; self:Print(TR:F("unknown race '%s': using the %s route. /fennick setup to pick another.", tostring(playerRace), db.route))
    end
  end
  db.rules = normalRules(db.rules) or (self:IsHardcore() and "HC" or "Normal")
  return db.route, db.class, db.rules
end

function E:Eligible(race, cls)
  local a = self.AVAIL and self.AVAIL[cls]; if not a then return true end
  for _, list in pairs(a) do if has(list, race) then return true end end
  return false
end

-- Keep a step for this profile? (race gate, class tag, ruleset tags, Questie class/race restriction)
function E:Keep(s, cls, rules)
  if not raceOk(s.race) then return false end
  if s.cls and s.cls ~= cls then return false end
  if s.death then return false end
  if s.rules and not routeRules(s.rules, rules) then return false end
  return true
end

-- Merge "go to X" + "accept/turn in at X" into one step, and drop consecutive duplicates.
local function near(a, b) return a.z and b.z and a.z == b.z and math.abs(a.x - b.x) < 1.5 and math.abs(a.y - b.y) < 1.5 end
local function sig(s)
  local t = { s.z or "", s.x and math.floor(s.x) or "", s.y and math.floor(s.y) or "", s.npc or "", s.mob or "", s.tr or "", s.lv or "", s.n or "" }
  for _, k in ipairs({ "a", "t" }) do for _, q in ipairs(s[k] or {}) do t[#t + 1] = k .. q end end
  for _, c in ipairs(s.c or {}) do t[#t + 1] = "c" .. c[1] .. ":" .. c[2] end
  return table.concat(t, "|")
end
E.StepSig = sig
-- 4.2 (P0-1): stable step identity. Progress (current step, skips, met interactions, branch) is keyed by this id, never by the
-- step's index, so a reload, a regenerated Data.lua or a runtime-inserted step (missed pickup, failed quest, hub, branch, level gap)
-- cannot shift saved progress. Build steps use s.id (build_allinone.py) or their content signature (made unique per guide in
-- BuildChain); runtime-inserted steps get an "rt:" id and are never used as the saved position anchor.
local function runtimeStep(s) return s.callback or s.gen or s.branch or s.branchEnd or s.gap or s.failq end
function E:StepId(s)
  if type(s) ~= "table" then return nil end
  if not s._sid then s._sid = (runtimeStep(s) and TR["rt:"] or "") .. (s.id or (sig(s) .. "|" .. tostring(s.n or ""))) end
  return s._sid
end
-- saved position = the first build step at or after the current index (runtime steps are re-created when needed)
function E:SavePos()
  local g = self.chain and self.chain[self.db.gi]; if not g then return end
  for i = self.db.step or 1, #g.steps do local s = g.steps[i]; if not runtimeStep(s) then self.db.stepKey = self:StepId(s); return end end
  self.db.stepKey = nil
end
function E:SeekKey(g, key)
  if not (g and key) then return nil end
  for i, s in ipairs(g.steps) do if self:StepId(s) == key then return i end end
end
-- one-time migration of index keys ("<guide>#<n>") written before 4.2 (db.keyV = 2; db.schema stays Safety.lua's table schema)
E.KEY_SCHEMA = 2
function E:MigrateIndexKeys(chain)
  if (tonumber(self.db.keyV) or 1) >= self.KEY_SCHEMA then return end
  local byName = {}; for _, g in ipairs(chain) do byName[g.name] = g end
  local function conv(k)
    local name, i, rest = tostring(k):match("^(.*)#(%d+)(.*)$")
    local g = name and byName[name]; local s = g and g.steps[tonumber(i)]
    if s then return name .. "#" .. self:StepId(s) .. rest end
  end
  for _, t in ipairs({ "skipped", "met" }) do
    local old = self.db[t]
    if type(old) == "table" then local new = {}; for k, v in pairs(old) do local nk = conv(k); if nk then new[nk] = v end end; self.db[t] = new end
  end
  if not self.db.stepKey and self.db.gname and byName[self.db.gname] and self.db.step then
    local g = byName[self.db.gname]; local s = g.steps[self.db.step]; if s then self.db.stepKey = self:StepId(s) end
  end
  if type(self.db.branch) == "table" and not self.db.branch.key then local g = chain[self.db.branch.gi or 0]; local s = g and g.steps[self.db.branch.step or 0]; if s then self.db.branch.key = self:StepId(s) end end
  self.db.keyV = self.KEY_SCHEMA
end
function E:MergeAll(steps) local m, n = self:MergeSteps(steps); repeat n = #m; m = self:MergeSteps(m) until #m == n; return m end
-- The stable saved-position signature deliberately omits interaction metadata.
-- Equal signatures alone cannot establish that two authored steps do the same work.
local function sameContent(a, b)
  if a == b then return true end
  if type(a) ~= "table" or type(b) ~= "table" then return false end
  for k, v in pairs(a) do
    if type(k) ~= "string" or (k:sub(1,1) ~= "_" and k ~= "pl" and k ~= "manualDone") then
      if not sameContent(v, b[k]) then return false end
    end
  end
  for k in pairs(b) do
    if a[k] == nil and (type(k) ~= "string" or (k:sub(1,1) ~= "_" and k ~= "pl" and k ~= "manualDone")) then return false end
  end
  return true
end
function E:MergeSteps(steps)
  local out = {}
  for _, s in ipairs(steps) do
    local p = out[#out]
    local plain = p and self:IsPureTravel(p) and not (p.npc or p.fly or p.hs or p.home)
    if p and sig(p) == sig(s) and sameContent(p, s) then -- exact duplicate
    elseif plain and not p.id and not p.cwid and self:IsPureTravel(s) and near(p, s) then -- two "go to" legs to the same spot: keep the later
      local m = {}; for k, v in pairs(s) do m[k] = v end; if p.n and not s.n then m.n = p.n end; out[#out] = m
    elseif p and not p.id and not p.cwid and (self:IsPureTravel(p) or (p.act == "talk" and p.npc and p.npc == s.npc and not p.c)) and not p.fly and not p.hs and not p.home and (not p.npc or p.npc == s.npc) and (s.a or s.t) and (not s.z or near(p, s)) then
      local m = {}; for k, v in pairs(p) do m[k] = v end; for k, v in pairs(s) do m[k] = v end
      if p.n and p.n ~= s.n then m.n2 = p.n end
      out[#out] = m
    else out[#out + 1] = s end
  end
  return out
end

-- Build the route: per segment (in order) the first registered guide family matching faction/route/ruleset.
function E:BuildChain()
  local route, cls, rules = self:Profile()
  local segs, pick, chain, priority = {}, {}, {}, {}
  for _, g in ipairs(self.all) do
    if g.faction == playerFaction and has(g.routes, route) and routeRules(g.rules, rules) then
      local rank = 1
      if rules == "Normal" then
        rank = has(g.rules, "Normal") and 3 or (has(g.rules, "PvE") and 2 or 1)
      end
      if not pick[g.seg] then segs[#segs + 1] = g.seg end
      if not priority[g.seg] or rank > priority[g.seg] then
        pick[g.seg], priority[g.seg] = g.src or g.name, rank
      end
    end
  end
  table.sort(segs)
  local dropped, offered = {}, {}
  for _, seg in ipairs(segs) do
    for _, g in ipairs(self.all) do
      if g.seg == seg and (g.src or g.name) == pick[seg] and g.faction == playerFaction and has(g.routes, route) and routeRules(g.rules, rules) then
        local kept, skippedZones = {}, {}
        local steps = self.RouteSteps and self:RouteSteps(g) or g.steps
        if self.FieldChapter then steps = self:FieldChapter(g, steps, rules) end
        for _, s in ipairs(steps) do
          if self:Keep(s, cls, rules) then
            local orphan = false -- steps whose quests were all dropped upstream
            local any, all = false, true
            for _, q in ipairs(s.t or {}) do any = true; if not dropped[q] then all = false end end
            for _, q in ipairs(s.c or {}) do any = true; if not dropped[q[1]] then all = false end end
            if any and all and not s.a then orphan = true end
            if not orphan then
              kept[#kept + 1] = s
              for _, q in ipairs(s.a or {}) do offered[q], dropped[q] = true, nil end
            end
          else
            for _, q in ipairs(s.a or {}) do if not offered[q] and not self:OnQuest1(q) then dropped[q] = true end end
          end
        end
        chain[#chain + 1] = { name = g.name, sourceKey=(g.src or "").."|"..g.name, lo = g.lo, hi = g.hi, steps = self:MergeAll(kept) }
      end
    end
  end
  self.chain = chain; self.byId = nil
  self.locationGoals, self.objectiveLocations = {}, {}
  for _, guide in ipairs(chain) do
    for _, s in ipairs(guide.steps) do
      if s.c and #s.c == 1 and s.z and not (s.a or s.t or s.act) then
        local key = s.c[1][1] .. ":" .. s.c[1][2]
        local old = self.objectiveLocations[key]
        if old == nil then self.objectiveLocations[key] = s
        elseif old and not near(old,s) then self.objectiveLocations[key] = false end
      end
    end
  end
  for _, g in ipairs(chain) do
    local target
    for i = #g.steps, 1, -1 do
      local s = g.steps[i]
      if self:IsLocationOnly(s) then
        if target and near(s, target) and (not s.npc or not target.npc or s.npc == target.npc) then
          self.locationGoals[s] = target
        else target = nil end
      elseif (s.a or s.t or s.c) and not (s.act or s.tr or s.use or s.buy or s.fly or s.home or s.hs or s.lv or s.hub or s.book or s.donate) then target = s
      else target = nil end
    end
  end
  for _, g in ipairs(chain) do local seen = {}
    for _, s in ipairs(g.steps) do s._sid = nil; local b = self:StepId(s); if seen[b] then seen[b] = seen[b] + 1; s._sid = b .. "~" .. seen[b] else seen[b] = 1 end end end
  self:MigrateIndexKeys(chain)
  for _, g in ipairs(chain) do for i, s in ipairs(g.steps) do s.manualDone = (self.db.skipped and self.db.skipped[self:SkipKey(g, i)]) or nil end end
  if not self:Eligible(playerRace, cls) then self:Print(TR:F("note: %s cannot be a %s; showing that class's steps anyway.", playerRace, cls)) end
  return chain
end

function E:SetProfile(k, v) if k == "rules" then v = normalRules(v) end; self.db[k] = v; self.db.gi, self.db.step, self.db.gname, self.db.stepKey = nil, nil, nil, nil; self:Start() end
function E:Start()
  if self.AtLevelCap and self:AtLevelCap() then if self.Refresh then self:Refresh() end; return end
  if self.logGate and (not self.db.gname or not self.db.coastalRouteVersion) then
    self.awaitingStart = true
    return
  end
  self.awaitingStart = nil
  self:BuildChain()
  if #self.chain == 0 then return self:Print(TR["no route for this faction/route/ruleset."]) end
  if self.db.gname and not (self.chain[self.db.gi or 0] and self.chain[self.db.gi].name == self.db.gname) then
    self.db.gi = nil; for i, g in ipairs(self.chain) do if g.name == self.db.gname then self.db.gi = i end end
  end
  if not (self.db.gi and self.chain[self.db.gi]) then
    local lvl = UnitLevel("player"); self.db.gi = 1
    local bestLo
    for i, g in ipairs(self.chain) do
      if lvl >= g.lo and lvl < g.hi then self.db.gi = i; break end
      if g.lo <= lvl and (not bestLo or g.lo > bestLo) then self.db.gi, bestLo = i, g.lo end
    end
    self.db.step = self:InitialStep(self.chain[self.db.gi], lvl)
  end
  local guide = self.chain[self.db.gi]
  local at = self:SeekKey(guide, self.db.stepKey)
  local saved = at and guide.steps[at]
  if not self.db.coastalRouteVersion and guide.name == "6-10 Durotar" and saved and saved.a
      and saved.a[1] == 99052 and not self:QuestAvailable(99052) then
    at = nil
  end
  if at then self.db.step = at
  elseif self.db.stepKey then self.db.step = self:InitialStep(guide, UnitLevel("player")) end
  self.db.coastalRouteVersion = 1
  self:PruneDB()
  self:Advance()
end

-- Dynamic reminders: trainer visit for the current level.
function E:Reminders()
  local lvl, out = UnitLevel("player"), {}
  if self:O("trainerRem") and self.db.trainedClassLevel ~= lvl and lvl >= 2 and lvl % 2 == 0 then out[#out + 1] = TR:F("New rank(s) at your class trainer (level %s).", lvl) end
  return table.concat(out, "\n")
end

-- Questie (optional): QuestieAdapter.lua is the only file that touches it; E:Questie() is nil unless enabled+healthy.
local function questie() return E.Questie and E:Questie() end
-- class check from Questie's requiredClasses bitmask (bit n-1 = classID n)
function E:ClassCanTake(id, db)
  db = db or self:Questie(); if not db then return true end
  local rc = self:QuestieCall(db.QueryQuestSingle, id, "requiredClasses")
  if type(rc) == "number" and rc > 0 then
    local _, _, classID = UnitClass("player")
    if classID and bit and bit.band(rc, bit.lshift(1, classID - 1)) == 0 then return false end
  end
  return true
end

function E:QuestName(id)
  local db = (not self:InCombat()) and questie()
  if db then
    local q = self:QuestieCall(db.QueryQuestSingle, id, "name")
    if type(q) == "string" and q ~= "" then return q end
  end
  if C_QuestLog and C_QuestLog.GetTitleForQuestID then
    local t = C_QuestLog.GetTitleForQuestID(id); if t then return t end
  end
  return self.qnames[id] or (TR:F("Quest %s", id))
end

-- Quest state (event-driven cache + client queries as the source of truth):
--   QUEST_ACCEPTED (questID is the last numeric arg) -> accepted; QUEST_TURNED_IN(questID) -> turned in;
--   QUEST_REMOVED(questID) -> no longer on the quest (abandon or turn-in; turn-in wins);
--   QUEST_LOG_UPDATE / UNIT_QUEST_LOG_CHANGED("player") -> re-poll objectives.
-- The cache covers the moment between the event and the quest log/flag catching up.
local QS = { accepted = {}, turned = {}, removed = {} }
E.QS = QS
local function done1(id)
  if QS.turned[id] then return true end
  if C_QuestLog and C_QuestLog.IsQuestFlaggedCompleted then return C_QuestLog.IsQuestFlaggedCompleted(id) and true or false end
  return IsQuestFlaggedCompleted and IsQuestFlaggedCompleted(id) and true or false
end
local function onQuest1(id)
  if QS.removed[id] then return false end
  if QS.accepted[id] then return true end
  if C_QuestLog and C_QuestLog.IsOnQuest then return C_QuestLog.IsOnQuest(id) and true or false end
  return GetQuestLogIndexByID and (GetQuestLogIndexByID(id) or 0) > 0 or false
end
E.Done1, E.OnQuest1 = function(_, id) return done1(id) end, function(_, id) return onQuest1(id) end
-- v3.9 Forever quest-ID variants (Safety.lua): the primary ID always counts; a variant counts only after the
-- live quest log shows it with the primary's title and objectives (E:LiveId), and its "completed" history
-- only counts when this character had that verified variant in the log (db.varSeen).
local function live(id) return (E.LiveId and E:LiveId(id)) or id end
local function done(id)
  if done1(id) then return true end
  if E.VariantDone then return E:VariantDone(id) end
  return false
end
local function onQuest(id) return onQuest1(live(id)) end
function E:QuestEvent(ev, ...)
  local id; for i = select("#", ...), 1, -1 do local v = select(i, ...); if type(v) == "number" and v > 0 then id = v; break end end
  if ev == "QUEST_TURNED_IN" then id = ...; if id then QS.turned[id] = true; QS.accepted[id] = nil end
  elseif ev == "QUEST_ACCEPTED" and id then QS.accepted[id] = true; QS.removed[id] = nil
  elseif ev == "QUEST_REMOVED" then id = ...; if id and not QS.turned[id] then QS.removed[id] = true; QS.accepted[id] = nil end end
end
-- a quest this character can take (Questie class filter, per quest - never per step)
function E:QuestAvailable(id)
  if onQuest(id) or done(id) then return true end
  if self.db and self.db.rules == "Normal" and self.FieldEligible and not self:FieldEligible(id) then return false end
  local gate = self.QuestRequirements and self.QuestRequirements[id]
  if gate and (UnitLevel("player") < gate[1] or (self.questLogReady and gate[2] and not done(gate[2]))) then return false end
  return self:ClassCanTake(id) and not (self.db and self.db.missed and self.db.missed[id])
end
E.IsOnQuest, E.IsQuestDone = onQuest, done

-- Missed pickups. Current step needs quest q (objective or turn-in) that is neither in the log nor done:
--   go back if cheap:  round trip to the accept step (on foot, RUNSPEED yd/s) <= CB_FREE s, or
--                      <= CB_MAX s and the quest's XP per second of detour >= your current XP/s;
--   otherwise skip:    q and its follow-up quests (E.FOLLOW) are marked missed, so every step for them is skipped.
-- A callback is one typed accept step inserted before the current step (one arrow); the route resumes after it.
-- QUEST_ACCEPTED for a missed quest brings it (and its follow-ups) back.
E.RUNSPEED, E.CB_FREE, E.CB_MAX = 7, 150, 300
function E:AcceptStepFor(q)
  for gi = self.db.gi, 1, -1 do local g = self.chain[gi]
    local top = (gi == self.db.gi) and (self.db.step - 1) or #g.steps
    for i = top, 1, -1 do local x = g.steps[i]; if x.a and x.z and not x.callback then for _, a in ipairs(x.a) do if a == q then return x end end end end
  end
end
function E:MarkMissed(q, root, why)
  self.db.missed = self.db.missed or {}; if self.db.missed[q] then return end
  self.db.missed[q] = root or q
  self:Debug("missed pickup " .. q .. " -> skip (" .. (why or "follow-up") .. ")")
  for _, n in ipairs((self.FOLLOW and self.FOLLOW[q]) or {}) do if not (onQuest(n) or done(n)) then self:MarkMissed(n, root or q) end end
end
function E:Unmiss(q)
  if not (self.db.missed and self.db.missed[q]) then return end
  local root = self.db.missed[q]; for k, r in pairs(self.db.missed) do if r == root or k == q then self.db.missed[k] = nil end end
  self:Debug("quest " .. q .. " accepted -> missed steps restored")
end
function E:MissedCheck()
  if not (self.questLogReady and self.chain) then return end
  local g, s = self:Current(); if not s or s.callback then return end
  if self.userStep == self:StepId(s) then return end
  local need = {}
  for _, q in ipairs(s.t or {}) do need[#need + 1] = q end
  for _, c in ipairs(s.c or {}) do need[#need + 1] = c[1] end
  self.db.cb = self.db.cb or {}
  for _, q in ipairs(need) do
    if self:QuestAvailable(q) and not onQuest(q) and not done(q) then
      local acc = not self.db.cb[q] and self:AcceptStepFor(q)
      if acc and self.ActionEndpoints and self.ActionEndpoints.a[q] then
        local pt = self.ActionEndpoints.a[q]
        acc = {z=pt[1],x=pt[2],y=pt[3],npc=pt[4]}
      end
      local d = acc and self:Distance(acc); local rt = d and 2 * d / self.RUNSPEED
      local xp, rate = self.QXP and self.QXP[q], self.XPPerSecond and self:XPPerSecond()
      local forced = self.IsForcedContent and self:IsForcedContent(self.QuestContent and self.QuestContent[q])
      local unlocks = self.ChainUnlocks and self.ChainUnlocks[q]
      local worth = rt and (rt <= self.CB_FREE or (rt <= self.CB_MAX and (unlocks or (xp and rate and xp / rt >= rate))))
      -- Normal may recover an explicitly requested pickup beyond the XP detour budget.
      -- Hardcore retains its existing detour limits; no unknown destination is routed.
      if forced and acc and rt and self.db.rules == "Normal" then worth = true end
      if worth then
        self.db.cb[q] = true
        local cbs = { a = { q }, npc = acc.npc, z = acc.z, x = acc.x, y = acc.y, callback = true, n = TR:F("Missed pickup: go back for %s, then continue.", self:QuestName(q)) }
        table.insert(g.steps, self.db.step, cbs)
        self:Debug(string.format("missed pickup %d -> callback (%.0f s round trip, xp %s, rate %s)", q, rt, tostring(xp), rate and string.format("%.2f/s", rate) or "n/a"))
        if self.Refresh then self:Refresh() end
        return true
      end
      if forced then
        self:Debug("forced pickup unresolved; retained for manual recovery")
        return
      end
      if rt then self:Print(TR:F("Passing %s: returning for the pickup would add about %.0f seconds.", self:QuestName(q),rt)) end
      self:MarkMissed(q, nil, acc and (rt and TR:F("%.0f s round trip", rt) or TR["pickup elsewhere"]) or TR["callback already offered / no pickup step"])
    end
  end
  if self.db.missed and next(self.db.missed) and self:StepDone(s) then self:Advance() end
end
-- quest finished but not turned in yet: every objective counts as done
local function questComplete(id)
  if C_QuestLog and C_QuestLog.IsComplete and C_QuestLog.IsComplete(id) then return true end
  if IsQuestComplete and IsQuestComplete(id) then return true end
  local idx = GetQuestLogIndexByID and GetQuestLogIndexByID(id)
  if idx and idx > 0 and GetQuestLogTitle then local c = select(6, GetQuestLogTitle(idx)); if c == 1 then return true end end
  return false
end
E.QuestComplete = function(_, id) return questComplete(id) end
local function objDone(id, n)
  if done(id) then return true end
  id = live(id)
  if not onQuest(id) then return false end
  if questComplete(id) then return true end
  local objs = C_QuestLog and C_QuestLog.GetQuestObjectives and C_QuestLog.GetQuestObjectives(id)
  if objs and objs[n] then return objs[n].finished and true or false end
  local idx = GetQuestLogIndexByID and GetQuestLogIndexByID(id)   -- clients without C_QuestLog objectives
  if idx and idx > 0 and GetQuestLogLeaderBoard then local _, _, fin = GetQuestLogLeaderBoard(n, idx); if fin ~= nil then return fin and true or false end end
  return false
end

-- On first install, enter at this level's part of the chosen guide. Keep earlier
-- active quest work and explicitly forced goals. Saved positions bypass this scan.
function E:InitialStep(g, lvl)
  if lvl <= g.lo then return 1 end
  local last = 1
  for i, s in ipairs(g.steps) do
    if not s.pl then return 1 end
    if s.pl >= lvl then return i end
    for _, c in ipairs(s.c or {}) do if onQuest(c[1]) and not objDone(c[1],s.fieldTarget and self:FieldObjectiveIndex(s) or c[2]) then return i end end
    for _, q in ipairs(s.t or {}) do if onQuest(q) and not done(q) then return i end end
    for _, q in ipairs(s.a or {}) do
      if not done(q) and not onQuest(q) and self.IsForcedContent and self:IsForcedContent(self.QuestContent and self.QuestContent[q]) and self:QuestAvailable(q) then return i end
    end
    last = i
  end
  return last
end

function E:IsLocationOnly(s)
  return s.z and not (s.a or s.t or s.c or s.act or s.mob or s.tr or s.lv or s.hub or s.gapfill
    or s.fly or s.hs or s.home or s.death or s.buy or s.use or s.loot or s.book or s.donate or s.prof)
end

-- Return a display-only action. The saved step, completion and skip keys remain intact.
function E:ActionView(s)
  if not s or not (s.t or s.a or s.c) then return s end
  local count = #(s.t or {}) + #(s.a or {}) + #(s.c or {})
  if count <= 1 and not (s.act or s.tr or s.buy) then return s end
  for _, stage in ipairs({"t","a","c"}) do
    for _, item in ipairs(s[stage] or {}) do
      local q = stage=="c" and item[1] or item
      if self:QuestAvailable(q) and not done(q) and not (stage=="a" and onQuest(q))
        and not (stage=="c" and objDone(q,item[2])) then
        local view = {[stage]={item}, cwid=s.cwid}
        local pt = self.ActionEndpoints and self.ActionEndpoints[stage] and self.ActionEndpoints[stage][q]
        if pt then view.z,view.x,view.y,view.npc = pt[1],pt[2],pt[3],pt[4]
        elseif stage=="c" then
          local target = self.objectiveLocations and self.objectiveLocations[q .. ":" .. item[2]]
          if target then
            view.z,view.x,view.y,view.mob,view.pts = target.z,target.x,target.y,target.mob,target.pts
            view.specificObjective = true
          else
            local z,x,y
            if C_QuestLog and C_QuestLog.GetNextWaypoint then z,x,y=C_QuestLog.GetNextWaypoint(live(q)) end
            if z and type(x)=="number" and type(y)=="number" and x>=0 and x<=1 and y>=0 and y<=1 then
              view.z,view.x,view.y=z,100*x,100*y
              view.specificObjective=true
            elseif s.c[1][1]==q and s.c[1][2]==item[2] then
              view.z,view.x,view.y,view.mob,view.pts,view.use=s.z,s.x,s.y,s.mob,s.pts,s.use
            end
          end
        elseif count==1 or (not s.t or #s.t==0) and stage=="a" and s.a[1]==q or stage=="t" and s.t[1]==q then
          view.z,view.x,view.y,view.npc=s.z,s.x,s.y,s.npc
        end
        return view
      end
    end
  end
  if s.act or s.tr or s.buy then
    local view={}; for k,v in pairs(s) do view[k]=v end
    view.a,view.t,view.c=nil,nil,nil
    return view
  end
  return s
end

-- Info-only steps (notes/reminders) never block: they are shown with the next action step.
function E:IsInfo(s) return not (s.a or s.t or s.c or s.tr or s.lv or s.fly or s.hs or s.home or s.z or s.hub or s.act or s.buy) end

-- Step completion. Every element must be complete; elements:
--   accept q   -> on the quest or already turned in      (QUEST_ACCEPTED)
--   turn-in q  -> turned in                               (QUEST_TURNED_IN)
--   objective  -> objective finished in the quest log    (QUEST_LOG_UPDATE / UNIT_QUEST_LOG_CHANGED)
--   train/level-> spell known / level reached
-- Location is NEVER a completion criterion for a step that has any quest/train/level element.
-- Only a pure travel step (no other element) completes on arrival. Quests this class cannot take
-- are dropped individually; the step is skipped only if every quest element was unavailable.
-- pure travel: a coordinate and nothing to do there (no NPC, target, interaction or quest). Only these complete on arrival.
function E:IsPureTravel(s) return s.z and not (s.a or s.t or s.c or s.tr or s.lv or s.hub or s.gapfill or s.npc or s.mob or s.act or s.buy or s.fly or s.hs or s.home or s.death) end
-- the step a '#completewith' background step runs alongside (same guide); nil if filtered out for this character
function E:CwTarget(s)
  if not s.cwid then return end
  self.byId = self.byId or {}
  local t = self.byId[s.cwid]; if t ~= nil then return t or nil end
  for _, g in ipairs(self.chain or {}) do for _, o in ipairs(g.steps) do if o.id then self.byId[o.id] = o end end end
  t = self.byId[s.cwid]; if not t then self.byId[s.cwid] = false end; return t
end
function E:StepDone(s)
  if s.manualDone then return true end
  if s.failq then return not (self.QuestFailed and self:QuestFailed(s.failq)) end   -- v3.9 re-take step for a failed quest
  if s.cwid and not s._cwIn then          -- background step: done once the step it runs alongside is done
    local t = self:CwTarget(s)
    if t and t ~= s then s._cwIn = true; local ok, d = pcall(self.StepDone, self, t); s._cwIn = nil; if ok and d then return true end end
  end
  if s.prof and not self:HasProf(s.prof) then return true end  -- profession content: only for your professions
  if s.gapfill and UnitLevel("player") >= s.gapfill then return true end  -- level gap already covered
  if s.hub then return self:HubDone(s) end
  if self:IsLocationOnly(s) then
    local goal = self.locationGoals and self.locationGoals[s]
    if goal then
      local pending = false
      for _, q in ipairs(goal.a or {}) do
        if self:QuestAvailable(q) and not onQuest(q) and not done(q) then pending = true end
      end
      for _, q in ipairs(goal.t or {}) do
        if self:QuestAvailable(q) and not done(q) then pending = true end
      end
      for _, c in ipairs(goal.c or {}) do
        if self:QuestAvailable(c[1]) and not objDone(c[1],c[2]) then pending = true end
      end
      if not pending then return true end
    end
    if s.npc and self.Met and self:Met(s,"talk") then return true end
    local distance = self:Distance(s)
    return distance ~= nil and distance < self:O("travelRadius")
  end
  if s.hubObjective then return not self:QuestAvailable(s.hubObjective) or self:Done1(s.hubObjective) or self:QuestComplete(s.hubObjective) end
  if self:IsInfo(s) then return true end
  local any, quest = false, false
  for _, q in ipairs(s.a or {}) do quest = true; if self:QuestAvailable(q) then any = true; if not (onQuest(q) or done(q)) then return false end end end
  for _, q in ipairs(s.t or {}) do quest = true; if self:QuestAvailable(q) then any = true; if not done(q) then return false end end end
  for _, c in ipairs(s.c or {}) do quest = true; if self:QuestAvailable(c[1]) then any = true; if not objDone(c[1], s.fieldTarget and self:FieldObjectiveIndex(s) or c[2]) then return false end end end
  if s.tr then any = true; if not IsSpellKnown(s.tr) and not (self.TrainerCleared and self:TrainerCleared(s)) then return false end end
  if s.lv then any = true; if UnitLevel("player") < s.lv then return false end end
  local ad = self.ActDone and self:ActDone(s); if ad == false then return false elseif ad then any = true end
  if s.mob and not quest and not s.lv and not s.act then any = true; if not (self.Met and self:Met(s, "kill")) then return false end end
  if any or quest then return true end
  if self:IsPureTravel(s) then local d = self:Distance(s); return d ~= nil and d < self:O("travelRadius") end
  return false
end

-- Position math. Both points go through the same conversion (game API, else datamine zone bounds
-- E.MAPB = {[uiMap]={instanceMap,x0,y0,x1,y1}}), so a sub-map/parent-map mismatch (e.g. Thunder Bluff
-- or Bloodhoof vs Mulgore) is compared in world yards, never in map percent.
local function mapbWorld(z, x, y) local b = E.MAPB and E.MAPB[z]; if not b then return end
  return b[1], b[4] - (y / 100) * (b[4] - b[2]), b[5] - (x / 100) * (b[5] - b[3]) end
function E:PlayerPos()
  if not (C_Map and C_Map.GetBestMapForUnit) then return end
  local m = C_Map.GetBestMapForUnit("player")
  for _ = 1, 5 do                                   -- climb to a parent map when this one has no position
    if not m then return end
    local p = C_Map.GetPlayerMapPosition(m, "player")
    if p and p.x and (p.x ~= 0 or p.y ~= 0) then return m, p.x * 100, p.y * 100 end
    local info = C_Map.GetMapInfo and C_Map.GetMapInfo(m); m = info and info.parentMapID
    if m == 0 then return end
  end
end
local function apiWorld(z, x, y) if not (C_Map.GetWorldPosFromMapPos and CreateVector2D) then return end
  local c, w = C_Map.GetWorldPosFromMapPos(z, CreateVector2D(x / 100, y / 100)); if c and w then return c, w.x, w.y end end
-- Distance in yards from the player to a point/step {z,x,y}; nil when unknown (never guessed).
function E:Distance(s)
  if not (s and s.z and s.x) then return nil end
  local pm, px, py = self:PlayerPos(); if not pm then return nil end
  local c1, a1, b1 = apiWorld(pm, px, py); local c2, a2, b2 = apiWorld(s.z, s.x, s.y)
  if not (c1 and c2) then
    local m = pm; while m and not (E.MAPB and E.MAPB[m]) do local i = C_Map.GetMapInfo and C_Map.GetMapInfo(m); local up = i and i.parentMapID
      if not up or up == 0 then m = nil else local p = C_Map.GetPlayerMapPosition(up, "player"); m = up; if p then px, py = p.x * 100, p.y * 100 end end end
    if not m then return nil end
    c1, a1, b1 = mapbWorld(m, px, py); c2, a2, b2 = mapbWorld(s.z, s.x, s.y)
  end
  if not (c1 and c2) or c1 ~= c2 then return nil end
  return math.sqrt((a1 - a2) ^ 2 + (b1 - b2) ^ 2)
end
E.MapbWorld = mapbWorld

-- P1-13: bounded saved tables. met/pat entries of guides behind the current one are dropped; failCb/cb/varRej capped.
local function cap(t, n) if type(t) ~= "table" then return end; local c = 0; for _ in pairs(t) do c = c + 1 end
  if c > n then for k in pairs(t) do t[k] = nil; c = c - 1; if c <= n then break end end end end
E.CAPS = { varRej = 100, failCb = 50, cb = 200, missed = 300, undead = 200, varSeen = 300 }
function E:PruneDB()
  if not (self.db and self.chain) then return end
  local behind = {}; for i = 1, (self.db.gi or 1) - 1 do local g = self.chain[i]; if g then behind[g.name] = true end end
  for _, t in ipairs({ "met", "pat" }) do local tb = self.db[t]
    if type(tb) == "table" then for k in pairs(tb) do local name = tostring(k):match("^(.-)#") ; if name and behind[name] then tb[k] = nil end end; cap(tb, 400) end end
  for k, n in pairs(self.CAPS) do cap(self.db[k], n) end
  if type(self.db.blocked) == "table" then while #self.db.blocked > 50 do table.remove(self.db.blocked, 1) end end
end
function E:Current() local g = self.chain and self.chain[self.db.gi]; return g, g and g.steps[self.db.step] end

function E:Advance()
  if self.AtLevelCap and self:AtLevelCap() then if self.Refresh then self:Refresh() end; return end
  local g = self.chain and self.chain[self.db.gi]; if not g then return end
  local i = self.db.step or 1
  if self.NormalTripTick then self:NormalTripTick(g,i) end
  while g.steps[i] and self:StepDone(g.steps[i]) do i = i + 1 end
  self.db.gname = g.name
  if not g.steps[i] and self.chain[self.db.gi + 1] then
    local nx = self.chain[self.db.gi + 1]
    if UnitLevel("player") < nx.lo - 1 and not g.gapAdded and self.GapStep then -- runtime level-gap fill
      local gs = self:GapStep(nx.lo); if gs then g.gapAdded = true; g.steps[#g.steps + 1] = gs; return self:Advance() end
    end
    self.db.gi, self.db.step = self.db.gi + 1, 1; return self:Advance()
  end
  self.db.step = math.max(1, math.min(i, #g.steps)); self:SavePos()
  if self.Refresh then self:Refresh() end
  if self.MissedCheck and not self.inMissed then self.inMissed = true; pcall(self.MissedCheck, self); self.inMissed = false end
end

function E:SkipKey(g, i) local s = g.steps[i]; return g.name .. "#" .. (s and self:StepId(s) or tostring(i)) end
-- Any step change by the user (Skip, Back, jump): drop the old arrow target and patrol state at once and
-- rebuild them for the new step, also in combat (one TomTom swap via the arrow controller's urgent path;
-- before v3.8.2 the old target stayed until combat ended or a later timer/event refreshed it).
function E:StepChanged(why)
  local _, cur = self:Current(); self.userStep = self:StepId(cur)       -- no automatic missed-pickup skip on a step the user chose (by id, P0-1)
  self:SavePos()
  if self.ResetWaypoint then self:ResetWaypoint() end
  if self.PatrolReenter then self:PatrolReenter(why) end
  self.urgentArrow = true
  if self.PatrolTick then pcall(self.PatrolTick, self) end
  if self.Refresh then self:Refresh() end
  self.urgentArrow = nil
  self:Debug("step change (" .. why .. ") -> arrow and patrol rebuilt")
end
function E:Skip()
  if self.AtLevelCap and self:AtLevelCap() then if self.SkipProgression then self:SkipProgression() end; return end
  local g, s = self:Current(); if not s then return end
  if self.FieldRegions and self.FieldRegions[s.normalTrip] then self:SkipRegion(s); return end
  if s.normalTrip then self:ChooseTrip("skip"); return end
  s.manualDone = true; self.db.skipped = self.db.skipped or {}; self.db.skipped[self:SkipKey(g, self.db.step)] = true
  self:Advance(); self:StepChanged("skip")
end
function E:Back()
  if self.AtLevelCap and self:AtLevelCap() then if self.RestoreProgression then self:RestoreProgression() end; return end
  local g = self.chain and self.chain[self.db.gi]; if not g then return end
  local i = math.max(1, self.db.step - 1)
  while i > 1 and self:IsInfo(g.steps[i]) do i = i - 1 end
  if g.steps[i] then g.steps[i].manualDone = nil; if self.db.skipped then self.db.skipped[self:SkipKey(g, i)] = nil end end; self.db.step = i
  self:StepChanged("back")
end

local f = CreateFrame("Frame")
f:RegisterEvent("ADDON_LOADED")
f:RegisterEvent("PLAYER_LOGIN")
f:RegisterEvent("PLAYER_LOGOUT")
f:RegisterEvent("PLAYER_REGEN_ENABLED")
f:RegisterEvent("ADDON_ACTION_BLOCKED")
f:RegisterEvent("ADDON_ACTION_FORBIDDEN")
E.evFrames = {}
-- every module registers its optional events here so the minimap toggle can unregister/re-register them all
-- What our code is doing right now: ADDON_ACTION_FORBIDDEN fires synchronously inside the offending call, so
-- the logger can name it even when the client reports func=UNKNOWN().
function E:Ctx(what, fn, ...) local prev = self.ctx; self.ctx = what; local r = { pcall(fn, ...) }; self.ctx = prev; return unpack(r) end
-- events this client forbids add-ons to register (fires ADDON_ACTION_FORBIDDEN, reported as UNKNOWN())
E.FORBIDDEN_EVENTS = { COMBAT_LOG_EVENT_UNFILTERED = true, COMBAT_LOG_EVENT = true }
function E:Events(frame, list)
  local ok = {}; for _, ev in ipairs(list) do if not self.FORBIDDEN_EVENTS[ev] then ok[#ok + 1] = ev end end
  self.evFrames[#self.evFrames + 1] = { frame, ok }
  for _, ev in ipairs(ok) do self:Ctx(TR:F("RegisterEvent %s", ev), frame.RegisterEvent, frame, ev) end
end
E:Events(f, { "QUEST_ACCEPTED", "QUEST_TURNED_IN", "QUEST_REMOVED", "QUEST_LOG_UPDATE", "UNIT_QUEST_LOG_CHANGED", "PLAYER_LEVEL_UP",
  "ZONE_CHANGED_NEW_AREA", "ZONE_CHANGED", "LEARNED_SPELL_IN_TAB", "PLAYER_CONTROL_GAINED",
  "QUEST_WATCH_UPDATE", "UI_INFO_MESSAGE", "UNIT_SPELLCAST_SUCCEEDED" })
-- P1-9: the one coalescer every noisy event uses. Bursts within 0.3 s become a single Advance (or Refresh).
local pending, later = false, false
function E:Poke()
  if pending or not self.db or self.disabled then return end
  pending = true
  C_Timer.After(0.3, function() pending = false; if E:O("autoAdvance") then E:Advance() elseif E.Refresh then E:Refresh() end end)
end
function E:PokeLater(sec)
  if later then return end; later = true
  C_Timer.After(sec or 1.5, function() later = false; E:Poke() end)
end
local function initDB()
  if E.db then return end
  _G[BRAND .. "_GuidepostDB"] = _G[BRAND .. "_GuidepostDB"] or {}
  E.db = _G[BRAND .. "_GuidepostDB"]
  E:Migrate(E.db)
  E.db.opt = E:ApplyDefaults(E.db.opt or {})
  -- M-P1-3: the old v3.8.3 "sounds off" step wrote through E.SHARED to Core's suite-wide Sounds setting and could undo a
  -- choice made in /beast. Sounds already default off in Core, so the step now only records that it ran.
  if not E.db.soundV383 then E.db.soundV383 = true end
  E.db.skipped = E.db.skipped or {}
  _G[BRAND .. "_GuidepostProfiles"] = _G[BRAND .. "_GuidepostProfiles"] or {}
end
f:SetScript("OnEvent", function(_, ev, a1, a2, ...)
  if ev == "ADDON_LOADED" then if a1 == BRAND .. "_Guidepost" then initDB() end return end
  if ev == "PLAYER_LOGOUT" then
    -- SavedVariables are written by the client after this event; make sure position is in the table
    if E.db and E.chain and E.chain[E.db.gi] then E.db.gname = E.chain[E.db.gi].name end
    if E.db then E.db.savedAt = time and time() or 0 end
    return
  end
  if ev == "QUEST_ACCEPTED" or ev == "QUEST_TURNED_IN" or ev == "QUEST_REMOVED" then E:QuestEvent(ev, a1, a2, ...) end
  if ev == "QUEST_ACCEPTED" and E.db then local id; for _, v in ipairs({ a1, a2, ... }) do if type(v) == "number" and v > 0 then id = v end end; if id then E:Unmiss(id) end end
  if E.disabled and not (ev == "ADDON_ACTION_BLOCKED" or ev == "ADDON_ACTION_FORBIDDEN" or ev == "PLAYER_REGEN_ENABLED" or ev == "PLAYER_LOGIN") then return end
  if (ev == "UNIT_QUEST_LOG_CHANGED" or ev == "UNIT_SPELLCAST_SUCCEEDED") and a1 ~= "player" then return end
  -- using a quest item / clicking an object: the quest log updates a moment later, so poll again after it
  if ev == "UNIT_SPELLCAST_SUCCEEDED" and E.db and not E.disabled then E:PokeLater(1.5) end   -- P1-9: one pending timer, not one per cast
  if ev == "ADDON_ACTION_BLOCKED" or ev == "ADDON_ACTION_FORBIDDEN" then
    -- record exactly what was blocked (any add-on) so the user can report it
    -- P1-13: only our own blocked actions are kept (another add-on's only in debug mode), at most 50 lines
    local ours = a1 and tostring(a1):find(E.brand)
    if E.db and (ours or E:O("debug")) then
      E.db.blocked = E.db.blocked or {}
      -- event args: addonName, functionName (the client sends "UNKNOWN()" when it cannot name it; ctx says what we were doing)
      local fn, ctx = tostring(a2 or "?"), E.ctx and (" during=" .. E.ctx) or ""
      table.insert(E.db.blocked, date("%H:%M:%S") .. " " .. ev .. " addon=" .. tostring(a1) .. " func=" .. fn .. ctx)
      while #E.db.blocked > 50 do table.remove(E.db.blocked, 1) end
      if a1 and tostring(a1):find(E.brand) then E:Print(TR:F("blocked: %s%s (please send /fennick debuglog output)", fn, ctx)) end
      E:Debug(ev .. " " .. tostring(a1) .. " " .. fn .. ctx)
    end
    return
  end
  if ev == "PLAYER_REGEN_ENABLED" then if E.db then E:FlushQueue() end return end
  if ev == "PLAYER_LOGIN" then
    initDB()
    E:Safe("init", function()
      if E.ClearStrayWaypoints then E:ClearStrayWaypoints() end
      if E.ArmLogGate then E:ArmLogGate("login") end
      if E.InitUI then E:InitUI() end; E:Start()   -- v3.9: ready only once the quest log has loaded (no fixed timer)
      for _, fn in ipairs(E.initHooks) do local ok, err = pcall(fn); if not ok then E:Debug("init hook: " .. tostring(err)) end end
      if not E:O("enabled") and E.SetEnabled then E:SetEnabled(false, true) end
      if not E.db.wizardDone and E.ShowSetup then E:ShowSetup() end
    end)
    return
  end
  if not E.db or E.disabled then return end
  E:Poke()
end)
-- arrival check for travel steps
C_Timer.NewTicker(1, function()
  if E.disabled or not E.db then return end
  if E.AtLevelCap and E:AtLevelCap() then return end
  local _, s = E:Current()
  if s and E.PatrolTick then E:PatrolTick() end   -- patrol arrow runs on this steady ticker: no TomTom callback, frame or autoAdvance dependency
  if not E:O("autoAdvance") then return end
  -- steady re-check of the current step: a missed/late quest log event never leaves a finished step on screen
  if s and E.userStep ~= E:StepId(s) and E:StepDone(s) then E:Advance() end
  if s and E.CheckWaypoint then E:CheckWaypoint(s) end
end)

-- P1-4 / K-1: no slash strings of our own any more; Beast Core owns /fennick, /beast and /fbc. The handler below is
-- registered with Core as subcommand "lvl" (/fennick lvl skip) and for the bare words Leveling owns (/fennick skip).
SlashCmdList.FENNICKGUIDE = function(msg)
  local cmd, arg = (msg or ""):match("^(%S*)%s*(.-)$"); cmd = cmd:lower()
  if cmd == "quest" then E:PrintQuestLocations(arg)
  elseif cmd == "wishlist" then
    local action, item, purpose = arg:match("^(%S+)%s*(%S*)%s*(%S*)$")
    if action == "add" or action == "remove" then
      local id = tonumber(item)
      purpose = purpose ~= "" and purpose or "specific"
      local ok
      if action == "add" then ok = E:AddItemGoal(id, purpose) else ok = E:RemoveItemGoal(id, purpose) end
      E:Print(ok and TR["Wishlist updated"] or TR["Invalid item or purpose"])
      if ok then E:ProgressionChanged() end
    elseif arg == "" or action == "list" then
      local goals = E:ItemGoals()
      if #goals == 0 then E:Print(TR["Wishlist is empty"]) end
      for _, goal in ipairs(goals) do
        local name, link
        if GetItemInfo then name, link = GetItemInfo(goal.item) end
        E:Print((link or name or TR["Item information unavailable"]) .. " - " .. table.concat(goal.purposes, ", "))
      end
    else E:Print("/fennick lvl wishlist add|remove <itemID> [current|future|appearance|specific|utility|collection]") end
  elseif cmd == "region" then E:ChooseRegion(arg:lower())
  elseif cmd == "secret" then E:ChooseTrip(arg:lower())
  elseif cmd == "nearby" then local g,s=E:Current(); local list=g and E:NormalTips(g,s,true) or {}; if #list==0 then E:Print("No eligible reviewed pickups for this guide.") end; for _,tip in ipairs(list) do E:Print(tip) end
  elseif cmd == "skip" then E:Skip() elseif cmd == "back" then E:Back()
  elseif cmd == "rules" and has(E.RULES, arg) then E:SetProfile("rules", arg)
  elseif cmd == "class" and arg ~= "" then E:SetProfile("class", arg:upper())
  elseif cmd == "route" and arg ~= "" then E:SetProfile("route", arg)
  elseif cmd == "list" then for i, g in ipairs(E.chain or {}) do E:Print(i .. ". " .. g.name .. " (" .. #g.steps .. ")") end
  elseif tonumber(cmd) and E.chain and E.chain[tonumber(cmd)] and not (E.AtLevelCap and E:AtLevelCap()) then E.db.gi, E.db.step, E.db.stepKey = tonumber(cmd), 1, nil; E:Advance()
  elseif cmd == "minimap" then local C = Fennick_BEAST; C:ToggleMinimap()   -- P1-7: the minimap button is Core's
    E:Print(TR:F("minimap button %s", (C.db.opt.minimap.hide and TR["hidden (/fennick minimap shows it)"] or TR["shown"])))
  elseif cmd == "config" or cmd == "options" or cmd == "settings" then if E.OpenSettings then E:OpenSettings() end
  elseif cmd == "toggle" or cmd == "on" or cmd == "off" then if E.SetEnabled then E:SetEnabled(cmd == "on" or (cmd == "toggle" and E.disabled)) end
  elseif cmd == "layout" then E:ToggleLayoutDebug()
  elseif cmd == "setup" then if E.ShowSetup then E:Safe("setup", function() E:ShowSetup() end) end
  elseif cmd == "hide" then if E.frame then E.frame:Hide() end
  elseif cmd == "role" or cmd == "loadout" then E:Safe("settings", function() Fennick_BEAST:OpenSettings() end)   -- old word kept: opens the Role setting
  elseif cmd == "debug" then E.db.opt.debug = not E:O("debug"); E.db.debug = nil; E:Print(TR:F("debug %s", (E:O("debug") and TR["ON (logs deferrals, TomTom/Questie calls in combat, blocked actions)"] or "OFF")))
  elseif cmd == "debuglog" then
    for _, l in ipairs(E.db.blocked or {}) do E:Print(l) end
    local log = E.db.debugLog or {}; for i = math.max(1, #log - 20), #log do if log[i] then E:Print(log[i]) end end
  elseif cmd == "prof" then
    local a = arg:lower()
    if a == "" or a == "detected" then E.db.profChoice = nil
    elseif a == "none" then E.db.profChoice = {}
    else local t = {}; for n in arg:gmatch("[^,]+") do t[#t + 1] = (n:gsub("^%s+", ""):gsub("%s+$", "")) end; E.db.profChoice = t end
    E:Print(TR:F("professions: %s", E:ProfSummary())); E:Advance()
  elseif cmd == "why" then for _, l in ipairs(E:Why()) do E:Print(l) end
  elseif cmd == "move" or cmd == "unlock" then if (msg or ""):lower():find("reset") then Fennick_BEAST.EditMode:ResetAll() else Fennick_BEAST:ToggleMove() end
  elseif cmd == "noauto" then if arg == "list" then local n = 0; for k, v in pairs(E:O("noAuto") or {}) do n = n + 1; E:Print(TR:F("don't automate: %s (%s)", tostring(v), k)) end; if n == 0 then E:Print(TR["don't-automate list is empty"]) end else E:ToggleNoAuto() end
  elseif cmd == "restore" then E:RestoreCVars()
  elseif cmd == "branch" then E:TakeBranch() elseif cmd == "main" then E:ReturnMain()
  elseif cmd == "escape" then E:ShowEscape(true)
  else if E.frame then E.frame:Show() end; E:Print(TR:F("route=%s class=%s rules=%s | /fennick skip|back|list|lvl <n>|hide | rules Normal|HC | branch | main | escape | role | debuglog | config | layout | toggle | noauto | restore | prof detected|none|Mining,Skinning | class WARRIOR | route Tauren|Undead|Durotar|DunMorogh|Westfall | /fennick help for Core commands", E.db.route, E.db.class, E.db.rules)) end
end
do
  local C = Fennick_BEAST
  local BARE = {}; for w in (TR["skip back rules class route list config options settings toggle on off layout hide role loadout debuglog prof branch main escape noauto restore"]):gmatch("%S+") do BARE[w] = true end
  C:RegisterSlash("lvl", function(arg, msg)
    if msg and arg == msg then SlashCmdList.FENNICKGUIDE(msg) else SlashCmdList.FENNICKGUIDE(arg) end end,
    "Leveling guide: skip, back, list, lvl <n>, rules, branch, main, escape, role, noauto, restore, toggle, config", BARE)
  -- /fennick debug (Core) also flips the Leveling debug log
  if C.slash.lvl then C.slash.lvl.onDebug = function() if E.db then E.db.opt.debug = C:O("debug"); E.db.debug = nil end end end
end

-- Key Bindings menu labels (Bindings.xml); these BINDING_* names are the documented way to label add-on bindings
BINDING_HEADER_FENNICK = TR["Fennick's Guidepost"]
BINDING_NAME_FENNICK_SKIP = TR["Skip step"]
BINDING_NAME_FENNICK_BACK = TR["Previous step"]
BINDING_NAME_FENNICK_TOGGLE = TR["Guide on/off"]
BINDING_NAME_FENNICK_SETTINGS = "Settings"
BINDING_NAME_FENNICK_ESCAPE = TR["Show PvP escape route"]
-- map pins (Core 1.5 broker): the current step and the next four, as quest givers, turn-ins or objectives
do local C = Fennick_BEAST
  if C and C.PublishMapPins then C:PublishMapPins("guidepost", function(map)
    local out = {}; local g = E.chain and E.db and E.chain[E.db.gi]; if not g then return out end
    for i = E.db.step or 1, math.min(#g.steps, (E.db.step or 1) + 4) do local s = E:ActionView(g.steps[i])
      if s and s.z == map and s.x and s.y then
        local cat = (s.t and s.t[1] and "qturnin") or (s.a and s.a[1] and "qavail") or ((s.c or s.mob) and "qobj") or nil
        if cat then out[#out + 1] = { cat = cat, name = (s.npc and s.npc:gsub("^%+", "")) or s.mob or TR["Guide step"], x = s.x / 100, y = s.y / 100, note = i == E.db.step and TR["Current step"] or TR["Coming up"] } end
      end
    end
    return out end) end
end
