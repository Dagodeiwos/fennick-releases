-- The single waypoint arrow: TomTom if installed (public AddWaypoint/RemoveWaypoint only), else the built-in arrow.
-- Ownership: only the focus owner (C:Owner()) may set or clear it. Any other module's request is refused (returns false).
local C = Fennick_BEAST
local uid
local arrow = CreateFrame("Frame", "Fennick_ArrowFrame", UIParent)
C.arrow = arrow
arrow:SetSize(56, 56); arrow:SetPoint("TOP", 0, -120); arrow:SetMovable(true); arrow:EnableMouse(true)
arrow:RegisterForDrag("LeftButton"); arrow:SetScript("OnDragStart", arrow.StartMoving); arrow:SetScript("OnDragStop", arrow.StopMovingOrSizing)
arrow.tex = arrow:CreateTexture(nil, "ARTWORK"); arrow.tex:SetAllPoints()
arrow.tex:SetTexture("Interface\\Minimap\\MinimapArrow")
arrow.text = Fennick_BEAST:NewFS(arrow, "OVERLAY", "GameFontNormal"); arrow.text:SetPoint("TOP", arrow, "BOTTOM", 0, -2)
arrow:Hide()
C.Skin:Add("arrow", arrow)

local target
local function worldOf(mapID, x, y)
  if not (C_Map and C_Map.GetWorldPosFromMapPos) then return end
  local c, w = C_Map.GetWorldPosFromMapPos(mapID, CreateVector2D(x, y)); return c, w
end
-- P2-16: the target's world position is computed once per target; the label text changes only when the yard count does
local function setText(self, s) if self.lastText ~= s then self.lastText = s; self.text:SetText(s) end end
arrow:SetScript("OnUpdate", function(self, el)
  self.t = (self.t or 0) + el; if self.t < 0.05 or not target then return end; self.t = 0
  local m = C_Map.GetBestMapForUnit("player"); local p = m and C_Map.GetPlayerMapPosition and C_Map.GetPlayerMapPosition(m, "player")
  if not p then setText(self, target.label); return end
  if target.c2 == nil then local c2, w2 = worldOf(target.z, target.x / 100, target.y / 100); target.c2 = c2 or false; target.wx = w2 and w2.x; target.wy = w2 and w2.y end
  local c1, w1 = worldOf(m, p.x, p.y)
  if not (w1 and target.wx) or c1 ~= target.c2 then setText(self, target.label); return end
  local dn, dw = target.wx - w1.x, target.wy - w1.y
  local fa = C:Facing()   -- nil during encounters (Forever 1.60.1): hide the pointer, keep the yard text
  if fa then self.tex:SetRotation(math.atan2(dw, dn) - fa); if not self.tex:IsShown() then self.tex:Show() end elseif self.tex:IsShown() then self.tex:Hide() end
  local yd = math.floor(math.sqrt(dn * dn + dw * dw))
  if yd ~= target.yd then target.yd = yd; setText(self, string.format("%s  %d yd", target.label, yd)) end
end)

-- ONE state machine: mode = "none" | "tomtom" | "builtin". Never both arrows, never more than one Fennick TomTom waypoint.
-- In combat TomTom is never touched (except an urgent request from the owner); the latest target is applied after combat.
local mode = "none"
local want = nil
local lastKey = nil
local wantBy = nil
function C:ArrowMode() return mode, uid, wantBy end
function C:ResetWaypoint() lastKey = nil end
function C:UseTomTom() return TomTom and TomTom.AddWaypoint and self:O("tomtom") end
local function dropTomTom() if uid and TomTom then C.ownRemove = true; pcall(TomTom.RemoveWaypoint, TomTom, uid); C.ownRemove = nil; C.ownUids[uid] = nil end; uid = nil end
function C:ArrowForget() uid = nil; mode = "none"; lastKey = nil end
local function hideBuiltin() target = nil; arrow:Hide() end
local function show(t) target = { z = t.z, x = t.x, y = t.y, label = t.label }; arrow:Show(); mode = "builtin" end
-- P2-17: only waypoints WE added (tracked uids) are ever removed; TomTom's internal tables are never read
C.ownUids = {}
function C:ClearStrayWaypoints()
  if not (TomTom and TomTom.RemoveWaypoint) or self:InCombat() then return 0 end
  local n = 0
  for wp in pairs(self.ownUids) do if wp ~= uid then self.ownRemove = true; pcall(TomTom.RemoveWaypoint, TomTom, wp); self.ownRemove = nil; n = n + 1 end; self.ownUids[wp] = nil end
  if uid then self.ownUids[uid] = true end
  return n
end
local function addTomTom(t)
  local ok, id = C:Ctx("TomTom:AddWaypoint", TomTom.AddWaypoint, TomTom, t.z, t.x / 100, t.y / 100,
    { title = t.label, persistent = false, minimap = true, world = true, crazy = true, cleardistance = 0, arrivaldistance = 0, silent = true, from = C.brand })
  if ok and id then uid = id; C.ownUids[id] = true; mode = "tomtom"; return true end
end
function C:ArrowKeyNow() local m = self.modules[self:Owner() or ""]; return m and self:Call(m, "StepKey") end
-- the owner says the user removed our TomTom waypoint by hand for this step (do not re-add until the step changes)
function C:ArrowClearedNow() local m = self.modules[self:Owner() or ""]; local c = self.arrowCleared or (m and self:Call(m, "ArrowCleared")); return c ~= nil and c == self:ArrowKeyNow() end
function C:ApplyArrow(urgent)
  local t = want
  if not urgent and self:ArrowClearedNow() then hideBuiltin(); return end
  local on = t and t.z and self:O("arrow") and not self.disabled
  if not on then if not self:InCombat() or mode ~= "tomtom" then dropTomTom(); hideBuiltin(); mode = "none" end; return end
  if self:InCombat() then
    -- P2-17: TomTom is not touched in combat. Single exception kept on purpose: an URGENT owner request (PvP/HC escape path)
    -- replaces our own TomTom waypoint (protected call), because leaving the old TomTom arrow up next to the built-in one = two arrows (RC-23).
    if urgent then
      if mode == "tomtom" or self:UseTomTom() then dropTomTom(); hideBuiltin(); if not addTomTom(t) then show(t) end else show(t) end
    elseif mode ~= "tomtom" then dropTomTom(); show(t) end
    self:Safe("waypoint", function() lastKey = nil; C:ApplyArrow() end)
    return
  end
  dropTomTom(); hideBuiltin()
  if self:UseTomTom() and addTomTom(t) then return end
  show(t)
end
-- PUBLIC for modules: returns true when the arrow is yours (focus owner) and the request was taken
function C:SetWaypointFor(key, s, label, force, urgent)
  if key ~= self:Owner() then self.refused = (self.refused or 0) + 1; return false end
  local k = s and s.z and (s.z .. ":" .. s.x .. ":" .. s.y) or "none"
  if k == lastKey and wantBy == key and not force then return true end
  lastKey = k; wantBy = key
  want = s and s.z and { z = s.z, x = s.x, y = s.y, label = string.format("%s (%.1f, %.1f)", label or "", s.x, s.y) } or nil
  self:ApplyArrow(urgent); return true
end
function C:ClearArrowFor(key) if key ~= self:Owner() then return false end; want = nil; lastKey = nil; dropTomTom(); hideBuiltin(); mode = "none"; return true end
-- focus moved to another module: the old owner's waypoint goes away at once
function C:ArrowOwnerChanged(prev, new)
  want, lastKey, wantBy = nil, nil, nil; self.arrowCleared = nil
  if not self:InCombat() then dropTomTom() end; hideBuiltin(); if mode ~= "tomtom" then mode = "none" end
  if new then local m = self.modules[new]; self:Call(m, "ArrowTaken") end
end
-- 1 s re-assert for the owner (TomTom dropped or reset our waypoint, or TomTom was enabled)
function C:CheckWaypointFor(key, t, label)
  if key ~= self:Owner() or self.disabled or not self:O("arrow") or self:InCombat() or not t then return end
  local lost = (mode == "tomtom" and not (TomTom and TomTom.IsValidWaypoint and TomTom:IsValidWaypoint(uid))) or mode == "none" or (mode == "builtin" and self:UseTomTom())
  if lost then lastKey = nil; self:SetWaypointFor(key, t, label) end
end
-- v1.5 map pin broker. Modules publish map pins with C:PublishMapPins(key, fn); fn(uiMap) returns
-- { { cat, name, x, y (0-1), note, done, level } }. Fennick's Cartographer draws them first. Without Cartographer the
-- current waypoint is mirrored to Blizzard's map pin (only when no pin of the player's own is set); TomTom stays the arrow.
C.mapPins = {}
function C:PublishMapPins(key, fn) if type(key) == "string" and type(fn) == "function" then self.mapPins[key] = fn; return true end; return false end
function C:MapPinsFor(map)
  local out = {}
  for key, fn in pairs(self.mapPins) do
    local ok, list = pcall(fn, map)
    if ok and type(list) == "table" then for _, p in ipairs(list) do if type(p) == "table" then p.from = key; out[#out + 1] = p end end end
  end
  return out
end
function C:Waypoint() return want end
local function cartographer() local K = rawget(_G, "Fennick_CARTOGRAPHER"); return type(K) == "table" and type(K.IsActive) == "function" and K:IsActive() and K or nil end
C.mirrored = nil
function C:MirrorWaypoint()
  local K = cartographer()
  if K then if K.Changed then pcall(K.Changed, K) end; return "cartographer" end
  if self:InCombat() or not (C_Map and C_Map.SetUserWaypoint and UiMapPoint and UiMapPoint.CreateFromCoordinates) then return nil end
  local has = C_Map.HasUserWaypoint and C_Map.HasUserWaypoint()
  if has and self.mirrored then   -- still ours only if the pin is exactly the point we set; else the player placed their own
    local m = self.mirrored; local ok, p = pcall(C_Map.GetUserWaypoint)
    local px, py = ok and p and p.position and p.position.x, ok and p and p.position and p.position.y
    if type(m) ~= "table" or not (ok and p and p.uiMapID == m.map and px and math.abs(px - m.x) < 1e-4 and math.abs(py - m.y) < 1e-4) then self.mirrored = nil end
  end
  if has and not self.mirrored then return nil end   -- the player's own pin: never replaced or cleared
  local t = want
  if not t then if self.mirrored and C_Map.ClearUserWaypoint then pcall(C_Map.ClearUserWaypoint) end; self.mirrored = nil; return nil end
  if C_Map.CanSetUserWaypointOnMap and not C_Map.CanSetUserWaypointOnMap(t.z) then return nil end
  local ok = pcall(C_Map.SetUserWaypoint, UiMapPoint.CreateFromCoordinates(t.z, t.x / 100, t.y / 100))
  self.mirrored = ok and { map = t.z, x = t.x / 100, y = t.y / 100 } or nil; return ok and "blizzard" or nil
end
local applyArrow = C.ApplyArrow
function C:ApplyArrow(...) local r = applyArrow(self, ...); pcall(self.MirrorWaypoint, self); return r end
