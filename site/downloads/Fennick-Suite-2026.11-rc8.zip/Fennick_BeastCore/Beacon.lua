-- Spirit Beacon protocol v1: manual observations, no relay or persistent peer records.
local C = Fennick_BEAST
if not C then return end
local TR = C.L
local prefix = "FennickCamp1"
local reports, lastSend, registered = {}, nil, false
local TTL, LIMIT = 120, 32
local function enabled() return C.db and C:ModDB("beacon").enabled == true end
function C:BeaconEnabled() return enabled() == true end
local function clock() return GetTime and GetTime() end
local function prune(now)
  for k,r in pairs(reports) do if now < r.received or now-r.received >= TTL then reports[k]=nil end end
end
local function register()
  if registered then return true end
  if not (C_ChatInfo and C_ChatInfo.RegisterAddonMessagePrefix) then return false end
  local ok, result = pcall(C_ChatInfo.RegisterAddonMessagePrefix, prefix)
  registered = ok and (result == true or (Enum and Enum.RegisterAddonMessagePrefixResult and (result ~= nil and (result == Enum.RegisterAddonMessagePrefixResult.Success or result == Enum.RegisterAddonMessagePrefixResult.DuplicatePrefix))))
  return registered
end
function C:SetBeaconEnabled(on)
  if not self.db then return false end
  if on == true and not register() then return false end
  self:ModDB("beacon").enabled = on == true
  if not on then reports = {} end
  return true
end
local function valid(z,x,y)
  return z and z > 0 and z <= 2147483647 and z%1 == 0 and x and x>=0 and x<=10000 and x%1==0 and y and y>=0 and y<=10000 and y%1==0
end
function C:ShareCampObservation()
  if not enabled() or not register() or not C_ChatInfo.SendAddonMessage then return false end
  local now = clock()
  if not now or (lastSend and now>=lastSend and now-lastSend<15) then return false end
  local channel = IsInRaid and IsInRaid() and "RAID" or IsInGroup and IsInGroup() and "PARTY"
  if not channel then return false end
  local z,x,y = self:PlayerPos()
  if not (z and x and y) then return false end
  x,y=math.floor(x*100+0.5),math.floor(y*100+0.5)
  if not valid(z,x,y) then return false end
  lastSend=now
  local ok,result=pcall(C_ChatInfo.SendAddonMessage,prefix,string.format("1:%d:%d:%d",z,x,y),channel)
  return ok and (result == true or (Enum and Enum.SendAddonMessageResult and result ~= nil and result == Enum.SendAddonMessageResult.Success))
end
C:On("PLAYER_LOGIN",function() if enabled() then register() end end)
C:On("GROUP_ROSTER_UPDATE",function() reports={} end)
C:On("PLAYER_ENTERING_WORLD",function() reports={} end)
local function groupSender(sender, channel)
  if not (UnitFullName and GetNumGroupMembers and IsInRaid) then return false end
  local raid = IsInRaid()
  if (raid and channel ~= "RAID") or (not raid and channel ~= "PARTY") then return false end
  local realm = GetNormalizedRealmName and GetNormalizedRealmName()
  local n = GetNumGroupMembers() or 0
  for i=1,math.min(n,40) do
    local unit = raid and ("raid"..i) or ("party"..i)
    local name, server = UnitFullName(unit)
    if name then
      server = server and server ~= "" and server or realm
      if (server and sender == name.."-"..server) or (sender == name and server == realm) then
        return not (UnitIsUnit and UnitIsUnit(unit,"player"))
      end
    end
  end
  return false
end
C:On("CHAT_MSG_ADDON",function(_,p,msg,channel,sender)
  if not enabled() or p~=prefix or (channel~="PARTY" and channel~="RAID") or type(sender)~="string" or #sender>128 or type(msg)~="string" or #msg>64 then return end
  if not (IsInGroup and IsInGroup()) or not groupSender(sender, channel) then return end
  local z,x,y=msg:match("^1:(%d+):(%d+):(%d+)$")
  z,x,y=tonumber(z),tonumber(x),tonumber(y)
  if not valid(z,x,y) then return end
  local now=clock(); if not now then return end
  prune(now)
  if reports[sender] and now-reports[sender].received<15 then return end
  local n=0; for _ in pairs(reports) do n=n+1 end
  if n>=LIMIT and not reports[sender] then return end
  reports[sender]={point={z=z,x=x/100,y=y/100},received=now}
end)
function C:CampObservations()
  local out,now={},clock()
  if not enabled() or not now then return out end
  prune(now)
  for _,r in pairs(reports) do
    out[#out+1]={point={z=r.point.z,x=r.point.x,y=r.point.y},age=now-r.received,source="peer",verified=false}
  end
  return out
end

-- Explicit controls; no automatic position transmission.
C:RegisterSlash("beacon", function(arg)
  arg = (arg or ""):lower():match("^%s*(.-)%s*$")
  if arg == "on" then
    C:Print(C:SetBeaconEnabled(true) and TR["Spirit Beacon enabled."] or TR["Spirit Beacon unavailable."])
  elseif arg == "off" then
    C:SetBeaconEnabled(false); C:Print(TR["Spirit Beacon disabled."])
  elseif arg == "share" then
    C:Print(C:ShareCampObservation() and TR["Camp observation submitted to group."] or TR["Camp observation not sent."])
  else
    C:Print(TR:F("Spirit Beacon: %s; /fennick beacon on|off|share", enabled() and TR["ON"] or TR["OFF"]))
  end
end, TR["Spirit Beacon: on, off, share"])
