-- Optional module material requests; advisory only, never reserves or consumes items.
local C = Fennick_BEAST
if not C then return end
local providers = {}
function C:RegisterMaterialProvider(key, fn)
  if type(key) ~= "string" or not self.modules[key] or type(fn) ~= "function" then return false end
  providers[key] = fn
  return true
end
function C:MaterialNeeds()
  local totals = {}
  for _, m in ipairs(self.order) do
    local fn = providers[m.key]
    if fn then
      local ok, rows = pcall(fn)
      if ok and type(rows) == "table" then
        for i = 1, math.min(#rows, 256) do
          local r = rows[i]
          if type(r) == "table" and type(r.item) == "number" and r.item > 0 and r.item <= 2147483647 and r.item % 1 == 0
            and type(r.count) == "number" and r.count > 0 and r.count <= 1000000 and r.count % 1 == 0 then
            local t = totals[r.item]
            if not t then t = { item = r.item, required = 0, modules = {} }; totals[r.item] = t end
            t.required = t.required + r.count
            t.modules[m.key] = (t.modules[m.key] or 0) + r.count
          end
        end
      elseif not ok then self:Debug("material provider: " .. m.key .. ": " .. tostring(rows)) end
    end
  end
  local out = {}
  for _, t in pairs(totals) do
    t.have = self:ItemCount(t.item)
    t.missing = math.max(0, t.required - t.have)
    out[#out + 1] = t
  end
  table.sort(out, function(a,b) return a.item < b.item end)
  return out
end

-- Optional, read-only opportunities. Coordinates follow Core's 0..100 convention.
local opportunities = {}
function C:RegisterOpportunityProvider(key, fn)
  if type(key) ~= "string" or not self.modules[key] or type(fn) ~= "function" then return false end
  opportunities[key] = fn
  return true
end
local function validPoint(p)
  return type(p) == "table" and type(p.z) == "number" and p.z > 0 and p.z % 1 == 0
    and type(p.x) == "number" and p.x >= 0 and p.x <= 100
    and type(p.y) == "number" and p.y >= 0 and p.y <= 100
end
function C:Opportunities()
  local out = {}
  for _, m in ipairs(self.order) do
    local fn = opportunities[m.key]
    if fn then
      local ok, rows = pcall(fn)
      if ok and type(rows) == "table" then
        local seen = {}
        for i = 1, math.min(#rows, 64) do
          local r = rows[i]
          if type(r) == "table" and type(r.id) == "string" and #r.id <= 80 and not seen[r.id]
            and type(r.label) == "string" and #r.label <= 512 and validPoint(r.point) then
            seen[r.id] = true
            local p = { z = r.point.z, x = r.point.x, y = r.point.y }
            out[#out + 1] = { module = m.key, id = r.id, label = r.label, point = p, yards = self:Yards(p.z, p.x, p.y) }
          end
        end
      end
    end
  end
  table.sort(out, function(a,b)
    local x,y = a.yards or math.huge,b.yards or math.huge
    if x ~= y then return x < y end
    if a.module ~= b.module then return a.module < b.module end
    return a.id < b.id
  end)
  return out
end


-- Shared visible-minimap update cadence; subscribers own their render caches.
local miniJobs, miniOrder, miniDriver = {}, {}, nil
local miniFailures, miniRetry = {}, {}
-- The tracking list identifies active spells. Our handoff distance is an estimate
-- in world yards, independent of map zoom; it does not imply a live spawn.
local gatheringSpells = {[2580]="ore", [2383]="herb"}
local tracked, trackingKey, trackingAt = {}, 0, nil
local function resourceKind(id, name, texture)
  if gatheringSpells[id] then return gatheringSpells[id] end
  for spell, kind in pairs(gatheringSpells) do
    local spellName = C_Spell and C_Spell.GetSpellName and C_Spell.GetSpellName(spell)
    local icon = C_Spell and C_Spell.GetSpellTexture and C_Spell.GetSpellTexture(spell)
    if GetSpellInfo and (not spellName or not icon) then
      local oldName, _, oldIcon = GetSpellInfo(spell)
      spellName, icon = spellName or oldName, icon or oldIcon
    end
    if (name and name == spellName) or (texture and texture == icon) then return kind end
  end
end

function C:GatheringTracking()
  local now = GetTime()
  if trackingAt and now >= trackingAt and now-trackingAt < 1 then return trackingKey end
  trackingAt = now
  tracked.ore, tracked.herb = nil, nil
  local api = C_Minimap
  local modern = api and api.GetNumTrackingTypes and api.GetTrackingInfo
  local count = modern and api.GetNumTrackingTypes or GetNumTrackingTypes
  local info = modern or GetTrackingInfo
  if count and info then
    for i=1,count() do
      local name, texture, active = info(i)
      local id
      if type(name) == "table" then
        local row = name
        name, texture, active, id = row.name, row.texture, row.active, row.spellID
      end
      if active == true or active == 1 then
        local kind = resourceKind(id, name, texture)
        if kind then tracked[kind] = true end
      end
    end
  elseif GetTrackingTexture then
    local kind = resourceKind(nil, nil, GetTrackingTexture())
    if kind then tracked[kind] = true end
  end
  trackingKey = (tracked.ore and 1 or 0) + (tracked.herb and 2 or 0)
  return trackingKey
end
C:On("MINIMAP_UPDATE_TRACKING", function() trackingAt = nil end)

function C:TrackedResourceNearby(kind, distanceSquared)
  return tracked[kind] and distanceSquared <= 100 * 100
end

function C:RegisterMinimapUpdate(key, fn)
  if type(key) ~= "string" or type(fn) ~= "function" or not CreateFrame then return false end
  if miniJobs[key] == nil then miniOrder[#miniOrder+1]=key end
  miniJobs[key]=fn; miniFailures[key]=nil; miniRetry[key]=nil
  if not miniDriver then
    miniDriver=CreateFrame("Frame")
    local elapsed=0
    miniDriver:SetScript("OnUpdate",function(_,dt)
      elapsed=elapsed+dt
      if elapsed<1/30 then return end
      elapsed=elapsed%(1/30)
      if not Minimap or not Minimap:IsVisible() then return end
      local map,x,y=C:PlayerPos()
      local rotating=C.MinimapRotates and C:MinimapRotates() or false
      local facing=0
      if rotating then facing=C.Facing and C:Facing() end
      local snapshot={map=map,x=x and x/100,y=y and y/100,rotating=rotating,facing=facing}
      local now=GetTime()
      for _,k in ipairs(miniOrder) do
        local job=miniJobs[k]
        if job and (not miniRetry[k] or now>=miniRetry[k]) then
          local ok,err=pcall(job,snapshot)
          if ok then miniFailures[k]=nil; miniRetry[k]=nil
          else
            local failures=(miniFailures[k] or 0)+1
            miniFailures[k]=failures
            miniRetry[k]=now+math.min(60,2^math.min(failures,6))
            C:Debug("minimap update retry: "..k..": "..tostring(err))
          end
        end
      end
    end)
  end
  return true
end


-- Static map conversions only; moving positions must bypass this bounded cache.
local worldCache, worldCount = {}, 0
function C:MapWorldPosition(map,x,y,static)
  if type(map)~="number" or type(x)~="number" or type(y)~="number" or not (x>=0 and x<=1 and y>=0 and y<=1) then return end
  if not (C_Map and C_Map.GetWorldPosFromMapPos and CreateVector2D) then return end
  local key=static and string.format("%d:%.12f:%.12f",map,x,y)
  local hit=key and worldCache[key]
  if hit then return hit[1],hit[2],hit[3] end
  local ok,cont,v=pcall(C_Map.GetWorldPosFromMapPos,map,CreateVector2D(x,y))
  if not ok or not cont or not v then return end
  local wx,wy=v.x,v.y
  if v.GetXY then wx,wy=v:GetXY() end
  if type(wx)~="number" or type(wy)~="number" then return end
  if key then
    if worldCount>=4096 then worldCache={}; worldCount=0 end
    worldCache[key]={cont,wx,wy}; worldCount=worldCount+1
  end
  return cont,wx,wy
end
C:On("PLAYER_ENTERING_WORLD",function() worldCache={}; worldCount=0 end)
