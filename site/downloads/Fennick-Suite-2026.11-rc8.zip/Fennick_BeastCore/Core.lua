-- Fennick's Beast Core: module registry, focus arbiter (who owns the arrow and the window), settings, combat-safe queue.
-- Generic only: no module content lives here. Modules register with C:RegisterModule{...}. Original code.
local BRAND = "Fennick"
local C = { brand = BRAND, modules = {}, order = {}, queue = {}, initHooks = {}, slash = {}, slashOrder = {}, listeners = {} }
do
-- ---------- shared localization (Core 1.3) ----------
-- Strings are keyed by their English text; a missing key returns the English text (so English never changes).
-- L:F(fmt, ...) formats with string.format; translations may reorder args with %1$s / %2$s. Any format error falls back
-- to the English format. Translations are added only for the running client language (C:AddTranslations).
local GAME = (GetLocale and GetLocale()) or "enUS"
local ALIAS = { enGB = "enUS", esMX = "esES", ptPT = "ptBR" }   -- fallback chain
local LOCALE = ALIAS[GAME] or GAME
local T = {}                                                    -- English key -> translated text (current locale only)
local L = setmetatable({}, { __index = function(_, k) local v = T[k]; if v ~= nil then return v end; return k end })
local META = { locale = LOCALE, game = GAME, machine = false, tables = T }

-- %n$s reordering: Lua 5.1 string.format has no positional args, so rewrite to plain order first
local function reorder(fmt, ...)
  if not fmt:find("%%%d+%$") then return string.format(fmt, ...) end
  local args, out = { ... }, {}
  local spec = fmt:gsub("%%(%d+)%$([%-%+ #0]*%d*%.?%d*[sdfgixXqc])", function(n, f) out[#out + 1] = args[tonumber(n)]; return "%" .. f end)
  return string.format(spec, unpack(out))
end
function L:F(fmt, ...)
  local tr = T[fmt]
  if tr then local ok, s = pcall(reorder, tr, ...); if ok then return s end end
  local ok, s = pcall(string.format, fmt, ...); if ok then return s end
  return fmt
end
function L:Locale() return LOCALE end
function L:IsMachine() return META.machine == true end
-- add a table for one locale; ignored unless it matches the client (after the fallback chain)
function L:Add(loc, tbl, machine)
  if (ALIAS[loc] or loc) ~= LOCALE or type(tbl) ~= "table" then return false end
  for k, v in pairs(tbl) do if type(k) == "string" and type(v) == "string" and v ~= "" then T[k] = v end end
  if machine then META.machine = true end
  return true
end
-- non-Latin client fonts: Cinzel has no Cyrillic or CJK glyphs, so titles fall back to the client font there
L.NO_LATIN_TITLE = { ruRU = true, koKR = true, zhCN = true, zhTW = true }
function L:LatinTitles() return not self.NO_LATIN_TITLE[GAME] end
C.L = L
end
local TR = C.L
-- 1.2 (P1-1): integer module API level. 1 = Beast Core 1.0, 2 = 1.1 (Look, ItemCooldown/AuraLeft/Yards/Duration), 3 = 1.2
-- (RegisterSlash, C:On, C.idleSince, C.dirty, StatusColor). Modules set m.minAPI; a missing C.API means 1. Never compare version strings.
-- 4 = 1.5; 5 = 1.6 (C:MapTip aggregate map tooltip, shared pin art C:PinPath, C:CopyBox, /fennick report, error ring).
C.API = 6
-- live server date (realm calendar when the client has it, else the local clock): {year, month, day}
function C:ServerDate()
  if C_DateAndTime and C_DateAndTime.GetCurrentCalendarTime then local ok, t = pcall(C_DateAndTime.GetCurrentCalendarTime)
    if ok and type(t) == "table" and t.year then return { year = t.year, month = t.month, day = t.monthDay or t.day } end end
  local t = date and date("*t", GetServerTime and GetServerTime() or nil); return t and { year = t.year, month = t.month, day = t.day } or nil
end
-- key of the current daily-quest day: changes exactly at the realm's daily reset (P2-13), local date only as a fallback
function C:DailyKey()
  local left = (C_DateAndTime and C_DateAndTime.GetSecondsUntilDailyReset and C_DateAndTime.GetSecondsUntilDailyReset()) or (GetQuestResetTime and GetQuestResetTime())
  local now = GetServerTime and GetServerTime() or (time and time())
  if tonumber(left) and tonumber(now) then return "r" .. math.floor((now + left) / 3600 + 0.5) end
  return date and date("%Y-%m-%d") or "?"
end
C.SCHEMA = 2   -- Fennick_CoreDB schema version (P2-4)
_G[BRAND .. "_BEAST"] = C
function C:AddTranslations(loc, tbl, machine) return self.L and self.L:Add(loc, tbl, machine) end

-- Shared look/arrow settings (per character, Fennick_CoreDB.opt). Modules keep their own settings.
C.DEFAULTS = { arrow = true, tomtom = true, sound = false, preset = "default", alpha = 0.75, fontOffset = 0, match = "auto", pixelBorder = false, scale = 1, lock = false,
  width = 400, pad = 16, rowGap = 8, lineSpacing = 4, guideMax = 3, windowHidden = false, focusOn = "auto", riders = true, debug = false,
  lsmBar = "Default", lsmBorder = "Default", lsmBackground = "Default", externalSkin = false, colorblind = false,
  posProfile = false, gridSnap = false, tooltip = true, tipCombat = false, tipMax = 8, tipLastSeen = true, tester = false, tipLines = {}, cues = {}, minimap = { hide = false, minimapPos = 200 } }
C.db = { opt = {} }   -- fallback before ADDON_LOADED (and if saved data is broken): every read still works
function C:O(k) local o = self.db and self.db.opt; if o and o[k] ~= nil then return o[k] end; return self.DEFAULTS[k] end
function C:Set(k, v) self.db.opt[k] = v end
function C:InCombat() return InCombatLockdown and InCombatLockdown() end
-- Forever 1.60.1: minimap rotation / player facing is blocked to add-ons during encounters and may come back as a secret
-- value (arithmetic on a secret throws) or nil. C:Facing() returns a plain number or nil; callers skip rotation on nil.
function C:Facing()
  if not GetPlayerFacing then return nil end
  if IsEncounterInProgress then local ok, e = pcall(IsEncounterInProgress); if not ok or e then return nil end end
  local ok, v = pcall(GetPlayerFacing); if not ok or v == nil then return nil end
  if issecretvalue then local ok2, sec = pcall(issecretvalue, v); if not ok2 or sec then return nil end end
  if type(v) ~= "number" or v ~= v then return nil end
  return v
end
-- true when the "Rotate minimap" option is on (a protected/odd CVar read counts as off)
function C:MinimapRotates()
  if not GetCVar then return false end
  local ok, v = pcall(GetCVar, "rotateMinimap"); return ok and v == "1"
end
function C:Print(msg) if DEFAULT_CHAT_FRAME then DEFAULT_CHAT_FRAME:AddMessage("|cff33ccff" .. BRAND .. ":|r " .. tostring(msg)) end end
-- Sound cues (COMBINED M-N-4): Core owns audio, as it owns the arrow. A module registers a cue once and plays it with
-- C:Cue(key). Nothing plays unless the master Sounds setting AND the cue's own toggle are on; every cue starts off (M-P2-5).
-- Modules never call cues on teleport or waypoint arrival (RSA S16).
C.cues, C.cueOrder = {}, {}
function C:RegisterCue(key, label, kit, fallback)
  if type(key) ~= "string" or self.cues[key] then return end
  self.cues[key] = { key = key, label = label or key, kit = kit, id = fallback }; self.cueOrder[#self.cueOrder + 1] = key
end
function C:CueEnabled(key) local t = self.db and self.db.opt and self.db.opt.cues; return type(t) == "table" and t[key] == true end
function C:SetCue(key, on) local o = self.db.opt; if type(o.cues) ~= "table" then o.cues = {} end; o.cues[key] = on and true or nil end
function C:CueOn(key) return self.cues[key] ~= nil and self:O("sound") == true and self:CueEnabled(key) end
function C:Cue(key)
  local c = self.cues[key]; local id = c and ((SOUNDKIT and c.kit and SOUNDKIT[c.kit]) or c.id)
  if id and PlaySound and self:CueOn(key) then pcall(PlaySound, id); return true end   -- the only PlaySound in the suite's Core
  return false
end
function C:Debug(msg) if self:O("debug") then self:Print("|cff999999" .. tostring(msg) .. "|r") end end
function C:Ctx(what, fn, ...) local prev = self.ctx; self.ctx = what; local r = { pcall(fn, ...) }; self.ctx = prev; return unpack(r) end
-- anything that creates/shows UI or touches another add-on waits for the end of combat (one entry per key)
function C:Safe(key, fn)
  if self:InCombat() then self.queue[key] = fn; return end
  local ok, err = pcall(fn); if not ok then self:Debug(key .. ": " .. tostring(err)) end
end
function C:FlushQueue() local q = self.queue; self.queue = {}; for k, fn in pairs(q) do local ok, err = pcall(fn); if not ok then self:Debug(k .. ": " .. tostring(err)) end end end

-- Modules -------------------------------------------------------------------------------------------
-- m = { key, label, priority (lower wins in Auto), HasStep(), View() -> {title, sub, lines, obj, guidance, point={z,x,y,label}},
--       Rider() -> one short line or nil (cheap; used when another module owns focus), Toggle(), OpenSettings(), Status(tt),
--       ownWindow = true when the module draws its own window (Core's window then stays hidden while it owns focus) }
function C:RegisterModule(m)
  assert(type(m) == "table" and type(m.key) == "string", "module needs a key")
  if self.modules[m.key] then return self.modules[m.key] end
  if (tonumber(m.minAPI) or 1) > self.API then   -- P1-1: refuse cleanly, one chat line, never a Lua error
    self.refusedModules = self.refusedModules or {}
    if not self.refusedModules[m.key] then self.refusedModules[m.key] = true
      -- M-P2-3: plain language, never "API n"; one line per refused module
      local who = m.label and TR:F("Fennick %s", m.label) or m.key
      if m.needs then self:Print(TR:F("%s needs a newer Fennick's Beast Core (%s+). Please update Beast Core.", who, m.needs))
      else self:Print(TR:F("%s needs a newer Fennick's Beast Core. Please update Beast Core to the latest version.", who)) end end
    return nil
  end
  m.priority = m.priority or 50; self.modules[m.key] = m; self.order[#self.order + 1] = m
  table.sort(self.order, function(a, b) if a.priority ~= b.priority then return a.priority < b.priority end return a.key < b.key end)
  if self.OnModulesChanged then self:OnModulesChanged() end
  return m
end
function C:Installed() local t = {}; for _, m in ipairs(self.order) do t[#t + 1] = m end; return t end
function C:Module(key) return self.modules[key] end
local function call(m, fn, ...) if m and type(m[fn]) == "function" then local ok, a, b = pcall(m[fn], m, ...); if ok then return a, b end; C:Debug(m.key .. "." .. fn .. ": " .. tostring(a)) end end
C.Call = function(_, m, fn, ...) return call(m, fn, ...) end
-- Focus choices: only installed modules, plus Auto
function C:FocusChoices() local t = { "auto" }; for _, m in ipairs(self.order) do t[#t + 1] = m.key end; return t end
function C:FocusLabel(k) if k == "auto" then return "Auto" end; local m = self.modules[k]; return m and m.label or k end
function C:SetFocus(k)
  if k ~= "auto" and not self.modules[k] then return false end
  self.db.opt.focusOn = k; self:ReassessOwner(TR["focus choice"]); return true
end
-- The one owner of the arrow and the focus window. A chosen focus that is not installed falls back to Auto.
function C:Owner()
  local f = self:O("focusOn")
  if f ~= "auto" and self.modules[f] then return f end
  -- P1-5 / K-8: in Auto a module with something to do RIGHT HERE (m:HereNow(), cheap/cached) takes focus temporarily while you
  -- stand still for 10 s (never mid-pull or while travelling); otherwise the first module (priority order) with a step owns it.
  local idle = self.idleSince and GetTime and (GetTime() - self.idleSince) >= 10
  if idle and not self:InCombat() then for _, m in ipairs(self.order) do if call(m, "HereNow") then return m.key end end end
  for _, m in ipairs(self.order) do if call(m, "HasStep") then return m.key end end
  -- nothing to do anywhere: the first module that is not finished for good (m:Finished(), e.g. a module done at max level)
  for _, m in ipairs(self.order) do if not call(m, "Finished") then return m.key end end
  return self.order[1] and self.order[1].key or nil
end
function C:ReassessOwner(why)
  local o = self:Owner()
  if o ~= self.lastOwner then
    local prev = self.lastOwner; self.lastOwner = o
    if self.ArrowOwnerChanged then self:ArrowOwnerChanged(prev, o) end
    for _, m in ipairs(self.order) do call(m, "FocusChanged", o, prev) end
    self:Debug("focus owner: " .. tostring(prev) .. " -> " .. tostring(o) .. " (" .. tostring(why) .. ")")
  end
  if self.RefreshWindow then self:RefreshWindow() end
  for _, fn in ipairs(self.reassessHooks) do pcall(fn, o, why) end
  return o
end
-- v1.5.1 hook point: fn(owner, why) runs after every owner re-check (1 s tick, login, focus choice); pcall-guarded
C.reassessHooks = C.reassessHooks or {}
function C:OnReassess(fn) if type(fn) == "function" then self.reassessHooks[#self.reassessHooks + 1] = fn; return true end; return false end
-- along-the-way lines from every module that does NOT own focus (cheap calls only; never moves the arrow)
function C:Riders(owner)
  local out = {}; if not self:O("riders") then return out end
  for _, m in ipairs(self.order) do if m.key ~= owner then local r = call(m, "Rider"); if type(r) == "string" and r ~= "" then out[#out + 1] = r end end end
  return out
end

-- Saved data guard: only a wrong-typed table is reset, never the whole profile
function C:GuardDB(db)
  if type(db.opt) ~= "table" then db.opt = {} end
  for k, v in pairs(self.DEFAULTS) do
    local o = db.opt[k]
    if o ~= nil and type(o) ~= type(v) then db.opt[k] = nil end
    if type(v) == "table" and type(db.opt[k]) ~= "table" then db.opt[k] = {}; for k2, v2 in pairs(v) do db.opt[k][k2] = v2 end end
  end
  if type(db.mod) ~= "table" then db.mod = {} end
end
-- P2-4: schema-versioned migrations. Keys are renamed or dropped ONLY by an explicit step here; anything unknown is kept
-- aside in db._unknown (never silently deleted because a default changed).
C.MIGRATIONS = {
  [2] = function(db)   -- 1.0/1.1 -> 1.2: unknown option keys move to _unknown instead of being pruned
    db._unknown = type(db._unknown) == "table" and db._unknown or {}
    for k, v in pairs(db.opt) do if C.DEFAULTS[k] == nil then db._unknown[k] = v; db.opt[k] = nil end end
  end,
}
function C:Migrate(db)
  local v = tonumber(db.v) or 1
  if v ~= v or v < 1 or v == math.huge or v % 1 ~= 0 then v = 1 end
  self.migrationFailed = nil
  for n = v + 1, self.SCHEMA do
    local step = self.MIGRATIONS[n]
    if step then
      local ok, err = pcall(step, db)
      if not ok then
        db.v = n - 1
        self.migrationFailed = n
        self:Debug("migration " .. n .. ": " .. tostring(err))
        return false
      end
    end
    db.v = n
  end
  db.v = math.max(v, self.SCHEMA)
  return true
end
-- per-module saved table inside Fennick_CoreDB (modules may also keep their own SavedVariables)
C:GuardDB(C.db)
function C:ModDB(key) self.db.mod = self.db.mod or {}; self.db.mod[key] = type(self.db.mod[key]) == "table" and self.db.mod[key] or {}; return self.db.mod[key] end

local f = CreateFrame("Frame")
C.eventFrame = f
f:RegisterEvent("ADDON_LOADED"); f:RegisterEvent("PLAYER_LOGIN"); f:RegisterEvent("PLAYER_REGEN_ENABLED"); f:RegisterEvent("PLAYER_LOGOUT")
local function initDB()
  if C.loaded then return end
  local db = _G.Fennick_CoreDB; if type(db) ~= "table" then db = {} end
  local prof = _G.Fennick_CoreProfiles; if type(prof) ~= "table" then prof = {} end; _G.Fennick_CoreProfiles = prof
  prof.seen = type(prof.seen) == "table" and prof.seen or {}
  local me = (GetRealmName and GetRealmName() or "?") .. "-" .. (UnitName and UnitName("player") or "?")
  -- saved data self-check: this character wrote a marker at its last logout; if it is missing now, the client did not load it
  C.svMissing = prof.seen[me] and not db.savedMarker or nil
  C.charKey = me
  _G.Fennick_CoreDB = db; C:GuardDB(db); C:Migrate(db); C.db = db; C.loaded = true
  if C.svMissing then C:Debug("saved settings were not loaded this session (marker missing)") end
end
function C:WhyLines()
  local t = {}
  if self.svMissing then t[#t + 1] = TR["Saved settings did not load this session (the marker written at your last logout is missing); defaults are in use."] end
  if self.EditMode and self.EditMode.why then t[#t + 1] = TR:F("Moving frames: %s", self.EditMode.why) end
  for _, m in ipairs(self.order) do if type(m.WhyLines) == "function" then local ok, r = pcall(m.WhyLines, m); if ok and type(r) == "table" then for _, l in ipairs(r) do t[#t + 1] = l end end end end
  local o = self:Owner(); t[#t + 1] = TR:F("Focus: %s%s", self:FocusLabel(self:O("focusOn")), (o and (TR:F(" (window and arrow follow %s)", self:FocusLabel(o))) or TR[" (no modules installed)"]))
  return t
end
C.InitDB = initDB
-- P2-21: one shared event frame for modules (C:On(event, fn)); handlers run protected
-- events this client forbids add-ons to register (ADDON_ACTION_FORBIDDEN, reported as UNKNOWN()); refused for every module
C.FORBIDDEN_EVENTS = { COMBAT_LOG_EVENT_UNFILTERED = true, COMBAT_LOG_EVENT = true }
function C:On(ev, fn)
  if self.FORBIDDEN_EVENTS[ev] then self:Debug("event refused (forbidden on this client): " .. tostring(ev)); return nil end
  if type(ev) ~= "string" or ev == "" or type(fn) ~= "function" then return nil end
  local l = self.listeners[ev]
  if not l then
    local ok, result = pcall(f.RegisterEvent, f, ev)
    if not ok or result == false then self:Debug("event registration failed: " .. ev); return nil end
    l = {}; self.listeners[ev] = l
  end
  for _, existing in ipairs(l) do if existing == fn then return fn end end
  l[#l + 1] = fn; return fn
end
local function dispatch(ev, ...) local l = C.listeners[ev]; if l then for _, fn in ipairs(l) do local ok, err = pcall(fn, ev, ...); if not ok then C:Debug(ev .. ": " .. tostring(err)) end end end end
f:SetScript("OnEvent", function(_, ev, a1, ...)
  dispatch(ev, a1, ...)
  if ev == "ADDON_LOADED" then if a1 == "Fennick_BeastCore" then initDB() end return end
  if ev == "PLAYER_REGEN_ENABLED" then C:FlushQueue(); return end
  if ev == "PLAYER_LOGOUT" then if C.loaded then C.db.savedMarker = time and time() or 1; if C.charKey then _G.Fennick_CoreProfiles.seen[C.charKey] = true end end return end
  if ev == "PLAYER_LOGIN" then
    initDB()
    C:Safe("core init", function()
      for _, fn in ipairs(C.initHooks) do local ok, err = pcall(fn); if not ok then C:Debug("init: " .. tostring(err)) end end
      C:ReassessOwner("login")
      if not C.db.wizardDone and C.ShowSetup and not C.setupDeferred then C:ShowSetup() end
    end)
  end
end)
-- owner re-check and window refresh (cheap): picks up a module finishing its steps in Auto
-- P1-12: the tick only re-checks; RefreshWindow early-returns when the view did not change. P2-21: C.idleSince (standing still, out of combat).
local function tick()
  local still = GetUnitSpeed and GetUnitSpeed("player") == 0 and not C:InCombat()
  if still then C.idleSince = C.idleSince or (GetTime and GetTime() or 0) else C.idleSince = nil end
  if C.loaded then C:ReassessOwner("tick") end
end
C.Tick = tick
if C_Timer and C_Timer.NewTicker then C_Timer.NewTicker(1, tick) end

-- P1-4 / K-1: Core owns every Fennick slash command. "/fennick", "/beast" and "/fbc" are aliases.
-- Modules add subcommands with C:RegisterSlash(key, fn(arg, msg), help); "/fennick <key> ..." runs them. Unknown input prints help.
SLASH_FENNICKCORE1 = "/fennick"; SLASH_FENNICKCORE2 = "/beast"; SLASH_FENNICKCORE3 = "/fbc"
C.CORE_HELP = { { "setup", TR["run the setup again"] }, { "move", TR["move/size frames (move reset)"] }, { "why", TR["what each module is waiting for"] },
  { "focuson", TR["focus: auto or a module key"] }, { "minimap", TR["show/hide the minimap button"] }, { "debug", TR["debug messages on/off"] },
  { "report", TR["copy a bug report text (version, add-ons, recent errors)"] }, { "tester", TR["tester mode on/off (saves recent errors on this PC only)"] }, { "help", TR["this list"] } }
function C:RegisterSlash(key, fn, help, bare)
  key = tostring(key):lower(); if type(fn) ~= "function" then return false end
  local core = { setup = 1, move = 1, why = 1, focuson = 1, follow = 1, debug = 1, help = 1, minimap = 1, report = 1, tester = 1 }
  if core[key] then return false end
  if not self.slash[key] then self.slashOrder[#self.slashOrder + 1] = key end
  self.slash[key] = { fn = fn, help = help, bare = type(bare) == "table" and bare or nil }; return true
end
function C:SlashHelp()
  self:Print(TR["commands (/fennick, /beast or /fbc):"])
  for _, h in ipairs(self.CORE_HELP) do self:Print("  " .. h[1] .. " - " .. h[2]) end
  for _, k in ipairs(self.slashOrder) do local r = self.slash[k]; self:Print("  " .. k .. (r.help and (" - " .. r.help) or "")) end
  self:Print("  " .. TR["<module> help - a few lines of help for one module (for example /fennick trail help)"])
  self:Print(TR:F("bug reports: %s (/fennick report copies the text to paste)", self.BUG_URL or "github.com/Dagodeiwos/fennick-releases/issues"))
  -- M-P2-9: what's installed, one line per module
  self:Print(TR["installed modules:"])
  if #self.order == 0 then self:Print("  " .. TR["no modules yet (the core works on its own: arrow, look and the monster tooltip)."]) end
  for _, line in ipairs(self:ModuleSummary()) do self:Print("  " .. line) end
end
-- M-P2-9: one line per installed module ("label: summary"), used by setup and /beast help
function C:ModuleSummary()
  local out = {}
  for _, m in ipairs(self.order) do out[#out + 1] = (m.summary and (m.label .. ": " .. m.summary)) or m.label end
  return out
end
SlashCmdList.FENNICKCORE = function(msg)
  local cmd, arg = (msg or ""):match("^(%S*)%s*(.-)$"); cmd = cmd:lower(); local larg = arg:lower()
  cmd = (C.SLASH_ALIAS and C.SLASH_ALIAS[cmd]) or cmd   -- /fennick guide -> lvl
  if cmd == "" then C:OpenSettings()
  elseif cmd == "setup" then C:ShowSetup()
  elseif cmd == "move" or cmd == "unlock" then if larg == "reset" then C.EditMode:ResetAll(); C:Print(TR["all Fennick frames reset"]) else C:ToggleMove() end
  elseif cmd == "why" then for _, l in ipairs(C:WhyLines()) do C:Print(l) end
  elseif cmd == "focuson" or cmd == "follow" then
    if larg ~= "" and C:SetFocus(larg) then C:Print(TR:F("focus: %s", C:FocusLabel(larg))) else
      local t = {}; for _, k in ipairs(C:FocusChoices()) do t[#t + 1] = k end; C:Print(TR:F("focus choices: %s", table.concat(t, ", "))) end
  elseif cmd == "minimap" then C:ToggleMinimap(); C:Print(TR:F("minimap button %s", (C.db.opt.minimap.hide and TR["hidden (/fennick minimap shows it)"] or TR["shown"])))
  elseif cmd == "debug" then C.db.opt.debug = not C:O("debug"); C:Print(TR:F("debug %s", (C:O("debug") and TR["on"] or TR["off"])))
    for _, k in ipairs(C.slashOrder) do local r = C.slash[k]; if r.onDebug then pcall(r.onDebug) end end
  elseif (larg == "help" or larg == "?") and C.HelpLines and C:HelpLines(cmd) then C:PrintHelp(cmd)
  elseif cmd == "report" then if C.ShowReport then C:ShowReport() end
  elseif cmd == "tester" then if C.SetTester then local on = (larg == "on") or (larg ~= "off" and not C:Tester()); C:SetTester(on); C:Print(TR:F("tester mode %s", (on and TR["on"] or TR["off"]))) end
  elseif cmd == "help" or cmd == "?" then C:SlashHelp()
  elseif C.slash[cmd] then local ok, err = pcall(C.slash[cmd].fn, arg, msg); if not ok then C:Debug("/" .. cmd .. ": " .. tostring(err)) end
  else
    -- a module may claim bare words it owns (e.g. "skip"): first module whose resolver accepts the command
    for _, k in ipairs(C.slashOrder) do local r = C.slash[k]; if r.bare and r.bare[cmd] then local ok, err = pcall(r.fn, msg, msg); if not ok then C:Debug(tostring(err)) end; return end end
    C:Print(TR:F("unknown command: %s", cmd)); C:SlashHelp()
  end
end

-- N-12: Core API self-test (debug line only; every caller already has a fallback)
C.API_NEEDED = { "C_Map.GetBestMapForUnit", "C_Map.GetPlayerMapPosition", "C_Map.GetWorldPosFromMapPos", "C_Timer.After", "C_Timer.NewTicker",
  "C_CurrencyInfo.GetCurrencyInfo", "C_DateAndTime.GetSecondsUntilDailyReset", "C_DateAndTime.GetCurrentCalendarTime", "GetItemCount", "GetFactionInfoByID", "UnitXPMax", "GetXPExhaustion" }
function C:ApiSelfTest()
  local miss = {}
  for _, path in ipairs(self.API_NEEDED) do
    local t = _G; for part in path:gmatch("[^%.]+") do t = type(t) == "table" and t[part] or nil end
    if type(t) ~= "function" then miss[#miss + 1] = path end
  end
  self.apiMissing = miss
  if #miss > 0 then self:Debug("API missing (fallbacks used): " .. table.concat(miss, ", ")) end
  return miss
end
C.initHooks[#C.initHooks + 1] = function() C:ApiSelfTest() end
