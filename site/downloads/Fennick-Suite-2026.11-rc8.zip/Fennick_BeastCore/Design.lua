local TR = (Fennick_BEAST and Fennick_BEAST.L) or setmetatable({ F = function(_, f, ...) local ok, s = pcall(string.format, f, ...); return ok and s or f end }, { __index = function(_, k) return k end })   -- l10n (Core C.L)
-- Core design system (Core 1.6, suite UX plan 3): one palette, one category colour table, one panel and one button
-- helper for every Fennick window. Fonts stay C:NewFS / C:TitleFS (face fixed). Plain insecure frames only.
local C = Fennick_BEAST
local W8 = "Interface\\Buttons\\WHITE8X8"
-- Shared cultivation palette: Skin owns the tokens; retain legacy names for module API compatibility.
local P = C.Skin.PAL
C.COL = { teal = P.header, dteal = P.btn, gold = P.gold, lgold = P.title,
  amber = P.amber, cream = P.text, dark = P.body, violet = { 0.588, 0.47, 0.863 },
  bronze = P.bronze, jade = P.jade, celestial = P.celestial }
-- map category colours, keyed by pin category (Trailmarks point types)
C.CAT_COL = { ore = { 0.83, 0.55, 0.20 }, herb = { 0.16, 0.70, 0.64 }, chest = { 0.95, 0.78, 0.30 }, mob = { 1.00, 0.62, 0.15 }, object = { 0.98, 0.70, 0.40 }, npc = { 0.55, 0.88, 0.82 } }
function C:Col(k, a) local c = self.COL[k] or self.COL.cream; return c[1], c[2], c[3], a or 1 end
local function tex(parent, layer, k, a) local t = parent:CreateTexture(nil, layer or "ARTWORK"); t:SetTexture(W8); t:SetVertexColor(C:Col(k, a)); return t end
-- small square glyph button (teal fill, gold edge, amber on hover) with an optional one-line tooltip on our own frame
function C:Button(parent, glyph, tipText, fn)
  local b = CreateFrame("Button", nil, parent); b:SetSize(18, 18)
  b.bg = tex(b, "BACKGROUND", "dteal", 1); b.bg:SetAllPoints(b)
  b.edge = tex(b, "BORDER", "gold", 1); b.edge:SetPoint("TOPLEFT", b, "TOPLEFT", -1, 1); b.edge:SetPoint("BOTTOMRIGHT", b, "BOTTOMRIGHT", 1, -1)
  b.bg:SetDrawLayer("ARTWORK")
  b.t = self:NewFS(b, "OVERLAY"); b.t:SetPoint("CENTER"); b.t:SetText(glyph); b.t:SetTextColor(C:Col("cream"))
  b:SetScript("OnEnter", function(s) s.edge:SetVertexColor(C:Col("lgold")); s.t:SetTextColor(C:Col("amber")); s.bg:SetVertexColor(C:Col("teal"))
    if GameTooltip and tipText then GameTooltip:SetOwner(s, "ANCHOR_TOP"); GameTooltip:AddLine(tipText, 1, 1, 1); GameTooltip:Show() end end)
  b:SetScript("OnLeave", function(s) s.edge:SetVertexColor(C:Col("gold")); s.t:SetTextColor(C:Col("cream")); s.bg:SetVertexColor(C:Col("dteal")); if GameTooltip then GameTooltip:Hide() end end)
  b:SetScript("OnClick", fn); return b
end
-- dialog panel: dark teal, gold edge, Cinzel title, close button; named frames must start with "Fennick_" (else unnamed)
function C:Panel(name, w, h, title)
  if type(name) ~= "string" or not name:find("^Fennick_%a") then name = nil end
  local f = CreateFrame("Frame", name, UIParent); f:SetSize(w, h); f:SetPoint("CENTER"); f:SetFrameStrata("DIALOG"); f:EnableMouse(true); f:Hide()
  f.bg = f:CreateTexture(nil, "BACKGROUND"); f.bg:SetTexture(W8); f.bg:SetVertexColor(C:Col("dteal", 0.95)); f.bg:SetAllPoints(f)
  f.edge = f:CreateTexture(nil, "BORDER"); f.edge:SetTexture(W8); f.edge:SetVertexColor(C:Col("gold")); f.edge:SetPoint("TOPLEFT", -1, 1); f.edge:SetPoint("BOTTOMRIGHT", 1, -1)
  f.title = self:TitleFS(self:NewFS(f, "OVERLAY", "GameFontNormal")); f.title:SetPoint("TOP", 0, -6); f.title:SetText(title or ""); f.title:SetTextColor(C:Col("gold"))
  f.close = self:Button(f, "x", TR["Close"], function() f:Hide() end); f.close:SetPoint("TOPRIGHT", -4, -4)
  if name and UISpecialFrames then table.insert(UISpecialFrames, name) end   -- Escape closes it (insecure list, as any add-on window)
  return f
end
