local TR = (Fennick_BEAST and Fennick_BEAST.L) or setmetatable({ F = function(_, f, ...) local ok, s = pcall(string.format, f, ...); return ok and s or f end }, { __index = function(_, k) return k end })   -- l10n (Core C.L)
-- Moving and sizing Fennick frames. Generic API for every module: C:RegisterMovable(key, frame, label, opts).
-- Path 1 (Blizzard Edit Mode present and the embedded LibEditMode loaded): frames show up in Edit Mode with Fennick
--   sliders (scale, width, height, alpha); positions are saved per Edit Mode layout.
-- Path 2 ("Fennick Edit Mode", used when Edit Mode is missing or the library failed): /beast move (or /fennick move),
--   Settings > Move frames, or the setup wizard. Drag handle, resize grip, arrow keys nudge (Shift = 10 px), optional grid
--   snap, per-frame and all reset. Locked by default, relocks when combat starts.
-- Both paths: our own (insecure) frames only, nothing moves in combat, no Blizzard frame is moved or written to.
local C = Fennick_BEAST
local EM = { frames = {}, order = {}, unlocked = false }
C.EditMode = EM
EM.SLIDERS = { scale = { 0.5, 2, 0.05 }, width = { 250, 700, 10 }, height = { 0, 600, 10 }, alpha = { 0, 1, 0.05 } }

-- storage: per-character in Fennick_CoreDB; with "use profile positions" the account-wide Fennick_CoreProfiles copy is used
local function store()
  local db = C.db; db.pos = type(db.pos) == "table" and db.pos or {}
  if C:O("posProfile") and type(_G.Fennick_CoreProfiles) == "table" then
    local p = _G.Fennick_CoreProfiles; p.pos = type(p.pos) == "table" and p.pos or {}; return p.pos
  end
  return db.pos
end
local function bucket(layout) local s = store(); local k = layout or "fennick"; s[k] = type(s[k]) == "table" and s[k] or {}; return s[k] end
function EM:Layout() return self.lem and self.layoutName or nil end
function EM:Get(key) return bucket(self:Layout())[key] end
function EM:Put(key, t) bucket(self:Layout())[key] = t end

-- frame settings (scale/width/height/alpha) read by modules for their windows
function C:FrameOpt(key, k)
  local p = EM:Get(key); if p and p[k] ~= nil then return p[k] end
  local d = EM.frames[key] and EM.frames[key].opts.defaults; if d and d[k] ~= nil then return d[k] end
  if k == "scale" then return self:O("scale") elseif k == "width" then return self:O("width") elseif k == "alpha" then return self:O("alpha") end
  return nil
end
local function apply(key)
  local r = EM.frames[key]; if not r or C:InCombat() then return end
  local f, p = r.frame, EM:Get(key) or {}
  if p.point then f:ClearAllPoints(); f:SetPoint(p.point, UIParent, p.point, p.x or 0, p.y or 0)
  elseif r.opts.default then local d = r.opts.default; f:ClearAllPoints(); f:SetPoint(d.point, UIParent, d.point, d.x or 0, d.y or 0) end
  if p.scale then f:SetScale(p.scale) end
  if p.alpha and f.SetBackdropColor and C.Skin then C.Skin:Style(f, p.alpha) end
  if r.opts.onChange then pcall(r.opts.onChange, p) end
end
EM.Apply = apply
local function savePoint(key)
  local r = EM.frames[key]; local f = r.frame
  local cx, cy = f:GetCenter(); local ux, uy; if UIParent.GetCenter then ux, uy = UIParent:GetCenter() end; if not (cx and ux) then return end
  local s = f:GetEffectiveScale() / UIParent:GetEffectiveScale()
  local x, y = cx * s - ux, cy * s - uy
  local grid = C:O("gridSnap") and 16 or nil
  if grid then x = math.floor(x / grid + 0.5) * grid; y = math.floor(y / grid + 0.5) * grid end
  local p = EM:Get(key) or {}; p.point, p.x, p.y = "CENTER", math.floor(x + 0.5), math.floor(y + 0.5); EM:Put(key, p); apply(key)
end
function EM:SetValue(key, k, v) local p = self:Get(key) or {}; p[k] = v; self:Put(key, p); apply(key) end
function EM:Reset(key) bucket(self:Layout())[key] = nil; apply(key) end
function EM:ResetAll() for k in pairs(self.frames) do self:Reset(k) end end
-- dragging is allowed only while unlocked (Fennick Edit Mode) or inside Blizzard Edit Mode (the library drives it)
function C:CanDrag(key) return EM.unlocked and not self:InCombat() end

-- Path 1: LibEditMode ---------------------------------------------------------------------------------
function EM:TryLib()
  if self.lemTried then return self.lem end; self.lemTried = true
  if not (EditModeManagerFrame and C_EditMode and LibStub) then self.why = TR["Blizzard Edit Mode not found: using Fennick Edit Mode"]; return end
  local ok, lib = pcall(LibStub, "LibEditMode", true)
  if not (ok and type(lib) == "table" and type(lib.AddFrame) == "function" and type(lib.AddFrameSettings) == "function"
    and type(lib.RegisterCallback) == "function" and type(lib.IsInEditMode) == "function" and lib.SettingType) then
    self.why = TR["Edit Mode library did not load: using Fennick Edit Mode"]; return
  end
  local ok2, err = pcall(lib.RegisterCallback, lib, "layout", function(name) EM.layoutName = name; for k in pairs(EM.frames) do C:Safe("em layout " .. k, function() apply(k) end) end end)
  if not ok2 then self.why = TR:F("Edit Mode library error (%s): using Fennick Edit Mode", tostring(err)); return end
  pcall(lib.RegisterCallback, lib, "enter", function() EM.inBlizzard = true end)
  pcall(lib.RegisterCallback, lib, "exit", function() EM.inBlizzard = false; for k in pairs(EM.frames) do C:Safe("em exit " .. k, function() apply(k) end) end end)
  self.lem = lib; self.why = TR["Blizzard Edit Mode: Fennick frames are listed there"]; return lib
end
local function num(v) if type(v) ~= "number" then return nil end; local ok, r = pcall(function() return v + 0 end); return ok and r or nil end  -- "secret" values fail arithmetic: ignore them
function EM:AddToLib(key)
  local lib, r = self.lem, self.frames[key]; if not lib or r.inLib then return end
  local d = r.opts.default or { point = "CENTER", x = 0, y = 0 }
  local ok = pcall(lib.AddFrame, lib, r.frame, function(_, layout, point, x, y)
    x, y = num(x), num(y); if not (point and x and y) or C:InCombat() then return end
    EM.layoutName = layout; local p = EM:Get(key) or {}; p.point, p.x, p.y = point, x, y; EM:Put(key, p); apply(key)
  end, { point = d.point, x = d.x or 0, y = d.y or 0 }, C.brand .. ": " .. r.label)
  if not ok then self.lem = nil; self.why = TR["Edit Mode library error on add: using Fennick Edit Mode"]; return end
  r.inLib = true
  local S = {}
  for _, k in ipairs({ "scale", "width", "height", "alpha" }) do
    if k ~= "width" and k ~= "height" or r.opts.resizable then
      local b = self.SLIDERS[k]
      S[#S + 1] = { name = (k:gsub("^%l", string.upper)), kind = lib.SettingType.Slider, minValue = b[1], maxValue = b[2], valueStep = b[3],
        default = C:FrameOpt(key, k) or b[1], get = function() return C:FrameOpt(key, k) or b[1] end,
        set = function(_, v) v = num(v); if v and not C:InCombat() then EM:SetValue(key, k, v) end end }
    end
  end
  pcall(lib.AddFrameSettings, lib, r.frame, S)
end

-- Path 2: Fennick Edit Mode overlay ---------------------------------------------------------------------
-- arrow keys nudge the frame under the mouse: our keyboard frame takes keys only while the mouse is over an unlocked frame (Esc locks)
local kb = CreateFrame("Frame", "Fennick_MoveKeys", UIParent); kb:Hide(); EM.kb = kb
kb:SetScript("OnKeyDown", function(self, key)
  local k = EM.nudge; local d = IsShiftKeyDown and IsShiftKeyDown() and 10 or 1
  local dx = (key == "LEFT" and -d) or (key == "RIGHT" and d) or 0; local dy = (key == "UP" and d) or (key == "DOWN" and -d) or 0
  if k and (dx ~= 0 or dy ~= 0) and not C:InCombat() then
    local p = EM:Get(k); if not (p and p.point) then savePoint(k); p = EM:Get(k) end
    p.x, p.y = (p.x or 0) + dx, (p.y or 0) + dy; EM:Put(k, p); apply(k)
  elseif key == "ESCAPE" then EM:SetUnlocked(false) end
end)
local function mover(key)
  local r = EM.frames[key]; if r.mover then return r.mover end
  local f = r.frame
  local m = CreateFrame("Frame", nil, f, "BackdropTemplate"); m:SetAllPoints(); m:SetFrameStrata("DIALOG"); m:EnableMouse(true)
  m.bg = m:CreateTexture(nil, "BACKGROUND"); m.bg:SetAllPoints(); m.bg:SetColorTexture(0.2, 0.6, 1, 0.25)
  m.label = Fennick_BEAST:NewFS(m, "OVERLAY", "GameFontNormal"); m.label:SetPoint("CENTER"); m.label:SetText(TR:F("%s\n|cff999999drag, arrows nudge, right-click resets|r", r.label))
  m:RegisterForDrag("LeftButton")
  m:SetScript("OnDragStart", function() if C:CanDrag(key) then f:SetMovable(true); f:StartMoving() end end)
  m:SetScript("OnDragStop", function() f:StopMovingOrSizing(); savePoint(key) end)
  -- P2-18: keys are captured only after a left-click selects the frame (nudge mode); other keys pass through to the game
  m:SetScript("OnMouseUp", function(_, b) if C:InCombat() then return end
    if b == "RightButton" then EM:Reset(key) elseif b == "LeftButton" and EM.unlocked then EM.nudge = key; kb:EnableKeyboard(true) end end)
  m:SetScript("OnEnter", function() EM.hover = key end)
  m:SetScript("OnLeave", function() if EM.hover == key then EM.hover = nil end; if EM.nudge == key and not C:InCombat() then EM.nudge = nil; kb:EnableKeyboard(false) end end)
  if r.opts.resizable then
    local g = CreateFrame("Button", nil, m); g:SetSize(16, 16); g:SetPoint("BOTTOMRIGHT", -2, 2)
    g:SetNormalTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
    g:SetScript("OnMouseDown", function() if C:CanDrag(key) then g.sx, g.w = GetCursorPosition(), f:GetWidth(); g:SetScript("OnUpdate", function()
      local x = GetCursorPosition(); local w = math.max(EM.SLIDERS.width[1], math.min(EM.SLIDERS.width[2], g.w + (x - g.sx) / f:GetEffectiveScale()))
      g.nw = math.floor(w); f:SetWidth(g.nw) end) end end)   -- P2-18: only the width changes while dragging
    g:SetScript("OnMouseUp", function() g:SetScript("OnUpdate", nil); if g.nw then EM:SetValue(key, "width", g.nw); g.nw = nil end end)
    m.grip = g
  end
  r.mover = m; m:Hide(); return m
end
function EM:SetUnlocked(on)
  if not on then EM.nudge = nil end
  if on and C:InCombat() then C:Print(TR["leave combat to move frames"]); return end
  if on and self.lem and not EditModeManagerFrame then self.lem = nil end
  self.unlocked = on and true or false
  for k, r in pairs(self.frames) do local m = mover(k); if on then r.frame:Show(); m:Show() else m:Hide() end end
  if on then kb:Show() else kb:EnableKeyboard(false); kb:Hide() end
  if not on then for k in pairs(self.frames) do apply(k) end; C:RefreshWindow() end
end
-- /beast move: Blizzard Edit Mode when available, else our overlay (toggle)
function C:ToggleMove()
  if self:InCombat() then return self:Print(TR["leave combat to move frames"]) end
  if EM.lem then return self:Print(TR["Fennick frames are in Blizzard Edit Mode: open it from the game menu (Esc > Edit Mode)."]) end
  EM:SetUnlocked(not EM.unlocked)
end
local cf = CreateFrame("Frame"); cf:RegisterEvent("PLAYER_REGEN_DISABLED")
cf:SetScript("OnEvent", function() if EM.unlocked then EM.unlocked = false; for _, r in pairs(EM.frames) do if r.mover then r.mover:Hide() end end; kb:Hide(); EM.relocked = true end end)

-- PUBLIC: register one of your frames. opts = { default = {point,x,y}, resizable = bool, defaults = {width=..}, onChange = fn(p) }
function C:RegisterMovable(key, frame, label, opts)
  if type(key) ~= "string" or not frame then return end
  local r = EM.frames[key] or {}; r.frame, r.label, r.opts = frame, label or key, opts or {}
  if not EM.frames[key] then EM.order[#EM.order + 1] = key end
  EM.frames[key] = r
  frame:SetMovable(true); frame:SetClampedToScreen(true)
  frame:SetScript("OnDragStart", function(f) if C:CanDrag(key) then f:StartMoving() end end)
  frame:SetScript("OnDragStop", function(f) f:StopMovingOrSizing(); if C:CanDrag(key) then savePoint(key) end end)
  if EM.lem or (C.loaded and EM:TryLib()) then EM:AddToLib(key) end
  C:Safe(TR:F("em apply %s", key), function() apply(key) end)
  if EM.unlocked then mover(key):Show() end
  return r
end
function EM:Mode() return self.lem and "blizzard" or "fennick" end
C.initHooks[#C.initHooks + 1] = function()
  EM:TryLib()
  for _, k in ipairs(EM.order) do if EM.lem then EM:AddToLib(k) end; apply(k) end
end
