local TR = (Fennick_BEAST and Fennick_BEAST.L) or setmetatable({ F = function(_, f, ...) local ok, s = pcall(string.format, f, ...); return ok and s or f end }, { __index = function(_, k) return k end })   -- l10n (Core C.L)
-- In-game help (Core 1.6, suite UX plan 5): /fennick help lists modules; /fennick <module> help prints 3-6 short,
-- translated lines; each settings section has a "? Help" row printing the same text. Modules register with
-- C:RegisterHelp(moduleKey, lines, slashKey). Standard verbs per module: (none) = open, share, why, help.
local C = Fennick_BEAST
C.help, C.helpAlias = C.help or {}, C.helpAlias or {}
C.SLASH_ALIAS = { guide = "lvl" }   -- /fennick guide -> /fennick lvl
function C:RegisterHelp(key, lines, slashKey)
  if type(key) ~= "string" or type(lines) ~= "table" then return false end
  local t = {}; for i = 1, math.min(#lines, 6) do if type(lines[i]) == "string" then t[#t + 1] = lines[i] end end
  self.help[key] = t; if type(slashKey) == "string" then self.helpAlias[slashKey:lower()] = key end
  return true
end
function C:HelpLines(key)
  key = type(key) == "string" and key:lower() or ""; key = self.SLASH_ALIAS[key] or key
  local t = self.help[key] or self.help[self.helpAlias[key] or ""]
  return t and #t > 0 and t or nil
end
function C:PrintHelp(key) local t = self:HelpLines(key); if not t then return false end; for _, l in ipairs(t) do self:Print(l) end; return true end
C:RegisterHelp("core", { TR["/fennick opens settings; /fennick setup runs the setup again."], TR["/fennick move moves frames; /fennick why says what each module is waiting for."],
  TR["/fennick report copies a bug report text to paste into the bug form."], TR["Map tooltips: hover a pin or shaded area; hold Shift for detail."] }, "core")
