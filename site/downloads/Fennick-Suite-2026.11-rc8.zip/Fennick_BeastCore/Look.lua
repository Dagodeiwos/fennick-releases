local TR = (Fennick_BEAST and Fennick_BEAST.L) or setmetatable({ F = function(_, f, ...) local ok, s = pcall(string.format, f, ...); return ok and s or f end }, { __index = function(_, k) return k end })   -- l10n (Core C.L)
-- v1.1 look alignment (UI-ALIGNMENT-ASSESSMENT.md options a, b, c, e). Original code.
-- (a) Font face is NEVER changed (the one deliberate exception: window titles use Cinzel, same size + offset): every Fennick FontString uses a private copy of a Blizzard font object
--     (CreateFont + CopyFontObject), re-sized with SetFont(sameFace, baseSize + offset, sameFlags). Frames follow the
--     UIParent scale (own scale defaults to 1 and only multiplies it).
-- (b) Match presets: blizzard | tracker (Objective Tracker text size) | elvui (auto-detected, read-only: its font SIZE and
--     E.mult pixel unit + pixel border) | custom. Presets set size offset, border style, padding, backdrop - never the face.
-- (c) Pixel-perfect borders/padding: unit = 768 / physical screen height / effective scale; PixelUtil when present.
-- (e) Live re-layout on UI_SCALE_CHANGED, DISPLAY_SIZE_CHANGED, EDIT_MODE_LAYOUTS_UPDATED and text-size changes,
--     deferred until combat ends.
local C = Fennick_BEAST
C.FONT_BASES = { "GameFontNormalLarge", "GameFontNormal", "GameFontHighlight", "GameFontHighlightSmall", "GameFontNormalSmall", "GameFontDisableSmall" }
C.fonts, C.fontBase = {}, {}
C.MATCH = { "blizzard", "tracker", "elvui", "custom" }
C.MATCH_LABEL = { blizzard = "Blizzard", tracker = TR["Objective Tracker size"], elvui = TR["ElvUI (detected)"], custom = "Custom" }
local function clamp(v, a, b) v = tonumber(v) or 0; if v < a then return a elseif v > b then return b end; return v end
function C:ElvUI()
  local e = rawget(_G, "ElvUI"); if type(e) ~= "table" then return end
  local E = e[1]; if type(E) ~= "table" then return end
  local ok, r = pcall(function()
    local size = E.db and E.db.general and tonumber(E.db.general.fontSize)
    local bd = E.media and E.media.backdropcolor; local bc = E.media and E.media.bordercolor
    return { size = size, mult = tonumber(E.mult), bg = type(bd) == "table" and { bd[1] or bd.r, bd[2] or bd.g, bd[3] or bd.b } or nil,
      edge = type(bc) == "table" and { bc[1] or bc.r, bc[2] or bc.g, bc[3] or bc.b } or nil }
  end)
  if ok then return r end
end
-- which match preset is active: the saved choice, else ElvUI when it is loaded, else Blizzard
function C:Match()
  local m = self:O("match")
  if m == "elvui" and not self:ElvUI() then m = nil end
  if not m or m == "auto" then m = self:ElvUI() and "elvui" or "blizzard" end
  return m
end
local function baseSize(name) local o = rawget(_G, name); if o and o.GetFont then local _, s = o:GetFont(); return tonumber(s) end end
-- text size offset in points (relative to the Blizzard size of each font object)
function C:FontOffset()
  local m = self:Match(); local user = clamp(self:O("fontOffset"), -4, 6)
  if m == "tracker" then
    local t = baseSize("ObjectiveTrackerLineFont"); local b = baseSize("GameFontHighlight")
    return (t and b) and clamp(t - b + user, -4, 8) or user
  elseif m == "elvui" then
    local e = self:ElvUI(); local b = baseSize("GameFontHighlight")
    return (e and e.size and b) and clamp(e.size - b + user, -4, 8) or user
  end
  return user
end
-- a private copy of a Blizzard font object, same face and flags, size + offset
function C:FontObj(base)
  base = base or "GameFontHighlight"
  local f = self.fonts[base]
  if not f then
    local src = rawget(_G, base); if not (src and CreateFont) then return src end
    f = CreateFont("Fennick_" .. base); f:CopyFontObject(src); self.fonts[base] = f
    local face, size, flags = src:GetFont(); self.fontBase[base] = { face, size, flags }
  end
  local b = self.fontBase[base]
  if b and b[1] and b[2] then f:SetFont(b[1], math.max(6, b[2] + self:FontOffset()), b[3] or "") end
  return f
end
-- Deliberate exception: window TITLES (and only titles) use Cinzel (SIL OFL 1.1, Media/OFL.txt), same size + offset and flags
C.TITLE_FACE = "Interface\\AddOns\\Fennick_BeastCore\\Media\\Cinzel.ttf"
C.titleFonts = {}
function C:TitleFontObj(base)
  base = base or "GameFontNormalLarge"; self:FontObj(base)
  local f = self.titleFonts[base]
  if self.L and self.L.LatinTitles and not self.L:LatinTitles() then return self.fonts[base] end   -- ruRU/koKR/zhCN/zhTW: client font
  if not f then if not CreateFont then return self.fonts[base] end; f = CreateFont("Fennick_Title_" .. base); self.titleFonts[base] = f end
  local b = self.fontBase[base]
  if b and b[2] then f:SetFont(self.TITLE_FACE, math.max(6, b[2] + self:FontOffset()), b[3] or "") end
  return f
end
function C:TitleFS(t, base)
  if not (t and t.SetFontObject) then return t end
  t.fennickTitle = true; t.fennickBase = base or t.fennickBase or "GameFontNormalLarge"
  local fo = self:TitleFontObj(t.fennickBase); if fo then t:SetFontObject(fo) end; return t
end
function C:RefreshFonts() for base in pairs(self.fonts) do self:FontObj(base) end; for base in pairs(self.titleFonts) do self:TitleFontObj(base) end end
do local lsm = LibStub and LibStub("LibSharedMedia-3.0", true)
  if lsm and lsm.Register then pcall(lsm.Register, lsm, "font", "Fennick Cinzel", C.TITLE_FACE) end end
-- every module text goes through this: parent:CreateFontString with our font object
-- l10n (Core 1.3): self-sizing buttons. Width = the label's width + padding, never below the layout's minimum width.
function C:ButtonTextWidth(b)
  local fsx = b and type(b.GetFontString) == "function" and b:GetFontString()
  local w = fsx and type(fsx.GetStringWidth) == "function" and fsx:GetStringWidth()
  if type(w) ~= "number" and b and type(b.GetTextWidth) == "function" then w = b:GetTextWidth() end
  return type(w) == "number" and w or 0
end
function C:FitButton(b, minW, pad, maxW)
  if not (b and type(b.SetWidth) == "function") then return 0 end
  local w = math.max(minW or 0, math.ceil(self:ButtonTextWidth(b) + (pad or 16)))
  if maxW then w = math.min(w, maxW) end
  b:SetWidth(w); return w
end
function C:NewFS(parent, layer, base)
  local t = parent:CreateFontString(nil, layer or "OVERLAY", base or "GameFontHighlight")
  local fo = self:FontObj(base); if fo and t.SetFontObject then t:SetFontObject(fo) end
  t.fennickBase = base or "GameFontHighlight"; self.texts = self.texts or {}; self.texts[#self.texts + 1] = t
  return t
end
-- (c) pixel unit of a frame: one physical pixel in its own coordinate space
function C:PixelUnit(frame)
  local h   -- N-13: stray local removed
  if GetPhysicalScreenSize then local ok, w, hh = pcall(GetPhysicalScreenSize); if ok then h = hh end end
  h = tonumber(h) or 1080; if h <= 0 then h = 1080 end
  local s = 1
  if frame and frame.GetEffectiveScale then local ok, v = pcall(frame.GetEffectiveScale, frame); if ok and tonumber(v) and v > 0 then s = v end
  elseif UIParent and UIParent.GetEffectiveScale then local ok, v = pcall(UIParent.GetEffectiveScale, UIParent); if ok and tonumber(v) and v > 0 then s = v end end
  return 768 / h / s
end
-- round a size to whole physical pixels (at least min pixels)
function C:Snap(v, frame, min)
  local u = self:PixelUnit(frame); local px = math.floor((tonumber(v) or 0) / u + 0.5)
  if PixelUtil and PixelUtil.GetNearestPixelSize and frame and frame.GetEffectiveScale then
    local ok, r = pcall(PixelUtil.GetNearestPixelSize, v, frame:GetEffectiveScale(), min or 1); if ok and tonumber(r) then return r end
  end
  return math.max(min or 0, px) * u
end
-- look values of the active match preset (border style, edge, inset, padding unit, backdrop colours)
function C:LookSpec(frame)
  local m = self:Match(); local u = self:PixelUnit(frame)
  if m == "elvui" then
    local e = self:ElvUI() or {}; local mult = (e.mult and e.mult > 0) and e.mult or u
    return { match = m, pixel = true, edge = mult, inset = mult, pad = self:O("pad"), bg = e.bg, edgeColor = e.edge or { 0, 0, 0 }, unit = mult }
  elseif m == "tracker" then
    return { match = m, pixel = false, edge = self:Snap(12, frame, 1), inset = self:Snap(3, frame, 1), pad = self:Snap(12, frame), unit = u }
  elseif m == "custom" then
    local px = self:O("pixelBorder")
    return { match = m, pixel = px and true or false, edge = px and u or self:Snap(12, frame, 1), inset = px and u or self:Snap(3, frame, 1), pad = self:Snap(self:O("pad"), frame), unit = u }
  end
  return { match = m, pixel = false, edge = self:Snap(12, frame, 1), inset = self:Snap(3, frame, 1), pad = self:Snap(self:O("pad"), frame), unit = u }
end
function C:Pad(frame) return self:LookSpec(frame).pad end
-- (e) live re-layout, never in combat
function C:Relook(why)
  if self:InCombat() then self.pendingLook = why or true; return false end
  self.pendingLook = nil
  self:RefreshFonts()
  if self.ApplyLook then pcall(self.ApplyLook, self) end
  self.lookCount = (self.lookCount or 0) + 1
  self:Debug("look re-applied (" .. tostring(why) .. ")")
  return true
end
local lf = CreateFrame("Frame")
for _, ev in ipairs({ "UI_SCALE_CHANGED", "DISPLAY_SIZE_CHANGED", "EDIT_MODE_LAYOUTS_UPDATED", "CVAR_UPDATE", "PLAYER_REGEN_ENABLED" }) do pcall(lf.RegisterEvent, lf, ev) end
local LOOK_EV = { UI_SCALE_CHANGED = true, DISPLAY_SIZE_CHANGED = true, EDIT_MODE_LAYOUTS_UPDATED = true, CVAR_UPDATE = true, PLAYER_REGEN_ENABLED = true }
lf:SetScript("OnEvent", function(_, ev, a1)
  if not C.loaded or not LOOK_EV[ev] then return end
  if ev == "PLAYER_REGEN_ENABLED" then if C.pendingLook then C:Relook(C.pendingLook) end return end
  if ev == "CVAR_UPDATE" then local n = tostring(a1 or ""):lower(); if not (n:find("font") or n:find("textscale") or n:find("uiscale")) then return end end
  C:Relook(ev)
end)
