local TR = (Fennick_BEAST and Fennick_BEAST.L) or setmetatable({ F = function(_, f, ...) local ok, s = pcall(string.format, f, ...); return ok and s or f end }, { __index = function(_, k) return k end })   -- l10n (Core C.L)
-- Aggregate map tooltip (Core 1.6, suite UX plan 2.1). One service for every Fennick map surface: Trailmarks on
-- Blizzard's world map and minimap, and Cartographer's own map and minimap. Read-only (allowed in combat), names only.
--   C:MapTip(owner, entries[, title])  entries: { kind, sub, name, label, seen, last, icon, note, names = {{name, n}} }
--   C:MapTipNear(owner, pool)           owner/pool frames carry .entry, .cx, .cy (draw position), .r (hit radius)
-- Format: line 1 gold title; then one line per group "<icon14> <name> x<count>" in type order
-- (quest mob > quest object > chest > ore > herb > npc > other); last line grey "Last seen ..." or "+N more - zoom in".
-- Never more than 8 lines (same cap as the monster tooltip). Shift adds per-group detail on the same lines.
local C = Fennick_BEAST
local MT = { MAX = 8, ORDER = { mob = 1, object = 2, chest = 3, ore = 4, herb = 5, npc = 6, qobj = 2, qavail = 6, flight = 7, ship = 7, zeppelin = 7, portal = 7, user = 8, target = 8 } }
C.MapTipLib = MT
local scratch, groups, gpool = {}, {}, {}
-- "just now", "5 min ago", "3 h ago", "2 days ago" (t = time() seconds)
function C:Ago(t)
  t = tonumber(t); if not t or t <= 0 then return nil end
  local now = time and time() or t; local d = math.max(0, now - t)
  if d < 120 then return TR["just now"] elseif d < 7200 then return TR:F("%d min ago", math.floor(d / 60))
  elseif d < 172800 then return TR:F("%d h ago", math.floor(d / 3600)) end
  return TR:F("%d days ago", math.floor(d / 86400))
end
-- names and notes can be player text (Cartographer pin names/notes): IDs stripped, then a raw "|" is escaped so it can
-- never start a colour, texture or link code in the tooltip (P2-2)
local function clean(s) local T = C.Tooltip; if T and T.Clean then s = T.Clean(s) end; if type(s) == "string" then s = s:gsub("|", "||") end; return s end
-- group key: mobs and other named things by name; ore/herb by their specific type (label) when known
local function addGroup(kind, name, label, icon, n, last, note)
  name = clean(label or name); if not name then return end
  local key = (kind or "other") .. "\1" .. name
  local g = groups[key]
  if not g then
    g = table.remove(gpool) or {}; g.kind, g.name, g.icon, g.n, g.last, g.note, g.hits = kind or "other", name, icon, 0, 0, nil, 0
    groups[key] = g; scratch[#scratch + 1] = g
  end
  g.n = g.n + (tonumber(n) or 1); g.hits = g.hits + 1; g.last = math.max(g.last, tonumber(last) or 0); if note and note ~= "" then g.note = clean(note) end
  if not g.icon then g.icon = icon end
end
local function reset() for k, g in pairs(groups) do groups[k] = nil; gpool[#gpool + 1] = g end; for i = #scratch, 1, -1 do scratch[i] = nil end end
-- entries -> sorted groups (reuses one scratch table; no new tables per hover once warm)
function C:MapTipGroups(entries)
  reset()
  for _, e in ipairs(entries or {}) do
    if type(e) == "table" then
      local kind = e.kind or "other"
      if type(e.names) == "table" and #e.names > 0 then
        for _, nn in ipairs(e.names) do addGroup(kind, nn[1], nn.label, nn.icon or e.icon, nn[2], nn.last or e.last) end
      else addGroup(kind, e.name, e.label, e.icon, e.seen, e.last, e.note) end
    end
  end
  table.sort(scratch, function(a, b)
    local oa, ob = MT.ORDER[a.kind] or 7, MT.ORDER[b.kind] or 7
    if oa ~= ob then return oa < ob end; if a.n ~= b.n then return a.n > b.n end; return a.name < b.name end)
  return scratch
end
-- one line of text for a group ("Copper Vein x12", "Kobold Miner (group) x8"); detail = Shift form
function C:MapTipLine(g, detail)
  local icon = g.icon and ("|T" .. g.icon .. ":14:14|t ") or ""
  local count = g.n > 1 and (" x" .. g.n) or ""
  local name = (g.kind == "mob" and g.hits > 0 and g.n > 1) and TR:F("%s (group)", g.name) or g.name
  local s = icon .. name .. count
  if detail then
    local ago = C:Ago(g.last > 0 and g.last or nil)
    if g.n > 0 and (g.kind == "mob" or g.kind == "object" or g.kind == "ore" or g.kind == "herb" or g.kind == "chest" or g.kind == "npc") then s = s .. "  |cff999999" .. TR:F("seen %d times", g.n) .. "|r" end
    if ago then s = s .. "  |cff999999" .. ago .. "|r" end
    if g.note then s = s .. "  |cffcfc6a8" .. g.note .. "|r" end
  end
  return s
end
-- the text lines (title first), never more than MAX; returned for tests and for the tooltip itself
function C:MapTipLines(entries, title, detail)
  local gs = self:MapTipGroups(entries)
  local out = { clean(title) or TR["This spot"] }
  if #gs == 0 then return out end
  local room = self.MapTipLib.MAX - 2   -- title + footer
  local single = #gs == 1
  local newest = 0
  for i, g in ipairs(gs) do
    newest = math.max(newest, g.last or 0)
    if i <= room then out[#out + 1] = self:MapTipLine(g, detail) end
  end
  if single and not detail and gs[1].note and #out < self.MapTipLib.MAX - 1 then out[#out + 1] = "|cffcfc6a8" .. gs[1].note .. "|r" end
  if #gs > room then out[#out + 1] = "|cff999999" .. TR:F("+%d more - zoom in", #gs - room) .. "|r"
  elseif C:O("tipLastSeen") ~= false and newest > 0 then local ago = C:Ago(newest); if ago then out[#out + 1] = "|cff999999" .. TR:F("Last seen %s", ago) .. "|r" end end
  for i = self.MapTipLib.MAX + 1, #out do out[i] = nil end
  return out
end
-- show the tooltip on our own frame (SetOwner on our frames only; no GameTooltip hooks here)
function C:MapTip(owner, entries, title, extra)
  if not (GameTooltip and owner) then return nil end
  local detail = IsShiftKeyDown and IsShiftKeyDown() or false
  local lines = self:MapTipLines(entries, title, detail)
  GameTooltip:SetOwner(owner, "ANCHOR_RIGHT")
  for i, l in ipairs(lines) do if i == 1 then GameTooltip:AddLine(l, 1, 0.82, 0.3) else GameTooltip:AddLine(l, 0.93, 0.89, 0.78) end end
  if extra and #lines < self.MapTipLib.MAX then GameTooltip:AddLine(extra, 0.7, 0.7, 0.7) end
  GameTooltip:Show(); self.mapTipLines = lines
  return lines
end
-- hit test: every shown frame of the pool within the hovered frame's radius (pins: icon size; shading: area radius)
local near = {}
function C:MapTipCollect(owner, pool)
  for i = #near, 1, -1 do near[i] = nil end
  local ox, oy, orad = owner.cx or 0, owner.cy or 0, owner.r or 8
  for _, f in ipairs(pool or {}) do
    if f.entry and f.IsShown and f:IsShown() then
      local dx, dy = (f.cx or 0) - ox, (f.cy or 0) - oy; local r = math.max(orad, f.r or 0)
      if dx * dx + dy * dy <= r * r then near[#near + 1] = f.entry end
    end
  end
  if #near == 0 and owner.entry then near[1] = owner.entry end
  -- the Core waypoint (Arrow.lua) on this surface: pools that do not draw it as a pin set pool.wp = { cx, cy } (P2-1)
  local wp = pool and pool.wp
  if wp and wp.cx then
    local dx, dy = wp.cx - ox, wp.cy - oy; local r = math.max(orad, 8)
    if dx * dx + dy * dy <= r * r then local e = self:MapTipWaypoint(); if e then near[#near + 1] = e end end
  end
  return near
end
-- the current Fennick waypoint as a tooltip entry (label only; never coordinates or IDs)
local wpEntry = { kind = "target", seen = 1, icon = "Interface\\Minimap\\MinimapArrow" }
function C:MapTipWaypoint()
  local w = self.Waypoint and self:Waypoint(); if not w then return nil end
  wpEntry.name = w.label or TR["Fennick waypoint"]; return wpEntry
end
function C:MapTipNear(owner, pool, title, extra) return self:MapTip(owner, self:MapTipCollect(owner, pool), title, extra) end
