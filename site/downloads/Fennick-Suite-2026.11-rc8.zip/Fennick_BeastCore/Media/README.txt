Fennick_BeastCore media
- Fennick_*.tga: add-on icons (64 px TGA; WoW loads a TGA when a texture path has no extension). Drawn at 32 px in window headers; Fennick_Minimap is the minimap button.
- Pin_<kind>_16.tga and Pin_<kind>_32.tga: the shared map pins used by every Fennick module (see Pins.lua). Area.tga: the soft area shading texture.
- Cinzel.ttf: window title font, SIL Open Font License 1.1 (OFL.txt).
Icons and pins are original Fennick art under the same license as the add-on.
