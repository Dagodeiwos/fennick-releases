local TR = (Fennick_BEAST and Fennick_BEAST.L) or setmetatable({ F = function(_, f, ...) local ok, s = pcall(string.format, f, ...); return ok and s or f end }, { __index = function(_, k) return k end })   -- l10n (Core C.L)
-- Minimap button: LibDBIcon if another add-on already loaded it (nothing embedded), else our own Minimap child.
-- Left-click: show/hide the focus window. Right-click: settings. Drag: move around the edge (angle saved). Tooltip: status.
local E = Fennick_BEAST
local ICON = "Interface\\AddOns\\Fennick_BeastCore\\Media\\Fennick_Minimap"
local btn, ldbi

local function tooltip(tt)
  tt:AddLine(E.brand)
  local o = E:Owner()
  tt:AddLine(TR:F("Focus: %s%s", E:FocusLabel(E:O("focusOn")), (o and E:O("focusOn") == "auto" and (TR:F("  (now: %s)", E:FocusLabel(o))) or "")), 1, 1, 1)
  for _, m in ipairs(E.order) do if m.Status then E:Call(m, "Status", tt) else tt:AddLine(m.label, 0.8, 0.8, 0.8) end end
  if #E.order == 0 then tt:AddLine(TR["No modules installed"], 0.8, 0.8, 0.8) end
  tt:AddLine(TR["Left-click: show/hide window   Shift-click: module on/off"], 0.5, 0.5, 0.5)
  tt:AddLine(TR["Right-click: settings   Drag: move"], 0.5, 0.5, 0.5)
end
local function click(_, b)
  if b == "RightButton" then E:OpenSettings(); return end
  -- P2-9 / K-3: left-click ALWAYS shows/hides the window; Shift-click turns the focused module on/off
  local m = E.modules[E:Owner() or ""]
  if IsShiftKeyDown and IsShiftKeyDown() then if m and m.Toggle then E:Call(m, "Toggle") end; return end
  if m and m.ToggleWindow then E:Call(m, "ToggleWindow") else E:ToggleWindow() end
end

local function place()
  local a = math.rad(E.db.opt.minimap.minimapPos or 200)
  local r = (Minimap:GetWidth() / 2) + 5
  btn:ClearAllPoints(); btn:SetPoint("CENTER", Minimap, "CENTER", math.cos(a) * r, math.sin(a) * r)
end
local function own()
  btn = CreateFrame("Button", "Fennick_MinimapButton", Minimap); btn:SetSize(31, 31); btn:SetFrameStrata("MEDIUM"); btn:SetFrameLevel(8)
  btn:RegisterForClicks("LeftButtonUp", "RightButtonUp"); btn:RegisterForDrag("LeftButton")
  btn:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")
  local ic = btn:CreateTexture(nil, "BACKGROUND"); ic:SetSize(21, 21); ic:SetTexture(ICON); ic:SetPoint("TOPLEFT", 6, -5); btn.icon = ic
  local bd = btn:CreateTexture(nil, "OVERLAY"); bd:SetSize(53, 53); bd:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder"); bd:SetPoint("TOPLEFT")
  btn:SetScript("OnClick", click)
  btn:SetScript("OnEnter", function(self) GameTooltip:SetOwner(self, "ANCHOR_LEFT"); tooltip(GameTooltip); GameTooltip:Show() end)
  btn:SetScript("OnLeave", function() GameTooltip:Hide() end)
  btn:SetScript("OnDragStart", function(self) self:SetScript("OnUpdate", function()
    local mx, my = Minimap:GetCenter(); local cx, cy = GetCursorPosition(); local sc = Minimap:GetEffectiveScale()
    E.db.opt.minimap.minimapPos = math.deg(math.atan2(cy / sc - my, cx / sc - mx)) % 360; place() end) end)
  btn:SetScript("OnDragStop", function(self) self:SetScript("OnUpdate", nil) end)
  place(); E.Skin:Add("minimap", btn); E.Skin:AddButton(btn, "minimap")
end

function E:UpdateMinimap()
  if ldbi then if self.db.opt.minimap.hide then ldbi:Hide(self.brand) else ldbi:Show(self.brand) end
  elseif btn then if self.db.opt.minimap.hide then btn:Hide() else btn:Show() end; btn.icon:SetDesaturated(self.disabled and true or false) end
end

table.insert(E.initHooks, function()
  local LS = LibStub
  local ldb = LS and LS("LibDataBroker-1.1", true); local icon = LS and LS("LibDBIcon-1.0", true)
  if ldb and icon then
    local obj = ldb:NewDataObject(E.brand, { type = "launcher", text = E.brand, icon = ICON, OnClick = click, OnTooltipShow = tooltip })
    if obj and pcall(icon.Register, icon, E.brand, obj, E.db.opt.minimap) then ldbi = icon end
  end
  if not ldbi and Minimap then own() end
  E:UpdateMinimap()
end)
function E:ToggleMinimap() self.db.opt.minimap.hide = not self.db.opt.minimap.hide; self:UpdateMinimap() end
