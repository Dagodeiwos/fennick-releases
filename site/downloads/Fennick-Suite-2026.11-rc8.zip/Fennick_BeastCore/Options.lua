local TR = (Fennick_BEAST and Fennick_BEAST.L) or setmetatable({ F = function(_, f, ...) local ok, s = pcall(string.format, f, ...); return ok and s or f end }, { __index = function(_, k) return k end })   -- l10n (Core C.L)
-- Core settings window (own frame, opened out of combat): focus (installed modules only), arrow, style, tooltip lines,
-- and one button per installed module that has its own settings.
local C = Fennick_BEAST
local P
local function onoff(v) return v and "|cff55ff55" .. TR["ON"] .. "|r" or "|cffff5555" .. TR["OFF"] .. "|r" end
local function adv(row) row.adv = true; return row end
local function coreRows()
  local r = {}
  -- l10n: one-line note while this client's language uses machine-translated text (About)
  if C.L and C.L:IsMachine() then r[#r + 1] = { function() return TR["Language: machine translation (not yet reviewed)."] end, function() end, nil, true } end
  r[#r + 1] = { function() return C.EditMode:Mode() == "blizzard" and TR["Move frames (opens Edit Mode)"] or (TR:F("Move frames (Fennick Edit Mode) %s", (C.EditMode.unlocked and TR["|cff55ff55unlocked|r"] or TR["locked"]))) end, function() P:Hide(); C:ToggleMove() end }
  r[#r + 1] = adv { function() return TR:F("   Grid snap %s", onoff(C:O("gridSnap"))) end, function() C:Set("gridSnap", not C:O("gridSnap")) end }
  r[#r + 1] = adv { function() return TR:F("   Positions: %s", (C:O("posProfile") and TR["shared profile"] or TR["this character"])) end, function() C:Set("posProfile", not C:O("posProfile")); for k in pairs(C.EditMode.frames) do C.EditMode.Apply(k) end end }
  r[#r + 1] = adv { function() return TR["   Reset all frame positions"] end, function() C.EditMode:ResetAll() end }
  r[#r + 1] = { function() return TR:F("Focus: %s", C:FocusLabel(C:O("focusOn"))) end, function(d)
    local ch = C:FocusChoices(); local i = 1; for k, v in ipairs(ch) do if v == C:O("focusOn") then i = k end end
    C:SetFocus(ch[(i - 1 + (d or 1)) % #ch + 1]) end, true }
  if C.BeaconEnabled then
    r[#r + 1] = adv { function() return TR:F("Spirit Beacon (group sharing) %s", onoff(C:BeaconEnabled())) end, function()
      if not C:SetBeaconEnabled(not C:BeaconEnabled()) then C:Print(TR["Spirit Beacon unavailable."]) end
    end }
  end
  -- Optional manual quest reward focus; unset disables reward advice.
  if C.RoleChoices and #C:RoleChoices() > 1 then
    r[#r + 1] = adv { function() return TR:F("Role: %s", (C.db and C.db.roleFocus) and C:RoleChoiceLabel(C.db.roleFocus) or C:RoleChoiceLabel(nil)) end, function(d)
      local ch = C:RoleChoices(); local cur = C.db and C.db.roleFocus or false; local i = 1
      for k, v in ipairs(ch) do if v == cur then i = k end end
      local nx = ch[(i - 1 + (d or 1)) % #ch + 1]; C:SetRoleFocus(nx or nil) end, true }
  end
  r[#r + 1] = adv { function() return TR:F("Along-the-way lines from other modules %s", onoff(C:O("riders"))) end, function() C:Set("riders", not C:O("riders")); C:RefreshWindow() end }
  r[#r + 1] = { function() return TR:F("Waypoint arrow %s", onoff(C:O("arrow"))) end, function() C:Set("arrow", not C:O("arrow")); C:ResetWaypoint(); C:ApplyArrow() end }
  r[#r + 1] = { function() return C:O("tomtom") and TR["Use TomTom when installed"] or TR["Use the built-in arrow"] end, function() C:Set("tomtom", not C:O("tomtom")); C:ResetWaypoint(); C:ApplyArrow() end }
  r[#r + 1] = { function() return TR:F("Style: %s", C:O("preset")) end, function(d)
    local o = C.Skin.PRESET_ORDER; local i = 1; for k, v in ipairs(o) do if v == C:O("preset") then i = k end end; C:ApplyPreset(o[(i - 1 + (d or 1)) % #o + 1]) end, true }
  r[#r + 1] = adv { function() return TR:F("Match: %s%s", C.MATCH_LABEL[C:Match()], (C:O("match") == "auto" and TR[" (auto)"] or "")) end, function(d)
    local o = { "auto", "blizzard", "tracker", "elvui", "custom" }; local i = 1; for k, v in ipairs(o) do if v == C:O("match") then i = k end end
    C:Set("match", o[(i - 1 + (d or 1)) % #o + 1]); C:Relook("match") end, true }
  r[#r + 1] = { function() local v = C:O("fontOffset") or 0; return TR:F("Text size %s%s (font face unchanged)", (v > 0 and "+" or ""), v) end, function(d)
    local v = (C:O("fontOffset") or 0) + (d or 1); if v > 6 then v = -4 elseif v < -4 then v = 6 end; C:Set("fontOffset", v); C:Relook(TR["text size"]) end, true }
  r[#r + 1] = adv { function() return TR:F("   Pixel borders (Custom) %s", onoff(C:O("pixelBorder"))) end, function() C:Set("pixelBorder", not C:O("pixelBorder")); C:Relook("border") end }
  r[#r + 1] = { function() return TR:F("Sounds %s", onoff(C:O("sound"))) end, function() C:Set("sound", not C:O("sound")) end }
  -- M-N-4: one toggle per registered cue (all off by default); a cue plays only while Sounds is also on
  for _, k in ipairs(C.cueOrder or {}) do local c = C.cues[k]
    r[#r + 1] = adv { function() return "   " .. c.label .. " " .. onoff(C:CueEnabled(k)) end, function() C:SetCue(k, not C:CueEnabled(k)) end }
  end
  r[#r + 1] = adv { function() return TR:F("Map tooltips: last seen %s", onoff(C:O("tipLastSeen"))) end, function() C:Set("tipLastSeen", not C:O("tipLastSeen")) end }
  r[#r + 1] = { function() return TR:F("Monster tooltip %s", onoff(C:O("tooltip"))) end, function() C:Set("tooltip", not C:O("tooltip")) end }
  for _, l in ipairs(C.Tooltip.lines) do
    r[#r + 1] = adv { function() return "   " .. l.label .. " " .. onoff(C.Tooltip:Enabled(l.key)) end, function() C.Tooltip:SetEnabled(l.key, not C.Tooltip:Enabled(l.key)) end }
  end
  return r
end
-- Settings sections (Core 1.6, suite UX plan 2.2): Core first, then one section per module. A section shows its basic
-- rows; rows a module marks { ..., adv = true } sit behind a "More" fold (closed by default, this session only), then the
-- module's "?" help row. all = true lists every row (tests, /fennick why).
C.fold = C.fold or {}
local function section(r, key, label, list, all)
  r[#r + 1] = { function() return label .. ":" end, function() end, nil, true }
  local nadv = 0
  for _, x in ipairs(list) do if x.adv then nadv = nadv + 1 elseif not x.helpRow then r[#r + 1] = x end end
  if nadv > 0 then
    local open = all or C.fold[key]
    if not all then r[#r + 1] = { function() return C.fold[key] and TR["   Fewer settings"] or TR:F("   More settings (%d)", nadv) end, function() C.fold[key] = not C.fold[key] end } end
    if open then for _, x in ipairs(list) do if x.adv then r[#r + 1] = x end end end
  end
  if C.HelpLines and C:HelpLines(key) then r[#r + 1] = { function() return TR["   ? Help"] end, function() C:PrintHelp(key) end, nil, nil, helpRow = true } end
end
local function rows(all)
  local r = {}
  section(r, "core", TR["Beast Core"], coreRows(), all)
  for _, m in ipairs(C.order) do if m.SettingsRows then section(r, m.key, m.label, C:Call(m, "SettingsRows") or {}, all) end end
  for _, m in ipairs(C.order) do if m.OpenSettings then r[#r + 1] = { function() return TR:F("%s settings...", m.label) end, function() P:Hide(); C:Call(m, "OpenSettings") end } end end
  return r
end
C.OptionRows = rows
local PER = 16
local page = 1
local function render()
  local list = rows(); local pages = math.max(1, math.ceil(#list / PER)); page = math.min(page, pages)
  for i, b in ipairs(P.b) do local c = list[(page - 1) * PER + i]
    if c then b.c = c; b:SetText(c[1]()); b:Show(); if b.SetEnabled then b:SetEnabled(not c[4]) end else b:Hide() end end   -- N-5: c[4] = plain text row
  -- l10n: rows and the window grow with the longest label (never narrower than the English layout)
  local mw = 348; for _, b in ipairs(P.b) do if b:IsShown() then mw = math.max(mw, math.ceil(C:ButtonTextWidth(b) + 16)) end end
  for _, b in ipairs(P.b) do b:SetWidth(mw) end; P:SetWidth(mw + 32)
  P.pg:SetText(page .. "/" .. pages); P.prev:SetEnabled(page > 1); P.next:SetEnabled(page < pages)
  P:SetHeight(60 + PER * 24 + 40)
end
local function build()
  P = CreateFrame("Frame", "Fennick_CoreSettings", UIParent, "BackdropTemplate"); P:SetSize(380, 400); P:SetPoint("CENTER"); P:SetFrameStrata("DIALOG")
  P:EnableMouse(true); P:SetMovable(true); P:RegisterForDrag("LeftButton"); P:SetScript("OnDragStart", P.StartMoving); P:SetScript("OnDragStop", P.StopMovingOrSizing)
  P.head = Fennick_BEAST:NewFS(P, "OVERLAY", "GameFontNormalLarge"); P.head:SetPoint("TOPLEFT", 16, -16); P.head:SetText(TR:F("%s settings", C.brand))
  P.hint = Fennick_BEAST:NewFS(P, "OVERLAY", "GameFontDisableSmall"); P.hint:SetPoint("BOTTOM", 0, 40); P.hint:SetText(TR["Right-click a row to cycle backwards."])
  P.b = {}
  for i = 1, PER do local b = CreateFrame("Button", nil, P, "UIPanelButtonTemplate"); b:SetSize(348, 20); b:SetPoint("TOPLEFT", 16, -44 - (i - 1) * 24)
    b:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    b:SetScript("OnClick", function(self, mb) if self.c then self.c[2](mb == "RightButton" and -1 or 1); render() end end); C.Skin:AddButton(b, "settings"); P.b[i] = b end
  local x = CreateFrame("Button", nil, P, "UIPanelCloseButton"); x:SetPoint("TOPRIGHT", -2, -2)
  local function nav(t, pt, dx, d) local b = CreateFrame("Button", nil, P, "UIPanelButtonTemplate"); b:SetSize(70, 20); b:SetPoint(pt, dx, 14); b:SetText(t); C:FitButton(b, 70)
    b:SetScript("OnClick", function() page = math.max(1, page + d); render() end); C.Skin:AddButton(b, "settings"); return b end
  P.prev = nav(TR["Prev"], "BOTTOMLEFT", 16, -1); P.next = nav(TR["Next"], "BOTTOMRIGHT", -16, 1)
  P.pg = Fennick_BEAST:NewFS(P, "OVERLAY", "GameFontHighlightSmall"); P.pg:SetPoint("BOTTOM", 0, 18)
  C.Skin:Add("settings", P); C.Skin:Style(P, 0.95)
end
function C:OpenSettings()
  if self:InCombat() then return self:Safe("settings", function() C:OpenSettings() end) end
  if not P then build() end; render(); P:Show()
end
