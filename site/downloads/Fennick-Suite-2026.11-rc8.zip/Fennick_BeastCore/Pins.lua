-- Shared map pin art (Core 1.6): the borderless Fennick pins at 16 and 32 px plus the soft
-- area texture live ONLY in Fennick_BeastCore/Media. This is the ONE path table for them; Trailmarks and Cartographer
-- read it (they keep only their own logos). Swap art by replacing the files in Media/ or editing this file only.
local C = Fennick_BEAST
local M = "Interface\\AddOns\\Fennick_BeastCore\\Media\\"
C.PIN_MEDIA = M
C.PIN_KEYS = { "chest", "flight", "herb", "ore", "portal", "quest", "ship", "user", "zeppelin",
  "herb_arthas_tears", "herb_black_lotus", "herb_blindweed", "herb_briarthorn", "herb_bruiseweed", "herb_dreamfoil", "herb_earthroot",
  "herb_fadeleaf", "herb_firebloom", "herb_ghost_mushroom", "herb_golden_sansam", "herb_goldthorn", "herb_grave_moss", "herb_gromsblood",
  "herb_icecap", "herb_khadgars_whisker", "herb_kingsblood", "herb_liferoot", "herb_mageroyal", "herb_mountain_silversage", "herb_peacebloom",
  "herb_plaguebloom", "herb_purple_lotus", "herb_silverleaf", "herb_stranglekelp", "herb_sungrass", "herb_wild_steelbloom", "herb_wintersbite",
  "ore_copper", "ore_dark_iron", "ore_gold", "ore_incendicite", "ore_indurium", "ore_iron", "ore_lesser_bloodstone", "ore_mithril",
  "ore_rich_thorium", "ore_silver", "ore_small_thorium", "ore_tin", "ore_truesilver" }
C.PIN_KNOWN = {}; for _, k in ipairs(C.PIN_KEYS) do C.PIN_KNOWN[k] = true end
C.PIN_AREA = M .. "Area"
-- base path of a pin (no size suffix); unknown keys -> the user pin
function C:PinBase(key) if not self.PIN_KNOWN[key] then key = "user" end; return M .. "Pin_" .. key end
-- path at a drawn size: 16 px art on the minimap and small pins, 32 px otherwise
function C:PinPath(key, size) return self:PinBase(key) .. (((size or 32) <= 16) and "_16" or "_32") end
-- module logos for pickers (Cartographer's icon picker): one copy each, in Beast Core Media (no per-module copies)
C.LOGO_FILES = { BeastCore = "Fennick_BeastCore", Guidepost = "Fennick_Guidepost", Rest = "Fennick_Rest", Reputation = "Fennick_Reputation",
  MerchantsFavor = "Fennick_MerchantsFavor", FoxTrials = "Fennick_FoxTrials", Trailmarks = "Fennick_Trailmarks_32" }
function C:LogoPath(k) local f = self.LOGO_FILES[k]; return f and (M .. f) or nil end
function C:PinKnown(key) return self.PIN_KNOWN[key] == true end
