# Fennick's Beast Core

The shared core of the Fennick add-ons: one focus window, one waypoint arrow, one look, one setup and one settings page that every Fennick module plugs into. It works on its own, and it is the only Fennick add-on every other one needs.

| | |
|---|---|
| Version | 1.6.1 |
| Game | WoW Forever (Interface 16001) |
| Requires | Nothing |
| Works with (optional) | TomTom, LibDBIcon-1.0, LibSharedMedia-3.0, Masque, ElvUI (read only) |
| License | PolyForm Noncommercial 1.0.0 (`LICENSE.md`) |

## What it does
- **Focus window.** One window shows the one thing to do next. Pick a module to focus on, or Auto: the first module with something to do owns the window and the arrow, and the others add one short line each.
- **Waypoint arrow.** A built-in arrow with distance, or TomTom's arrow when TomTom is installed. Two modules never drive the arrow at once.
- **Monster tooltip.** Level range, elite or rare, health when known, quests in your log or on your route, notable drops, and cloth for humanoids. At most 8 lines, nothing added in combat unless you turn it on, and no IDs are ever shown.
- **Map tooltips.** Hover a Fennick pin or shaded area and one tooltip lists everything under the cursor, grouped by type and with when it was last seen.
- **Moving frames.** Fennick frames appear in the game's Edit Mode. Without Edit Mode, `/fennick move` lets you drag, resize and nudge them. Frames lock again when combat starts.
- **Look.** Teal and gold by default, a dark style and a minimal style, a colour-blind option for every module, and text that follows your UI scale and text size. Window titles use the Cinzel font; every other text keeps the game's own font face.
- **Sounds.** None by default. Each optional sound cue has its own switch under Settings, and all start off.
- **Bug report text.** `/fennick report` opens a copy box with your versions, language and recent Fennick errors, ready to paste into a bug report. Nothing is sent anywhere.

## Install
Unzip `Fennick_BeastCore` into `World of Warcraft/_forever_/Interface/AddOns/`. Add any Fennick modules you want next to it; none are required. A module that needs a newer Core says so in one chat line and stays off, without a Lua error.

## Use
- `/fennick`, `/beast` or `/fbc` followed by a word: `setup`, `move`, `move reset`, `why`, `focuson <module|auto>`, `minimap`, `report`, `tester on|off`, `debug`, `help`.
- `/fennick help` lists every word, including the ones modules add. An unknown word prints the list.
- Minimap button: left-click shows or hides the window, Shift-click turns the focused module on or off, right-click opens Settings, drag to move it.

## Settings
Open the game's Settings and choose Fennick, or right-click the minimap button. Beast Core comes first, then one section per installed module. Each section shows its everyday rows; the rest sit behind "More settings".

## Role detection
Core works out how your character fights from two things the game already shows you: where your talent points sit and what your gear adds. It picks one of six simple roles (Melee DPS, Ranged DPS, Magic DPS, Healing, Tank, Hybrid) with a focus where your class has one, such as Shadow Magic DPS for a Priest. Under 10 talent points it goes by gear alone. If two different roles fit about equally, it says Hybrid. You can always set the role yourself under Settings, "Role", including Hybrid. A Survival Hunter counts as Melee DPS without a ranged weapon equipped and as Ranged DPS with one. Guidepost's quest reward pick uses it.

## Compatibility
- **TomTom:** used through its public functions only, and never in combat.
- **ElvUI:** read only. I take its font size, pixel unit and border colours so Fennick frames match.
- **Edit Mode:** supported through LibEditMode by p3lim (MIT, included unmodified in `Libs/LibEditMode`) and LibStub (public domain).

## How it works (for developers)
- `Core.lua` creates the shared table `C` and stores it as the global `Fennick_BEAST`. In Lua every value is a table, a function or a plain value, and add-ons share code by putting one table in the global namespace. `C:Method()` is Lua shorthand for `C.Method(C)`, much like calling a member function with `this`.
- Each module file starts with a guard such as `if not (Fennick_BEAST and Fennick_BEAST.API >= 3) then return end`. A `return` at the top level of a Lua file ends only that file, so a module quietly stays off when Core is missing or too old.
- Modules register with `C:RegisterModule{...}` (a Lua call may drop the parentheses when its only argument is a table literal). The module declares the Core version it needs (`needs = "1.6"`); Core refuses it with one chat line if Core is too old.
- WoW runs add-on code on events (`frame:RegisterEvent("PLAYER_LOGIN")`) and on a frame timer. Core runs one shared 1-second clock (`C:OnReassess`) so modules do not each start their own.
- "Taint" is WoW's rule that add-on code may not touch protected UI during combat. Core never changes Blizzard frames in combat and queues such work until combat ends (`C:Safe`).
- Role detection lives in `Role.lua`. It only reads public values (`GetTalentTabInfo`, `GetSpellBonusDamage`, `GetSpellBonusHealing`, `UnitDefense`, equipped item links), so it cannot taint anything. Modules call `C:Role()` and subscribe with `C:OnRoleChanged(fn)`, which stores your function and calls it later (a callback).
- The public API for module and skin authors is in `API.md` and `SKINNING.md` in the project repository.

## Support
Bug reports and questions: https://github.com/Dagodeiwos/fennick-releases/issues

## License
PolyForm Noncommercial 1.0.0. See `LICENSE.md` in this folder. The add-ons are free; they are not for sale.
