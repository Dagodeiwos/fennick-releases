local TR = (Fennick_BEAST and Fennick_BEAST.L) or setmetatable({ F = function(_, f, ...) local ok, s = pcall(string.format, f, ...); return ok and s or f end }, { __index = function(_, k) return k end })   -- l10n (Core C.L)
-- Core 1.6 (suite UX plan 5): shared copy box, error ring buffer and /fennick report.
-- C:CopyBox(title, text[, checks]): the one read-only multi-line box of the suite (report, Cartographer share, Fox Trials),
--   text pre-selected for Ctrl+C; typing resets it, Escape closes. checks (optional, at most 2): { { label, checked, onClick(on) } }
--   draw check boxes along the bottom (Fox Trials "Only Fail and Untested", "Copy result + report"); hidden otherwise.
--   Copy-out only: there is no import anywhere and nothing is sent over the network.
-- C:Debug lines and protected-call errors go to a ring of the last 50 (memory only; saved, capped at 50, only while
--   tester mode is on). Every line passes Tooltip Clean() first, so no IDs.
-- /fennick report: one copy-box text that pastes into the "Report text" field of the GitHub bug-report form.
local C = Fennick_BEAST
C.BUG_URL = "github.com/Dagodeiwos/fennick-releases/issues"   -- public bug reports (never translated)
C.RING_MAX = 50
C.errors = C.errors or {}
local function clean(s) local T = C.Tooltip; s = tostring(s or ""); if T and T.Clean then return T.Clean(s) or "" end; return s end
function C:PushError(msg)
  local line = clean(msg); if line == "" then return end
  local t = (date and date("%H:%M:%S")) or ""
  local r = self.errors; r[#r + 1] = t .. " " .. line
  while #r > self.RING_MAX do table.remove(r, 1) end
  if self:Tester() and self.db and self.db.opt then self.db.errors = r end
end
-- every debug line also lands in the ring (printing still needs /fennick debug or tester mode)
local baseDebug = C.Debug
function C:Debug(msg) self:PushError(msg); if self:O("debug") or self:Tester() then self:Print("|cff999999" .. tostring(msg) .. "|r") end end
C.baseDebug = baseDebug
-- tester mode: opt-in (/fennick tester on). Debug lines, saved error ring, module versions on the focus title, unlocks
-- Fox Trials' "Copy result + report". Never changes gameplay behaviour. Off by default.
function C:Tester() return self.db and self.db.opt and self.db.opt.tester == true end
function C:SetTester(on)
  self.db.opt.tester = on and true or false
  if on then self.db.errors = self.errors else self.db.errors = nil end
  self.dirty = true; if self.RefreshWindow then pcall(self.RefreshWindow, self) end
end
C.initHooks[#C.initHooks + 1] = function()
  -- tester mode on: bring back the saved ring (capped)
  if C:Tester() and type(C.db.errors) == "table" then
    local keep = {}; for _, l in ipairs(C.db.errors) do if type(l) == "string" then keep[#keep + 1] = l end end
    for i = 1, #C.errors do keep[#keep + 1] = C.errors[i] end
    while #keep > C.RING_MAX do table.remove(keep, 1) end
    C.errors = keep; C.db.errors = keep
  elseif not C:Tester() then C.db.errors = nil end
end
-- ---------- copy box ----------
local boxChecks = {}   -- the copy box's optional check boxes (created on first use)
function C:CopyBox(title, text, checks)
  local cf = self.copyBox
  if not cf then
    cf = CreateFrame("Frame", "Fennick_CoreCopyBox", UIParent, BackdropTemplateMixin and "BackdropTemplate" or nil); self.copyBox = cf
    cf:SetSize(560, 380); cf:SetPoint("CENTER"); cf:SetFrameStrata("DIALOG"); cf:EnableMouse(true)
    if self.Skin and self.Skin.Add then self.Skin:Add("copyBox", cf); self.Skin:Style(cf, 0.97) end
    if UISpecialFrames then table.insert(UISpecialFrames, "Fennick_CoreCopyBox") end
    cf.title = self:NewFS(cf, "OVERLAY", "GameFontNormal"); cf.title:SetPoint("TOPLEFT", 14, -12); cf.title:SetPoint("RIGHT", cf, "RIGHT", -14, 0)
    local sf = CreateFrame("ScrollFrame", "Fennick_CoreCopyBoxScroll", cf, "UIPanelScrollFrameTemplate"); sf:SetPoint("TOPLEFT", 14, -36); sf:SetPoint("BOTTOMRIGHT", -34, 44)
    local eb = CreateFrame("EditBox", nil, sf); eb:SetMultiLine(true); eb:SetAutoFocus(false); eb:SetFontObject(self:FontObj("GameFontHighlightSmall")); eb:SetWidth(500)
    sf:SetScrollChild(eb); cf.eb = eb
    eb:SetScript("OnTextChanged", function(s, user) if user then s:SetText(cf.text or ""); s:HighlightText() end end)
    eb:SetScript("OnEscapePressed", function() cf:Hide() end)
    eb:SetScript("OnEditFocusGained", function(s) s:HighlightText() end)
    local close = CreateFrame("Button", nil, cf, "UIPanelButtonTemplate"); close:SetSize(100, 22); close:SetPoint("BOTTOMRIGHT", -14, 12)
    close:SetText(TR["Close"]); close:SetScript("OnClick", function() cf:Hide() end)
  end
  for i = 1, 2 do
    local spec = type(checks) == "table" and checks[i]; local b = boxChecks[i]
    if spec and not b then
      b = CreateFrame("CheckButton", nil, cf, "UICheckButtonTemplate"); b:SetPoint("BOTTOMLEFT", 10 + (i - 1) * 240, 8); boxChecks[i] = b
      b.label = self:NewFS(cf, "OVERLAY", "GameFontHighlightSmall"); b.label:SetPoint("LEFT", b, "RIGHT", 2, 0)
      b:SetScript("OnClick", function(s) if s.fn then s.fn(s:GetChecked() and true or false) end end)
    end
    if b then
      if spec then b.fn = spec[3]; b.label:SetText(spec[1] or ""); b:SetChecked(spec[2] and true or false); b:Show(); b.label:Show()
      else b.fn = nil; b:Hide(); b.label:Hide() end
    end
  end
  cf.text = tostring(text or ""); cf.title:SetText(title or TR["Press Ctrl+C to copy"])
  cf:Show(); cf.eb:SetText(cf.text); cf.eb:SetFocus(); cf.eb:HighlightText()
  return cf
end
-- ---------- report ----------
C.REPORT_ADDONS = { { "Fennick_BeastCore", "Core" }, { "Fennick_Guidepost", "Guidepost" }, { "Fennick_Rest", "Rest" }, { "Fennick_Reputation", "Reputation" },
  { "Fennick_MerchantsFavor", "Merchant's Favor" }, { "Fennick_Trailmarks", "Trailmarks" }, { "Fennick_Cartographer", "Cartographer" }, { "Fennick_FoxTrials", "Fox Trials" } }
C.REPORT_OTHERS = { "Questie", "TomTom", "SexyMap", "ElvUI", "Leatrix_Plus", "Mapster" }
local function meta(addon, field)
  local fn = (C_AddOns and C_AddOns.GetAddOnMetadata) or rawget(_G, "GetAddOnMetadata")
  if type(fn) ~= "function" then return nil end; local ok, v = pcall(fn, addon, field); return ok and v or nil
end
local function loaded(addon)
  local fn = (C_AddOns and C_AddOns.IsAddOnLoaded) or rawget(_G, "IsAddOnLoaded")
  if type(fn) ~= "function" then return nil end; local ok, v = pcall(fn, addon); return ok and v and true or false
end
local function state(addon)
  if loaded(addon) then return "loaded" end
  local fn = (C_AddOns and C_AddOns.GetAddOnInfo) or rawget(_G, "GetAddOnInfo")
  if type(fn) == "function" then local ok, name, _, _, _, reason = pcall(fn, addon)
    if ok and name and reason ~= "MISSING" then return "disabled" end end
  return "missing"
end
-- a module's add-on folder comes from its own icon path (Interface\AddOns\<folder>\...), or the icon name itself
function C:ModuleVersion(key)
  local m = self.modules[key or ""]; local icon = m and type(m.icon) == "string" and m.icon or ""
  local folder = icon:match("AddOns\\(Fennick_%w+)") or icon:match("^(Fennick_%w+)$")
  return folder and meta(folder, "Version") or nil
end
-- short digest of the non-default Core options (keys and values only; no names, no IDs)
function C:SettingsHash()
  local keys = {}; local o = self.db and self.db.opt or {}
  for k, v in pairs(o) do local d = self.DEFAULTS[k]; if type(v) ~= "table" and v ~= d and k ~= "tester" then keys[#keys + 1] = k .. "=" .. tostring(v) end end
  table.sort(keys); local s = table.concat(keys, ";"); local h = 5381
  for i = 1, #s do h = (h * 33 + s:byte(i)) % 4294967296 end
  return string.format("%08x", h), #keys
end
function C:ReportText()
  local out = {}
  local ver, build = "?", "?"; if GetBuildInfo then local ok, v, b = pcall(GetBuildInfo); if ok then ver, build = v or "?", b or "?" end end
  local rules = "?"; local G = rawget(_G, "Fennick_GUIDE_ENGINE"); if type(G) == "table" and G.db and G.db.rules then rules = tostring(G.db.rules) end
  out[#out + 1] = string.format("Fennick report v1 | %s | client %s (%s) | locale %s | realm type %s", (date and date("%Y-%m-%d")) or "?", tostring(ver), tostring(build), (GetLocale and GetLocale()) or "enUS", rules)
  local mods = {}
  for _, a in ipairs(self.REPORT_ADDONS) do local st = state(a[1]); local v = meta(a[1], "Version")
    if st == "loaded" then mods[#mods + 1] = a[2] .. " " .. (v or "?") elseif st == "disabled" then mods[#mods + 1] = a[2] .. " (disabled)" else mods[#mods + 1] = a[2] .. " (missing)" end end
  if loaded("Fennick_BeastCore") == nil then mods[1] = "Core " .. (meta("Fennick_BeastCore", "Version") or "?") end
  out[#out + 1] = "Modules: " .. table.concat(mods, ", ")
  local others = {}
  for _, a in ipairs(self.REPORT_OTHERS) do if loaded(a) then others[#others + 1] = a .. " " .. (meta(a, "Version") or "") else others[#others + 1] = a .. " no" end end
  out[#out + 1] = "Other add-ons of note: " .. table.concat(others, ", "):gsub("%s+,", ",")
  local h, n = self:SettingsHash(); out[#out + 1] = string.format("Settings hash: %s (%d changed)%s", h, n, self:Tester() and " | tester mode" or "")
  local o = self.Owner and self:Owner(); local m = o and self.modules[o]
  local step = m and type(m.ReportStep) == "function" and select(2, pcall(m.ReportStep, m)) or nil
  out[#out + 1] = "Focus: " .. (m and (m.key .. (tonumber(step) and (" step " .. math.floor(tonumber(step))) or "")) or "none")
  local r = self.errors; local from = math.max(1, #r - 19)
  out[#out + 1] = string.format("Last %d Fennick errors/debug lines:", math.min(20, #r))
  for i = from, #r do out[#out + 1] = "  " .. clean(r[i]) end
  out[#out + 1] = "Bugs: " .. self.BUG_URL
  return table.concat(out, "\n")
end
function C:ShowReport()
  local text = self:ReportText()
  self:Safe("report", function() self:CopyBox(TR["Fennick report: press Ctrl+C, then paste it into Report text on the bug form"], text) end)
  return text
end
