local TR = (Fennick_BEAST and Fennick_BEAST.L) or setmetatable({ F = function(_, f, ...) local ok, s = pcall(string.format, f, ...); return ok and s or f end }, { __index = function(_, k) return k end })   -- l10n (Core C.L)
-- Optional player-selected quest reward focus. No talent or equipment inference.
local C = Fennick_BEAST
if not C then return end
local R = { listeners = {} }
C.RoleAPI = R

-- The six simplified roles (Pet DPS was folded into Ranged DPS and Magic DPS in October 2026). The key is stable (saved, compared in code); the label is what the player reads.
R.ROLES = { MELEE = TR["Melee DPS"], RANGED = TR["Ranged DPS"], MAGIC = TR["Magic DPS"], HEAL = TR["Healing"],
  TANK = TR["Tank"], HYBRID = TR["Hybrid"] }

-- Class-compatible manual reward focus choices; stable keys preserve saved settings.
R.CLASS = {
  WARRIOR = { { key = "MELEE", role = "MELEE", label = TR["Melee DPS"] },
              { key = "TANK", role = "TANK", label = TR["Melee Tank"] } },
  PALADIN = { { key = "HOLY_TANK", role = "TANK", label = TR["Holy Magic Tank"], school = 2 },
              { key = "HOLY_MELEE", role = "MELEE", label = TR["Holy Magic Melee DPS"], school = 2 },
              { key = "HEAL", role = "HEAL", label = TR["Healing"] } },
  HUNTER  = { { key = "RANGED", role = "RANGED", label = TR["Ranged DPS"] },
              { key = "MELEE", role = "MELEE", label = TR["Melee DPS"] } },
  ROGUE   = { { key = "MELEE", role = "MELEE", label = TR["Melee DPS"] } },
  PRIEST  = { { key = "HOLY_MAGIC", role = "MAGIC", label = TR["Holy Magic DPS"], school = 2 },
              { key = "HEAL", role = "HEAL", label = TR["Healing"] },
              { key = "SHADOW_MAGIC", role = "MAGIC", label = TR["Shadow Magic DPS"], school = 6 } },
  SHAMAN  = { { key = "NATURE_MAGIC", role = "MAGIC", label = TR["Nature/Fire Magic DPS"], school = 4, school2 = 3 },
              { key = "MELEE", role = "MELEE", label = TR["Melee DPS"] },
              { key = "HEAL", role = "HEAL", label = TR["Healing"] } },
  MAGE    = { { key = "ARCANE_MAGIC", role = "MAGIC", label = TR["Arcane Magic DPS"], school = 7 },
              { key = "FIRE_MAGIC", role = "MAGIC", label = TR["Fire Magic DPS"], school = 3 },
              { key = "FROST_MAGIC", role = "MAGIC", label = TR["Frost Magic DPS"], school = 5 } },
  WARLOCK = { { key = "SHADOW_MAGIC", role = "MAGIC", label = TR["Shadow Magic DPS"], school = 6 },
              { key = "FIRE_MAGIC", role = "MAGIC", label = TR["Fire Magic DPS"], school = 3 } },
  DRUID   = { { key = "MAGIC", role = "MAGIC", label = TR["Arcane/Nature Magic DPS"], school = 7, school2 = 4 },
              { key = "MELEE", role = "MELEE", label = TR["Melee DPS"] },
              { key = "TANK", role = "TANK", label = TR["Melee Tank"] },
              { key = "HEAL", role = "HEAL", label = TR["Healing"] } },
}

-- Stat weights per role for gear advice (relative value of one point). SP_<school> is spell power that only helps one
-- school ("Increases damage done by Fire spells"); it counts fully for the focus school and not at all otherwise.
R.WEIGHTS = {
  MELEE  = { STRENGTH = 1.0, AGILITY = 0.8, STAMINA = 0.5, ATTACK_POWER = 0.45, CRIT = 8, HIT = 8, ARMOR = 0.02, DPS = 3.0 },
  RANGED = { AGILITY = 1.0, STAMINA = 0.5, INTELLECT = 0.3, ATTACK_POWER = 0.45, RANGED_DPS = 3.0, CRIT = 8, HIT = 8, ARMOR = 0.02 },
  MAGIC  = { INTELLECT = 0.8, SPELL_POWER = 1.0, SP_SCHOOL = 1.0, STAMINA = 0.5, SPIRIT = 0.35, CRIT = 6, HIT = 8, MP5 = 1.2, WAND_DPS = 1.0 },
  HEAL   = { INTELLECT = 0.9, HEALING = 0.8, SPELL_POWER = 0.6, STAMINA = 0.5, SPIRIT = 0.5, MP5 = 1.5 },
  TANK   = { STAMINA = 1.0, DEFENSE = 1.2, ARMOR = 0.05, BLOCK = 0.6, STRENGTH = 0.6, AGILITY = 0.6, DPS = 1.5 },
  HYBRID = { STRENGTH = 0.5, AGILITY = 0.5, INTELLECT = 0.5, STAMINA = 0.6, SPIRIT = 0.3, SPELL_POWER = 0.5, HEALING = 0.3, ATTACK_POWER = 0.25, DPS = 1.5 },
}
-- Holy tank and Holy melee Paladins scale with spell power too (Consecration, Seal damage): a small spell power weight.
R.EXTRA = { HOLY_TANK = { SPELL_POWER = 0.3, SP_SCHOOL = 0.3 }, HOLY_MELEE = { SPELL_POWER = 0.3, SP_SCHOOL = 0.3 } }

-- "a and f()" would keep only f's first return value, so test UnitClass first and then take the second one (the
-- English class token, e.g. "PRIEST"; the first is the localized display name).
local function className() if not UnitClass then return nil end; local _, cls = UnitClass("player"); return cls end
function R:Options(cls) return self.CLASS[cls or className() or ""] or {} end
local function option(cls, key) for _, o in ipairs(R:Options(cls)) do if o.key == key then return o end end end

-- Public API on Core: C:Role() -> role key (MELEE, RANGED, MAGIC, HEAL, TANK or HYBRID), option table or nil, true when the player chose it.
function C:Role()
  local cls = className(); local over = self.db and self.db.roleFocus
  if over == "HYBRID" then return "HYBRID", nil, true end   -- Hybrid picked on purpose in Settings
  local o = over and option(cls, over)
  if o then return o.role, o, true end
  return nil, nil, false
end
function C:RoleLabel()
  local role, o, chosen = self:Role(); if not role then return TR["not known yet"] end
  local t = o and o.label or R.ROLES[role]
  return t
end
-- Weights for gear advice, with school spell power folded in for the focus school.
function C:RoleWeights()
  local role, o = self:Role(); if not role then return nil end
  local w = {}; for k, v in pairs(R.WEIGHTS[role] or {}) do w[k] = v end
  for k, v in pairs(o and R.EXTRA[o.key] or {}) do w[k] = (w[k] or 0) + v end
  return w, o and o.school, o and o.school2
end
-- Player override (nil = no focus). Saved per character in Fennick_CoreDB.
function C:SetRoleFocus(key) if not self.db then return end; self.db.roleFocus = key; R:Check() end
function C:RoleChoices() local t = { false }; for _, o in ipairs(R:Options()) do t[#t + 1] = o.key end; t[#t + 1] = "HYBRID"; return t end
function C:RoleChoiceLabel(key)
  if not key then return TR["None"] end; if key == "HYBRID" then return R.ROLES.HYBRID end
  local o = option(nil, key); return o and o.label or key
end
-- Saved-settings migration (Core 1.8). Pet DPS is gone: a saved Pet DPS choice becomes Ranged DPS (Hunter) or Shadow
-- Magic DPS (Warlock); any other key the class no longer has falls back to no focus (nil). Safe to run any number
-- of times and with a nil table (both just return). Returns the value it left in db.roleFocus.
R.MIGRATE = { HUNTER = { PET = "RANGED" }, WARLOCK = { PET = "SHADOW_MAGIC" } }
function R:Migrate(db, cls)
  if type(db) ~= "table" then return nil end
  local k = db.roleFocus; if k == nil or k == "HYBRID" then return k end
  cls = cls or className()
  local m = self.MIGRATE[cls or ""]; if m and m[k] then k = m[k] end
  if not option(cls, k) then k = nil end
  db.roleFocus = k; return k
end
C.initHooks[#C.initHooks + 1] = function() R:Migrate(C.db) end
-- Callback when the role or focus changes: fn(role, option). Returns fn so callers can keep a handle.
function C:OnRoleChanged(fn) if type(fn) == "function" then R.listeners[#R.listeners + 1] = fn; return fn end end

-- Notify consumers only when the selected focus changes.
function R:Check()
  local role, o = C:Role(); local sig = tostring(role) .. ":" .. tostring(o and o.key)
  if sig == self.last then return end
  self.last = sig
  for _, fn in ipairs(self.listeners) do local ok, err = pcall(fn, role, o); if not ok then C:Debug("role: " .. tostring(err)) end end
end
C:On("PLAYER_ENTERING_WORLD", function() R:Check() end)

-- Item stats for gear advice, normalized to short keys (STRENGTH, SPELL_POWER, SP_FIRE, ...).
-- GetItemStats gives the generic stats. Spell power for one school ("Equip: Increases damage done by Fire spells and
-- effects by up to 7.") is not a stat in this client, so I read the item's tooltip lines (C_TooltipInfo, read-only data,
-- no tooltip frame is shown) and look for an "Equip:" line naming one school. School names come from the client's own
-- localized strings, so this works in every language the client ships.
local STATKEY = { ITEM_MOD_STRENGTH_SHORT = "STRENGTH", ITEM_MOD_AGILITY_SHORT = "AGILITY", ITEM_MOD_STAMINA_SHORT = "STAMINA",
  ITEM_MOD_INTELLECT_SHORT = "INTELLECT", ITEM_MOD_SPIRIT_SHORT = "SPIRIT", ITEM_MOD_SPELL_POWER_SHORT = "SPELL_POWER",
  ITEM_MOD_SPELL_HEALING_DONE_SHORT = "HEALING", ITEM_MOD_SPELL_DAMAGE_DONE_SHORT = "SPELL_POWER", ITEM_MOD_ATTACK_POWER_SHORT = "ATTACK_POWER",
  ITEM_MOD_DEFENSE_SKILL_RATING_SHORT = "DEFENSE", ITEM_MOD_BLOCK_VALUE_SHORT = "BLOCK", ITEM_MOD_CRIT_RATING_SHORT = "CRIT",
  ITEM_MOD_HIT_RATING_SHORT = "HIT", ITEM_MOD_POWER_REGEN0_SHORT = "MP5", ITEM_MOD_MANA_REGENERATION_SHORT = "MP5",
  RESISTANCE0_NAME = "ARMOR", ITEM_MOD_DAMAGE_PER_SECOND_SHORT = "DPS" }
R.STATKEY = STATKEY
-- school index -> the client's localized school name global (with an English fallback for test runs)
local SCHOOLS = { [2] = { "STRING_SCHOOL_HOLY", "Holy" }, [3] = { "STRING_SCHOOL_FIRE", "Fire" }, [4] = { "STRING_SCHOOL_NATURE", "Nature" },
  [5] = { "STRING_SCHOOL_FROST", "Frost" }, [6] = { "STRING_SCHOOL_SHADOW", "Shadow" }, [7] = { "STRING_SCHOOL_ARCANE", "Arcane" } }
function R:SchoolPower(link)
  local out = {}
  if not (link and C_TooltipInfo and C_TooltipInfo.GetHyperlink) then return out end
  local ok, data = pcall(C_TooltipInfo.GetHyperlink, link); if not (ok and data and data.lines) then return out end
  local equip = _G.ITEM_SPELL_TRIGGER_ONEQUIP or "Equip:"
  for _, line in ipairs(data.lines) do
    local t = line.leftText
    if type(t) == "string" and t:sub(1, #equip) == equip then
      local hit, n
      for i, sc in pairs(SCHOOLS) do local name = _G[sc[1]] or sc[2]; if t:find(name, 1, true) then if hit ~= nil then hit = false else hit = i end end end
      n = tonumber(t:match("(%d+)%D*$"))   -- the last number on the line is the amount
      if hit and n then out[hit] = (out[hit] or 0) + n end
    end
  end
  return out
end
function C:ItemStats(link)
  local raw = (C_Item and C_Item.GetItemStats and C_Item.GetItemStats(link)) or (GetItemStats and GetItemStats(link)) or {}
  local s = {}
  for k, v in pairs(raw) do local key = STATKEY[k]; if key then s[key] = (s[key] or 0) + v end end
  if s.DPS and GetItemInfoInstant then
    local _, _, _, equip, _, cls, sub = GetItemInfoInstant(link)
    if equip == "INVTYPE_RANGED" or equip == "INVTYPE_RANGEDRIGHT" or equip == "INVTYPE_THROWN" then
      s[(cls == 2 and sub == 19) and "WAND_DPS" or "RANGED_DPS"] = s.DPS; s.DPS = nil end
  end
  for i, n in pairs(R:SchoolPower(link)) do s["SP_" .. i] = n end
  return s
end
-- Score of one item for the current role (no weapon-type fit; callers multiply their own fit). nil when no role.
function C:RoleItemScore(link, w, school, school2)
  if not w then w, school, school2 = self:RoleWeights() end
  if not (w and link) then return nil end
  local total = 0
  for k, v in pairs(self:ItemStats(link)) do
    local sc = tonumber(k:match("^SP_(%d)$"))
    if sc then if sc == school or sc == school2 then total = total + (w.SP_SCHOOL or 0) * v end
    elseif w[k] then total = total + w[k] * v end
  end
  return total
end
