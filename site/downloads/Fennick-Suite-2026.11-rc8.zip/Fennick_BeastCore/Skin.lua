local TR = (Fennick_BEAST and Fennick_BEAST.L) or setmetatable({ F = function(_, f, ...) local ok, s = pcall(string.format, f, ...); return ok and s or f end }, { __index = function(_, k) return k end })   -- l10n (Core C.L)
-- Public skinning API (Fennick_BEAST.Skin), optional Masque + LibSharedMedia-3.0, style presets.
-- Nothing embedded: libraries are used only when another add-on already loaded them (LibStub(name, true)).
-- Taint-free: only our own frames are touched; skin callbacks run protected (pcall) and out of combat.
local E = Fennick_BEAST
local Skin = { frames = {}, buttons = {}, callbacks = {}, version = 1 }
E.Skin = Skin

local function LS(name) return LibStub and LibStub(name, true) end
local masqueGroup
local function masque()
  if masqueGroup == nil then
    local MSQ = LS("Masque"); masqueGroup = false
    if MSQ and MSQ.Group then local ok, g = pcall(MSQ.Group, MSQ, E.brand, "Buttons"); if ok and g then masqueGroup = g end end
  end
  return masqueGroup or nil
end

local function fire(kind, frame)
  for _, cb in ipairs(Skin.callbacks) do
    E:Safe(TR:F("skin:%s%s", tostring(cb), kind), function()
      local ok, err = pcall(cb, "FRAME_CREATED", kind, frame); if not ok then E:Debug("skin callback error: " .. tostring(err)) end
    end)
  end
end

-- internal: called by Fennick when it creates a frame (kind = "guide", "arrow", "minimap", "settings", "setup", "profs", "loadout", ...)
function Skin:Add(kind, frame) self.frames[kind] = frame; fire(kind, frame); return frame end
-- internal: buttons go to Masque (if loaded) and to skin callbacks as kind "button"
function Skin:AddButton(btn, owner)
  self.buttons[#self.buttons + 1] = btn; btn.fennickOwner = owner
  local g = masque(); if g then pcall(g.AddButton, g, btn, { Icon = btn.icon, Highlight = btn.GetHighlightTexture and btn:GetHighlightTexture() or nil }) end
  if owner ~= "minimap" then pcall(self.StyleButton, self, btn) end
  fire("button", btn); return btn
end

-- PUBLIC: table kind -> frame (copy) plus .buttons list. Frames also have stable global names (see SKINNING.md).
function Skin:GetFrames()
  local t = { buttons = {} }; for k, v in pairs(self.frames) do t[k] = v end
  for i, b in ipairs(self.buttons) do t.buttons[i] = b end; return t
end
-- PUBLIC: callback(event, kind, frame); event is "FRAME_CREATED" (also replayed for frames that already exist)
-- or "STYLE_CHANGED" (kind = preset name, frame = nil). Returns a handle for UnregisterSkin.
function Skin:RegisterSkin(cb)
  if type(cb) ~= "function" then return end
  self.callbacks[#self.callbacks + 1] = cb
  for kind, f in pairs(self.frames) do E:Safe("skinreplay" .. tostring(cb) .. kind, function() pcall(cb, "FRAME_CREATED", kind, f) end) end
  for _, b in ipairs(self.buttons) do E:Safe("skinreplayb" .. tostring(cb) .. tostring(b), function() pcall(cb, "FRAME_CREATED", "button", b) end) end
  return cb
end
function Skin:UnregisterSkin(h) for i, cb in ipairs(self.callbacks) do if cb == h then table.remove(self.callbacks, i); return true end end end
-- PUBLIC: an external skin can ask Fennick to stop drawing its own backdrops/fonts (it styles everything itself)
function Skin:SetExternal(on) E.db.opt.externalSkin = on and true or false; E:ApplyLook() end

-- LibSharedMedia (optional) ------------------------------------------------------------------------
local DEF = { font = "Fonts\\FRIZQT__.TTF", statusbar = "Interface\\TargetingFrame\\UI-StatusBar",
  border = "Interface\\Tooltips\\UI-Tooltip-Border", background = "Interface\\Tooltips\\UI-Tooltip-Background" }
function Skin:Media(kind, name)
  if name and name ~= "Default" then
    local lsm = LS("LibSharedMedia-3.0")
    if lsm and lsm.Fetch then local ok, p = pcall(lsm.Fetch, lsm, kind, name, true); if ok and p then return p end end
  end
  return DEF[kind]
end

-- Presets ------------------------------------------------------------------------------------------
-- One Fennick look for every module. default = teal + gold (1 px pixel-snapped gold edge), light-gold
-- titles, cream text, amber accents; green stays the "done" signal and red is reserved for the HC badge. dark = the old neutral
-- look (pre-1.2 default), minimal = borderless. Font FACE is never changed by any preset (only the size offset).
local function hex(h) return { tonumber(h:sub(1, 2), 16) / 255, tonumber(h:sub(3, 4), 16) / 255, tonumber(h:sub(5, 6), 16) / 255 } end
Skin.PAL = { header = hex("193D35"), body = hex("14191B"), gold = hex("D6B66C"), title = hex("E8D29A"), text = hex("E3D8BB"),
  amber = hex("E0953A"), hover = hex("315247"), card = hex("193D35"), track = hex("303A33"), btn = hex("203B33"), hc = hex("78201A"), bronze = hex("80633D"), jade = hex("83BFA7"), celestial = hex("739CC7"), muted = { 0.47, 0.47, 0.47 } }
local P = Skin.PAL
Skin.PRESETS = {
  default = { alpha = 0.94, border = true, pixel = true, bg = P.body, edge = P.gold, title = P.title, text = P.text, sep = { P.gold[1], P.gold[2], P.gold[3], 0.6 }, sepGap = 8,
    header = { P.header[1], P.header[2], P.header[3], 1 }, card = { P.card[1], P.card[2], P.card[3], 1 }, accent = P.amber, accentW = 3, bar = P.jade, track = P.track,
    guideHdr = P.gold, guideHdrText = "GUIDANCE", buttons = "fennick", warn = P.amber },
  minimal = { alpha = 0.0, border = false, bg = { 0, 0, 0 }, edge = { 0, 0, 0 }, title = { 0.9, 0.9, 0.9 }, sep = { 1, 1, 1, 0.25 }, sepGap = 10,
    header = { 0, 0, 0, 0 }, card = { 1, 1, 1, 0.07 }, accent = P.amber, accentW = 2, bar = P.gold, track = { 0.16, 0.16, 0.16 }, guideHdr = { 0.6, 0.6, 0.6 }, guideHdrText = "Guidance", warn = P.amber },
  dark = { alpha = 0.75, border = true, bg = { 0, 0, 0 }, edge = { 1, 1, 1 }, title = { 1, 0.82, 0 }, sep = { 1, 1, 1, 0.15 }, sepGap = 8,
    header = { 0.15, 0.35, 0.6, 0.55 }, card = { 1, 1, 1, 0.07 }, accent = { 0.2, 0.7, 1 }, accentW = 2, bar = { 0.2, 0.7, 1 }, track = { 0.16, 0.16, 0.16 }, guideHdr = { 0.6, 0.6, 0.6 }, guideHdrText = "Guidance", warn = { 1, 0.6, 0.33 } },
}
function E:Preset() return Skin.PRESETS[self:O("preset")] or Skin.PRESETS.default end
-- module icons (64 px TGA). WoW loads TGA when the path has no extension. Never used below 32 px except the minimap.
E.ICONS = { minimap = "Fennick_Minimap", core = "Fennick_BeastCore" }   -- modules name their own icon file (m.icon)
function E:Icon(key) local m = self.modules[key]; local n = (m and type(m.icon) == "string" and m.icon) or self.ICONS[key] or self.ICONS.core; if n:find("\\", 1, true) then return n end return "Interface\\AddOns\\Fennick_BeastCore\\Media\\" .. n end
-- N-1 / K-9: shared status colours; the colour-blind option swaps green/red for blue/orange
E.STATUS = { done = { 0.33, 1, 0.33 }, warn = P.amber, danger = { 1, 0.33, 0.33 }, muted = P.muted, info = P.text }
E.STATUS_CB = { done = { 0.35, 0.7, 1 }, danger = { 1, 0.6, 0.1 } }
function E:StatusColor(kind) local cb = self:O("colorblind") and self.STATUS_CB[kind]; return cb or self.STATUS[kind] or self.STATUS.info end
function E:StatusHex(kind) local c = self:StatusColor(kind); return string.format("|cff%02x%02x%02x", c[1] * 255, c[2] * 255, c[3] * 255) end
function E:OnOff(v) return v and (self:StatusHex("done") .. TR["ON"] .. "|r") or (self:StatusHex("danger") .. TR["OFF"] .. "|r") end
-- LSM media "Fennick Teal" / "Fennick Gold 1px" (registered only when another add-on loaded LibSharedMedia)
do local lsm = LS("LibSharedMedia-3.0")
  if lsm and lsm.Register then pcall(lsm.Register, lsm, "background", "Fennick Teal", "Interface\\Buttons\\WHITE8X8"); pcall(lsm.Register, lsm, "border", "Fennick Gold 1px", "Interface\\Buttons\\WHITE8X8") end end
-- Buttons in the Fennick look: dark teal fill, 1 px gold edge, light-gold label, burnt-amber hover; HC badge = red + amber edge.
-- Skipped when Masque styles our buttons or an external skin owns the look.
function Skin:StyleButton(b)
  if not b or not b.CreateTexture then return end
  local p = E:Preset(); local own = p.buttons == "fennick" and not E:O("externalSkin") and not masque()
  local function tex(k, layer) if type(b[k]) ~= "table" then b[k] = b:CreateTexture(nil, layer or "BACKGROUND") end; return b[k] end
  local bg, t1, t2, t3, t4 = tex("fbg"), tex("fe1", "BORDER"), tex("fe2", "BORDER"), tex("fe3", "BORDER"), tex("fe4", "BORDER")
  for _, n in ipairs({ "Left", "Middle", "Right" }) do local r = b[n]; if type(r) == "table" and r.SetAlpha then r:SetAlpha(own and 0 or 1) end end
  for _, g in ipairs({ "GetNormalTexture", "GetPushedTexture", "GetDisabledTexture" }) do local r = b[g] and b[g](b); if type(r) == "table" and r.SetAlpha then r:SetAlpha(own and 0 or 1) end end
  if not own then for _, t in ipairs({ bg, t1, t2, t3, t4 }) do t:Hide() end; return end
  local hc = b.fennickHC == true; local fill = hc and P.hc or P.btn; local edge = hc and P.amber or P.gold; local px = E:Snap(1, b, 1)
  bg:ClearAllPoints(); bg:SetAllPoints(); bg:SetColorTexture(fill[1], fill[2], fill[3], 1); bg:Show()
  t1:ClearAllPoints(); t1:SetPoint("TOPLEFT"); t1:SetPoint("TOPRIGHT"); t1:SetHeight(px)
  t2:ClearAllPoints(); t2:SetPoint("BOTTOMLEFT"); t2:SetPoint("BOTTOMRIGHT"); t2:SetHeight(px)
  t3:ClearAllPoints(); t3:SetPoint("TOPLEFT"); t3:SetPoint("BOTTOMLEFT"); t3:SetWidth(px)
  t4:ClearAllPoints(); t4:SetPoint("TOPRIGHT"); t4:SetPoint("BOTTOMRIGHT"); t4:SetWidth(px)
  for _, t in ipairs({ t1, t2, t3, t4 }) do t:SetColorTexture(edge[1], edge[2], edge[3], 1); t:Show() end
  local fsx = b.GetFontString and b:GetFontString(); if type(fsx) == "table" and fsx.SetTextColor then fsx:SetTextColor(P.title[1], P.title[2], P.title[3]) end
  if b.fennickHover ~= true and b.HookScript then b.fennickHover = true
    b:HookScript("OnEnter", function(self) if type(self.fbg) == "table" and self.fbg:IsShown() and self.fennickHC ~= true then self.fbg:SetColorTexture(P.hover[1], P.hover[2], P.hover[3], 1) end end)
    b:HookScript("OnLeave", function(self) if type(self.fbg) == "table" and self.fbg:IsShown() then local c = (self.fennickHC == true) and P.hc or P.btn; self.fbg:SetColorTexture(c[1], c[2], c[3], 1) end end) end
  b.fennickStyle = { fill = fill, edge = edge, text = P.title }
end
function Skin:StyleBar(bar)
  if not bar then return end; local p = E:Preset()
  if bar.SetStatusBarTexture then pcall(bar.SetStatusBarTexture, bar, self:Media("statusbar", E:O("lsmBar"))) end
  local c = p.bar or P.gold; if bar.SetStatusBarColor then bar:SetStatusBarColor(c[1], c[2], c[3]) end
  if type(bar.track) ~= "table" and bar.CreateTexture then bar.track = bar:CreateTexture(nil, "BACKGROUND"); bar.track:SetAllPoints() end
  local t = p.track or P.track; if type(bar.track) == "table" then bar.track:SetColorTexture(t[1], t[2], t[3], 1) end
  bar.fennickColor, bar.fennickTrack = c, t
end
Skin.PRESET_ORDER = { "default", "minimal", "dark" }
function E:ApplyPreset(name)
  local p = Skin.PRESETS[name]; if not p then return end
  self.db.opt.preset = name; self.db.opt.alpha = p.alpha
  self:ApplyLook()
  for _, cb in ipairs(Skin.callbacks) do pcall(cb, "STYLE_CHANGED", name) end
end
-- applies preset colours + media to one of our backdrop frames (skipped when an external skin owns the look)
function Skin:Style(f, alpha)
  if not f or E:O("externalSkin") or not f.SetBackdrop then return end
  local p = self.PRESETS[E:O("preset")] or self.PRESETS.default
  local L = E.LookSpec and E:LookSpec(f) or { edge = 12, inset = 3 }
  if p.pixel and L.match ~= "elvui" and L.match ~= "tracker" then local u = E:PixelUnit(f); L = { match = L.match, pixel = true, edge = u, inset = u, pad = L.pad, unit = u } end   -- UI-1: crisp 1 px gold edge
  local edgeFile = p.border and (L.pixel and "Interface\\Buttons\\WHITE8X8" or self:Media("border", E:O("lsmBorder"))) or nil
  f:SetBackdrop({ bgFile = L.pixel and "Interface\\Buttons\\WHITE8X8" or self:Media("background", E:O("lsmBackground")), edgeFile = edgeFile,
    edgeSize = L.edge, insets = { left = L.inset, right = L.inset, top = L.inset, bottom = L.inset } })
  local bg = L.bg or p.bg
  f:SetBackdropColor(bg[1], bg[2], bg[3], alpha or E:O("alpha"))
  if p.border then local ec = L.edgeColor or p.edge; f:SetBackdropBorderColor(ec[1], ec[2], ec[3], 1) end
end
-- one place re-applies the look: Core's own frames, then every module (m:ApplyLook)
function E:ApplyLook()
  if self.RefreshFonts then self:RefreshFonts() end
  for kind, f in pairs(Skin.frames) do if f.SetBackdrop and kind ~= "arrow" and kind ~= "button" then Skin:Style(f, kind == "setup" and 0.95 or nil) end end
  for _, b in ipairs(Skin.buttons) do if b.fennickOwner ~= "minimap" then pcall(Skin.StyleButton, Skin, b) end end
  if self.LayoutWindow then pcall(self.LayoutWindow, self) end
  for _, m in ipairs(self.order) do self:Call(m, "ApplyLook") end
end
