local TR = (Fennick_BEAST and Fennick_BEAST.L) or setmetatable({ F = function(_, f, ...) local ok, s = pcall(string.format, f, ...); return ok and s or f end }, { __index = function(_, k) return k end })   -- l10n (Core C.L)
-- Generic step engine for modules: a step list, completion predicates, manual skip, player position and game-state helpers.
-- A step = { id, text, sub, npc, z, x, y, done = function() end, avail = function() end, tips = {...} }.
local C = Fennick_BEAST
-- Short-lived shared inventory cache, invalidated immediately on bag changes.
local counts, countAt = {}, nil
local function clearCounts() counts = {}; countAt = nil end
C:On("BAG_UPDATE", clearCounts)
C:On("BAG_UPDATE_DELAYED", clearCounts)
C:On("PLAYER_ENTERING_WORLD", clearCounts)
function C:ItemCount(item)
  if item == nil then return 0 end
  local now = GetTime and GetTime()
  if now and (not countAt or now < countAt or now - countAt >= 0.25) then counts = {}; countAt = now end
  if now and counts[item] ~= nil then return counts[item] end
  local n = (C_Item and C_Item.GetItemCount and C_Item.GetItemCount(item)) or (GetItemCount and GetItemCount(item)) or 0
  if now then counts[item] = n end
  return n
end
-- Shared quest snapshots. Cache false as well as true; never persist across sessions.
local completed, active, questAt = {}, {}, nil
local function clearQuests() completed = {}; active = {}; questAt = nil end
for _, ev in ipairs({"QUEST_LOG_UPDATE", "QUEST_ACCEPTED", "QUEST_REMOVED", "QUEST_TURNED_IN", "PLAYER_ENTERING_WORLD"}) do C:On(ev, clearQuests) end
local function questClock()
  local now = GetTime and GetTime()
  if now and (not questAt or now < questAt or now - questAt >= 0.25) then clearQuests(); questAt = now end
  return now
end
function C:QuestDone(q)
  if q == nil then return false end
  local now = questClock()
  if now and completed[q] ~= nil then return completed[q] end
  local done
  if C_QuestLog and C_QuestLog.IsQuestFlaggedCompleted then done = C_QuestLog.IsQuestFlaggedCompleted(q)
  elseif IsQuestFlaggedCompleted then done = IsQuestFlaggedCompleted(q) end
  done = done and true or false
  if now then completed[q] = done end
  return done
end
function C:OnQuest(q)
  if q == nil then return false end
  local now = questClock()
  if now and active[q] ~= nil then return active[q] end
  local on
  if C_QuestLog and C_QuestLog.IsOnQuest then on = C_QuestLog.IsOnQuest(q)
  elseif C_QuestLog and C_QuestLog.GetLogIndexForQuestID then on = (C_QuestLog.GetLogIndexForQuestID(q) or 0) > 0
  elseif GetQuestLogIndexByID then on = (GetQuestLogIndexByID(q) or 0) > 0 end
  on = on and true or false
  if now then active[q] = on end
  return on
end
-- One faction snapshot serves both standing display and raw quest requirements.
local factions, factionAt = {}, nil
local function clearFactions() factions = {}; factionAt = nil end
C:On("UPDATE_FACTION", clearFactions)
C:On("PLAYER_ENTERING_WORLD", clearFactions)
local function faction(fid)
  if fid == nil or not GetFactionInfoByID then return end
  local now = GetTime and GetTime()
  if now and (not factionAt or now < factionAt or now - factionAt >= 0.25) then clearFactions(); factionAt = now end
  if now and factions[fid] ~= nil then return factions[fid] or nil end
  local name, _, st, lo, hi, val = GetFactionInfoByID(fid)
  local data = name and { name = name, standing = st, lo = lo or 0, hi = hi or 0, value = val or 0 } or false
  if now then factions[fid] = data end
  return data or nil
end
-- standing 1..8 (Hated..Exalted), value inside the bar, bar max; nil for unknown factions
function C:Standing(fid)
  local d = faction(fid); if not d then return end
  return d.standing, d.value - d.lo, d.hi - d.lo, d.name
end
-- raw reputation value on the Neutral = 0 scale
function C:RepValue(fid)
  local d = faction(fid); if d then return d.value end
end
C.STANDING = { "Hated", "Hostile", "Unfriendly", "Neutral", "Friendly", "Honored", "Revered", "Exalted" }
-- l10n: the client's own standing names (FACTION_STANDING_LABEL1..8), English as the fallback
for i = 1, 8 do local g = _G["FACTION_STANDING_LABEL" .. i]; if type(g) == "string" and g ~= "" then C.STANDING[i] = g end end
-- Share position reads within a rendered frame; never retain across frames.
local posAt, posMap, posX, posY
function C:PlayerPos()
  local now = GetTime and GetTime()
  if now and posAt == now then return posMap, posX, posY end
  local m = C_Map and C_Map.GetBestMapForUnit and C_Map.GetBestMapForUnit("player")
  local p = m and C_Map.GetPlayerMapPosition and C_Map.GetPlayerMapPosition(m, "player")
  posAt, posMap, posX, posY = now, nil, nil, nil
  if p then
    local x,y=p.x,p.y; if p.GetXY then x,y=p:GetXY() end
    if type(x)=="number" and type(y)=="number" and x>=0 and x<=1 and y>=0 and y<=1 then posMap,posX,posY=m,x*100,y*100 end
  end
  return posMap, posX, posY
end
C:On("PLAYER_ENTERING_WORLD", function() posAt = nil end)
C:On("ZONE_CHANGED_NEW_AREA", function() posAt = nil end)
local zc = {}
function C:ZoneName(z)
  if not z then return end
  if zc[z] == nil then local i = C_Map and C_Map.GetMapInfo and C_Map.GetMapInfo(z); zc[z] = i and i.name end
  return zc[z] or nil
end
function C:Where(s) if not (s and s.z and type(s.x) == "number" and type(s.y) == "number") then return "" end; local zn = self:ZoneName(s.z); return string.format("  |cff999999%s(%.0f, %.0f)|r", zn and (zn .. " ") or "", s.x, s.y) end
-- first open step of a list (not done, available, not skipped by hand)
function C:FirstStep(key, list)
  local sk = self:ModDB(key).skipped or {}
  for i, s in ipairs(list or {}) do
    local ok1, av = true, true; if s.avail then ok1, av = pcall(s.avail, s) end
    if ok1 and av and not sk[s.id or i] then
      local ok2, d = true, false; if s.done then ok2, d = pcall(s.done, s) end
      if ok2 and not d then return s, i end
    end
  end
end
function C:SkipStep(key, s) if s then local d = self:ModDB(key); d.skipped = d.skipped or {}; d.skipped[s.id or s] = true end end
function C:UnskipAll(key) self:ModDB(key).skipped = {} end
-- distance in yards from the player to a map point (z, x, y in 0-100); nil when unknown (different continent, no API)
local worldAt, worldMap, worldX, worldY, worldOK, worldContinent, worldPos
function C:Yards(z, x, y)
  if not (C_Map and C_Map.GetWorldPosFromMapPos and CreateVector2D and z and type(x) == "number" and type(y) == "number") then return end
  local m, px, py = self:PlayerPos(); if not m then return end
  local now = GetTime and GetTime()
  if not now or worldAt ~= now or worldMap ~= m or worldX ~= px or worldY ~= py then
    worldOK, worldContinent, worldPos = pcall(C_Map.GetWorldPosFromMapPos, m, CreateVector2D(px / 100, py / 100))
    worldAt, worldMap, worldX, worldY = now, m, px, py
  end
  local ok1, c1, w1 = worldOK, worldContinent, worldPos
  local ok2, c2, w2 = pcall(C_Map.GetWorldPosFromMapPos, z, CreateVector2D(x / 100, y / 100))
  if not (ok1 and ok2 and w1 and w2) or c1 ~= c2 then return end
  return math.sqrt((w1.x - w2.x) ^ 2 + (w1.y - w2.y) ^ 2)
end
-- remaining seconds of a player aura by spell ID (nil = not present); auras without expiry count as long-lasting
local auras, auraAt = {}, nil
local function clearAuras() auras = {}; auraAt = nil end
C:On("UNIT_AURA", function(_, unit) if unit == "player" then clearAuras() end end)
C:On("PLAYER_ENTERING_WORLD", clearAuras)
function C:AuraLeft(id)
  if id == nil or not (C_UnitAuras and C_UnitAuras.GetPlayerAuraBySpellID) then return end
  local now = GetTime and GetTime()
  if now and (not auraAt or now < auraAt or now - auraAt >= 0.25) then clearAuras(); auraAt = now end
  local a = now and auras[id]
  if a == nil or not now then
    local ok, data = pcall(C_UnitAuras.GetPlayerAuraBySpellID, id)
    if not ok then return end
    a = type(data) == "table" and { expiration = tonumber(data.expirationTime) or 0, applications = data.applications } or false
    if now then auras[id] = a end
  end
  if not a then return end
  if a.expiration <= 0 then return math.huge, a.applications end
  return math.max(0, a.expiration - (now or 0)), a.applications
end
-- seconds until an item is usable again (0 = ready, nil = unknown)
function C:ItemCooldown(item)
  local f = (C_Container and C_Container.GetItemCooldown) or GetItemCooldown; if not f then return end
  local ok, start, dur = pcall(f, item); if not ok or not start then return end
  if start == 0 or dur == 0 then return 0 end
  return math.max(0, start + dur - (GetTime and GetTime() or 0))
end
function C:Duration(sec)
  if not sec then return "?" end
  if sec >= 86400 then return string.format("%d d %d h", sec / 86400, (sec % 86400) / 3600) end
  if sec >= 3600 then return TR:F("%d h %d min", sec / 3600, (sec % 3600) / 60) end
  return string.format("%d min", math.max(1, math.ceil(sec / 60)))
end
