local TR = (Fennick_BEAST and Fennick_BEAST.L) or setmetatable({ F = function(_, f, ...) local ok, s = pcall(string.format, f, ...); return ok and s or f end }, { __index = function(_, k) return k end })   -- l10n (Core C.L)
-- Monster tooltip (MobInfo-style). Hooks GameTooltip only through HookScript / TooltipDataProcessor post-calls:
-- no secure frame is changed, nothing is created or shown in combat, lines are only appended.
-- Lines are registered: Core registers the generic ones; modules add their own with C.Tooltip:RegisterLine().
-- Visible text never contains IDs (every line passes through Clean()).
local C = Fennick_BEAST
local T = { lines = {}, data = {}, version = 1 }
C.Tooltip = T

-- PUBLIC: fn(info) -> string, or a list of strings, or nil. info = { unit, name, level, classification, npcID (internal only),
--   humanoid, hpMax, data = merged module data for this monster }. label shows in Settings; order sorts the lines.
function T:RegisterLine(key, label, fn, order, owner)
  if type(key) ~= "string" or type(fn) ~= "function" then return end
  for _, l in ipairs(self.lines) do if l.key == key then return l end end
  local l = { key = key, label = label or key, fn = fn, order = order or 50, owner = owner }
  self.lines[#self.lines + 1] = l; table.sort(self.lines, function(a, b) return a.order < b.order end); return l
end
-- PUBLIC: provider(npcID) -> table merged into info.data (lo, hi, rank, drops = {names}, starts = {names}, quests = {titles})
function T:RegisterData(provider) if type(provider) == "function" then self.data[#self.data + 1] = provider end end
function T:Enabled(key) local t = C:O("tipLines"); return not (type(t) == "table" and t[key] == false) end
function T:SetEnabled(key, on) C.db.opt.tipLines = type(C.db.opt.tipLines) == "table" and C.db.opt.tipLines or {}; C.db.opt.tipLines[key] = on and true or false end

-- no IDs in visible text: drop "id", "ID:", long digit runs (>4) and bracketed numbers
function T.Clean(s)
  if type(s) ~= "string" then return nil end
  -- GUIDs (Creature-0-4372-0-1-3098-00001A2B3C, Player-4372-0ABC1234, GameObject-...) and Trailmarks ID keys (n3098, o4711)
  s = s:gsub("%a+%-%d+%-%d+%-%d+%-%d+%-%d+%-%x+", ""):gsub("Player%-%d+%-%x+", ""):gsub("%f[%w][no]%d%d%d+%f[%W]", "")
  s = s:gsub("%f[%w][Ii][Dd]%f[%W]%s*:?%s*%d*", ""):gsub("[%(%[]%s*#?%d+%s*[%)%]]", ""):gsub("#%d+", "")
  s = s:gsub("%f[%d]%d%d%d%d%d+%f[%D]", "")
  s = s:gsub("[%(%[]%s*[%)%]]", ""):gsub("%s%s+", " "):gsub("^%s+", ""):gsub("%s+$", "")
  return s ~= "" and s or nil
end
local HUMANOID = { Humanoid = true, Humanoide = true, ["Humanoïde"] = true, ["Гуманоид"] = true, ["人型生物"] = true, ["인간형"] = true, ["Umanoide"] = true }
local function npcID(unit)
  local g = UnitGUID and UnitGUID(unit); if not g then return end
  local kind, _, _, _, _, id = strsplit("-", g)   -- 1.60.1: server/spawn fields are obfuscated; field 6 (NPC ID) is still real
  if kind == "Creature" or kind == "Vehicle" then return tonumber(id) end
end
local cache, cacheN = {}, 0
function T:Info(unit)
  if not (UnitExists and UnitExists(unit)) or (UnitIsPlayer and UnitIsPlayer(unit)) then return end
  local id = npcID(unit); if not id then return end
  local now = GetTime and GetTime() or 0
  local c = cache[unit .. id]; if c and now - c.t < 0.5 then return c.info end
  local data = {}
  for _, p in ipairs(self.data) do local ok, d = pcall(p, id); if ok and type(d) == "table" then for k, v in pairs(d) do data[k] = v end end end
  local hp = UnitHealthMax and UnitHealthMax(unit) or 0
  local info = { unit = unit, npcID = id, name = UnitName(unit), level = UnitLevel(unit) or 0, classification = UnitClassification and UnitClassification(unit) or "normal",
    humanoid = UnitCreatureType and HUMANOID[UnitCreatureType(unit) or ""] or false, hpMax = hp > 100 and hp or nil,   -- 100 = percent only (not known)
    friendly = UnitIsFriend and UnitIsFriend("player", unit), data = data }
  cache[unit .. id] = { t = now, info = info }
  cacheN = cacheN + 1; if cacheN > 64 then cache = {}; cacheN = 0 end   -- P1-13: bounded (cleared past 64 entries)
  return info
end
function T:Build(unit)
  local info = self:Info(unit); if not info then return {} end
  local out, max = {}, C:O("tipMax")
  for _, l in ipairs(self.lines) do
    if #out >= max then break end
    if self:Enabled(l.key) then
      local ok, r = pcall(l.fn, info)
      if ok and r then
        if type(r) == "string" then r = { r } end
        for _, s in ipairs(r) do local c2 = T.Clean(s); if c2 and #out < max then out[#out + 1] = c2 end end
      end
    end
  end
  return out
end
local function onUnit(tt)
  if not C:O("tooltip") or C.disabled then return end
  if C:InCombat() and not C:O("tipCombat") then return end
  if tt ~= GameTooltip then return end
  local _, unit = tt:GetUnit(); if not unit then return end
  local ok, lines = pcall(T.Build, T, unit); if not ok then C:Debug("tooltip: " .. tostring(lines)); return end
  for _, s in ipairs(lines) do tt:AddLine(s, 0.75, 0.85, 1, true) end
  if #lines > 0 and not C:InCombat() then tt:Show() end
end
T.OnUnit = onUnit
function T:Hook()
  if self.hooked then return end; self.hooked = true
  if TooltipDataProcessor and TooltipDataProcessor.AddTooltipPostCall and Enum and Enum.TooltipDataType and Enum.TooltipDataType.Unit then
    TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Unit, function(tt) onUnit(tt) end)
  elseif GameTooltip and GameTooltip.HookScript then
    GameTooltip:HookScript("OnTooltipSetUnit", onUnit)
  end
end
C.initHooks[#C.initHooks + 1] = function() T:Hook() end

-- Generic lines ------------------------------------------------------------------------------------
local RANK = { elite = "Elite", rare = "Rare", rareelite = TR["Rare Elite"], worldboss = "Boss" }
T:RegisterLine("level", TR["Level range and elite/rare"], function(i)
  local lo, hi = i.data.lo, i.data.hi
  local lv = (lo and hi and lo ~= hi) and (lo .. "-" .. hi) or (i.level > 0 and tostring(i.level) or "??")
  local r = RANK[i.classification] or (i.data.rank and RANK[i.data.rank])
  return TR:F("Level %s%s", lv, (r and ("  " .. r) or ""))
end, 10)
T:RegisterLine("hp", TR["Health (when known)"], function(i)
  local hp = i.hpMax or i.data.hp; if not hp then return end
  local s = tostring(math.floor(hp)); local k; repeat s, k = s:gsub("^(%d+)(%d%d%d)", "%1,%2") until k == 0
  return TR:F("Health %s", s)
end, 20)
-- quest objectives in your quest log that name this monster
local qcache, qstamp = {}, -1
local function logObjectives()
  local stamp = C.questStamp or 0; if stamp == qstamp then return qcache end
  qstamp, qcache = stamp, {}
  local n = (C_QuestLog and C_QuestLog.GetNumQuestLogEntries and C_QuestLog.GetNumQuestLogEntries()) or (GetNumQuestLogEntries and GetNumQuestLogEntries()) or 0
  for i = 1, math.min(n, 40) do
    local title, _, _, header, _, complete = GetQuestLogTitle and GetQuestLogTitle(i)
    if title and not header then
      for j = 1, (GetNumQuestLeaderBoards and GetNumQuestLeaderBoards(i) or 0) do
        local text, _, done = GetQuestLogLeaderBoard(j, i)
        if text and not done then qcache[#qcache + 1] = { title = title, text = text } end
      end
    end
  end
  return qcache
end
local qf = CreateFrame("Frame"); qf:RegisterEvent("QUEST_LOG_UPDATE"); qf:SetScript("OnEvent", function() C.questStamp = (C.questStamp or 0) + 1 end)
T:RegisterLine("quests", TR["Quest objectives this monster counts for"], function(i)
  local out, seen = {}, {}
  if i.name and not i.friendly then
    for _, o in ipairs(logObjectives()) do
      if not seen[o.title] and o.text:find(i.name, 1, true) then seen[o.title] = true; out[#out + 1] = TR:F("Quest: %s (%s)", o.title, o.text:gsub("^.-:%s*", "")) end
      if #out >= 3 then break end
    end
  end
  for _, t in ipairs(i.data.quests or {}) do if not seen[t] and #out < 3 then seen[t] = true; out[#out + 1] = TR:F("Quest: %s", t) end end
  return out
end, 40)
T:RegisterLine("drops", TR["Notable drops (incl. quest-starting items)"], function(i)
  local out = {}
  for _, n in ipairs(i.data.starts or {}) do if #out < 2 then out[#out + 1] = TR:F("Drops %s (starts a quest)", n) end end
  for _, n in ipairs(i.data.drops or {}) do if #out < 3 then out[#out + 1] = TR:F("Drops %s", n) end end
  return out
end, 50)
-- cloth from humanoids by monster level (the usual cloth for that level band)
-- l10n: cloth names come from the client by item ID (English only until the item is cached)
local CLOTH = { { 1, 14, "Linen Cloth", 2589 }, { 15, 25, "Wool Cloth", 2592 }, { 26, 37, "Silk Cloth", 4306 }, { 35, 48, "Mageweave Cloth", 4338 }, { 46, 63, "Runecloth", 14047 } }
function T.ClothFor(lv) local t = {}; for _, b in ipairs(CLOTH) do if lv >= b[1] and lv <= b[2] then
  local n = GetItemInfo and GetItemInfo(b[4]); t[#t + 1] = type(n) == "string" and n or b[3] end end; return t end
T:RegisterLine("cloth", TR["Cloth drops (humanoids)"], function(i)
  if not i.humanoid or i.friendly then return end
  local c = T.ClothFor(i.level > 0 and i.level or (i.data.lo or 0)); if #c == 0 then return end
  return TR:F("Cloth: %s", table.concat(c, TR[" or "]))
end, 60)
