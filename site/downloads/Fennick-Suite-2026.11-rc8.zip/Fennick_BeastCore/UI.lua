local TR = (Fennick_BEAST and Fennick_BEAST.L) or setmetatable({ F = function(_, f, ...) local ok, s = pcall(string.format, f, ...); return ok and s or f end }, { __index = function(_, k) return k end })   -- l10n (Core C.L)
-- Core focus window: draws the focus owner's current step when that module has no window of its own.
-- Same look as every Fennick window: generous padding, title, step line, objective, separator, "Guidance" (max N lines).
local C = Fennick_BEAST
local f
local function fs(parent, font) local t = Fennick_BEAST:NewFS(parent, "OVERLAY", font or "GameFontHighlight"); t:SetJustifyH("LEFT"); t:SetJustifyV("TOP"); t:SetWordWrap(true); return t end
local function build()
  f = CreateFrame("Frame", "Fennick_CoreFrame", UIParent, "BackdropTemplate")
  f:SetPoint("RIGHT", -60, 60); f:SetMovable(true); f:EnableMouse(true); f:SetClampedToScreen(true); f:RegisterForDrag("LeftButton")
  
  -- UI-1 header: band, 32 px module icon, "Fennick · <Module>", gold divider; focus card with amber accent bar; GUIDANCE label
  f.headerBg = f:CreateTexture(nil, "BORDER"); f.divider = f:CreateTexture(nil, "ARTWORK")
  f.icon = f:CreateTexture(nil, "ARTWORK"); f.icon:SetSize(32, 32)
  f.card = f:CreateTexture(nil, "BACKGROUND", nil, 1); f.accent = f:CreateTexture(nil, "ARTWORK")
  f.title = C:TitleFS(fs(f, "GameFontNormalLarge")); f.sub = fs(f, "GameFontDisableSmall"); f.line = fs(f); f.obj = fs(f, "GameFontHighlightSmall")
  f.sep = f:CreateTexture(nil, "ARTWORK"); f.sep:SetHeight(1)
  f.guideHdr = fs(f, "GameFontNormalSmall"); f.guide = fs(f, "GameFontHighlight")   -- guidance at body size (12) in every module
  -- P2-11: hovering the Guidance block shows every line (the window shows at most guideMax)
  f.guideHit = CreateFrame("Frame", nil, f); f.guideHit:SetAllPoints(f.guide); f.guideHit:EnableMouse(true)
  f.guideHit:SetScript("OnEnter", function(self) if not (f.allGuide and #f.allGuide > 0) or not GameTooltip then return end
    GameTooltip:SetOwner(self, "ANCHOR_LEFT"); GameTooltip:AddLine(TR["Guidance"]); for _, l in ipairs(f.allGuide) do GameTooltip:AddLine(l, 1, 1, 1, true) end; GameTooltip:Show() end)
  f.guideHit:SetScript("OnLeave", function() if GameTooltip then GameTooltip:Hide() end end)
  -- optional thin bar a module can fill (view.bar = { value = 0..1, color = {r,g,b} })
  f.bar = CreateFrame("StatusBar", nil, f); f.bar:SetMinMaxValues(0, 1); f.bar:SetHeight(6); f.bar:Hide()
  C.Skin:StyleBar(f.bar)
  local function btn(t, fn) local b = CreateFrame("Button", nil, f, "UIPanelButtonTemplate"); b:SetSize(64, 20); b:SetText(t); C:FitButton(b, 64); b:SetScript("OnClick", fn); C.Skin:AddButton(b, "window"); return b end
  f.back = btn(TR["Back"], function() local m = C.modules[C:Owner() or ""]; C:Call(m, "Back"); C:RefreshWindow() end)
  f.skip = btn(TR["Skip"], function() local m = C.modules[C:Owner() or ""]; C:Call(m, "Skip"); C:RefreshWindow() end)
  C.frame = f; C.Skin:Add("window", f); C.Skin:Style(f); f:Hide()
  C:RegisterMovable("window", f, "Fennick window", { default = { point = "RIGHT", x = -60, y = 60 }, resizable = true, onChange = function() C:LayoutWindow() end })
end
function C:LayoutWindow()
  if not f then return end
  self.lastViewHash = nil   -- a re-layout (look, size, Edit Mode) always allows the next draw
  f:SetScale(self:FrameOpt("window", "scale") or self:O("scale"))
  local pad, gap, W = self:Pad(f), self:Snap(self:O("rowGap"), f), self:Snap(self:FrameOpt("window", "width") or self:O("width"), f)
  f.sep:SetHeight(self:Snap(1, f, 1))
  local inner = W - 2 * pad; local y = -pad
  local p = self.Skin.PRESETS[self:O("preset")] or self.Skin.PRESETS.default
  local function place(t, x, w) if (t:GetText() or "") == "" then t:Hide(); return end
    t:Show(); t:SetWidth(w or inner); if t.SetSpacing then t:SetSpacing(self:O("lineSpacing")) end
    t:ClearAllPoints(); t:SetPoint("TOPLEFT", x or pad, y); y = y - (t:GetStringHeight() or 12) - gap end
  -- header band with icon
  local hp = p.header or { 0, 0, 0, 0 }; local top = y
  local iconOn = f.iconPath ~= nil and p.header and hp[4] > 0
  local tx = iconOn and (pad + 32 + 8) or pad
  if iconOn then f.icon:Show(); f.icon:ClearAllPoints(); f.icon:SetPoint("TOPLEFT", pad, y) else f.icon:Hide() end
  place(f.title, tx, inner - (tx - pad)); place(f.sub, tx, inner - (tx - pad))
  if iconOn then y = math.min(y, top - 32 - gap) end
  local px = self:Snap(1, f, 1)
  f.headerBg:ClearAllPoints(); f.headerBg:SetPoint("TOPLEFT", px, -px); f.headerBg:SetPoint("BOTTOMRIGHT", f, "TOPRIGHT", -px, y + gap / 2)
  f.headerBg:SetColorTexture(hp[1], hp[2], hp[3], hp[4] or 1); f.headerBg:SetShown((hp[4] or 0) > 0)
  local sc = p.sep
  f.divider:ClearAllPoints(); f.divider:SetPoint("TOPLEFT", px, y + gap / 2); f.divider:SetPoint("BOTTOMRIGHT", f, "TOPRIGHT", -px, y + gap / 2 - px)
  f.divider:SetColorTexture(sc[1], sc[2], sc[3], math.max(sc[4] or 0.2, 0.4)); f.divider:Show()
  y = y - gap / 2
  if f.barOn then f.bar:Show(); f.bar:SetWidth(inner); f.bar:ClearAllPoints(); f.bar:SetPoint("TOPLEFT", pad, y); y = y - 6 - gap else f.bar:Hide() end
  -- focus card: current line + objective, amber accent bar
  local cTop = y; local cp = math.floor(gap / 2 + 0.5); local aw = self:Snap(p.accentW or 3, f, 1)
  y = y - cp; place(f.line, pad + aw + cp, inner - aw - 2 * cp); place(f.obj, pad + aw + cp, inner - aw - 2 * cp); y = y + gap - cp
  local cc = p.card or { 1, 1, 1, 0.07 }; local ac = p.accent or { 1, 0.6, 0.2 }
  f.card:ClearAllPoints(); f.card:SetPoint("TOPLEFT", pad, cTop); f.card:SetPoint("BOTTOMRIGHT", f, "TOPRIGHT", -pad, y); f.card:SetColorTexture(cc[1], cc[2], cc[3], cc[4] or 1); f.card:Show()
  f.accent:ClearAllPoints(); f.accent:SetPoint("TOPLEFT", pad, cTop); f.accent:SetPoint("BOTTOMRIGHT", f, "TOPLEFT", pad + aw, y); f.accent:SetColorTexture(ac[1], ac[2], ac[3], 1); f.accent:Show()
  y = y - gap
  if (f.guide:GetText() or "") ~= "" then
    y = y - (p.sepGap - gap); f.sep:Show(); f.sep:ClearAllPoints(); f.sep:SetPoint("TOPLEFT", pad, y); f.sep:SetWidth(inner)
    f.sep:SetColorTexture(p.sep[1], p.sep[2], p.sep[3], p.sep[4]); y = y - p.sepGap
    local gh = p.guideHdr or { 0.6, 0.6, 0.6 }; f.guideHdr:SetTextColor(gh[1], gh[2], gh[3])
    place(f.guideHdr); place(f.guide)
  else f.sep:Hide(); f.guideHdr:Hide(); f.guide:Hide() end
  if f.noNav then f.back:Hide(); f.skip:Hide(); y = y + gap - pad   -- modules without steps (view.nav == false): no Back/Skip
  else f.back:Show(); f.skip:Show()
    f.back:ClearAllPoints(); f.back:SetPoint("TOPLEFT", pad, y); f.skip:ClearAllPoints(); f.skip:SetPoint("LEFT", f.back, "RIGHT", 8, 0)
    y = y - 20 - pad end
  f:SetSize(W, math.max(-y, self:FrameOpt("window", "height") or 0))
end
-- view = { title, sub, bar, line, obj, guidance = {...}, point = {z,x,y}, label }
function C:RenderView(key, v)
  if not f then build() end
  local p = self:Preset(); local m = self.modules[key]
  f.iconPath = v.icon or self:Icon(key); f.icon:SetTexture(f.iconPath)
  local ver = self.Tester and self:Tester() and self.ModuleVersion and self:ModuleVersion(key)   -- tester mode: version on the title
  f.title:SetText(((v.title and (self.brand .. " · " .. v.title)) or "") .. (ver and (" |cff999999v" .. ver .. "|r") or "")); f.sub:SetText(v.sub or "")
  local tc = p.title; f.title:SetTextColor(tc[1], tc[2], tc[3]); if p.text then f.line:SetTextColor(p.text[1], p.text[2], p.text[3]) end; f.line:SetText(v.line or TR["Nothing to do right now."]); f.obj:SetText(v.obj or "")
  f.noNav = v.nav == false
  f.back:SetText(v.backLabel or "Back"); C:FitButton(f.back, v.backLabel and 86 or 64); C:FitButton(f.skip, 64)   -- N-3: modules can relabel Back (e.g. "Unskip all")
  f.barOn = type(v.bar) == "table" and type(v.bar.value) == "number"
  if f.barOn then C.Skin:StyleBar(f.bar); f.bar:SetValue(math.max(0, math.min(1, v.bar.value))) end   -- UI-1: gold bar, the module's colour is ignored
  -- P2-11: the module's first guidance line, then riders (other modules), then the rest (lower value)
  local g, src = {}, v.guidance or {}
  if src[1] then g[1] = src[1] end
  for _, r in ipairs(self:Riders(key)) do g[#g + 1] = "|cff999999" .. r .. "|r" end
  for i = 2, #src do g[#g + 1] = src[i] end
  f.allGuide = g
  local max = self:O("guideMax"); local shown = {}
  for i = 1, math.min(max, #g) do shown[i] = g[i] end
  local txt = table.concat(shown, "\n"); if #g > max then txt = TR:F("%s |cff777777(+%s, hover)|r", txt, (#g - max)) end
  f.guideHdr:SetText(#g > 0 and (p.guideHdrText or "Guidance") or ""); f.guide:SetText(txt)
  self:LayoutWindow()
  if v.point then self:SetWaypointFor(key, v.point, v.label or "") else self:ClearArrowFor(key) end
end
function C:RefreshWindow()
  if self.disabled then if f then f:Hide() end return end
  local key = self:Owner(); local m = key and self.modules[key]
  if not m or m.ownWindow or self:O("windowHidden") then
    if f and f:IsShown() then self:Safe("core window hide", function() f:Hide() end) end
    return
  end
  local v = self:Call(m, "View")
  if type(v) ~= "table" then return end
  -- P1-12: nothing changed since the last draw -> no re-layout, no new closure
  local h = self:ViewHash(key, v)
  if h == self.lastViewHash and not self.dirty and f and f:IsShown() then self.skippedDraws = (self.skippedDraws or 0) + 1; return end
  self.dirty = nil
  self:Safe("core window", function() C:RenderView(key, v); f:Show(); C.lastViewHash = h end)
end
function C:ViewHash(key, v)
  local t = { key, tostring(v.title), tostring(v.sub), tostring(v.line), tostring(v.obj), tostring(v.nav), tostring(v.label) }
  if type(v.bar) == "table" then t[#t + 1] = tostring(v.bar.value) end
  if type(v.point) == "table" then t[#t + 1] = tostring(v.point.z) .. ":" .. tostring(v.point.x) .. ":" .. tostring(v.point.y) end
  for _, l in ipairs(v.guidance or {}) do t[#t + 1] = tostring(l) end
  for _, r in ipairs(self:Riders(key)) do t[#t + 1] = r end
  return table.concat(t, "\31")
end
function C:ToggleWindow() self.db.opt.windowHidden = not self:O("windowHidden"); if f and self:O("windowHidden") then f:Hide() end; self:RefreshWindow() end
