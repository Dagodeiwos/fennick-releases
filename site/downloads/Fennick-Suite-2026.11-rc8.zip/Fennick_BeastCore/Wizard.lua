local TR = (Fennick_BEAST and Fennick_BEAST.L) or setmetatable({ F = function(_, f, ...) local ok, s = pcall(string.format, f, ...); return ok and s or f end }, { __index = function(_, k) return k end })   -- l10n (Core C.L)
-- Setup wizard. Core pages are generic; each installed module adds its own pages (C:RegisterWizardPages(key, pages)).
-- The Focus page lists only installed modules. Own frame only; opens out of combat. /beast setup re-runs it.
local C = Fennick_BEAST
local W, page, PAGES = nil, 1, {}
C.wizardPages = {}
-- page = { title, body = function() -> text, choices = { { label(), onClick(dir), cycles } } }
function C:RegisterWizardPages(key, pages) self.wizardPages[key] = pages end
local function onoff(k) return C:OnOff(C:O(k)) end   -- N-1 shared status colours
function C:WizardPages()
  local mods = {}; for _, l in ipairs(self:ModuleSummary()) do mods[#mods + 1] = "\n- " .. l end   -- M-P2-9: one line per module
  local P = {}
  P[#P + 1] = { TR["Welcome"], function()
    return TR:F("Welcome to %s.\n\nInstalled: %s\n\nEverything can be changed later in Settings (/beast).", C.brand, (#mods > 0 and table.concat(mods, "") or TR["no modules yet (the core works on its own: arrow, look and the monster tooltip)."]))
      .. ((C.L and C.L:IsMachine()) and ("\n\n" .. TR["Language: machine translation (not yet reviewed)."]) or "") end, {} }
  if #self.order > 0 then
    local ch = {}
    for _, k in ipairs(self:FocusChoices()) do ch[#ch + 1] = { function() return (C:O("focusOn") == k and "> " or "") .. C:FocusLabel(k) end, function() C:SetFocus(k) end } end
    P[#P + 1] = { TR["Focus"], function() return TR["What should the window and arrow follow?\nAuto: the first module with something to do; the others only add short along-the-way lines."] end, ch }
  end
  for _, m in ipairs(self.order) do for _, pg in ipairs(self.wizardPages[m.key] or {}) do P[#P + 1] = pg end end
  P[#P + 1] = { TR["Waypoint arrow"], function() return TR:F("TomTom: %s. The built-in arrow works without it.", ((TomTom and TR["installed"]) or TR["not installed"])) end,
    { { function() return TR:F("Arrow %s", onoff("arrow")) end, function() C:Set("arrow", not C:O("arrow")); C:ResetWaypoint(); C:ApplyArrow() end },
      { function() return C:O("tomtom") and TR["Use TomTom"] or TR["Use built-in"] end, function() C:Set("tomtom", not C:O("tomtom")); C:ResetWaypoint(); C:ApplyArrow() end } } }
  P[#P + 1] = { TR["Style"], function() return TR["Pick a look. Fonts and textures from SharedMedia appear in Settings if installed."] end,
    { { function() return (C:O("preset") == "default" and "> " or "") .. "Default" end, function() C:ApplyPreset("default") end },
      { function() return (C:O("preset") == "minimal" and "> " or "") .. "Minimal" end, function() C:ApplyPreset("minimal") end },
      { function() return (C:O("preset") == "dark" and "> " or "") .. "Dark" end, function() C:ApplyPreset("dark") end } } }
  P[#P + 1] = { TR["Frames"], function() return C.EditMode:Mode() == "blizzard" and TR["Fennick windows are listed in Blizzard Edit Mode (Esc > Edit Mode) with scale, width, height and alpha sliders; positions follow your Edit Mode layout."] or TR["Move and size Fennick windows: unlock, drag, arrow keys nudge, right-click a frame to reset. Frames lock again when combat starts."] end,
    { { function() return C.EditMode:Mode() == "blizzard" and TR["Open Edit Mode"] or (C.EditMode.unlocked and TR["Lock frames"] or TR["Unlock frames"]) end, function() C:ToggleMove() end },
      { function() return TR["Reset all positions"] end, function() C.EditMode:ResetAll() end } } }
  P[#P + 1] = { TR["Minimap button"], function() return TR["Left-click shows or hides the window, right-click opens Settings, drag to move."] end,
    { { function() return TR:F("Button %s", (C.db.opt.minimap.hide and TR["hidden"] or "shown")) end, function() C:ToggleMinimap() end } } }
  P[#P + 1] = { TR["Done"], function() return TR["All set. Your choices are saved for this character."] end, {} }
  return P
end
local function render()
  local p = PAGES[page]
  W.head:SetText(TR:F("%s setup  (%s/%s): %s", C.brand, page, #PAGES, p[1])); W.body:SetText(p[2]())
  for i, b in ipairs(W.choice) do
    local c = p[3][i]
    if c then b.c = c; b:SetText(c[1]()); b:Show(); b.l:SetShown(c[3] and true or false); b.r:SetShown(c[3] and true or false) else b:Hide(); b.l:Hide(); b.r:Hide() end
  end
  W.prev:SetEnabled(page > 1); W.next:SetText(page == #PAGES and TR["Finish"] or TR["Next"])
end
C.RenderSetup = function() if W and W:IsShown() then render() end end
local function build()
  W = CreateFrame("Frame", "Fennick_SetupFrame", UIParent, "BackdropTemplate")
  W:SetSize(460, 330); W:SetPoint("CENTER"); W:SetFrameStrata("DIALOG"); W:EnableMouse(true); W:SetMovable(true); W:SetClampedToScreen(true)
  W:RegisterForDrag("LeftButton"); W:SetScript("OnDragStart", W.StartMoving); W:SetScript("OnDragStop", W.StopMovingOrSizing)
  W.head = Fennick_BEAST:NewFS(W, "OVERLAY", "GameFontNormalLarge"); W.head:SetPoint("TOPLEFT", 16, -16)
  W.body = Fennick_BEAST:NewFS(W, "OVERLAY", "GameFontHighlight"); W.body:SetPoint("TOPLEFT", 16, -46); W.body:SetWidth(428); W.body:SetJustifyH("LEFT")
  if W.body.SetSpacing then W.body:SetSpacing(3) end
  W.choice = {}
  for i = 1, 4 do
    local b = CreateFrame("Button", nil, W, "UIPanelButtonTemplate"); b:SetSize(220, 22); b:SetPoint("TOP", 0, -140 - (i - 1) * 28)
    b:SetScript("OnClick", function(self) if type(self.c) == "table" then self.c[2](1); render() end end)
    local function arrow(t, x, d) local a = CreateFrame("Button", nil, W, "UIPanelButtonTemplate"); a:SetSize(24, 22); a:SetPoint("RIGHT", b, x < 0 and "LEFT" or "RIGHT", x, 0); a:SetText(t)
      a:SetScript("OnClick", function() if type(b.c) == "table" then b.c[2](d); render() end end); C.Skin:AddButton(a, "setup"); return a end
    b.l = arrow("<", -4, -1); b.r = arrow(">", 28, 1)
    C.Skin:AddButton(b, "setup"); W.choice[i] = b
  end
  local function nav(t, point, x, fn) local b = CreateFrame("Button", nil, W, "UIPanelButtonTemplate"); b:SetSize(90, 22); b:SetPoint(point, x, 14); b:SetText(t); C:FitButton(b, 90); b:SetScript("OnClick", fn); C.Skin:AddButton(b, "setup"); return b end
  W.prev = nav(TR["Back"], "BOTTOMLEFT", 16, function() page = math.max(1, page - 1); render() end)
  W.next = nav(TR["Next"], "BOTTOMRIGHT", -16, function()
    if page == #PAGES then C:SetupDone(); W:Hide(); C:Print(TR["setup complete - /beast setup to run it again"]) else page = page + 1; render() end end)
  nav(TR["Skip setup"], "BOTTOM", 0, function() C:SetupDone(); W:Hide() end)
  -- P1-15 / K-4: the X counts as Skip (setup is not reopened at every login) and says how to run it again
  local x = CreateFrame("Button", nil, W, "UIPanelCloseButton"); x:SetPoint("TOPRIGHT", -2, -2)
  x:SetScript("OnClick", function() C:SetupDone(); W:Hide(); C:Print(TR["setup closed - /beast setup to run it again"]) end); W.close = x
  C.Skin:Add("setup", W); C.Skin:Style(W, 0.95)
end
function C:SetupDone() self.db.wizardDone = true; for _, m in ipairs(self.order) do self:Call(m, "SetupDone") end end
function C:ShowSetup()
  if self:InCombat() then return self:Safe("setup", function() C:ShowSetup() end) end
  if not W then build() end
  PAGES = self:WizardPages(); page = 1; render(); W:Show()
end
