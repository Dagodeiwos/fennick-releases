local TR = (Fennick_BEAST and Fennick_BEAST.L) or setmetatable({ F = function(_, f, ...) local ok, s = pcall(string.format, f, ...); return ok and s or f end }, { __index = function(_, k) return k end })   -- l10n (Core C.L)
if not (Fennick_BEAST and (Fennick_BEAST.API or 1) >= 3) then return end   -- file-top guard
-- ONE icon path table for Cartographer. Art: original Fennick art (compass and module logos here; the 50 shared
-- borderless pins at 16/32 px and the area texture come from Beast Core's one pin table, C:PinBase, Core 1.6).
-- When the art changes, swap the files in Media/ (or Beast Core's Media/) or edit this file only.
-- COMPASS: the module icon and the map compass rose both come from CG.ICONS.compass / compass_small (the borderless
-- four-point rose with an amber north, branding/Cartographer icon_64/icon_32).
local CG = Fennick_CARTOGRAPHER; if not CG then return end
local M = "Interface\\AddOns\\Fennick_Cartographer\\Media\\"
local C = Fennick_BEAST
local function pin(k) return C.PinBase and C:PinBase(k) or ("Interface\\AddOns\\Fennick_BeastCore\\Media\\Pin_" .. k) end
local PINS = { "chest", "flight", "herb", "ore", "portal", "quest", "ship", "user", "zeppelin",
  "herb_arthas_tears", "herb_black_lotus", "herb_blindweed", "herb_briarthorn", "herb_bruiseweed", "herb_dreamfoil", "herb_earthroot",
  "herb_fadeleaf", "herb_firebloom", "herb_ghost_mushroom", "herb_golden_sansam", "herb_goldthorn", "herb_grave_moss", "herb_gromsblood",
  "herb_icecap", "herb_khadgars_whisker", "herb_kingsblood", "herb_liferoot", "herb_mageroyal", "herb_mountain_silversage", "herb_peacebloom",
  "herb_plaguebloom", "herb_purple_lotus", "herb_silverleaf", "herb_stranglekelp", "herb_sungrass", "herb_wild_steelbloom", "herb_wintersbite",
  "ore_copper", "ore_dark_iron", "ore_gold", "ore_incendicite", "ore_indurium", "ore_iron", "ore_lesser_bloodstone", "ore_mithril",
  "ore_rich_thorium", "ore_silver", "ore_small_thorium", "ore_tin", "ore_truesilver" }
CG.PIN_KEYS = PINS
CG.ICONS = { compass = M .. "Fennick_Cartographer", compass_small = M .. "Fennick_Cartographer_32", area = C.PIN_AREA or "Interface\\AddOns\\Fennick_BeastCore\\Media\\Area", line = "Interface\\Buttons\\WHITE8X8" }
CG.LOGOS = { "BeastCore", "Guidepost", "Rest", "Reputation", "MerchantsFavor", "FoxTrials", "Trailmarks" }
for _, k in ipairs(PINS) do CG.ICONS[k] = pin(k) end
for _, k in ipairs(CG.LOGOS) do CG.ICONS["logo_" .. k:lower()] = C:LogoPath(k) end   -- module logos live once, in Beast Core Media
CG.ICONS.logo_cartographer = M .. "Fennick_Cartographer_32"
local SIZED = {}; for _, k in ipairs(PINS) do SIZED[k] = true end
-- path for a key at a drawn size: 16 px art on the minimap and at small sizes, 32 px otherwise; unknown keys -> user pin
function CG:Icon(key, size)
  if not self.ICONS[key] or key == "area" or key == "line" then key = "user" end
  if not SIZED[key] then return self.ICONS[key] end
  return self.ICONS[key] .. (((size or 32) <= 16) and "_16" or "_32")
end
function CG:IconKnown(key) return self.ICONS[key] ~= nil and key ~= "area" and key ~= "line" end
-- picker grid: every pin, then the compass and the module logos
function CG:IconList()
  local t = {}
  for _, k in ipairs(PINS) do t[#t + 1] = { key = k, path = self:Icon(k, 32), small = self:Icon(k, 16) } end
  t[#t + 1] = { key = "logo_cartographer", path = self.ICONS.logo_cartographer, small = self.ICONS.logo_cartographer }
  for _, k in ipairs(self.LOGOS) do local key = "logo_" .. k:lower(); t[#t + 1] = { key = key, path = self.ICONS[key], small = self.ICONS[key] } end
  return t
end
-- Look notes: palette (Core C.COL since Core 1.6; the table below is only the fallback) and route styles
CG.COL = C.COL or { teal = { 0.055, 0.29, 0.333 }, dteal = { 0.031, 0.204, 0.235 }, gold = { 0.831, 0.651, 0.29 }, lgold = { 0.941, 0.816, 0.541 },
  amber = { 0.878, 0.584, 0.227 }, cream = { 0.965, 0.902, 0.784 }, dark = { 0.078, 0.094, 0.11 }, violet = { 0.588, 0.47, 0.863 } }
CG.ROUTE = { ship = { "cream", 8, 5, 2, 0.85 }, zeppelin = { "amber", 4, 4, 2, 0.85 }, tram = { "cream", 8, 5, 2, 0.85 },
  flight = { "lgold", 0, 0, 1.5, 0.75 }, portal = { "violet", 2, 4, 2, 0.8 }, user = { "amber", 0, 0, 2, 1.0 }, walk = { "amber", 3, 3, 2, 1.0 } }
