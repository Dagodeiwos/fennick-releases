local TR = (Fennick_BEAST and Fennick_BEAST.L) or setmetatable({ F = function(_, f, ...) local ok, s = pcall(string.format, f, ...); return ok and s or f end }, { __index = function(_, k) return k end })   -- l10n (Core C.L)
if not (Fennick_BEAST and (Fennick_BEAST.API or 1) >= 3) then return end   -- file-top guard
-- The Cartographer world map: our own window (plain frames, no secure templates, no Blizzard map frames touched).
-- Art is the client's own map textures (C_Map art layers + explored overlays). Smooth pan (drag), mouse-wheel zoom on the
-- cursor, zone drill-down (left click) and back out (right click), coordinates, you and your party, pins, routes, filters.
local C = Fennick_BEAST
local CG = Fennick_CARTOGRAPHER; if not CG then return end
local W8 = "Interface\\Buttons\\WHITE8X8"
local function col(k, a) local c = CG.COL[k]; return c[1], c[2], c[3], a or 1 end
local function tex(parent, layer, k, a) local t = parent:CreateTexture(nil, layer or "ARTWORK"); t:SetTexture(W8); t:SetVertexColor(col(k, a)); return t end
-- Core's shared glyph button (C:Button, Core 1.6)
local function button(parent, glyph, tipText, fn) return C:Button(parent, glyph, tipText, fn) end
CG.button = button
local M = { zoom = 1, px = 0, py = 0, tiles = {}, pins = {}, segs = {}, over = {} }
CG.map = M
function CG:MapFrame()
  if M.f then return M.f end
  local f = CreateFrame("Frame", "Fennick_CartographerMap", UIParent); M.f = f
  f:SetSize(self:O("width"), self:O("height")); f:SetPoint("CENTER"); f:SetFrameStrata("HIGH"); f:SetToplevel(true)
  f:EnableMouse(true); f:RegisterForDrag("LeftButton"); f:Hide()
  if UISpecialFrames then table.insert(UISpecialFrames, "Fennick_CartographerMap") end   -- Escape closes it (insecure list, as any add-on window)
  f.shadow = f:CreateTexture(nil, "BACKGROUND"); f.shadow:SetTexture(W8); f.shadow:SetVertexColor(0, 0, 0, 0.45); f.shadow:SetPoint("TOPLEFT", -4, 4); f.shadow:SetPoint("BOTTOMRIGHT", 4, -4)
  f.bg = tex(f, "BACKGROUND", "dteal", self:O("alpha")); f.bg:SetAllPoints(f)
  f.edges = {}
  for i, p in ipairs({ { "TOPLEFT", "TOPRIGHT", 0, 1 }, { "BOTTOMLEFT", "BOTTOMRIGHT", 0, 1 }, { "TOPLEFT", "BOTTOMLEFT", 1, 0 }, { "TOPRIGHT", "BOTTOMRIGHT", 1, 0 } }) do
    local e = tex(f, "OVERLAY", "gold", 1); e:SetPoint(p[1]); e:SetPoint(p[2]); if p[3] == 1 then e:SetWidth(1) else e:SetHeight(1) end; f.edges[i] = e end
  f.ticks = {}
  for i, p in ipairs({ "TOPLEFT", "TOPRIGHT", "BOTTOMLEFT", "BOTTOMRIGHT" }) do
    local h = tex(f, "OVERLAY", "amber", 0.9); h:SetSize(6, 1); h:SetPoint(p, f, p, 0, 0)
    local v = tex(f, "OVERLAY", "amber", 0.9); v:SetSize(1, 6); v:SetPoint(p, f, p, 0, 0); f.ticks[#f.ticks + 1] = h; f.ticks[#f.ticks + 1] = v end
  -- title bar
  local tb = CreateFrame("Frame", nil, f); tb:SetHeight(24); tb:SetPoint("TOPLEFT"); tb:SetPoint("TOPRIGHT"); f.tb = tb
  tb.bg = tex(tb, "ARTWORK", "teal", 0.95); tb.bg:SetAllPoints(tb)
  tb.rule = tex(tb, "OVERLAY", "gold", 1); tb.rule:SetHeight(1); tb.rule:SetPoint("BOTTOMLEFT"); tb.rule:SetPoint("BOTTOMRIGHT")
  f.icon = tb:CreateTexture(nil, "OVERLAY"); f.icon:SetSize(20, 20); f.icon:SetPoint("LEFT", 4, 0); f.icon:SetTexture(self.ICONS.compass_small)
  f.title = C:TitleFS(C:NewFS(tb, "OVERLAY", "GameFontNormal")); f.title:SetPoint("CENTER"); f.title:SetTextColor(col("gold")); f.title:SetText(TR["FENNICK'S CARTOGRAPHER"])
  if f.title.SetShadowColor then f.title:SetShadowColor(col("dark")); f.title:SetShadowOffset(1, -1) end
  f.sub = C:NewFS(tb, "OVERLAY"); f.sub:SetPoint("LEFT", f.icon, "RIGHT", 6, 0); f.sub:SetTextColor(col("cream", 0.8))
  f.close = button(tb, "x", TR["Close"], function() f:Hide() end); f.close:SetPoint("RIGHT", -4, 0)
  f.zin = button(tb, "+", TR["Zoom in"], function() CG:Zoom(1.25) end); f.zin:SetPoint("RIGHT", f.close, "LEFT", -4, 0)
  f.zout = button(tb, "-", TR["Zoom out"], function() CG:Zoom(0.8) end); f.zout:SetPoint("RIGHT", f.zin, "LEFT", -4, 0)
  f.reset = button(tb, "o", TR["Reset view"], function() CG:ResetView() end); f.reset:SetPoint("RIGHT", f.zout, "LEFT", -4, 0)
  f.filter = button(tb, "F", TR["Filter icons"], function() CG:ToggleFilters("world") end); f.filter:SetPoint("RIGHT", f.reset, "LEFT", -4, 0)
  f.addpin = button(tb, "P", TR["Add a pin at the map centre"], function() CG:PinEditor(nil, M.map, CG:CenterXY()) end); f.addpin:SetPoint("RIGHT", f.filter, "LEFT", -4, 0)
  f.routeB = button(tb, "R", TR["How do I get there? (Shift-click a spot)"], function() CG:ShowRoutePanel() end); f.routeB:SetPoint("RIGHT", f.addpin, "LEFT", -4, 0)
  f.search = CreateFrame("EditBox", nil, tb); f.search:SetSize(120, 16); f.search:SetPoint("RIGHT", f.routeB, "LEFT", -8, 0); f.search:SetAutoFocus(false)
  if f.search.SetFontObject then f.search:SetFontObject(C:FontObj("GameFontHighlightSmall") or "GameFontHighlightSmall") end
  f.search.bg = tex(f.search, "BACKGROUND", "dteal", 1); f.search.bg:SetAllPoints(f.search)
  f.search:SetScript("OnTextChanged", function(s) M.query = s:GetText(); CG:DrawPins() end)
  f.search:SetScript("OnEscapePressed", function(s) s:SetText(""); s:ClearFocus() end)
  f.searchHint = C:NewFS(f.search, "OVERLAY"); f.searchHint:SetPoint("LEFT", 2, 0); f.searchHint:SetText(TR["Search pins"]); f.searchHint:SetTextColor(col("cream", 0.4))
  -- canvas: clipped scroll area, 6 px inset, a 1 px dark-teal inner line
  local clip = CreateFrame("Frame", nil, f); clip:SetPoint("TOPLEFT", 6, -30); clip:SetPoint("BOTTOMRIGHT", -6, 24); clip:SetClipsChildren(true); M.clip = clip
  clip.line = tex(clip, "BACKGROUND", "dteal", 1); clip.line:SetPoint("TOPLEFT", -1, 1); clip.line:SetPoint("BOTTOMRIGHT", 1, -1)
  local cv = CreateFrame("Frame", nil, clip); cv:SetPoint("TOPLEFT"); cv:SetSize(1002, 668); M.cv = cv
  M.routeLayer = CreateFrame("Frame", nil, cv); M.routeLayer:SetAllPoints(cv); M.pinLayer = CreateFrame("Frame", nil, cv); M.pinLayer:SetAllPoints(cv)
  M.pinLayer:SetFrameLevel((tonumber(M.routeLayer:GetFrameLevel()) or 1) + 2)
  clip:EnableMouse(true); clip:EnableMouseWheel(true)
  clip:SetScript("OnMouseWheel", function(_, d) CG:Zoom(d > 0 and 1.15 or 1 / 1.15, true) end)
  clip:SetScript("OnMouseDown", function(_, b) if b == "LeftButton" then local x, y = GetCursorPosition(); M.drag = { x, y, M.px, M.py, false } end end)
  clip:SetScript("OnMouseUp", function(_, b)
    local d = M.drag; M.drag = nil
    if b == "RightButton" then CG:GoUp() return end
    if d and not d[5] then local x, y = CG:CursorXY(); if x then
      if IsShiftKeyDown and IsShiftKeyDown() then CG:RouteTo(M.map, x, y)
      elseif IsControlKeyDown and IsControlKeyDown() then CG:PinEditor(nil, M.map, x, y)
      else CG:DrillDown(x, y) end end end
  end)
  -- coordinate readout
  local ro = CreateFrame("Frame", nil, f); ro:SetHeight(18); ro:SetPoint("BOTTOMLEFT", 6, 3); ro:SetPoint("BOTTOMRIGHT", -6, 3); f.ro = ro
  ro.bg = tex(ro, "ARTWORK", "dteal", 0.85); ro.bg:SetAllPoints(ro); ro.rule = tex(ro, "OVERLAY", "gold", 1); ro.rule:SetHeight(1); ro.rule:SetPoint("TOPLEFT"); ro.rule:SetPoint("TOPRIGHT")
  ro.t = C:NewFS(ro, "OVERLAY"); ro.t:SetPoint("LEFT", 6, 0); ro.t:SetTextColor(col("cream"))
  ro.hint = C:NewFS(ro, "OVERLAY"); ro.hint:SetPoint("RIGHT", -6, 0); ro.hint:SetTextColor(col("cream", 0.7))
  ro.hint:SetText(TR["Drag: pan  Wheel: zoom  Click: zone  Right-click: up  Ctrl-click: pin  Shift-click: route"])
  -- compass rose (four-point rose, amber north), bottom-right of the canvas
  M.compass = f:CreateTexture(nil, "OVERLAY"); M.compass:SetSize(48, 48); M.compass:SetPoint("BOTTOMRIGHT", clip, "BOTTOMRIGHT", -6, 6); M.compass:SetTexture(self.ICONS.compass)
  f:SetScript("OnUpdate", function(_, el) M.acc = (M.acc or 0) + el; CG:OnMapUpdate(el) end)
  if C.RegisterMovable then pcall(C.RegisterMovable, C, "cartographer", f, TR["Cartographer map"], { default = { point = "CENTER", x = 0, y = 0 } }) end
  f:SetScript("OnDragStart", function(s) if not CG:O("locked") and not C:InCombat() then s:StartMoving() end end)
  f:SetScript("OnDragStop", function(s) s:StopMovingOrSizing() end)
  self:ApplyMapLook(); return f
end
function CG:ApplyMapLook()
  local f = M.f; if not f then return end
  local ext = C.Skin and C.db and C.db.opt and C.db.opt.externalSkin
  f:SetSize(self:O("width"), self:O("height")); f:SetScale(self:O("scale"))
  if not C:InCombat() then f:SetAlpha(1) end
  f.bg:SetVertexColor(col("dteal", ext and 0 or self:O("alpha")))
  local minimal = C.O and C:O("preset") == "minimal"
  for _, t in ipairs(f.ticks) do if minimal or ext then t:Hide() else t:Show() end end
  local u = tonumber(C.PixelUnit and C:PixelUnit(f)) or 1; for i, e in ipairs(f.edges) do if i <= 2 then e:SetHeight(u) else e:SetWidth(u) end end   -- 1 screen pixel gold edge
  if C.Skin and C.Skin.Add then pcall(C.Skin.Add, C.Skin, "cartographer", f) end
  self:LayoutCanvas()
end
-- current map, art and layout
function CG:SetMap(map)
  if type(map) ~= "number" then return end
  M.map = map; M.zoom, M.px, M.py = 1, 0, 0
  local info = C_Map and C_Map.GetMapInfo and C_Map.GetMapInfo(map)
  if M.f then M.f.sub:SetText(info and info.name or ""); M.f.title:SetText(TR["FENNICK'S CARTOGRAPHER"]) end
  self:LoadArt(); self:LayoutCanvas(); self:DrawAll()
end
function CG:LoadArt()
  for _, t in ipairs(M.tiles) do t:Hide() end
  for _, t in ipairs(M.over) do t:Hide() end
  if not (C_Map and C_Map.GetMapArtLayers and C_Map.GetMapArtLayerTextures) then M.art = nil; return 0 end
  local ok, layers = pcall(C_Map.GetMapArtLayers, M.map); local L = ok and type(layers) == "table" and layers[1]
  if not L then M.art = nil; return 0 end
  M.art = L
  local ok2, files = pcall(C_Map.GetMapArtLayerTextures, M.map, 1); files = ok2 and files or {}
  local cols = math.ceil(L.layerWidth / L.tileWidth); local n = 0
  for i, file in ipairs(files) do
    local t = M.tiles[i] or M.cv:CreateTexture(nil, "BACKGROUND"); M.tiles[i] = t
    local r, c = math.floor((i - 1) / cols), (i - 1) % cols
    t:SetTexture(file); t:ClearAllPoints(); t:SetPoint("TOPLEFT", M.cv, "TOPLEFT", c * L.tileWidth, -r * L.tileHeight); t:SetSize(L.tileWidth, L.tileHeight); t:Show(); n = n + 1
  end
  if self:O("explored") and C_MapExplorationInfo and C_MapExplorationInfo.GetExploredMapTextures then
    local okE, ex = pcall(C_MapExplorationInfo.GetExploredMapTextures, M.map); local k = 0
    if okE and type(ex) == "table" then for _, e in ipairs(ex) do
      local tw, th = e.textureWidth or 256, e.textureHeight or 256; local fi = 0
      for r = 0, (e.numTexturesTall or 1) - 1 do for c = 0, (e.numTexturesWide or 1) - 1 do fi = fi + 1; local file = e.fileDataIDs and e.fileDataIDs[fi]
        if file then k = k + 1; local t = M.over[k] or M.cv:CreateTexture(nil, "ARTWORK"); M.over[k] = t
          t:SetTexture(file); t:ClearAllPoints(); t:SetPoint("TOPLEFT", M.cv, "TOPLEFT", (e.offsetX or 0) + c * 256, -((e.offsetY or 0) + r * 256)); t:SetSize(math.min(256, tw - c * 256), math.min(256, th - r * 256)); t:Show() end end end
    end end
  end
  return n
end
function CG:LayoutCanvas()
  if not M.clip then return end
  local w, h = M.clip:GetWidth() or 1, M.clip:GetHeight() or 1
  local aw, ah = (M.art and M.art.layerWidth) or 1002, (M.art and M.art.layerHeight) or 668
  M.cv:SetSize(aw, ah)
  local fit = math.min(w / aw, h / ah); M.base = fit
  local s = fit * M.zoom; M.cv:SetScale(math.max(0.05, s))
  local maxx, maxy = math.max(0, aw * s - w), math.max(0, ah * s - h)
  M.px = math.max(-maxx, math.min(0, M.px)); M.py = math.max(0, math.min(maxy, M.py))
  M.cv:ClearAllPoints(); M.cv:SetPoint("TOPLEFT", M.clip, "TOPLEFT", (M.px + math.max(0, (w - aw * s) / 2)) / s, (M.py - math.max(0, (h - ah * s) / 2)) / s)
end
function CG:Zoom(factor, atCursor)
  local old = M.zoom; M.zoom = math.max(1, math.min(8, M.zoom * factor)); if M.zoom == old then return M.zoom end
  local cx, cy
  if atCursor then cx, cy = self:CursorXY() end
  if not cx then cx, cy = self:CenterXY() end
  local aw, ah = M.cv:GetWidth(), M.cv:GetHeight(); local s = M.base * M.zoom
  local w, h = M.clip:GetWidth(), M.clip:GetHeight()
  M.px, M.py = -(cx * aw * s - w / 2), (cy * ah * s - h / 2)
  self:LayoutCanvas(); self:DrawAll(); return M.zoom
end
function CG:ResetView() M.zoom, M.px, M.py = 1, 0, 0; self:LayoutCanvas(); self:DrawAll() end
-- 0-1 map position under the cursor / at the view centre
function CG:CursorXY()
  if not (M.cv and GetCursorPosition) then return nil end
  local x, y = GetCursorPosition(); local s = tonumber(M.cv:GetEffectiveScale()); local l, t = tonumber(M.cv:GetLeft()), tonumber(M.cv:GetTop())
  if not (l and t and s and s > 0) then return nil end
  local mx, my = (x / s - l) / M.cv:GetWidth(), (t - y / s) / M.cv:GetHeight()
  if mx < 0 or mx > 1 or my < 0 or my > 1 then return nil end
  return mx, my
end
function CG:CenterXY()
  local s = (M.base or 1) * M.zoom; local aw, ah = (M.cv and M.cv:GetWidth()) or 1, (M.cv and M.cv:GetHeight()) or 1
  local w, h = (M.clip and M.clip:GetWidth()) or 1, (M.clip and M.clip:GetHeight()) or 1
  return math.max(0, math.min(1, (-M.px + w / 2) / (aw * s))), math.max(0, math.min(1, (M.py + h / 2) / (ah * s)))
end
function CG:DrillDown(x, y)
  if not (C_Map and C_Map.GetMapInfoAtPosition) then return end
  local ok, info = pcall(C_Map.GetMapInfoAtPosition, M.map, x, y)
  if ok and info and info.mapID and info.mapID ~= M.map then self:SetMap(info.mapID) end
end
function CG:GoUp()
  local info = C_Map and C_Map.GetMapInfo and C_Map.GetMapInfo(M.map)
  if info and info.parentMapID and info.parentMapID > 0 then self:SetMap(info.parentMapID) end
end
-- drawing: pins (pooled), routes (dashed texture segments), you and party
local function pinFrame(i)
  local p = M.pins[i]; if p then return p end
  p = CreateFrame("Button", nil, M.pinLayer); p.tex = p:CreateTexture(nil, "OVERLAY"); p.tex:SetAllPoints(p)
  p:SetScript("OnEnter", function(s) if not GameTooltip then return end
    if C.MapTipNear then C:MapTipNear(s, M.pins, nil, s.pin and TR["Click to edit or delete"] or nil) end end)
  p:SetScript("OnLeave", function() if GameTooltip then GameTooltip:Hide() end end)
  p:SetScript("OnClick", function(s) if s.pin then CG:PinEditor(s.pin) end end)
  M.pins[i] = p; return p
end
function CG:IconFor(p, size)
  if p.tm and (size or 32) <= 16 then local A = self:TMApi(); if A and A.PinFor then local ok, path = pcall(A.PinFor, p.tm, p.name, 16); if ok and path then return path end end end
  if p.iconPath then return p.iconPath end
  if p.icon then return self:Icon(p.icon, size) end
  return self:Icon(self.CAT_ICON[p.cat] or "user", size)
end
function CG:DrawPins()
  if not (M.f and M.f:IsShown() and M.map) then return 0 end
  local list = self:Search(self:Collect(M.map, "world"), M.query)
  local f = self:Filters("world"); local sz = 20 * (f.scale or 1) / ((M.base or 1) * M.zoom)
  local aw, ah = M.cv:GetWidth(), M.cv:GetHeight(); local n = 0
  for _, e in ipairs(list) do n = n + 1; local p = pinFrame(n)
    local s = e.area and (e.diameter and e.diameter * math.max(aw,ah) or sz * 2.2) or sz
    p:SetSize(s, s); p:ClearAllPoints(); p:SetPoint("CENTER", M.pinLayer, "TOPLEFT", e.x * aw, -e.y * ah)
    p.tex:SetTexture(e.area and self.ICONS.area or self:IconFor(e, 32)); p:SetAlpha(e.dim and 0.5 or 1)
    if e.area then local c = e.shade or CG.COL.teal; p.tex:SetVertexColor(c[1], c[2], c[3], e.opacity or 0.22) else p.tex:SetVertexColor(1, 1, 1, 1) end
    p.name, p.note, p.pin = e.name, e.note, e.pin; p.entry = self:TipEntry(e); p.cx, p.cy, p.r = e.x * aw, -e.y * ah, s / 2; p:Show() end
  if self.Markers then for _, m in ipairs(self:Markers()) do if m.map == M.map then n = n + 1; local p = pinFrame(n)   -- registered markers (CG:RegisterMarker, e.g. a route start flag)
    local s = (m.size or 24) / ((M.base or 1) * M.zoom)
    p:SetSize(s, s); p:ClearAllPoints(); p:SetPoint("CENTER", M.pinLayer, "TOPLEFT", m.x * aw, -m.y * ah)
    p.tex:SetTexture(m.icon or self:Icon("user", 32)); p.tex:SetVertexColor(1, 1, 1, 1); p:SetAlpha(1)
    p.name, p.note, p.pin = m.name, nil, nil; p.entry = { name = m.name }; p.cx, p.cy, p.r = m.x * aw, -m.y * ah, s / 2; p:Show() end end end
  -- Peer camps are transient, non-editable and never saved or routed automatically.
  if C.CampObservations then
    for _, r in ipairs(C:CampObservations()) do
      if r.point.z == M.map then
        n = n + 1; local p = pinFrame(n)
        local s = sz
        p:SetSize(s,s); p:ClearAllPoints()
        p:SetPoint("CENTER", M.pinLayer, "TOPLEFT", r.point.x/100*aw, -r.point.y/100*ah)
        p.tex:SetTexture(C:PinPath("user",32)); p.tex:SetVertexColor(0.45,0.61,0.78,1); p:SetAlpha(0.65)
        p.name, p.note, p.pin = TR["Reported campsite (unverified)"], nil, nil
        p.entry = { name = p.name }; p.cx,p.cy,p.r = r.point.x/100*aw,-r.point.y/100*ah,s/2
        p:Show()
      end
    end
  end
  for i = n + 1, #M.pins do M.pins[i]:Hide() end
  M.drawn = n; return n
end
local function seg(i)
  local t = M.segs[i]; if t then return t end
  t = M.routeLayer:CreateTexture(nil, "ARTWORK"); t:SetTexture(CG.ICONS.line); M.segs[i] = t; return t
end
-- a straight dashed line from (x1,y1) to (x2,y2) in canvas units, drawn with short textures (dash on/off from the look notes)
function CG:Line(i, x1, y1, x2, y2, style, alpha)
  local st = self.ROUTE[style] or self.ROUTE.flight; local c = self.COL[st[1]]
  local dx, dy = x2 - x1, y2 - y1; local len = math.sqrt(dx * dx + dy * dy); if len < 1 then return i end
  local u = 1 / ((M.base or 1) * M.zoom); local on, off = st[2] * u, st[3] * u; local w = st[4] * u
  if on <= 0 then on, off = len, 0 end
  local step = on + off; local d = 0
  while d < len and i < 4000 do
    local a, b = d, math.min(len, d + on); local mx, my = x1 + dx * (a + b) / 2 / len, y1 + dy * (a + b) / 2 / len
    local t = seg(i); i = i + 1
    t:ClearAllPoints(); t:SetSize(b - a, w); t:SetPoint("CENTER", M.routeLayer, "TOPLEFT", mx, -my)
    if t.SetRotation then t:SetRotation(-math.atan2(dy, dx)) end
    t:SetVertexColor(c[1], c[2], c[3], alpha or st[5]); t:Show()
    d = d + step
  end
  return i
end
function CG:DrawRoutes()
  if not (M.f and M.f:IsShown() and M.map) then return 0 end
  local aw, ah = M.cv:GetWidth(), M.cv:GetHeight(); local i = 1
  if self:O("routes") then
    local nodes = self.NODES or {}; local fac = UnitFactionGroup and UnitFactionGroup("player"); fac = fac and fac:sub(1, 1)
    local wf, wm = self:CatOn("world", "flight") and self:O("routeFlight"), nil
    if wf then for _, t in ipairs(self.TAXI or {}) do local a, b = nodes[t[1]], nodes[t[2]]
      if a and b and a.z == M.map and b.z == M.map and (a.f == "N" or a.f == fac) and (b.f == "N" or b.f == fac) then
        local known = self:KnowsTaxi(a.id) and self:KnowsTaxi(b.id)
        i = self:Line(i, a.x / 100 * aw, a.y / 100 * ah, b.x / 100 * aw, b.y / 100 * ah, "flight", not known and 0.3 or nil) end end end
    for _, l in ipairs(self.LINKS or {}) do
      local opt = (l.k == "ship" and "routeShip") or (l.k == "zeppelin" and "routeZeppelin") or "routeTram"
      local cat = l.k == "tram" and "portal" or l.k
      if self:O(opt) and self:CatOn("world", cat) and l.a[1] == M.map and l.b[1] == M.map then
        i = self:Line(i, l.a[2] / 100 * aw, l.a[3] / 100 * ah, l.b[2] / 100 * aw, l.b[3] / 100 * ah, l.k) end end
  end
  -- planned trip: legs on this map
  local prevx, prevy
  for _, l in ipairs(M.trip or {}) do
    if l.z == M.map and l.x then
      if prevx then i = self:Line(i, prevx * aw, prevy * ah, l.x / 100 * aw, l.y / 100 * ah, l.kind == "walk" and "user" or l.kind) end
      prevx, prevy = l.x / 100, l.y / 100
    else prevx = nil end
  end
  for k = i, #M.segs do M.segs[k]:Hide() end
  return i - 1
end
-- you and party members (dots), refreshed a few times a second while the map is open
function CG:DrawUnits()
  M.units = M.units or {}
  local units = { "player" }; if self:O("party") then for k = 1, 4 do units[#units + 1] = "party" .. k end end
  local aw, ah = M.cv:GetWidth(), M.cv:GetHeight(); local n = 0
  for _, u in ipairs(units) do
    local pos = UnitExists and UnitExists(u) and C_Map and C_Map.GetPlayerMapPosition and C_Map.GetPlayerMapPosition(M.map, u)
    local x, y = pos and pos.x, pos and pos.y
    if x and y and x > 0 and y > 0 then n = n + 1
      local d = M.units[n] or M.pinLayer:CreateTexture(nil, "OVERLAY"); M.units[n] = d
      d:SetTexture(u == "player" and "Interface\\Minimap\\MinimapArrow" or "Interface\\Minimap\\PartyRaidBlips")
      if u ~= "player" and d.SetTexCoord then d:SetTexCoord(0.875, 1, 0.25, 0.5) elseif d.SetTexCoord then d:SetTexCoord(0, 1, 0, 1) end
      local s = (u == "player" and 24 or 14) / ((M.base or 1) * M.zoom); d:SetSize(s, s); d:ClearAllPoints(); d:SetPoint("CENTER", M.pinLayer, "TOPLEFT", x * aw, -y * ah)
      if u == "player" and d.SetRotation then local fa = C.Facing and C:Facing(); if fa then d:SetRotation(fa) end end; d:Show()   -- facing nil in encounters: keep the last rotation
      if u == "player" then M.me = { x, y } end
    end
  end
  for k = n + 1, #M.units do M.units[k]:Hide() end
  return n
end
function CG:DrawAll() if not (M.f and M.f:IsShown()) then return end; self:DrawRoutes(); self:DrawPins(); self:DrawUnits() end
function CG:OnMapUpdate(el)
  if M.drag and GetCursorPosition then local x, y = GetCursorPosition(); local d = M.drag; local s = M.clip:GetEffectiveScale() or 1
    if math.abs(x - d[1]) + math.abs(y - d[2]) > 3 then d[5] = true end
    M.px, M.py = d[3] + (x - d[1]) / s, d[4] + (d[2] - y) / s; self:LayoutCanvas() end
  if (M.acc or 0) < 0.2 then return end; M.acc = 0
  if self:O("fadeMove") and GetUnitSpeed and (GetUnitSpeed("player") or 0) > 0 then M.f:SetAlpha(0.5) else M.f:SetAlpha(1) end
  self:DrawUnits()
  -- Refresh only when the bounded set of visible peer locations changes.
  if C.CampObservations then
    local keys = {}
    for _, r in ipairs(C:CampObservations()) do
      if r.point.z == M.map then keys[#keys+1] = tostring(r.point.x)..":"..tostring(r.point.y) end
    end
    table.sort(keys)
    local signature = table.concat(keys,";")
    if signature ~= M.campSignature then M.campSignature = signature; self:DrawPins() end
  end
  if self.version ~= M.drawnVersion then M.drawnVersion = self.version; self:DrawRoutes(); self:DrawPins() end
  if self:O("coords") then
    local me = M.me; local cx, cy = self:CursorXY()
    local a = me and string.format("%.1f, %.1f", me[1] * 100, me[2] * 100) or "-"
    local b = cx and string.format("%.1f, %.1f", cx * 100, cy * 100) or "-"
    M.f.ro.t:SetText(TR:F("Player %s   Cursor %s", a, b))
    if M.f.searchHint then if (M.query or "") == "" and not (M.f.search.HasFocus and M.f.search:HasFocus()) then M.f.searchHint:Show() else M.f.searchHint:Hide() end end
  end
end
function CG:OpenMap(map)
  local f = self:MapFrame(); f:Show()
  local m = map or (C_Map and C_Map.GetBestMapForUnit and C_Map.GetBestMapForUnit("player")) or M.map or 1415
  self:SetMap(m); return f
end
-- with OpenMap loaded the game's world map is OpenMap's view: open that instead of our window (out of combat only;
-- in combat the map key still works, as it is not overridden)
function CG:ToggleMap()
  if self.OpenMapPresent and self:OpenMapPresent() then
    if M.f then M.f:Hide() end
    local tw = rawget(_G, "ToggleWorldMap"); if type(tw) == "function" and not C:InCombat() then pcall(tw) end
    return nil
  end
  local f = self:MapFrame(); if f:IsShown() then f:Hide() else self:OpenMap() end
end
-- "how do I get there": from your position to a spot on the map
function CG:RouteTo(map, x, y)
  local pm = C_Map and C_Map.GetBestMapForUnit and C_Map.GetBestMapForUnit("player")
  local pos = pm and C_Map.GetPlayerMapPosition and C_Map.GetPlayerMapPosition(pm, "player")
  if not (pos and pos.x) then C:Print(TR["Cartographer: your position is not available here."]); return nil end
  local legs, total = self:Route(pm, pos.x, pos.y, map, x, y)
  if not legs then C:Print(TR["Cartographer: no route found to that spot."]); return nil end
  M.trip = legs; M.tripLines = self:RouteLines(legs); self.version = self.version + 1
  self:ShowRoutePanel(); return legs, total
end
