local TR = (Fennick_BEAST and Fennick_BEAST.L) or setmetatable({ F = function(_, f, ...) local ok, s = pcall(string.format, f, ...); return ok and s or f end }, { __index = function(_, k) return k end })   -- l10n (Core C.L)
if not (Fennick_BEAST and (Fennick_BEAST.API or 1) >= 3) then return end   -- file-top guard
-- Minimap: restyles Blizzard's Minimap frame (not protected) instead of replacing the render surface the client owns.
-- Shape (round/square mask), size, wheel zoom, the Fennick border ring, a coordinate plaque, Cartographer pins at 16 px within a
-- distance limit, optional gathering of other add-ons' minimap buttons. All changes wait until out of combat; switching
-- Cartographer's minimap off restores Blizzard's saved size, mask and buttons.
local C = Fennick_BEAST
local CG = Fennick_CARTOGRAPHER; if not CG then return end
local W8 = "Interface\\Buttons\\WHITE8X8"
local ROUND = "Textures\\MinimapMask"
local MM = { pins = {}, orig = nil, moved = {} }
CG.mini = MM
local OUT_R = { [0] = 233.3, 200, 166.7, 133.3, 100, 66.7 }
local IN_R = { [0] = 150, 120, 90, 60, 40, 25 }
local function col(k, a) local c = CG.COL[k]; return c[1], c[2], c[3], a or 1 end
function CG:MinimapActive() return self:O("enabled") and self:O("miniOn") and Minimap ~= nil end
local function anchors(frame)
  local points = {}
  for i = 1, frame:GetNumPoints() do points[i] = {frame:GetPoint(i)} end
  return points
end

local function restoreAnchors(frame, points)
  frame:ClearAllPoints()
  for _, p in ipairs(points) do frame:SetPoint(p[1], p[2], p[3], p[4], p[5]) end
end

-- The cluster header and compass can be siblings of the terrain renderer.
-- Keep the map and its tracking/pin children live while suppressing just the stock art.
local function hideChrome(frame)
  if frame and MM.chrome[frame] == nil then
    MM.chrome[frame] = frame:IsShown() and true or false
    frame:Hide()
  end
end

local function releaseSquare()
  if not MM.chrome then return end
  for frame, shown in pairs(MM.chrome) do if shown then frame:Show() end end
  MM.chrome = nil
  restoreAnchors(Minimap, MM.orig.points)
  if MM.title then MM.title:Hide(); MM.clock:Hide() end
end

local function squareLayout()
  MM.chrome = MM.chrome or {}
  local cluster = MinimapCluster
  hideChrome(MinimapBorder)
  hideChrome(MinimapBorderTop)
  hideChrome(MinimapCompassTexture)
  hideChrome(MinimapNorthTag)
  hideChrome(MinimapZoneTextButton)
  hideChrome(MinimapToggleButton)
  hideChrome(TimeManagerClockButton)
  hideChrome(GameTimeFrame)
  if cluster then
    hideChrome(cluster.BorderTop)
    hideChrome(cluster.BorderTopFrame)
    hideChrome(cluster.ZoneTextButton)
  end
  Minimap:ClearAllPoints()
  Minimap:SetPoint("TOPRIGHT", UIParent, "TOPRIGHT", -10, -26)
end

function CG:MinimapSide(square)
  local size = tonumber(self:O("miniSize"))
  if size and size > 0 then return size end
  if not square then return MM.orig.w end
  local height = UIParent:GetHeight() * UIParent:GetEffectiveScale() / Minimap:GetEffectiveScale()
  return math.max(120, math.floor(height * 0.23 + 0.5))
end

function CG:ApplyMinimap()
  if not Minimap then return false end
  if C:InCombat() then C:Safe("cartographer minimap", function() CG:ApplyMinimap() end); return false end
  if not self:MinimapActive() then return self:RestoreMinimap() end
  if not MM.orig then
    MM.orig = {w=Minimap:GetWidth(), h=Minimap:GetHeight(), points=anchors(Minimap),
      mask=Minimap.GetMaskTexture and Minimap:GetMaskTexture() or ROUND}
  end
  local square = self:MiniShape() == "SQUARE"
  if square then squareLayout() else releaseSquare() end
  local s = self:MinimapSide(square)
  Minimap:SetSize(s, s)
  if Minimap.SetMaskTexture then Minimap:SetMaskTexture(self:MiniShape() == "SQUARE" and W8 or ROUND) end
  if not MM.ring then
    MM.ring = CreateFrame("Frame", nil, Minimap); MM.ring:SetAllPoints(Minimap); MM.ring:SetFrameLevel((tonumber(Minimap:GetFrameLevel()) or 1) + 4)
    MM.layers = {}
    local edges = {{"TOPLEFT","TOPRIGHT"}, {"BOTTOMLEFT","BOTTOMRIGHT"}, {"TOPLEFT","BOTTOMLEFT"}, {"TOPRIGHT","BOTTOMRIGHT"}}
    local border = {}
    for i, edge in ipairs(edges) do
      local t = MM.ring:CreateTexture(nil, "OVERLAY")
      t:SetTexture(W8); t:SetVertexColor(col("gold"))
      t:SetPoint(edge[1], Minimap, edge[1])
      t:SetPoint(edge[2], Minimap, edge[2])
      if i <= 2 then t:SetHeight(1) else t:SetWidth(1) end
      border[i] = t
    end
    MM.layers[1] = border
    MM.title = C:NewFS(MM.ring, "OVERLAY")
    MM.title:SetPoint("BOTTOM", Minimap, "TOP", 0, 4)
    MM.title:SetTextColor(col("gold"))
    MM.clock = C:NewFS(MM.ring, "OVERLAY")
    MM.clock:SetPoint("TOPLEFT", Minimap, "BOTTOMLEFT", 1, -5)
    MM.plaque = CreateFrame("Frame", nil, Minimap); MM.plaque:SetSize(90, 16); MM.plaque:SetPoint("TOP", Minimap, "BOTTOM", 0, -6)
    MM.plaque.bg = MM.plaque:CreateTexture(nil, "BACKGROUND"); MM.plaque.bg:SetTexture(W8); MM.plaque.bg:SetVertexColor(col("gold")); MM.plaque.bg:SetAllPoints(MM.plaque)
    MM.plaque.t = C:NewFS(MM.plaque, "OVERLAY"); MM.plaque.t:SetPoint("CENTER"); MM.plaque.t:SetTextColor(col("dark"))
    MM.filter = CG.button(MM.ring, "F", TR["Filter minimap icons"], function() CG:ToggleFilters("mini") end); MM.filter:SetPoint("BOTTOMLEFT", Minimap, "BOTTOMLEFT", -2, -2)
  end
  if square then MM.title:Show(); MM.clock:Show() else MM.title:Hide(); MM.clock:Hide() end
  for _, L in ipairs(MM.layers) do for _, t in ipairs(L) do if square then t:Show() else t:Hide() end end end   -- round (setting): Blizzard's own round border stays
  MM.ring:Show(); if self:O("miniCoords") then MM.plaque:Show() else MM.plaque:Hide() end
  if self:O("miniZoomWheel") and not MM.wheel and Minimap.EnableMouseWheel then
    Minimap:EnableMouseWheel(true)
    Minimap:HookScript("OnMouseWheel", function(_, d) if CG:MinimapActive() and CG:O("miniZoomWheel") then CG:MiniZoom(d) end end); MM.wheel = true
  end
  if self:O("miniGather") then self:GatherButtons() else self:ReleaseButtons() end
  MM.applied = true; return true
end
function CG:RestoreMinimap()
  MM.signature=nil; MM.listAt=nil
  if not (Minimap and MM.orig) then return false end
  if C:InCombat() then C:Safe("cartographer minimap", function() CG:RestoreMinimap() end); return false end
  releaseSquare()
  Minimap:SetSize(MM.orig.w, MM.orig.h); if Minimap.SetMaskTexture then Minimap:SetMaskTexture(MM.orig.mask) end
  MM.orig = nil
  if MM.ring then MM.ring:Hide() end; if MM.plaque then MM.plaque:Hide() end
  for _, p in ipairs(MM.pins) do p:Hide() end
  self:ReleaseButtons(); MM.applied = false; return true
end
function CG:MiniZoom(d)
  if not (Minimap.GetZoom and Minimap.SetZoom) then return end
  local z = (tonumber(Minimap:GetZoom()) or 0) + (d > 0 and 1 or -1); local mx = (Minimap.GetZoomLevels and Minimap:GetZoomLevels() or 6) - 1
  Minimap:SetZoom(math.max(0, math.min(mx, z)))
end
-- other add-ons' minimap buttons (LibDBIcon and named Minimap children): laid out in rows below the map only when the user asks;
-- the original anchors are kept and put back when the option is turned off. Never touches Blizzard's own buttons.
-- Forever 1.60.1 reorganized the minimap header, so Blizzard's frames are found at runtime: a global name set by Blizzard's own
-- (secure) code (issecurevariable), Blizzard name prefixes, and the classic names below as a seed. Missing names are fine.
-- Only Minimap's own children are ever gathered; header frames that live elsewhere in the cluster are never touched (read-only).
local BLIZZ_SEED = { MinimapZoomIn = 1, MinimapZoomOut = 1, MiniMapTracking = 1, MiniMapTrackingFrame = 1, MiniMapMailFrame = 1, MinimapBackdrop = 1, GameTimeFrame = 1,
  MiniMapBattlefieldFrame = 1, MiniMapWorldMapButton = 1, TimeManagerClockButton = 1, MinimapZoneTextButton = 1, MiniMapLFGFrame = 1 }
local BLIZZ_PREFIX = { "^MiniMap", "^Minimap", "^GameTime", "^TimeManager", "^QueueStatus" }
function CG:IsBlizzardMinimapFrame(n)
  if not n or n:find("^LibDBIcon10_") then return false end
  if BLIZZ_SEED[n] then return true end
  if issecurevariable then local ok, sec = pcall(issecurevariable, n); if ok and sec then return true end end
  for _, p in ipairs(BLIZZ_PREFIX) do if n:find(p) then return true end end
  return false
end
function CG:ForeignButtons()
  local out = {}
  if not (Minimap and Minimap.GetChildren) then return out end
  for _, ch in ipairs({ Minimap:GetChildren() }) do
    local n = ch.GetName and ch:GetName()
    if n and not CG:IsBlizzardMinimapFrame(n) and (n:find("^LibDBIcon10_") or (ch.IsObjectType and ch:IsObjectType("Button"))) and not n:find("^Fennick_Cartographer") then out[#out + 1] = ch end
  end
  table.sort(out, function(a, b) return (a:GetName() or "") < (b:GetName() or "") end); return out
end
function CG:GatherButtons()
  if C:InCombat() then return 0 end
  local list = self:ForeignButtons()
  local n = 0
  local pitch = 36
  for _, b in ipairs(list) do
    if not (b.IsProtected and b:IsProtected()) and b:IsShown() then
      pitch = math.max(pitch, b:GetWidth() + 2, b:GetHeight() + 2)
    end
  end
  local columns = math.max(1, math.floor(Minimap:GetWidth() / pitch))
  for _, b in ipairs(list) do
    if not (b.IsProtected and b:IsProtected()) and b:IsShown() then
      if not MM.moved[b] then MM.moved[b] = anchors(b) end
      b:ClearAllPoints()
      b:SetPoint("TOPRIGHT", Minimap, "BOTTOMRIGHT", -(n % columns) * pitch, -24 - math.floor(n / columns) * pitch)
      n = n + 1
    end
  end
  return n
end
function CG:ReleaseButtons()
  if C:InCombat() then return 0 end
  local n = 0
  for b, p in pairs(MM.moved) do restoreAnchors(b, p); n = n + 1; MM.moved[b] = nil end
  return n
end
-- pins on the minimap: same sources and categories as the world map, its own filters, 16 px art, distance limit
function CG:MiniRadius()
  if C_Minimap and C_Minimap.GetViewRadius then local ok, r = pcall(C_Minimap.GetViewRadius); if ok and r then return r end end
  local z = Minimap.GetZoom and Minimap:GetZoom() or 0; local indoor = GetCVar and GetCVar("minimapZoom") ~= nil and IsIndoors and IsIndoors()
  return (indoor and IN_R or OUT_R)[z] or 233.3
end
-- shape-aware clip and edge clamp: square (default) keeps a pin when it is inside the square and pulls it in so the
-- whole icon stays inside the edge; round does the same against the circle. Returns nil when the spot is off the map.
function CG:MiniShape() return self:O("miniShape") == "round" and "ROUND" or "SQUARE" end
function CG:MiniClip(sx, sy, half, size)
  local r = math.max(0, half - (size or 16) / 2)
  if self:MiniShape() == "SQUARE" then
    if math.abs(sx) > half or math.abs(sy) > half then return nil end
    return math.max(-r, math.min(r, sx)), math.max(-r, math.min(r, sy))
  end
  local d = math.sqrt(sx * sx + sy * sy); if d > half then return nil end
  if d > r and d > 0 then return sx * r / d, sy * r / d end
  return sx, sy
end
-- Note (P2-1): the community convention is a global GetMinimapShape. We chain the one present when this file loads;
-- an add-on loaded later that redefines it replaces ours (its own shape then wins). Accepted and documented.
-- other add-ons ask GetMinimapShape() where to put their buttons: SQUARE while our square minimap is active
local prevShape = rawget(_G, "GetMinimapShape")
function GetMinimapShape()
  if CG:MinimapActive() then return CG:MiniShape() end
  if prevShape then local ok, v = pcall(prevShape); if ok and v then return v end end
  return "ROUND"
end
function CG:DrawMinimap(snapshot)
  if not self:MinimapActive() or C:InCombat() then return 0 end
  local now=GetTime()
  if MM.chrome and (not MM.chromeAt or now-MM.chromeAt>=1 or now<MM.chromeAt) then
    MM.chromeAt=now
    MM.title:SetText(GetMinimapZoneText and GetMinimapZoneText() or GetZoneText())
    if GetGameTime then
      local hour, minute = GetGameTime()
      MM.clock:SetText(string.format("%02d:%02d", hour, minute))
    end
  end
  local map,me
  if snapshot then map=snapshot.map; me=snapshot
  else
    map=C_Map and C_Map.GetBestMapForUnit and C_Map.GetBestMapForUnit("player")
    me=map and C_Map.GetPlayerMapPosition and C_Map.GetPlayerMapPosition(map,"player")
  end
  if not (map and me and me.x and me.y) then MM.signature=nil; for _,p in ipairs(MM.pins) do p:Hide() end; return 0 end
  local f = self:Filters("mini"); local R = self:MiniRadius(); local lim = f.dist or 400
  local half = Minimap:GetWidth() / 2; local rot = snapshot and snapshot.rotating or (not snapshot and C.MinimapRotates and C:MinimapRotates()) or false; local fa = 0
  if rot then if snapshot then fa=snapshot.facing else fa=C.Facing and C:Facing() end; if not fa then MM.signature=nil; for i = 1, #MM.pins do MM.pins[i]:Hide() end; return 0 end end   -- facing hidden (encounter): no pins rather than wrong ones
  local sz = 16 * (f.scale or 1); local n = 0
  if MM.listMap ~= map or MM.listVersion ~= self.version or not MM.listAt or now-MM.listAt >= 1 or now<MM.listAt then
    MM.list = self:Collect(map,"mini"); MM.listMap,MM.listVersion,MM.listAt=map,self.version,now
    MM.signature=nil; MM.nearPins=nil
  end
  local tracking = C.GatheringTracking and C:GatheringTracking() or 0
  local signature=table.concat({tracking,map,me.x,me.y,fa,R,half,self:MiniShape(),sz,lim},":")
  if MM.signature==signature then return MM.shown or 0 end
  local cont, px, py = self:WorldPos(map, me.x, me.y)
  if not (cont and px and py) then MM.signature=nil; for _,p in ipairs(MM.pins) do p:Hide() end; return 0 end
  if MM.plaque and MM.plaque.t then
    local coords=string.format("%.1f, %.1f",me.x*100,me.y*100)
    if coords~=MM.coords then MM.plaque.t:SetText(coords); MM.coords=coords end
  end
  -- The 64-yard margin keeps every newly visible pin in the shortlist between rebuilds.
  if not MM.nearPins or MM.nearLimit~=lim or MM.nearCont~=cont or (px-MM.nearX)^2+(py-MM.nearY)^2>64^2 then
    MM.nearPins={}; MM.nearX,MM.nearY,MM.nearLimit,MM.nearCont=px,py,lim,cont
    for _,entry in ipairs(MM.list) do
      local ec,x,y=self:WorldPos(map,entry.x,entry.y,true)
      if ec==cont and x and y and (x-px)^2+(y-py)^2<=(lim+64)^2 then
        MM.nearPins[#MM.nearPins+1]={entry,x,y}
      end
    end
  end
  local cs,sn=math.cos(fa),math.sin(fa)
  for _,pin in ipairs(MM.nearPins) do
    local e,wx,wy=pin[1],pin[2],pin[3]
    local dx, dy = wx - px, wy - py
    if dx*dx+dy*dy <= lim*lim and not (tracking ~= 0 and C:TrackedResourceNearby(e.cat, dx*dx + dy*dy)) then
      -- world X is north, world Y is west: screen right = -dy, screen up = dx
      local sx, sy = -dy / R * half, dx / R * half
      if rot then sx, sy = sx * cs - sy * sn, sx * sn + sy * cs end
      local size = sz
      if e.area then
        local radius = e.diameter and e.diameter / 2 or 0.015
        local _, ax, ay = self:WorldPos(map, math.min(1,e.x+radius), e.y, true)
        local _, bx, by = self:WorldPos(map, e.x, math.min(1,e.y+radius), true)
        local extent = 0
        if ax and ay then extent=math.max(extent,math.sqrt((ax-wx)^2+(ay-wy)^2)) end
        if bx and by then extent=math.max(extent,math.sqrt((bx-wx)^2+(by-wy)^2)) end
        local room = self:MiniShape()=="SQUARE" and half-math.max(math.abs(sx),math.abs(sy)) or half-math.sqrt(sx*sx+sy*sy)
        size=math.min(math.max(sz,2*extent/R*half),2*room)
        if size<4 then sx=nil end
      else
        sx, sy = CG:MiniClip(sx, sy, half, sz)
      end
      if sx then n = n + 1
        local p = MM.pins[n]; if not p then p = CreateFrame("Frame", nil, Minimap); p.tex = p:CreateTexture(nil, "OVERLAY"); p.tex:SetAllPoints(p); MM.pins[n] = p
          p:EnableMouse(true); p:SetScript("OnEnter", function(s) if GameTooltip and C.MapTipNear then C:MapTipNear(s, MM.pins) end end)
          p:SetScript("OnLeave", function() if GameTooltip then GameTooltip:Hide() end end) end
        p:SetSize(size, size); p:ClearAllPoints(); p:SetPoint("CENTER", Minimap, "CENTER", sx, sy); if p.renderEntry~=e then p.tex:SetTexture(e.area and self.ICONS.area or self:IconFor(e, 16)); local c = e.area and (e.shade or CG.COL.teal); if c then p.tex:SetVertexColor(c[1],c[2],c[3],e.opacity or 0.22) else p.tex:SetVertexColor(1,1,1,1) end; p.name = e.name; p.entry = CG:TipEntry(e); p.renderEntry=e end; p.cx, p.cy, p.r = sx, sy, size / 2; p:Show()
        if n >= 120 then break end
      end
    end
  end
  for i = n + 1, #MM.pins do MM.pins[i]:Hide() end
  MM.signature, MM.shown = signature, n
  return n
end
