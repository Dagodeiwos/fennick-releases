local TR = (Fennick_BEAST and Fennick_BEAST.L) or setmetatable({ F = function(_, f, ...) local ok, s = pcall(string.format, f, ...); return ok and s or f end }, { __index = function(_, k) return k end })   -- l10n (Core C.L)
if not (Fennick_BEAST and (Fennick_BEAST.API or 1) >= 3) then return end   -- file-top guard
-- Optional compatibility with OpenMap (MIT, CurseForge project 1735937), a seamless world map add-on.
-- Original Fennick code: no OpenMap code or art is copied. We call only its public API (the OpenMapAPI global,
-- major version 1): IsStitched, CanvasFromWorldPos, ArtTopLevel and RegisterCallback. Every call is type-checked
-- and pcall-guarded; any error switches this bridge off for the session and Cartographer carries on as before.
-- When OpenMap is loaded: the map key and /fennick map open the game's world map (OpenMap's view); Cartographer
-- does not set its key override, never hooks or re-scripts OpenMap's or Blizzard's map frames, and draws its pins,
-- travel routes, planned trip and any registered markers (e.g. a route start flag) on a frame of its own that sits on
-- the world map canvas. Without OpenMap nothing here runs.
local C = Fennick_BEAST
local CG = Fennick_CARTOGRAPHER; if not CG then return end
local OM = { failed = false, pins = {}, segs = {}, wcache = {} }
CG.openmap = OM
-- generic marker hook: fn() returns a list of { map, x, y (0..1), icon, size, name } drawn on our own map and on OpenMap.
-- The route start flag registers here ("start"); so can any later marker.
CG.markers = CG.markers or {}
function CG:RegisterMarker(key, fn) if type(key) == "string" and (fn == nil or type(fn) == "function") then self.markers[key] = fn; self.version = self.version + 1; return true end; return false end
function CG:Markers()
  local out = {}
  for k, fn in pairs(self.markers) do local ok, list = pcall(fn); if ok and type(list) == "table" then for _, m in ipairs(list) do
    if type(m) == "table" and type(m.map) == "number" and type(m.x) == "number" and type(m.y) == "number" then m.src = k; out[#out + 1] = m end end end end
  return out
end
local function api()
  if OM.failed then return nil end
  local A = rawget(_G, "OpenMapAPI")
  if type(A) ~= "table" or A.major ~= 1 or type(A.IsStitched) ~= "function" or type(A.CanvasFromWorldPos) ~= "function" then return nil end
  return A
end
local function fail(where, err) OM.failed = true; if OM.frame then OM.frame:Hide() end; if C.Debug then C:Debug("cartographer openmap off (" .. where .. "): " .. tostring(err)) end end
-- OpenMap loaded (and its API is one we know)
function CG:OpenMapPresent() return api() ~= nil end
function CG:OpenMapStitched()
  local A = api(); if not A then return false end
  local ok, on = pcall(A.IsStitched); if not ok then fail("IsStitched", on); return false end
  return on == true
end
-- a point on a uiMap (0..1) -> x, y on the world map canvas (0..1 of it), or nil
local function worldPos(map, x, y)
  local k = map .. ":" .. math.floor(x * 1000) .. ":" .. math.floor(y * 1000); local c = OM.wcache[k]
  if c == nil then
    c = false
    if C_Map and C_Map.GetWorldPosFromMapPos and CreateVector2D then
      local ok, cont, v = pcall(C_Map.GetWorldPosFromMapPos, map, CreateVector2D(x, y))
      if ok and cont and v then local wx, wy = v.x, v.y; if v.GetXY then wx, wy = v:GetXY() end; if wx and wy then c = { cont, wx, wy } end end
    end
    OM.wcache[k] = c
  end
  return c or nil
end
function CG:OpenMapCanvasXY(map, x, y)
  local A = api(); if not A or type(map) ~= "number" or type(x) ~= "number" or type(y) ~= "number" then return nil end
  local w = worldPos(map, x, y); if not w then return nil end
  local ok, cx, cy = pcall(A.CanvasFromWorldPos, w[1], w[2], w[3])
  if not ok then fail("CanvasFromWorldPos", cx); return nil end
  if type(cx) ~= "number" or type(cy) ~= "number" then return nil end
  return cx, cy
end
-- the world map and its canvas, read only (we parent one frame of our own to the canvas; nothing of theirs is changed)
local function canvas()
  local wm = rawget(_G, "WorldMapFrame"); if not (wm and wm.IsShown and wm:IsShown()) then return nil end
  local ok, cv = pcall(function() return wm.GetCanvas and wm:GetCanvas() or (wm.ScrollContainer and wm.ScrollContainer.Child) end)
  if ok and cv and cv.GetWidth then return cv, wm end
end
local function layer(cv)
  local f = OM.frame
  if f and OM.canvas ~= cv then f:Hide(); f, OM.frame, OM.pins, OM.segs = nil, nil, {}, {} end   -- a new canvas: a new frame of ours (never re-parented)
  if not f then f = CreateFrame("Frame", nil, cv); OM.frame, OM.canvas = f, cv; f:SetAllPoints(cv)
    f:SetScript("OnUpdate", function(_, el) OM.acc = (OM.acc or 0) + el; if OM.acc < 0.25 then return end; OM.acc = 0
      if CG.version ~= OM.drawnVersion then pcall(CG.DrawOpenMap, CG) end end)
  end
  if not C:InCombat() then   -- frame levels on the map wait out combat (as OpenMap's own notes say)
    local A = api(); local top = 0
    if A and type(A.ArtTopLevel) == "function" then local ok, t = pcall(A.ArtTopLevel); if ok and type(t) == "number" then top = t end end
    pcall(f.SetFrameLevel, f, math.min(9000, top + 20))
  end
  return f
end
local function pin(i)
  local p = OM.pins[i]; if p then return p end
  p = CreateFrame("Button", nil, OM.frame); p.tex = p:CreateTexture(nil, "OVERLAY"); p.tex:SetAllPoints(p)
  p:SetScript("OnEnter", function(s) if GameTooltip and C.MapTipNear then C:MapTipNear(s, OM.pins, nil, s.pin and TR["Click to edit or delete"] or nil) end end)
  p:SetScript("OnLeave", function() if GameTooltip then GameTooltip:Hide() end end)
  p:SetScript("OnClick", function(s) if s.pin and CG.PinEditor then CG:PinEditor(s.pin) end end)
  OM.pins[i] = p; return p
end
local function seg(i) local t = OM.segs[i]; if t then return t end; t = OM.frame:CreateTexture(nil, "ARTWORK"); t:SetTexture(CG.ICONS.line); OM.segs[i] = t; return t end
local function line(i, x1, y1, x2, y2, style, alpha, unit)
  local st = CG.ROUTE[style] or CG.ROUTE.flight; local c = CG.COL[st[1]] or { 1, 1, 1 }
  local dx, dy = x2 - x1, y2 - y1; local len = math.sqrt(dx * dx + dy * dy); if len < 0.5 then return i end
  local on, off, w = st[2] * unit, st[3] * unit, st[4] * unit
  if on <= 0 then on, off = len, 0 end
  local d = 0
  while d < len and i < 3000 do
    local a, b = d, math.min(len, d + on); local mx, my = x1 + dx * (a + b) / 2 / len, y1 + dy * (a + b) / 2 / len
    local t = seg(i); i = i + 1
    t:ClearAllPoints(); t:SetSize(b - a, w); t:SetPoint("CENTER", OM.frame, "TOPLEFT", mx, -my)
    if t.SetRotation then t:SetRotation(-math.atan2(dy, dx)) end
    t:SetVertexColor(c[1], c[2], c[3], alpha or st[5]); t:Show(); d = d + on + off
  end
  return i
end
function CG:ClearOpenMap() for _, p in ipairs(OM.pins) do p:Hide() end; for _, t in ipairs(OM.segs) do t:Hide() end; OM.drawn = 0 end
-- draw pins, routes, the planned trip and markers on OpenMap's stitched view; returns the number of pins drawn
function CG:DrawOpenMap()
  OM.drawnVersion = self.version
  if not (self:O("enabled") and self:OpenMapStitched()) then if OM.frame then self:ClearOpenMap() end; return 0 end
  local cv, wm = canvas(); if not cv then return 0 end
  local f = layer(cv); f:Show()
  local W, H = tonumber(cv:GetWidth()) or 0, tonumber(cv:GetHeight()) or 0; if W <= 0 or H <= 0 then return 0 end
  local sc = tonumber(cv.GetScale and cv:GetScale()) or 1; if sc <= 0 then sc = 1 end; local unit = 1 / sc
  local map = wm.GetMapID and wm:GetMapID()
  -- canvas positions depend only on the map the stitched view sits on: cached per host map (cleared on StitchedChanged)
  if OM.host ~= map then OM.host, OM.ccache = map, {} end
  local cc = OM.ccache
  local function P(pm, x, y)
    local k = pm .. ":" .. x .. ":" .. y; local c = cc[k]
    if c == nil then local cx, cy = self:OpenMapCanvasXY(pm, x, y); c = cx and { cx, cy } or false; cc[k] = c end
    if c then return c[1] * W, c[2] * H end
  end
  local n, i = 0, 1
  if map then
    local list = self:Collect(map, "world"); local fl = self:Filters("world"); local sz = 20 * (fl.scale or 1) * unit
    for _, e in ipairs(list) do local px, py = P(map, e.x, e.y)
      if px then n = n + 1; local p = pin(n); local s = e.area and sz * 2.2 or sz
        p:SetSize(s, s); p:ClearAllPoints(); p:SetPoint("CENTER", f, "TOPLEFT", px, -py)
        p.tex:SetTexture(e.area and self.ICONS.area or self:IconFor(e, 32)); p:SetAlpha(e.dim and 0.5 or 1)
        if e.area then local c = CG.COL.teal; p.tex:SetVertexColor(c[1], c[2], c[3], 0.28) else p.tex:SetVertexColor(1, 1, 1, 1) end
        p.name, p.note, p.pin = e.name, e.note, e.pin; p.entry = self:TipEntry(e); p.cx, p.cy, p.r = px, -py, s / 2; p:Show() end end
  end
  for _, m in ipairs(self:Markers()) do local px, py = P(m.map, m.x, m.y)
    if px then n = n + 1; local p = pin(n); local s = (m.size or 24) * unit
      p:SetSize(s, s); p:ClearAllPoints(); p:SetPoint("CENTER", f, "TOPLEFT", px, -py)
      p.tex:SetTexture(m.icon or self:Icon("user", 32)); p.tex:SetVertexColor(1, 1, 1, 1); p:SetAlpha(1)
      p.name, p.note, p.pin = m.name, nil, nil; p.entry = { name = m.name }; p.cx, p.cy, p.r = px, -py, s / 2; p:Show() end end
  if self:O("routes") then   -- travel routes: both ends must place on the stitched view
    local nodes = self.NODES or {}; local fac = UnitFactionGroup and UnitFactionGroup("player"); fac = fac and fac:sub(1, 1)
    if self:CatOn("world", "flight") and self:O("routeFlight") then for _, t in ipairs(self.TAXI or {}) do local a, b = nodes[t[1]], nodes[t[2]]
      if a and b and (a.f == "N" or a.f == fac) and (b.f == "N" or b.f == fac) then
        local x1, y1 = P(a.z, a.x / 100, a.y / 100); local x2, y2 = P(b.z, b.x / 100, b.y / 100)
        if x1 and x2 then i = line(i, x1, y1, x2, y2, "flight", not (self:KnowsTaxi(a.id) and self:KnowsTaxi(b.id)) and 0.3 or nil, unit) end end end end
    for _, l in ipairs(self.LINKS or {}) do
      local opt = (l.k == "ship" and "routeShip") or (l.k == "zeppelin" and "routeZeppelin") or "routeTram"
      if (l.f == "N" or l.f == fac) and self:O(opt) and self:CatOn("world", l.k == "tram" and "portal" or l.k) then
        local x1, y1 = P(l.a[1], l.a[2] / 100, l.a[3] / 100); local x2, y2 = P(l.b[1], l.b[2] / 100, l.b[3] / 100)
        if x1 and x2 then i = line(i, x1, y1, x2, y2, l.k, nil, unit) end end end
  end
  local prevx, prevy   -- the planned trip: every leg, across zones (the stitched view shows them all)
  for _, l in ipairs(self.map.trip or {}) do
    local x, y; if l.x and l.y then x, y = P(l.z, l.x / 100, l.y / 100) end
    if x then if prevx then i = line(i, prevx, prevy, x, y, l.kind == "walk" and "user" or l.kind, nil, unit) end; prevx, prevy = x, y else prevx = nil end
  end
  for k = n + 1, #OM.pins do OM.pins[k]:Hide() end
  for k = i, #OM.segs do OM.segs[k]:Hide() end
  OM.drawn = n; return n
end
local function redraw() if not OM.failed then local ok, err = pcall(CG.DrawOpenMap, CG); if not ok then fail("draw", err) end end end
-- callbacks: OpenMap tells us when its view moves or it switches between its map and Blizzard's
function CG:HookOpenMap()
  if OM.registered then return true end
  local A = api(); if not (A and type(A.RegisterCallback) == "function") then return false end
  local ok, err = pcall(A.RegisterCallback, OM, "OpenMap_StitchedChanged", function() OM.drawnVersion, OM.host = nil, nil; redraw() end)
  if ok then ok, err = pcall(A.RegisterCallback, OM, "OpenMap_ViewChanged", function() redraw() end) end
  if not ok then fail("RegisterCallback", err); return false end
  OM.registered = true; return true
end
C:On("PLAYER_LOGIN", function() if CG:OpenMapPresent() then CG:HookOpenMap() end end)
