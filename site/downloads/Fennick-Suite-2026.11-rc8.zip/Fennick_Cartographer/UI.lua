local TR = (Fennick_BEAST and Fennick_BEAST.L) or setmetatable({ F = function(_, f, ...) local ok, s = pcall(string.format, f, ...); return ok and s or f end }, { __index = function(_, k) return k end })   -- l10n (Core C.L)
if not (Fennick_BEAST and (Fennick_BEAST.API or 1) >= 3) then return end   -- file-top guard
-- Panels: icon filters (per map), the pin editor with the icon picker grid, the trip panel and the copy-only share box.
local C = Fennick_BEAST
local CG = Fennick_CARTOGRAPHER; if not CG then return end
local W8 = "Interface\\Buttons\\WHITE8X8"
local function col(k, a) local c = CG.COL[k]; return c[1], c[2], c[3], a or 1 end
-- Core's shared panel (C:Panel, Core 1.6); only our own name prefix is ever passed
local function panel(name, w, h, title)
  if type(name) ~= "string" or not name:find("^Fennick_Cartographer") then name = nil end
  return C:Panel(name, w, h, title)
end
local function row(parent, i, y)
  local r = CreateFrame("Button", nil, parent); r:SetSize(300, 18); r:SetPoint("TOPLEFT", 10, y)
  r.icon = r:CreateTexture(nil, "OVERLAY"); r.icon:SetSize(16, 16); r.icon:SetPoint("LEFT", 0, 0)
  r.t = C:NewFS(r, "OVERLAY"); r.t:SetPoint("LEFT", r.icon, "RIGHT", 6, 0); r.t:SetTextColor(col("cream"))
  return r
end
-- icon filters (Questie-style): every category with its icon; world map and minimap each keep their own choice
function CG:FilterRows(which)
  local f = self:Filters(which); local rows = {}
  local function onoff(v) return v and C:OnOff(true) or C:OnOff(false) end
  rows[#rows + 1] = { TR:F("Show all icons %s", onoff(f.all ~= false)), function() CG:ShowAll(which, f.all == false) end }
  rows[#rows + 1] = { TR:F("Hide completed quests %s", onoff(f.hideDone)), function() CG:SetMapOpt(which, "hideDone", not f.hideDone) end }
  rows[#rows + 1] = { TR:F("Hide low-level quests %s", onoff(f.hideLow)), function() CG:SetMapOpt(which, "hideLow", not f.hideLow) end }
  rows[#rows + 1] = { TR:F("Icon size: %d%%", math.floor((f.scale or 1) * 100 + 0.5)), function() local s = (f.scale or 1) + 0.25; if s > 2 then s = 0.5 end; CG:SetMapOpt(which, "scale", s) end }
  if which == "mini" then rows[#rows + 1] = { TR:F("Minimap distance limit: %d yards", f.dist or 400), function() local d = (f.dist or 400) + 200; if d > 1200 then d = 200 end; CG:SetMapOpt("mini", "dist", d) end } end
  rows[#rows + 1] = { TR:F("Save filters for all characters %s", onoff(self:AccountWide())), function() CG:SetAccountWide(not CG:AccountWide()) end }
  -- tree (suite UX plan 2.2): the 15 map categories first; Trailmarks' six types sit under one "Trailmarks finds" fold and
  -- the specific ores/herbs under their type, all folded by default. A search (any part, any case) lists every match.
  local entries = self:FilterEntries(); local kids = {}
  local function up(e) return e.parent or (e.key:find("^tm_") and "tm") or nil end
  for _, e in ipairs(entries) do local pa = up(e); if pa then kids[pa] = (kids[pa] or 0) + 1 end end
  local q = type(self.filterQuery) == "string" and self.filterQuery:lower() or ""
  self.filterOpen = self.filterOpen or {}
  local open = self.filterOpen
  local function foldRow(key, depth, label)
    rows[#rows + 1] = { (depth and "   " or "") .. (open[key] and TR["   - fold"] or TR:F("   + %s (%d)", label, kids[key])), function() CG.filterOpen[key] = not CG.filterOpen[key] end, nil, fold = key }
  end
  local tmFold = false
  for _, e in ipairs(entries) do
    local key, pa = e.key, up(e)
    if q == "" and pa == "tm" and not tmFold then tmFold = true; foldRow("tm", nil, TR["Trailmarks finds"]) end
    local visible
    if q ~= "" then visible = (e.label or ""):lower():find(q, 1, true) ~= nil
    else visible = not pa or (open[pa] and (pa == "tm" or open.tm)) end
    if visible then
      local indent = (q == "" and pa) and ((pa == "tm") and "   " or "      ") or ""
      rows[#rows + 1] = { TR:F("%s%s %s", indent, e.label or "", onoff(self:CatRaw(which, key))), function() CG:SetCat(which, key, not CG:CatRaw(which, key)) end, e.icon, key = key }
      if q == "" and kids[key] then foldRow(key, true, TR["specific types"]) end
    end
  end
  return rows
end
function CG:ToggleFilters(which)
  local p = self.filterPanel or panel("Fennick_CartographerFilters", 330, 470, TR["Filter icons"]); self.filterPanel = p
  if p:IsShown() and p.which == which then p:Hide(); return p end
  p.which = which or "world"
  if type(p.rows) ~= "table" then
    p.tabW = CG.button(p, "W", TR["World map"], function() p.which = "world"; CG:FillFilters() end); p.tabW:SetPoint("TOPLEFT", 8, -6)
    p.tabM = CG.button(p, "M", TR["Minimap"], function() p.which = "mini"; CG:FillFilters() end); p.tabM:SetPoint("LEFT", p.tabW, "RIGHT", 4, 0)
    -- search box: filters the list by name as you type (local only; nothing is imported)
    p.search = CreateFrame("EditBox", nil, p); p.search:SetSize(310, 18); p.search:SetPoint("TOPLEFT", 10, -30); p.search:SetAutoFocus(false)
    if p.search.SetFontObject then p.search:SetFontObject(C:FontObj("GameFontHighlightSmall") or "GameFontHighlightSmall") end
    p.search.bg = p.search:CreateTexture(nil, "BACKGROUND"); p.search.bg:SetTexture(W8); p.search.bg:SetVertexColor(col("teal", 0.8)); p.search.bg:SetAllPoints(p.search)
    p.search.hint = C:NewFS(p.search, "OVERLAY"); p.search.hint:SetPoint("LEFT", 4, 0); p.search.hint:SetText(TR["Search"]); p.search.hint:SetTextColor(col("cream", 0.5))
    p.search:SetScript("OnTextChanged", function(s2) CG.filterQuery = s2:GetText() or ""; if CG.filterQuery == "" then s2.hint:Show() else s2.hint:Hide() end; CG:FillFilters() end)
    p.search:SetScript("OnEscapePressed", function(s2) s2:ClearFocus() end)
    p.scroll = CreateFrame("ScrollFrame", nil, p); p.scroll:SetPoint("TOPLEFT", 0, -54); p.scroll:SetPoint("BOTTOMRIGHT", 0, 8)
    p.body = CreateFrame("Frame", nil, p.scroll); p.body:SetSize(320, 10); p.scroll:SetScrollChild(p.body); p.scroll:EnableMouseWheel(true)
    p.scroll:SetScript("OnMouseWheel", function(s, d) local v = (s:GetVerticalScroll() or 0) - d * 36; s:SetVerticalScroll(math.max(0, v)) end)
    p.rows = {}
  end
  p:Show(); self:FillFilters(); return p
end
function CG:FillFilters()
  local p = self.filterPanel; if not (p and p:IsShown()) then return end
  p.title:SetText(p.which == "mini" and TR["Filter icons: minimap"] or TR["Filter icons: world map"])
  local rows = self:FilterRows(p.which)
  for i, r in ipairs(rows) do
    local b = p.rows[i] or row(p.body, i, -(i - 1) * 20); p.rows[i] = b
    b.t:SetText(r[1]); b.icon:SetTexture(r[3]); if r[3] then b.icon:Show() else b.icon:Hide() end
    b:SetScript("OnClick", function() r[2](); CG:FillFilters() end); b:Show()
  end
  for i = #rows + 1, #p.rows do p.rows[i]:Hide() end
  p.body:SetHeight(#rows * 20); return #rows
end
-- pin editor: name, note, icon (picker grid of every pin and module icon); edit and delete saved pins
function CG:PinEditor(index, map, x, y)
  local p = self.editor
  if not p then
    p = panel("Fennick_CartographerPin", 360, 330, TR["Map pin"]); self.editor = p
    local function box(label, yoff)
      local l = C:NewFS(p, "OVERLAY"); l:SetPoint("TOPLEFT", 12, yoff); l:SetText(label); l:SetTextColor(col("cream", 0.8))
      local e = CreateFrame("EditBox", nil, p); e:SetSize(240, 18); e:SetPoint("TOPLEFT", 100, yoff + 2); e:SetAutoFocus(false)
      if e.SetFontObject then e:SetFontObject(C:FontObj("GameFontHighlight") or "GameFontHighlight") end
      e.bg = e:CreateTexture(nil, "BACKGROUND"); e.bg:SetTexture(W8); e.bg:SetVertexColor(col("teal", 0.8)); e.bg:SetAllPoints(e)
      e:SetScript("OnEscapePressed", function(s) s:ClearFocus() end); return e
    end
    p.name = box(TR["Name"], -32); p.note = box(TR["Note"], -56)
    p.grid = {}
    local list = self:IconList()
    for i, e in ipairs(list) do
      local b = CreateFrame("Button", nil, p); b:SetSize(24, 24); b:SetPoint("TOPLEFT", 12 + ((i - 1) % 12) * 28, -84 - math.floor((i - 1) / 12) * 28)
      b.t = b:CreateTexture(nil, "ARTWORK"); b.t:SetAllPoints(b); b.t:SetTexture(e.path)
      b.sel = b:CreateTexture(nil, "OVERLAY"); b.sel:SetTexture(W8); b.sel:SetVertexColor(col("amber", 0.35)); b.sel:SetAllPoints(b); b.sel:Hide()
      b.key = e.key; b:SetScript("OnClick", function() p.icon = e.key; CG:PickerMark() end); p.grid[i] = b
    end
    p.save = CG.button(p, "OK", TR["Save pin"], function() CG:SaveEditor() end); p.save:SetSize(60, 18); p.save:SetPoint("BOTTOMRIGHT", -10, 10)
    p.del = CG.button(p, "Del", TR["Delete pin"], function() if p.index then CG:DeletePin(p.index) end; p:Hide() end); p.del:SetSize(60, 18); p.del:SetPoint("RIGHT", p.save, "LEFT", -8, 0)
  end
  local pin = index and self:DB().pins[index]
  p.index, p.map, p.x, p.y = index, pin and pin.map or map, pin and pin.x or x, pin and pin.y or y
  p.name:SetText(pin and pin.name or ""); p.note:SetText(pin and pin.note or ""); p.icon = pin and pin.icon or "user"
  if index then p.del:Show() else p.del:Hide() end
  self:PickerMark(); p:Show(); return p
end
function CG:PickerMark() local p = self.editor; for _, b in ipairs(p.grid) do if b.key == p.icon then b.sel:Show() else b.sel:Hide() end end end
function CG:SaveEditor()
  local p = self.editor; if not p then return nil end
  local r
  if p.index then r = self:EditPin(p.index, p.name:GetText(), p.note:GetText(), p.icon) and p.index
  elseif p.map and p.x then r = self:AddPin(p.map, p.x, p.y, p.name:GetText(), p.note:GetText(), p.icon) end
  p:Hide(); return r
end
-- trip panel ("how do I get there")
function CG:ShowRoutePanel()
  local p = self.routePanel or panel("Fennick_CartographerRoute", 380, 200, TR["How do I get there?"]); self.routePanel = p
  if type(p.lines) ~= "table" then p.lines = {} end
  local lines = (self.map.tripLines and #self.map.tripLines > 0) and self.map.tripLines or { TR["Shift-click a spot on the Cartographer map to plan a trip with flight paths, ships, zeppelins and the tram."] }
  for i, l in ipairs(lines) do
    local t = p.lines[i] or C:NewFS(p, "OVERLAY"); p.lines[i] = t; t:SetPoint("TOPLEFT", 12, -28 - (i - 1) * 18); t:SetWidth(356); t:SetJustifyH("LEFT"); t:SetText(TR:F("%d. %s", i, l)); t:SetTextColor(col("cream")); t:Show()
  end
  for i = #lines + 1, #p.lines do p.lines[i]:Hide() end
  p:SetHeight(40 + #lines * 18); p:Show(); return p, lines
end
-- copy-only share box for saved pins (no import anywhere)
function CG:ShowShare()
  -- Core's one copy box (Report.lua C:CopyBox): read-only, pre-selected, typing resets, Escape closes
  local text, count = self:ShareText()
  local p = C:CopyBox(TR["Share my pins (copy text)"], text); p.count = count; self.share = p; return p
end
