local TR = (Fennick_BEAST and Fennick_BEAST.L) or setmetatable({ F = function(_, f, ...) local ok, s = pcall(string.format, f, ...); return ok and s or f end }, { __index = function(_, k) return k end })   -- l10n (Core C.L)
if not Fennick_GUIDE_ENGINE then return end   -- P1-1: Core.lua refused to load (Beast Core too old)
-- v4.1 XP boost prompts: one line in Guidance, out of combat, no sound; never uses anything and never says to buy or cook.
--   Well Fed XP Boost (+5% kill XP, ~15 min): before a kill-heavy hunt when it is missing or under 3 min and you carry XP food
--   Archmagister's Wisdom (+10% XP from Undead, 5 min, 6 h cooldown): before an Undead hunt when owned and ready
--   Cozy Sleeping Bag (+1% XP per minute in it, 3 stacks, 2 h): at breaks, or before a kill-heavy hunt when the buff is low
-- Never on turn-in legs, travel, Hardcore danger (escape active / contested zone) or with an elite or boss targeted.
local E = Fennick_GUIDE_ENGINE
local C = Fennick_BEAST
E.XPFOOD = E.XPFOOD or {}
E.BOOST = { food = 1243969, arch = 1292997, archItem = 273049, bag = 211527, bagBuff = 429959 }
function E:XPFoodInBags()
  local lvl = UnitLevel and UnitLevel("player") or 1
  for id, v in pairs(self.XPFOOD) do
    local name, req = type(v) == "table" and v[1] or v, type(v) == "table" and v[2] or 0
    if (req or 0) <= lvl and C:ItemCount(id) > 0 then return name end
  end
end
function E:IsUndeadHunt(s)
  if s.ud then return true end
  local n = s.mob and s.mob:gsub("^%+", ""); local u = self.db.undead; if not (n and u) then return false end
  if u[n] then return true end
  for _, id in ipairs(self.NPCID and self.NPCID[n] or {}) do if u["#" .. id] then return true end end
  return false
end
function E:BoostQuiet(s)
  if not s or not self:O("boostTips") then return true end
  if C:InCombat() or (UnitAffectingCombat and UnitAffectingCombat("player")) then return true end
  if UnitExists and UnitExists("target") then local cl = UnitClassification and UnitClassification("target"); if cl == "elite" or cl == "rareelite" or cl == "worldboss" then return true end end
  if s.fly or s.hs or s.home or (s.t and not s.c and not s.mob) or (s.a and not s.c and not s.mob) or self:IsPureTravel(s) then return true end
  if self.escapeActive then return true end
  if self.db.rules == "HC" and s.z and self.CONTESTED and self.CONTESTED[s.z] then return true end
  return false
end
function E:BoostTips(s)
  local out = {}
  if self:BoostQuiet(s) then return out end
  local B = self.BOOST
  if s.kh then
    local left = C:AuraLeft(B.food)
    if not left or left < 180 then local f = self:XPFoodInBags(); if f then out[#out + 1] = TR:F("Eat %s before this hunt: +5%% kill XP while Well Fed.", f) end end
    if self:IsUndeadHunt(s) and C:ItemCount(B.archItem) > 0 and (C:ItemCooldown(B.archItem) or 1) == 0 and not C:AuraLeft(B.arch) then
      out[#out + 1] = TR["Use Archmagister's Wisdom before this Undead hunt: +10% XP for 5 min."] end
  end
  -- Cozy Sleeping Bag: Rest owns the reminder (one notification, Rest 1.2.1); Guidepost never shows it
  return out
end
local baseTips = E.ExtraTips
function E:ExtraTips(s)
  local out = baseTips and baseTips(self, s) or {}
  local ok, b = pcall(self.BoostTips, self, s)
  if ok then for _, l in ipairs(b) do out[#out + 1] = l end end
  return out
end
-- learn real creature types: targets that are Undead mark their name (so later hunts on them get the Undead line)
local f = CreateFrame("Frame"); f:RegisterEvent("PLAYER_TARGET_CHANGED")
f:SetScript("OnEvent", function()
  if not E.db or not (UnitExists and UnitExists("target")) then return end
  local ok, ty = pcall(UnitCreatureType, "target")
  -- P2-20: UnitCreatureType is localized, so compare against the client's own "Undead" family name when available
  local undeadName = (C_CreatureInfo and C_CreatureInfo.GetCreatureTypeInfo and (C_CreatureInfo.GetCreatureTypeInfo(6) or {}).name) or "Undead"
  if ok and (ty == undeadName or ty == "Undead") then local n, id = UnitName("target"), E.CreatureId and E:CreatureId("target"); E.db.undead = E.db.undead or {}
    if id then E.db.undead["#" .. id] = true elseif n then E.db.undead[n] = true end end   -- l10n: by creature ID
end)
if C_Timer and C_Timer.NewTicker then C_Timer.NewTicker(2, function()
  local still = GetUnitSpeed and GetUnitSpeed("player") == 0 and not C:InCombat()
  if still then E.idleSince = E.idleSince or GetTime() else E.idleSince = nil end
end) end
