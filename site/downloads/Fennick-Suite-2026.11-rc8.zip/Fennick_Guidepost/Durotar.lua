-- The source outline interleaves class-specific copies of the Razor Hill chain
-- and offers its last quest first. Keep unrelated actions in their authored order.
local E = Fennick_GUIDE_ENGINE
if not E then return end
local chain = {[99048]=true,[99049]=true,[99051]=true,[99052]=true}
local stop = {z=1411,x=52.2,y=43.1,npc="Orgnil Soulscar"}
local function orgnil(t,a,normal)
  return {t=t,a=a,z=stop.z,x=stop.x,y=stop.y,npc=stop.npc,pl=8.7,
    rules=normal and {"Normal","PvE"} or nil}
end
local sequence = {
  orgnil(nil,{99048}),
  {z=1411,x=58.6,y=45.6,npc="Heglan Shadeeye",t={99048},a={99049},pl=8.7},
  {z=1411,x=58.84,y=44.36,c={{99049,1}},pl=8.7},
  {z=1411,x=60.06,y=42.39,c={{99049,2}},pl=8.7},
  {z=1411,x=60.11,y=44.80,c={{99049,3}},pl=8.7},
  orgnil({99049},{99051}),
  {z=1411,x=58.99,y=26.22,c={{99051,1}},mob="Spitelash Scout",pl=8.7},
  orgnil({99051},nil), orgnil(nil,{99052},true),
  {z=1411,x=59.22,y=17.60,c={{99052,1}},mob="Aggor the Young",rules={"PvE"},pl=8.7},
  orgnil({99052},nil,true),
}
function E:RouteSteps(g)
  if g.src ~= "TrollWLD-Horde-01-12_Durotar.lua" or g.hi < 10 then return g.steps end
  local out, inserted, coast = {}, false, false
  for _, s in ipairs(g.steps) do
    -- Leave Razor Hill with the breadcrumb and visit the hut before diving for the tools.
    -- Keep a second opportunity on the return circuit for players still below level eight.
    if g.name == "6-10 Durotar" and not coast and s.c and s.c[1][1] == 825 then
      for i=1,5 do
        local copy = {}
        for k,v in pairs(sequence[i]) do copy[k]=v end
        copy.pl,copy.crit = s.pl,"chain"
        out[#out+1]=copy
      end
      coast=true
    end
    if g.name == "6-10 Durotar" and not inserted and (s.pl or 0) >= 8.7 then
      for _, row in ipairs(sequence) do out[#out+1] = row end
      inserted = true
    end
    local hit, keep = false, {}
    for _, stage in ipairs({"t","a","c"}) do
      for _, v in ipairs(s[stage] or {}) do
        if chain[stage=="c" and v[1] or v] then hit=true
        else keep[stage]=keep[stage] or {}; table.insert(keep[stage],v) end
      end
    end
    if not hit then out[#out+1] = s
    elseif keep.t or keep.a or keep.c or s.act or s.tr then
      local copy = {}; for k,v in pairs(s) do copy[k]=v end
      copy.t,copy.a,copy.c = keep.t,keep.a,keep.c
      out[#out+1] = copy
    end
  end
  return out
end
