local E = Fennick_GUIDE_ENGINE
if not E then return end

local labels = {}
for id, quest in pairs(E.FieldQuests) do labels[id] = quest[1] end
E:RegisterQuestNames(labels)

local function fieldStep(id, stage, point, index)
  local step = {id="field-"..id.."-"..stage..(index or ""), z=point[1], x=point[2], y=point[3]}
  if stage == "c" then
    step.c = {{id, index}}
    step.n = point[4]
    step.fieldTarget = point[4]
  else
    step[stage] = {id}
    step.npc = point[4]
  end
  return step
end

local function appendBatch(out, ids)
  for _, id in ipairs(ids) do
    out[#out+1] = fieldStep(id, "a", E.FieldQuests[id][5])
  end
  for _, id in ipairs(ids) do
    for index, point in ipairs(E.FieldQuests[id][6]) do
      out[#out+1] = fieldStep(id, "c", point, index)
    end
  end
  for _, id in ipairs(ids) do
    out[#out+1] = fieldStep(id, "t", E.FieldQuests[id][7])
  end
end

function E:FieldChapter(g, steps, rules)
  if rules ~= "Normal" or (g.lo == 1 and g.src ~= "hub:Elwynn" and g.src ~= "hub:Teldrassil") then return steps end
  local batches = self.FieldChapters[g.faction..g.lo] or self.FieldChapters["Both"..g.lo]
  if not batches then return steps end
  local out, used = {}, {}
  for _, hub in ipairs(steps) do
    if hub.hub then
      for i, ids in ipairs(batches) do
        local quest = self.FieldQuests[ids[1]]
        local p = quest[5]
        -- Shadowglen's legacy outline also contains an Elwynn fallback hub.
        if not used[i] and (g.lo ~= 1 or hub.z == steps[1].z)
            and (quest[3] == "" or quest[3] == g.faction:sub(1,1))
            and hub.z == p[1] and (hub.x-p[2])^2 + (hub.y-p[3])^2 <= 36 then
          local first = #out + 1
          appendBatch(out, ids)
          for j=first,#out do out[j].pl = hub.pl end
          used[i] = true
        end
      end
    end
    out[#out+1] = hub
  end
  return out
end

function E:FieldEligible(id)
  local q = self.FieldQuests[id]
  if not q then return true end
  if UnitLevel("player") < q[2] then return false end
  for _, pre in ipairs(q[4]) do
    if self.questLogReady and not self.IsQuestDone(pre) then return false end
  end
  return true
end

-- Live objectives can appear in a different order from the catalog. Match the
-- current log when its localized text contains the target; otherwise keep its index.
function E:FieldObjectiveIndex(step, rows)
  local c = step.c[1]
  rows = rows or (C_QuestLog and C_QuestLog.GetQuestObjectives and C_QuestLog.GetQuestObjectives(c[1]))
  for i, row in ipairs(rows or {}) do
    if type(row.text) == "string" and row.text:find(step.fieldTarget, 1, true) then return i end
  end
  return c[2]
end

local regionCache = {}
function E:RegionalStep(key)
  local region = self.FieldRegions[key]
  if not region or self.db.rules ~= "Normal" then return end
  local level = UnitLevel("player")
  if level < (key == "riverglades" and 36 or 54) or level >= 60 then return end
  if key == "hyjal-group" and (not GetNumGroupMembers or GetNumGroupMembers() < 2) then return end
  local side = UnitFactionGroup("player")
  local batches = region[side] or region.Both
  if not batches then return end
  local cacheKey = key..side
  if not regionCache[cacheKey] then
    local list = {}
    for _, ids in ipairs(batches) do appendBatch(list, ids) end
    regionCache[cacheKey] = list
  end
  for _, s in ipairs(regionCache[cacheKey]) do
    local id = s.a and s.a[1] or s.t and s.t[1] or s.c[1][1]
    if not (self.db.regionSkipped and self.db.regionSkipped[id]) and (s.a or self.IsOnQuest(id)) and self:QuestAvailable(id) and not self:StepDone(s) then
      local copy = {}
      for k,v in pairs(s) do copy[k] = v end
      copy.gen, copy.normalTrip = true, key
      return copy
    end
  end
end

function E:SkipRegion(step)
  local id = step.a and step.a[1] or step.t and step.t[1] or step.c[1][1]
  self.db.regionSkipped = self.db.regionSkipped or {}
  self.db.regionSkipped[id] = true
  self:Advance()
end

function E:ChooseRegion(key)
  if key == "stop" then self:ChooseTrip("stop"); return end
  if self.FieldRegions[key] then self.db.regionSkipped = nil end
  if self.FieldRegions[key] and self.questLogReady and self:RegionalStep(key) then
    if key == "riverglades" then
      self:Print("Reach Riverglades by road from northern Redridge or southern Badlands, or sail from Steamwheedle Port in Tanaris to Powderfuse Port.")
    else
      self:Print("Reach Mount Hyjal through Darkwhisper Gorge in southern Winterspring.")
    end
    self.db.normalTrip = key
    self:Advance()
  else
    self:Print("Normal regional routes: /fennick lvl region riverglades (36+) or hyjal (54+). Grouped Horde can choose hyjal-group (54+). Completed or unavailable routes are skipped.")
  end
end
