local TR = (Fennick_BEAST and Fennick_BEAST.L) or setmetatable({ F = function(_, f, ...) local ok, s = pcall(string.format, f, ...); return ok and s or f end }, { __index = function(_, k) return k end })   -- l10n (Core C.L)
if not Fennick_GUIDE_ENGINE then return end   -- P1-1: Core.lua refused to load (Beast Core too old)
-- v3.10 Forever extras: loot-started quests ("along the way" on a hunt) and their optional turn-ins.
--   loot step  {loot={itemID, questID}, cwid=hunt}: done once the quest is in the log or finished, or when its hunt is done.
--   turn-in    {t={questID}, optq=questID}: only matters when you actually got the quest; otherwise it is skipped.
-- Item detection: BAG_UPDATE_DELAYED / CHAT_MSG_LOOT -> a one-line tip "Right-click X to start Y" (no sound).
local E = Fennick_GUIDE_ENGINE
E.LOOTQ = E.LOOTQ or {}
local function have(item) local n = (C_Item and C_Item.GetItemCount and C_Item.GetItemCount(item)) or (GetItemCount and GetItemCount(item)) or 0; return n > 0 end
local function got(q) return E:OnQuest1(E.LiveId and E:LiveId(q) or q) or E:Done1(q) end
E.LootHave, E.LootGot = have, got

local baseInfo = E.IsInfo
function E:IsInfo(s) if s and (s.loot or s.optq) then return false end return baseInfo(self, s) end

local baseDone = E.StepDone
function E:StepDone(s)
  if s and s.manualDone then return true end
  if s and s.loot then
    local q = s.loot[2]
    if got(q) then return true end
    if s.cwid and not s._cwIn then local t = self:CwTarget(s); if t and t ~= s then s._cwIn = true; local ok, d = pcall(self.StepDone, self, t); s._cwIn = nil; if ok and d then return true end end end
    return false
  end
  if s and s.optq and self.questLogReady and not got(s.optq) then return true end   -- never found the item: nothing to turn in
  return baseDone(self, s)
end

local baseMissed = E.MissedCheck
function E:MissedCheck(...)
  local _, s = self:Current(); if s and (s.optq or s.loot) then return end   -- optional quests are never "missed"
  return baseMissed(self, ...)
end

-- items in your bags that start a guide quest you don't have yet
function E:LootPending()
  local out = {}
  for item, v in pairs(self.LOOTQ or {}) do
    if have(item) and not got(v.q) and (not self.QuestAvailable or self:QuestAvailable(v.q)) then out[#out + 1] = v end
  end
  table.sort(out, function(a, b) return a.q < b.q end)
  return out
end
local baseTips = E.ExtraTips
function E:ExtraTips(s)
  local out = baseTips and baseTips(self, s) or {}
  for _, v in ipairs(self:LootPending()) do out[#out + 1] = TR:F("Right-click %s to start %s", v.item, v.title) end
  return out
end

local told = {}
local f = CreateFrame("Frame")
E:Events(f, { "BAG_UPDATE_DELAYED", "QUEST_ACCEPTED" })   -- P1-10: no CHAT_MSG_LOOT; registered through E:Events
f:SetScript("OnEvent", function(_, ev)
  if E.disabled or E:InCombat() then return end   -- bags settle after combat; BAG_UPDATE_DELAYED fires again
  local ok, err = pcall(function()
    for _, v in ipairs(E:LootPending()) do
      if not told[v.q] then told[v.q] = true; E:Print(TR:F("You have %s: right-click it to start %s.", v.item, v.title)) end
    end
    E:Poke()
  end)
  if not ok and E.Debug then E:Debug("loot quest check: " .. tostring(err)) end
end)

-- a loot step points where its hunt points (same patrol loop)
local baseTP = E.TargetPoint
function E:TargetPoint(s)
  if s and s.loot and not s.z then local t = self.CwTarget and self:CwTarget(s); if t and t ~= s then return baseTP(self, t) end end
  return baseTP(self, s)
end

-- v3.11 library books: {book={itemID, questID}} loot step; {t={questID}, optbook=itemID} hand-in at the librarian.
-- The book step is done once the book is in your bags (or handed in); the hand-in is skipped when you have no book.
local function bookDone(s) local item, q = s.book[1], s.book[2]; return have(item) or E:Done1(q) or E:OnQuest1(q) end
local base2 = E.StepDone
function E:StepDone(s)
  if s and s.manualDone then return true end
  if s and s.book then return bookDone(s) end
  if s and s.optbook then
    local q = s.t and s.t[1]
    if q and self:Done1(q) then return true end
    if self.questLogReady and not have(s.optbook) and not (q and self:OnQuest1(q)) then return true end
    return false
  end
  return base2(self, s)
end
local baseInfo2 = E.IsInfo
function E:IsInfo(s) if s and (s.book or s.optbook) then return false end return baseInfo2(self, s) end
local baseMissed2 = E.MissedCheck
function E:MissedCheck(...)
  local _, s = self:Current(); if s and (s.optbook or s.book or s.fq and s.optq) then return end
  return baseMissed2(self, ...)
end

-- v4.0 cloth donations: {donate={questID, clothItemID, count, {prereqs}}} at a city cloth quartermaster.
-- Only shown when you carry the cloth and the earlier donations are done; never "missed", never farmed for.
local function count(item) return (C_Item and C_Item.GetItemCount and C_Item.GetItemCount(item)) or (GetItemCount and GetItemCount(item)) or 0 end
E.ClothCount = count
local base3 = E.StepDone
function E:StepDone(s)
  if s and s.manualDone then return true end
  if s and s.donate then
    local q, item, n, pre = s.donate[1], s.donate[2], s.donate[3], s.donate[4]
    if self:Done1(q) then return true end
    if not self.questLogReady then return false end
    if self:OnQuest1(q) then return false end
    if count(item) < n then return true end
    for _, p in ipairs(pre or {}) do if not self:Done1(p) then return true end end
    return false
  end
  return base3(self, s)
end
local baseInfo3 = E.IsInfo
function E:IsInfo(s) if s and s.donate then return false end return baseInfo3(self, s) end
local baseMissed3 = E.MissedCheck
function E:MissedCheck(...)
  local _, s = self:Current(); if s and s.donate then return end
  return baseMissed3(self, ...)
end
