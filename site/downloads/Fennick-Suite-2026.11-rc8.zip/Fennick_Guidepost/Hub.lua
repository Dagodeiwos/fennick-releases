local TR = (Fennick_BEAST and Fennick_BEAST.L) or setmetatable({ F = function(_, f, ...) local ok, s = pcall(string.format, f, ...); return ok and s or f end }, { __index = function(_, k) return k end })   -- l10n (Core C.L)
if not Fennick_GUIDE_ENGINE then return end   -- P1-1: Core.lua refused to load (Beast Core too old)
-- Hub steps: turn a quest-hub step into concrete steps at runtime from Questie (if installed).
-- Without Questie the hub stays a single manual step with a note (outline behaviour).
local E = Fennick_GUIDE_ENGINE
local indexedDB, zoneIndex
local function validCoord(v)
  return type(v) == "number" and v >= 0 and v <= 100
end

-- Compare each known NPC spawn in this area to the hub. A giver may roam
-- or have multiple spawn points, and the first listed giver can be elsewhere.
local function nearestGiver(db, quest, field, area, hub)
  local sources = E:QuestieCall(db.QueryQuestSingle, quest, field)
  local npcs = type(sources) == "table" and sources[1]
  local best
  for _, npc in ipairs(type(npcs) == "table" and npcs or {}) do
    local spawns = E:QuestieCall(db.QueryNPCSingle, npc, "spawns")
    local points = type(spawns) == "table" and spawns[area]
    for _, point in ipairs(type(points) == "table" and points or {}) do
      if type(point) == "table" and validCoord(point[1]) and validCoord(point[2]) then
        local x, y = point[1], point[2]
        local d = (x - hub.x)^2 + (y - hub.y)^2
        if not best or d < best.distance then best = {x=x, y=y, distance=d} end
      end
    end
  end
  if not best and E.ReviewedQuestPoint then
    local step = field == "finishedBy" and {t={quest}} or {a={quest}}
    local point = E:ReviewedQuestPoint(step)
    if point and point.z == hub.z then
      best = {x=point.x, y=point.y, distance=(point.x-hub.x)^2 + (point.y-hub.y)^2}
    end
  end
  return best
end

local function active(hub)
  local _, current = E:Current()
  return current == hub and not E.disabled
end

function E.HubIndexReady() return zoneIndex ~= nil end

local function freeQuestSlots()
  local countEntries = (C_QuestLog and C_QuestLog.GetNumQuestLogEntries) or GetNumQuestLogEntries
  if not countEntries then return 15 end
  local _, used = countEntries()
  local cap = C_QuestLog and C_QuestLog.GetMaxNumQuestsCanAccept and C_QuestLog.GetMaxNumQuestsCanAccept()
  cap = cap or MAX_QUESTLOG_QUESTS
  if type(used) ~= "number" or type(cap) ~= "number" then return 15 end
  return math.max(0, cap - used)
end

local function hubPreference(db, id, accepted, level, groupSize)
  local questLevel = E:QuestieCall(db.QueryQuestSingle, id, "questLevel")
  local tag = db.GetQuestTagInfo and E:QuestieCall(db.GetQuestTagInfo, id)
  local tags = db.questTagIds or {}
  if tag and tag == tags.PVP then return end
  if E.db.rules == "HC" then
    if type(questLevel) ~= "number" or questLevel <= 0 or questLevel > level then return end
    if tag == nil or (tag ~= 0 and tag ~= tags.CLASS) then return end
  end
  local dungeon = tag ~= nil and tag == tags.DUNGEON
  if tag and (tag == tags.RAID or tag == tags.RAID_10 or tag == tags.RAID_25) then return end
  if (dungeon or (tag and tag == tags.ELITE)) and groupSize <= 1 then return end
  local mode = dungeon and E:ContentMode("dungeon")
  if not accepted then
    if mode == "off" or type(questLevel) ~= "number" or questLevel > level + 3 then return end
    if E:QuestieCall(db.IsDoable, id) ~= true then return end
  end
  return mode == "force" or (E.IsForcedContent and E:IsForcedContent(E.QuestContent and E.QuestContent[id])) or false
end

local eligibilityRevision = 0
if Fennick_BEAST and Fennick_BEAST.On then
  for _, event in ipairs({"QUEST_ACCEPTED", "QUEST_TURNED_IN", "QUEST_REMOVED", "GROUP_ROSTER_UPDATE", "PLAYER_LEVEL_UP"}) do
    Fennick_BEAST:On(event, function() eligibilityRevision = eligibilityRevision + 1 end)
  end
end

function E:ExpandHub(hub)
  if hub.expanded or hub.pending or not active(hub) or self:InCombat() then return end
  local db = self:Questie()
  local area = self.AREA and self.AREA[hub.z]
  if not db or not area or not validCoord(hub.x) or not validCoord(hub.y) then return end
  if indexedDB ~= db then zoneIndex, indexedDB = nil, db end
  -- Older integrations without an eligibility check retain manual hub guidance.
  if type(db.IsDoable) ~= "function" then return end
  local pointers = db.QuestPointers or db.questData
  if not zoneIndex and (type(pointers) ~= "table" or not next(pointers)) then return end
  hub.pending = true
  local revision = eligibilityRevision
  local function resume(fn)
    C_Timer.After(0, function()
      if not active(hub) then hub.pending = nil; return end
      if E:InCombat() then
        E:Safe("hub", function() hub.pending = nil; if active(hub) then E:ExpandHub(hub) end end)
        return
      end
      if revision ~= eligibilityRevision or E:Questie() ~= db then hub.pending = nil; return end
      fn()
    end)
  end

  local list, cursor = {}, 1
  local function candidates()
    local ids = zoneIndex[area] or {}
    local level = UnitLevel("player")
    local groupSize = GetNumGroupMembers and GetNumGroupMembers() or 0
    for i = cursor, math.min(cursor + 31, #ids) do
      local id = ids[i]
      if not self:Done1(id) and self:QuestAvailable(id) then
        local accepted = self:OnQuest1(id)
        local forced = hubPreference(db, id, accepted, level, groupSize)
        if forced ~= nil then
          local target = nearestGiver(db, id, accepted and "finishedBy" or "startedBy", area, hub)
          if target then
            target.id, target.accepted = id, accepted == true
            target.ready = accepted and self:QuestComplete(id) or false
            target.forced = forced
            list[#list + 1] = target
          end
        end
      end
    end
    cursor = cursor + 32
    if cursor <= #ids then resume(candidates); return end
    table.sort(list, function(a, b)
      if a.ready ~= b.ready then return a.ready end
      if a.accepted ~= b.accepted then return a.accepted end
      if a.forced ~= b.forced then return a.forced end
      if a.distance ~= b.distance then return a.distance < b.distance end
      return a.id < b.id
    end)
    local g = self:Current()
    local add, objectives, turns = {}, {}, {}
    local slots = freeQuestSlots()
    for i = 1, math.min(15, #list) do
      local entry = list[i]
      local id = entry.id
      if entry.ready then
        add[#add+1] = {z=hub.z, x=entry.x, y=entry.y, t={id}, gen=true}
        slots = slots + 1
      else
        if not entry.accepted then
          if slots == 0 then break end
          slots = slots - 1
          add[#add+1] = {z=hub.z, x=entry.x, y=entry.y, a={id}, gen=true}
        end
        objectives[#objectives+1] = {hubObjective=id, c={{id,1}}, gen=true, n=TR:F("Hub loop: finish %s", self:QuestName(id))}
        local finish = entry.accepted and entry or nearestGiver(db, id, "finishedBy", area, hub)
        turns[#turns+1] = {z=finish and hub.z, x=finish and finish.x, y=finish and finish.y, t={id}, gen=true}
      end
    end
    for _, step in ipairs(objectives) do add[#add+1] = step end
    for _, step in ipairs(turns) do add[#add+1] = step end
    for i = #add, 1, -1 do table.insert(g.steps, self.db.step + 1, add[i]) end
    hub.emptyRevision = #add == 0 and revision or nil
    hub.pending, hub.expanded = nil, #add > 0
    self:Poke()
  end

  if zoneIndex then resume(candidates); return end
  local index, last = {}, nil
  local function build()
    for i = 1, 200 do
      last = next(pointers, last)
      if not last then zoneIndex = index; resume(candidates); return end
      if type(last) == "number" then
        local zone = self:QuestieCall(db.QueryQuestSingle, last, "zoneOrSort")
        if zone then
          index[zone] = index[zone] or {}
          table.insert(index[zone], last)
        end
      end
    end
    resume(build)
  end
  resume(build)
end

function E:HubDone(hub)
  if hub.expanded then return true end
  if hub.emptyRevision == eligibilityRevision then return UnitLevel("player") >= (hub.hi or 60) end
  local db = self:Questie()
  if db and type(db.IsDoable) == "function" and self.AREA and self.AREA[hub.z] and validCoord(hub.x) and validCoord(hub.y) then
    if not hub.pending and not self:InCombat() then
      local distance = self:Distance(hub)
      if distance and distance < 60 then self:ExpandHub(hub) end
    end
    if hub.pending then return false end
  end
  return UnitLevel("player") >= (hub.hi or 60)
end

-- Runtime gap fill: nearest-level hub for the faction (PvP/HC avoid contested zones).
function E:GapStep(target)
  local fac = UnitFactionGroup("player"); local L = UnitLevel("player"); local best
  for _, h in ipairs(self.HUBS[fac] or {}) do
    local lo, hi, name, z, x, y = h[1], h[2], h[3], h[4], h[5], h[6]
    if L >= lo and L < hi and not (self.db.rules == "HC" and self.CONTESTED[z]) then
      if not best or math.abs((lo + hi) / 2 - L) < math.abs((best[1] + best[2]) / 2 - L) then best = h end
    end
  end
  if not best then return nil end
  return { hub = 1, z = best[4], x = best[5], y = best[6], lo = best[1], hi = best[2], npc = best[3], gapfill = target,
    n = TR:F("Level gap: you are below %s. Quest at %s until %s.", target, best[3], target) }
end
