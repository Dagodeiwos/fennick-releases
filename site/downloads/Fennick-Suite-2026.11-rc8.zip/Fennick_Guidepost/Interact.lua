local TR = (Fennick_BEAST and Fennick_BEAST.L) or setmetatable({ F = function(_, f, ...) local ok, s = pcall(string.format, f, ...); return ok and s or f end }, { __index = function(_, k) return k end })   -- l10n (Core C.L)
if not Fennick_GUIDE_ENGINE then return end   -- P1-1: Core.lua refused to load (Beast Core too old)
-- Typed NPC interaction steps (vendor, trainer, flight path, hearth bind, bank, stable, talk, fly, hearth,
-- deathskip) and patrol/hotspot targets for hunt steps. Interaction steps complete only on the matching
-- interaction event or game state, never on arrival. Patrol points advance on proximity only; the hunt step
-- itself still completes only when its quest objectives are done.
local E = Fennick_GUIDE_ENGINE
local ACT_EVENTS = {
  MERCHANT_SHOW = "merchant", MERCHANT_CLOSED = "merchant_closed", TRAINER_SHOW = "trainer", TRAINER_CLOSED = "trainer_closed",
  TAXIMAP_OPENED = "taxi", HEARTHSTONE_BOUND = "bound", BANKFRAME_OPENED = "bank", PET_STABLE_SHOW = "stable",
  BAG_UPDATE_DELAYED = "bags", GOSSIP_SHOW = "talk", QUEST_GREETING = "talk", QUEST_DETAIL = "talk", PLAYER_UNGHOST = "alive", PLAYER_ALIVE = "alive",
}

local function key() local g = E:Current(); return g and (E:SkipKey(g, E.db.step)) end
function E:Met(s, what)
  if s.met and s.met[what] then return true end
  local _, cur = self:Current()
  return cur == s and self.db.met and self.db.met[(key() or "") .. ":" .. what] or false
end
local function mark(what)
  local g, s = E:Current(); if not s then return end
  s.met = s.met or {}; s.met[what] = true; s._key = key()
  E.db.met = E.db.met or {}; E.db.met[s._key .. ":" .. what] = true
end

-- l10n fix: GetBindLocation is in the client's language; s.home is English. Compare with the client's own zone/subzone
-- texts while you stand on the step's map (map ID), so it works on any client; the English name is only a fallback.
local function onStepMap(s)
  local m = C_Map and C_Map.GetBestMapForUnit and C_Map.GetBestMapForUnit("player")
  return not s.z or not m or m == s.z
end
local function bindMatches(s)
  local b = GetBindLocation and GetBindLocation(); if not (b and s.home) then return false end
  b = b:lower()
  if onStepMap(s) and E.AtBindLocation and E:AtBindLocation() then return true end
  local h = s.home:lower()
  return b == h or b:find(h, 1, true) ~= nil or h:find(b, 1, true) ~= nil
end
local function bought(s)  -- required items in bags (optional "if available" items do not block)
  local need = false
  for _, it in ipairs(s.buy or {}) do
    if it[4] == 0 and it[1] and it[1] > 0 then need = true; if (GetItemCount and GetItemCount(it[1]) or 0) < it[2] then return false, true end end
  end
  return true, need
end

-- nil: step has no interaction; true/false: interaction satisfied or not
function E:ActDone(s)
  local a = s.act or (s.hs and "hs") or (s.fly and "fly") or (s.home and "home"); if not a then return nil end
  -- vendor: done when the bags hold the required items, or after buying from this vendor (window opened, then closed),
  -- whichever comes first (before v3.8.3 a required item below the count blocked forever, e.g. 9 milk after a sip)
  if a == "vendor" then local ok, need = bought(s); if need and ok then return true end; return self:Met(s, "merchant_closed") and true or false
  elseif a == "trainer" then if self:TrainerCleared(s) then return true end; if s.tr then return IsSpellKnown(s.tr) and true or false end; return self:Met(s, "trainer_closed") and true or false
  elseif a == "fp" then return self:Met(s, "taxi") and true or false
  elseif a == "home" then return bindMatches(s) or (self:Met(s, "bound") and true or false)
  elseif a == "bank" then return self:Met(s, "bank") and true or false
  elseif a == "stable" then return self:Met(s, "stable") and true or false
  elseif a == "fly" then return self:Met(s, "flight") and true or false
  elseif a == "hs" then return self:Met(s, "hearth") and true or false
  elseif a == "deathskip" then return self:Met(s, "alive") and true or false
  elseif a == "talk" then return self:Met(s, "talk") and true or false end
  return false
end

local ACT_TEXT = {
  bank = function(s) return TR:F("Open your bank at %s", (s.npc or TR["the banker"])) end,
  stable = function(s) return TR:F("Stable your pet at %s", (s.npc or TR["the stable master"])) end,
  deathskip = function() return TR["Deathskip: die, release and resurrect at the spirit healer"] end,
  talk = function(s) return TR:F("Talk to %s", (s.npc or TR["the NPC"])) end,
  fp = function(s) return TR:F("Discover the %s flight path at %s", (s.fp or TR["local"]), (s.npc or TR["the flight master"])) end,
  home = function(s) return TR:F("Set your hearthstone at %s%s", (s.npc or TR["the innkeeper"]), (s.home and (TR:F(" in %s", s.home)) or "")) end,
  vendor = function(s)
    local req, opt = {}, {}
    for _, it in ipairs(s.buy or {}) do local n = it[3] or (GetItemInfo and it[1] > 0 and GetItemInfo(it[1])) or (TR:F("item %s", it[1]))
      if it[4] == 0 then req[#req + 1] = it[2] .. " " .. n else opt[#opt + 1] = n end end
    local who = s.npc or TR["the vendor"]
    if #req > 0 then local why = E:BuyWhy(s); return TR:F("Buy %s%s from %s", table.concat(req, ", "), (why and (" (" .. why .. ")") or ""), who) end
    if #opt > 0 then return TR:F("Visit %s: buy %s if available%s", who, table.concat(opt, ", "), (s.repair and TR[", repair"] or "")) end
    return TR:F("Visit %s: sell junk%s", who, (s.repair and TR[" and repair"] or ""))
  end,
  trainer = function(s) local sp = s.tr and GetSpellInfo and GetSpellInfo(s.tr)
    return TR:F("Train %s at %s", (sp or TR["your new spells"]), (s.npc or TR["your trainer"])) end,
}
-- one short reason for a buy step, from the item names (drink/food/ammo/bags)
function E:BuyWhy(s)
  local kinds, seen = {}, {}
  for _, it in ipairs(s.buy or {}) do local n = (it[3] or ""):lower(); local k
    -- P2-20: item class first (any client language); English names only as a fallback
    local info = (it[1] and GetItemInfoInstant) and { GetItemInfoInstant(it[1]) } or {}
    local cls, sub = info[6], info[7]
    if cls == 6 then k = "ammo" elseif cls == 1 or cls == 11 then k = TR["bag space"]
    elseif not E.EN_CLIENT then if cls == 0 and sub == 5 then k = TR["food or drink"] end   -- l10n fix: no name matching off English
    elseif n:find("water") or n:find("milk") or n:find("juice") or n:find("cider") or n:find("tea") or n:find("nectar") then k = TR["mana drink"]
    elseif n:find("arrow") or n:find("shot") or n:find("bullet") then k = "ammo"
    elseif n:find("bag") or n:find("pouch") or n:find("quiver") then k = TR["bag space"]
    elseif n:find("bread") or n:find("meat") or n:find("cheese") or n:find("apple") or n:find("melon") or n:find("fish") or n:find("mutton") or n:find("jerky") or n:find("ribs") or n:find("roll") or n:find("stew") or n:find("muffin") then k = "food" end
    if k and not seen[k] then seen[k] = true; kinds[#kinds + 1] = k end end
  return #kinds > 0 and table.concat(kinds, ", ") or nil
end
function E:ActText(s) s = self:Localized(s); local f = ACT_TEXT[s.act or (s.home and "home") or ""]; return f and f(s) or nil end

-- ---------- hunt targets: Questie spawn clusters at runtime, else the plan's hotspots ----------
local cache = {}
local function clusters(pts)
  local cells = {}
  for _, p in ipairs(pts) do local k = math.floor(p[1] / 6) .. ":" .. math.floor(p[2] / 6)
    local c = cells[k] or { n = 0, x = 0, y = 0 }; c.n = c.n + 1; c.x = c.x + p[1]; c.y = c.y + p[2]; cells[k] = c end
  local out = {}; for _, c in pairs(cells) do out[#out + 1] = { c.x / c.n, c.y / c.n, n = c.n } end
  table.sort(out, function(a, b) return a.n > b.n end)
  return out
end
function E:QuestieHotspots(s)
  if not s.c then return nil end
  local db = self:Questie(); if not db or not db.QueryNPCSingle then return nil end
  local zdb = self:QuestieModule("ZoneDB", { "GetUiMapIdByAreaId" }); if not zdb then return nil end
  local byMap = {}
  for _, c in ipairs(s.c) do
    local obj = self:QuestieCall(db.QueryQuestSingle, c[1], "objectives")
    local creatures = type(obj) == "table" and obj[1]
    for _, o in ipairs(type(creatures) == "table" and creatures or {}) do
      local spawns = self:QuestieCall(db.QueryNPCSingle, o[1], "spawns")
      for area, list in pairs(type(spawns) == "table" and spawns or {}) do
        local map = self:QuestieCall(zdb.GetUiMapIdByAreaId, zdb, area)
        if map then byMap[map] = byMap[map] or {}; for _, p in ipairs(list) do if p[1] and p[1] > 0 then table.insert(byMap[map], p) end end end
      end
    end
  end
  local best, bm; for m, l in pairs(byMap) do if not best or #l > #best or m == s.z then best, bm = l, m; if m == s.z then break end end end
  if not best or #best == 0 then return nil end
  local cl = clusters(best); local pts = {}
  for i = 1, math.min(4, #cl) do pts[i] = { cl[i][1], cl[i][2] } end
  return pts, bm
end
-- Fennick's Trailmarks (optional add-on): your own recorded quest-target finds for this hunt, when there are enough.
-- Never required; any error or missing add-on falls back to the plan/Questie data.
function E:TrailmarkHotspots(s)
  local TM = Fennick_TRAILMARKS; if not (TM and TM.HuntSpots) or self:InCombat() then return nil end
  local names, texts = {}, {}
  if type(s.mob) == "string" then names[1] = s.mob:gsub("^%+", "") end
  for _, c in ipairs(s.c or {}) do
    local ok, objs = pcall(C_QuestLog and C_QuestLog.GetQuestObjectives, c[1])
    local o = ok and type(objs)=="table" and objs[c[2]]
    if o and type(o.text)=="string" then texts[#texts+1]=o.text end
  end
  local ok, pts = pcall(TM.HuntSpots, TM, s.z, names, texts)
  return ok and pts or nil
end
-- Patrol = ONE continuous loop. Plan points are already a shortest closed tour (build: nearest-neighbour + 2-opt);
-- Questie clusters (only when the plan has none) get a nearest-neighbour loop here. Points closer than 2x the
-- radius are merged. The arrow flows point to point and loops; the step completes only on its objectives.
function E:SpacePoints(z, pts)
  local minyd = 2 * self:O("patrolRadius"); local out = {}
  for _, q in ipairs(pts) do local ok = true
    for _, k in ipairs(out) do local c1, a1, b1 = E.MapbWorld(z, q[1], q[2]); local c2, a2, b2 = E.MapbWorld(z, k[1], k[2])
      if c1 and c2 and math.sqrt((a1 - a2) ^ 2 + (b1 - b2) ^ 2) < minyd then ok = false; break end end
    if ok then out[#out + 1] = q end end
  return out
end
function E:Patrol(s)
  if s.specificObjective and not s.pts then return end
  local k = (self.StepSig and self.StepSig(s)) or tostring(s)
  if cache[k] == nil then
    local p
    local tm = not s.specificObjective and (s.c or s.mob) and s.z and self:TrailmarkHotspots(s)
    if tm then p = { z = s.z, pts = tm, src = "Trailmarks" }
    elseif s.pts then p = { z = s.z, pts = s.pts, src = "plan" }
    elseif not self:InCombat() then local pts, z = self:QuestieHotspots(s)
      if pts then local order, used, cur = { pts[1] }, { [1] = true }, pts[1]
        for _ = 2, #pts do local bi, bd
          for j, q in ipairs(pts) do if not used[j] then local d = (q[1] - cur[1]) ^ 2 + (q[2] - cur[2]) ^ 2; if not bd or d < bd then bi, bd = j, d end end end
          used[bi] = true; cur = pts[bi]; order[#order + 1] = cur end
        p = { z = z, pts = order, src = "Questie" } end
    else return nil end                               -- Questie is not called in combat; decide after combat
    if p then p.pts = self:SpacePoints(p.z, p.pts) end
    cache[k] = p or false
  end
  return cache[k] or nil, k
end
function E:PatrolState(k) self.db.pat = self.db.pat or {}; local st = self.db.pat[k]; if not st then st = { i = 1, dir = 1, hits = 0 }; self.db.pat[k] = st end; return st end
-- player and loop in the same world-yard frame (datamine zone bounds; parent-map climb for sub-maps)
function E:PlayerWorld()
  local pm, px, py = self:PlayerPos(); if not pm then return end
  while pm and not (self.MAPB and self.MAPB[pm]) do local info = C_Map.GetMapInfo and C_Map.GetMapInfo(pm); local up = info and info.parentMapID
    if not up or up == 0 then return end
    local p = C_Map.GetPlayerMapPosition(up, "player"); if not p then return end; pm, px, py = up, p.x * 100, p.y * 100 end
  return E.MapbWorld(pm, px, py)
end
local function segDist(px, py, ax, ay, bx, by)
  local dx, dy = bx - ax, by - ay; local l2 = dx * dx + dy * dy
  local t = l2 > 0 and math.max(0, math.min(1, ((px - ax) * dx + (py - ay) * dy) / l2)) or 0
  return math.sqrt((px - ax - t * dx) ^ 2 + (py - ay - t * dy) ^ 2)
end
-- where the player is relative to the loop: distances to every point and to the loop path
function E:PatrolGeo(p)
  local c, a, b = self:PlayerWorld(); if not c then return end
  local W, d = {}, {}
  for j, q in ipairs(p.pts) do local c2, a2, b2 = E.MapbWorld(p.z, q[1], q[2]); if c2 ~= c then return end; W[j] = { a2, b2 }; d[j] = math.sqrt((a - a2) ^ 2 + (b - b2) ^ 2) end
  local off = math.huge
  for j = 1, #W do local n = W[j % #W + 1]; off = math.min(off, segDist(a, b, W[j][1], W[j][2], n[1], n[2])) end
  return d, off
end
-- guide to the closest point, then continue in the direction whose next point is nearer
function E:PatrolResync(p, st, d, why)
  local n = #p.pts; local best = 1; for j = 2, n do if d[j] < d[best] then best = j end end
  local nx, pv = best % n + 1, (best - 2) % n + 1
  st.i, st.dir, st.hits, st.from = best, (d[pv] < d[nx]) and -1 or 1, 0, nil
  self:Debug(string.format("patrol resync (%s): closest point %d of %d, %.0f yd, dir %+d", why, best, n, d[best], st.dir))
  self:ResetWaypoint(); if self.Refresh then self:Refresh() end
end
-- arrow point for a step: the loop's current point, else the step coordinate. No counter text.
function E:TargetPoint(s)
  if s.fromBag then return end
  if s.hub and s.logPoint then return s.logPoint end
  local p, k; if s.c or s.mob then p, k = self:Patrol(s) end
  if p and #p.pts > 0 then
    local st = self:PatrolState(k); if st.i > #p.pts or st.i < 1 then st.i = 1 end
    local q = p.pts[st.i]; return { z = p.z, x = q[1], y = q[2], loop = #p.pts > 1 or nil }
  end
  if s.z and s.x and s.y then return { z = s.z, x = s.x, y = s.y } end
  if self.ReviewedQuestPoint then return self:ReviewedQuestPoint(s) end
end
-- Entry, reload, zone change, death/resurrect, branch/escape return: resync on the next tick.
function E:PatrolReenter(why) self.patActive = nil; self.patWhy = why end
-- 1 s tick: resync when needed or when straying > 2x radius off the loop; otherwise advance once per
-- arrival (2 in-radius samples, re-arm after leaving 1.25x radius), looping in the chosen direction.
function E:PatrolTick()
  local _, s = self:Current(); if not s or not (s.c or s.mob) then return end
  s = self:ActionView(s)
  local p, k = self:Patrol(s); if not (p and #p.pts > 1) then return end
  local st = self:PatrolState(k); local r = self:O("patrolRadius"); local n = #p.pts
  if st.i > n or st.i < 1 then st.i = 1 end
  local d, off = self:PatrolGeo(p); if not d then return end          -- no position: change nothing
  if self.patActive ~= k then self.patActive = k; return self:PatrolResync(p, st, d, self.patWhy or TR["enter step"]) end
  self.patWhy = nil
  if off > 2 * r then
    local best = 1; for j = 2, n do if d[j] < d[best] then best = j end end
    if not st.stray or best ~= st.i then st.stray = true; return self:PatrolResync(p, st, d, TR["strayed off the loop"]) end
    return
  end
  if st.stray then st.stray = nil end
  if st.from then if d[st.from] <= 1.25 * r then return end; st.from = nil end
  if d[st.i] < r then st.hits = (st.hits or 0) + 1 else st.hits = 0 end
  if st.hits >= 2 then
    st.hits = 0; st.from = st.i; st.i = (st.i - 1 + (st.dir or 1)) % n + 1
    self:Debug(string.format("patrol arrival at point %d (%.0f yd, r=%d) -> next %d", st.from, d[st.from], r, st.i))
    self:ResetWaypoint(); if self.Refresh then self:Refresh() end
  end
end

local f = CreateFrame("Frame")
-- Trainer services are filtered by the client. An empty initial list may still be loading.
local sawTrainerRows
function E:ReadTrainer(ev)
  if ev=="TRAINER_CLOSED" then sawTrainerRows=nil; return end
  if ev=="TRAINER_SHOW" then sawTrainerRows=nil end
  if not (GetTrainerServiceInfo and GetNumTrainerServices and GetTrainerServiceTypeFilter) then return end
  local filter=GetTrainerServiceTypeFilter("available")
  if filter~=true and filter~=1 then return end
  local count=GetNumTrainerServices() or 0
  local available,recognized=false,false
  for i=1,count do
    local _,second,third=GetTrainerServiceInfo(i)
    local status=third
    if second=="available" or second=="used" or second=="unavailable" then status=second end
    if status=="available" then available=true end
    if status=="used" or status=="available" or status=="unavailable" then recognized=true end
    if status=="header" and GetTrainerServiceInfo then
      -- Collapsed service headers can conceal available ranks.
      local expanded=select(4,GetTrainerServiceInfo(i))
      if not expanded or expanded==0 then return end
    end
  end
  if recognized then sawTrainerRows=true end
  if not recognized and not (count==0 and sawTrainerRows) then return end
  local lvl=UnitLevel("player")
  local _,step=self:Current()
  if step and step.npc and step.act=="trainer" and self:NpcIs("npc",step.npc)==true then
    self.db.trainerVisits=self.db.trainerVisits or {}
    self.db.trainerVisits[step.npc]=not available and lvl or nil
  end
  if IsTradeskillTrainer and not IsTradeskillTrainer() and IsTalentTrainer and IsTalentTrainer() then
    self.db.trainedClassLevel=not available and lvl or nil
  end
end
function E:TrainerCleared(s)
  return s.act=="trainer" and s.npc and self.db.trainerVisits and self.db.trainerVisits[s.npc]==UnitLevel("player")
end
local list = { "TRAINER_UPDATE", "UNIT_SPELLCAST_SUCCEEDED", "PLAYER_CONTROL_LOST", "ZONE_CHANGED_NEW_AREA", "UNIT_HEALTH" }
for ev in pairs(ACT_EVENTS) do list[#list + 1] = ev end
E:Events(f, list)
f:SetScript("OnEvent", function(_, ev, a1, _, a3)
  if not E.db or E.disabled then return end
  if ev=="TRAINER_SHOW" or ev=="TRAINER_UPDATE" or ev=="TRAINER_CLOSED" then E:ReadTrainer(ev) end
  if ev == "UNIT_SPELLCAST_SUCCEEDED" and a1 ~= "player" then return end   -- P1-9: other units' casts are noise
  -- Forever 1.60.1: nameplates have a shorter vertical range, so mobs far above or below you get no plate and are not seen here (degrades, never errors). We do not change nameplate CVars.
  if ev == "UNIT_HEALTH" and not (a1 == "target" or (a1 and a1:find("^nameplate"))) then return end
  local _, s = E:Current(); if not s then return end
  local what = ACT_EVENTS[ev]
  if what == "talk" or ev == "MERCHANT_SHOW" or ev == "TRAINER_SHOW" or ev == "TAXIMAP_OPENED" then
    if s.act == "talk" and (not s.npc or E:NpcIs("npc", s.npc) ~= false) then mark("talk") end
  end
  -- the interaction must be with this step's NPC when one is named (another vendor/trainer is not a proxy)
  if (ev == "MERCHANT_SHOW" or ev == "TRAINER_SHOW" or ev == "TAXIMAP_OPENED" or ev == "BANKFRAME_OPENED" or ev == "PET_STABLE_SHOW") and s.npc then
    if E:NpcIs("npc", s.npc) == false then what = nil end
  end
  if what == "merchant_closed" and not E:Met(s, "merchant") then what = nil end
  if what == "trainer_closed" and not E:Met(s, "trainer") then what = nil end
  if what == "talk" and s.npc and E:NpcIs("npc", s.npc) ~= true then what = nil end
  if what then mark(what) end
  if ev == "UNIT_SPELLCAST_SUCCEEDED" and a1 == "player" then
    if a3 == 8690 or a3 == 556 or (E.IsHearthSpell and E:IsHearthSpell(a3)) then mark("hearth") end
    E.lastCastAt = GetTime()
  end
  if ev == "PLAYER_CONTROL_LOST" and UnitOnTaxi and UnitOnTaxi("player") then mark("flight") end
  if ev == "UNIT_HEALTH" then
    if not (s.mob and not s.c) then return end
    local u = a1; if not (u == "target" or (u and u:find("^nameplate"))) then return end
    if not (UnitIsDead and UnitIsDead(u)) or (UnitIsTapDenied and UnitIsTapDenied(u)) or E:NpcIs(u, s.mob) ~= true then return end
    local guid = UnitGUID(u); E.killed = E.killed or {}; if not guid or E.killed[guid] then return end
    E.killed[guid] = true; mark("kill")
  end
  if ev == "ZONE_CHANGED_NEW_AREA" then E:ResetWaypoint(); E:PatrolReenter("zone change")
    -- hearth by any item/spell: a cast just before arriving in the zone the hearthstone is bound to
    if s.act == "hs" and E.lastCastAt and GetTime() - E.lastCastAt < 30 and E.AtBindLocation and E:AtBindLocation() then mark("hearth") end
  end
  if ev == "PLAYER_UNGHOST" or ev == "PLAYER_ALIVE" then E:PatrolReenter("resurrect") end
  if ev == "UNIT_HEALTH" and what ~= "kill" then return end
  E:Poke()   -- P1-9: coalesced (was one Advance per event)
end)
