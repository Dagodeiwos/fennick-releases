local TR = (Fennick_BEAST and Fennick_BEAST.L) or setmetatable({ F = function(_, f, ...) local ok, s = pcall(string.format, f, ...); return ok and s or f end }, { __index = function(_, k) return k end })   -- l10n (Core C.L)
if not Fennick_GUIDE_ENGINE then return end   -- P1-1: Core.lua refused to load (Beast Core too old)
-- Registers the leveling guide as a Fennick's Beast Core module ("leveling"). The guide keeps its own window;
-- it hides while another module owns focus and shows again when focus comes back. The arrow is Core's.
local E = Fennick_GUIDE_ENGINE
local C = Fennick_BEAST
local M = { key = "leveling", label = "Guidepost", priority = 10, ownWindow = true, minAPI = 3, needs = "1.2", icon = "Interface\\AddOns\\Fennick_Guidepost\\Media\\Fennick_Guidepost",
  summary = TR["step-by-step leveling routes to 60"] }   -- M-P2-9
-- M-N-4: sound cues live in Core's registry (each has its own toggle under Sounds; all start off)
if C.RegisterCue then C:RegisterCue("pvpEscape", TR["PvP escape alert"], "RAID_WARNING", 8959); C:RegisterCue("stepDone", TR["Quest step done"], "IG_QUEST_LIST_COMPLETE", 618) end
function M:Finished()
  if not E.db then return false end
  if (UnitLevel("player") or 0) >= ((GetMaxPlayerLevel and GetMaxPlayerLevel()) or 60) then return true end
  local g, s = E:Current(); return E.chain and g == E.chain[#E.chain] and s and E.db.step >= #g.steps and E:StepDone(s) or false
end
-- P1-5: no step once the last step of the last guide is done, or at max level (Auto then hands focus to the next module)
function M:HasStep()
  if not E.db or E.disabled then return false end
  if (UnitLevel("player") or 0) >= ((GetMaxPlayerLevel and GetMaxPlayerLevel()) or 60) then return false end
  local g, s = E:Current(); if s == nil then return false end
  if E.chain and g == E.chain[#E.chain] and E.db.step >= #g.steps and E:StepDone(s) then return false end
  return true
end
function M:StepKey() return E.StepKeyNow and E:StepKeyNow() end
function M:ReportStep() return E.db and E.db.step end   -- /fennick report: step number only
function M:ArrowCleared() return E.arrowCleared end
function M:Toggle() E:SetEnabled(E.disabled) end
-- P2-9: minimap left-click shows/hides the guide window only (the guide stays on)
function M:ToggleWindow() if not E.frame then return end; C:Safe("leveling window", function() if E.frame:IsShown() then E.frame:Hide() elseif E:WantShown() then E.frame:Show(); E:Refresh() end end) end
function M:OpenSettings() E:OpenSettings() end
function M:ApplyLook() if E.ApplyLook then E:ApplyLook() end end
function M:SetupDone() if E.db then E.db.wizardDone = true end end
function M:Back() E:Back() end
function M:Skip() E:Skip() end
function M:ArrowTaken() E:ResetWaypoint(); if E.Refresh then E:Refresh() end end
function M:FocusChanged(owner)
  if not E.frame then return end
  if owner == "leveling" then C:Safe("leveling show", function() if not E.disabled then E.frame:Show(); E:Refresh() end end)
  else C:Safe("leveling hide", function() E.frame:Hide() end) end
end
-- cheap along-the-way line while another module owns focus
function M:Rider()
  if not E.db or E.disabled then return end
  local _, s = E:Current(); if not s or E:IsInfo(s) then return end
  local t = E.StepText and E:StepText(s); if not t then return end
  t = t:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):gsub("%s+%(%d+, %d+%)", "")
  return TR:F("Guidepost: %s", t)
end
function M:Status(tt)
  local g = E:Current()
  tt:AddLine(TR:F("Guidepost: %s  %s / %s / %s", (E.disabled and TR["|cffff5555off|r"] or TR["|cff55ff55on|r"]), (E.db and E.db.route or "?"), (E.db and E.db.class or "?"), (E.db and E.db.rules or "?")), 1, 1, 1)
  if g then tt:AddLine(TR:F("%s  step %s/%s", g.name, E.db.step, #g.steps), 0.8, 0.8, 0.8) end
end
-- route hint for other modules (Rest): zones of the next leg and the next planned hearth bind
function M:RouteHint()
  if not E.db or not E.chain then return end
  local zones, nextBind, hearthSoon = {}, nil, nil; local gi, i, n = E.db.gi, E.db.step or 1, 0
  while gi and E.chain[gi] and n < 60 do
    local g = E.chain[gi]; local s = g.steps[i]
    if not s then gi, i = gi + 1, 1 else
      if s.z then zones[s.z] = true end
      if s.home and not nextBind then nextBind = s.home end
      if s.act == "hs" and n < 25 then hearthSoon = true end
      i, n = i + 1, n + 1 end
  end
  return { zones = zones, nextBind = nextBind, hearthSoon = hearthSoon }
end
C:RegisterModule(M)
if C.RegisterHelp then C:RegisterHelp("leveling", { TR["Guidepost shows your next leveling step and points the arrow at it."],
  TR["/fennick lvl skip and /fennick lvl back move between steps; /fennick guide works too."],
  TR["/fennick lvl config opens Guidepost's own settings (rules, role, window)."],
  TR["/fennick why says what the current step is waiting for."] }, "lvl") end
E.module = M

-- only the focus owner draws; Refresh is a no-op (window hidden) while another module owns focus
local baseRefresh = E.Refresh
function E:Refresh(...)
  if C:Owner() ~= "leveling" then if self.frame and self.frame:IsShown() then C:Safe("leveling hide", function() E.frame:Hide() end) end return end
  return baseRefresh(self, ...)
end
-- other modules' along-the-way lines go into Guidance (Auto focus)
local baseTips = E.ExtraTips
function E:ExtraTips(s)
  local out = baseTips and baseTips(self, s) or {}
  for _, r in ipairs(C:Riders("leveling")) do out[#out + 1] = r end
  return out
end
function E:UpdateMinimap() if C.UpdateMinimap then C:UpdateMinimap() end end

-- frame moving/sizing through Core (Blizzard Edit Mode or Fennick Edit Mode); size sliders override the guide width/scale
table.insert(E.initHooks, function()
  if E.frame then C:RegisterMovable("leveling", E.frame, "Leveling guide", { default = { point = "RIGHT", x = -40, y = 120 }, resizable = true,
    onChange = function() if E.Layout then pcall(E.Layout, E) end end }) end
end)
local baseO = E.O
function E:O(k)
  if (k == "width" or k == "scale") and C.EditMode then local p = C.EditMode:Get("leveling"); if p and p[k] then return p[k] end end
  return baseO(self, k)
end
local baseWhy = E.Why
function E:Why() local t = baseWhy and baseWhy(self) or {}; for _, l in ipairs(C:WhyLines()) do t[#t + 1] = l end; return t end
-- /fennick why (Core) includes the Leveling lines
function M:WhyLines() return baseWhy and baseWhy(E) or {} end
