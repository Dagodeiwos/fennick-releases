local TR = (Fennick_BEAST and Fennick_BEAST.L) or setmetatable({ F = function(_, f, ...) local ok, s = pcall(string.format, f, ...); return ok and s or f end }, { __index = function(_, k) return k end })   -- l10n (Core C.L)
if not Fennick_GUIDE_ENGINE then return end   -- P1-1: Core.lua refused to load (Beast Core too old)
-- Leveling lines for the Core monster tooltip: XP per kill at your level, kills to level, and this guide's own data
-- (level range, quest-starting drops, route quest objectives). Registered through C.Tooltip; no IDs in visible text.
local E = Fennick_GUIDE_ENGINE
local C = Fennick_BEAST
E.MOB = E.MOB or {}
-- Classic kill XP: (5*L + 45) at equal level; +5% per level above (max +4), linear drop to 0 at the gray level; elites x2
local function zeroDiff(L) if L < 8 then return 5 elseif L < 10 then return 6 elseif L < 12 then return 7 elseif L < 16 then return 8
  elseif L < 20 then return 9 elseif L < 30 then return 11 elseif L < 40 then return 12 elseif L < 45 then return 13 elseif L < 50 then return 14
  elseif L < 55 then return 15 else return 16 end end
local function grayLevel(L) if L <= 5 then return 0 elseif L <= 39 then return L - math.floor(L / 10) - 5 elseif L <= 59 then return L - math.floor(L / 5) - 1 end; return L - 9 end
function E.KillXP(pl, ml, elite)
  if not pl or not ml or ml <= 0 or pl >= 60 then return 0 end
  local base = pl * 5 + 45; local xp
  if ml >= pl then xp = base * (1 + 0.05 * math.min(ml - pl, 4))
  elseif ml <= grayLevel(pl) then xp = 0
  else xp = base * (1 - (pl - ml) / zeroDiff(pl)) end
  if elite then xp = xp * 2 end
  return math.max(0, math.floor(xp + 0.5))
end
local routeQ, routeKey = {}, nil
local function onRoute(q)
  local key = E.chain and #E.chain .. ":" .. tostring(E.db and E.db.gi)
  if key ~= routeKey then routeKey = key; routeQ = {}
    for gi, g in ipairs(E.chain or {}) do if gi >= (E.db and E.db.gi or 1) then for _, s in ipairs(g.steps) do for _, c in ipairs(s.c or {}) do routeQ[c[1]] = true end end end end end
  return routeQ[q]
end
C.Tooltip:RegisterData(function(id)
  local m = E.MOB[id]; if not m then return end
  local d = { lo = m[1], hi = m[2], rank = m[3] }
  local qs = {}
  for _, q in ipairs(m.q or {}) do
    if E:QuestAvailable(q) and not E:Done1(q) and (onRoute(q) or E:OnQuest1(q)) and #qs < 3 then qs[#qs + 1] = E:QuestName(q) end
  end
  if #qs > 0 then d.quests = qs end
  local st = {}
  for _, it in ipairs(m.st or {}) do local v = E.LOOTQ[it]; if v and not E:Done1(v.q) and not E:OnQuest1(v.q) then st[#st + 1] = v.item end end
  if #st > 0 then d.starts = st end
  return d
end)
local function xpFor(i) return E.KillXP(UnitLevel("player"), i.level > 0 and i.level or i.data.hi, i.classification == "elite" or i.classification == "rareelite" or i.data.rank == "elite") end
C.Tooltip:RegisterLine("xp", TR["XP per kill (Leveling)"], function(i)
  if i.friendly then return end
  local xp = xpFor(i); if xp <= 0 then return (UnitLevel("player") or 0) < 60 and TR["No XP (too low)"] or nil end
  return TR:F("XP per kill: about %s", xp)
end, 30, "leveling")
C.Tooltip:RegisterLine("ktl", TR["Kills to level (Leveling)"], function(i)
  if i.friendly then return end
  local xp = xpFor(i); if xp <= 0 then return end
  local need = (UnitXPMax and UnitXPMax("player") or 0) - (UnitXP and UnitXP("player") or 0); if need <= 0 then return end
  -- P2-6: rested XP doubles kill XP until the rested pool is used up
  local rested = GetXPExhaustion and GetXPExhaustion() or 0; rested = tonumber(rested) or 0
  local n, got, r = 0, 0, rested
  while got < need and n < 10000 do local bonus = math.min(xp, r); r = r - bonus; got = got + xp + bonus; n = n + 1 end
  return TR:F("Kills to level: %s%s", n, (rested > 0 and TR[" (rested)"] or ""))
end, 31, "leveling")
