local TR = (Fennick_BEAST and Fennick_BEAST.L) or setmetatable({ F = function(_, f, ...) local ok, s = pcall(string.format, f, ...); return ok and s or f end }, { __index = function(_, k) return k end })   -- l10n (Core C.L)
if not Fennick_GUIDE_ENGINE then return end   -- P1-1: Core.lua refused to load (Beast Core too old)
-- Settings panel (own frame), enable/disable, named profiles (save/load/reset).
-- Combat-safe: only our own insecure frames; nothing Blizzard-owned is reparented, hooked or modified.
local E = Fennick_GUIDE_ENGINE
local panel

-- Enable / disable ------------------------------------------------------------
function E:SetEnabled(on, silent)
  self.disabled = not on; self.db.opt.enabled = on and true or false
  -- events stay registered (re-registering on every toggle repeated any forbidden registration); every
  -- handler returns early while E.disabled. Only our own frames are shown/hidden here.
  if on then
    if self.frame and self:WantShown() then self.frame:Show() end   -- P1-6: never over another module's focus
    if self.ResetWaypoint then self:ResetWaypoint() end
    self:Start()
  else
    if self.frame then self.frame:Hide() end
    self.escapeActive = false; if self.frame and self.frame.escape then self.frame.escape:Hide() end
    self:Safe("wpclear", function() if E.ResetWaypoint then E:ResetWaypoint() end; E:ClearArrow() end)
  end
  if self.UpdateMinimap then self:UpdateMinimap() end
  if not silent then self:Print(TR:F("guide %s", (on and TR["enabled"] or TR["disabled"]))) end
end

-- Profiles: account-wide named copies (Fennick_GuidepostProfiles), per-character live settings ---------
local function copy(t) local o = {}; for k, v in pairs(t) do o[k] = type(v) == "table" and copy(v) or v end; return o end
function E:SaveProfile(name)
  _G.Fennick_GuidepostProfiles = _G.Fennick_GuidepostProfiles or {}
  _G.Fennick_GuidepostProfiles[name] = { opt = copy(self.db.opt), rules = self.db.rules, profChoice = self.db.profChoice }
  self:Print(TR:F("settings saved as profile '%s'", name))
end
function E:LoadProfile(name)
  local p = _G.Fennick_GuidepostProfiles and _G.Fennick_GuidepostProfiles[name]; if not p then return self:Print(TR:F("no profile '%s'", name)) end
  self.db.opt = self:ApplyDefaults(copy(p.opt)); self.db.profChoice = p.profChoice
  self:ApplyLook(); if p.rules then self:SetProfile("rules", p.rules) end
  self:Print(TR:F("loaded profile '%s'", name))
end
function E:ResetSettings()
  -- M-P2-1: resets Guidepost's own settings only; shared look, sound and minimap settings belong to Beast Core (/beast)
  self.db.opt = self:ApplyDefaults({}); self.db.profChoice = nil
  self:ApplyLook(); if self.Refresh then self:Refresh() end; self:Print(TR["settings reset to defaults"])
end
-- Panel widgets (own templates only: UICheckButtonTemplate / UIPanelButtonTemplate / InputBoxTemplate, unnamed) ---
local y
local function header(p, txt) local t = Fennick_BEAST:NewFS(p, "OVERLAY", "GameFontNormal"); t:SetPoint("TOPLEFT", p.col, y); t:SetText(txt); y = y - 20 end
local function check(p, key, txt, after)
  local c = CreateFrame("CheckButton", nil, p, "UICheckButtonTemplate"); c:SetSize(22, 22); c:SetPoint("TOPLEFT", p.col, y)
  local l = Fennick_BEAST:NewFS(c, "OVERLAY", "GameFontHighlightSmall"); l:SetPoint("LEFT", c, "RIGHT", 2, 0); l:SetText(txt)
  c.refresh = function() c:SetChecked(E:O(key) and true or false) end
  c:SetScript("OnClick", function(self) E.db.opt[key] = self:GetChecked() and true or false; if after then after() end; if E.Refresh then E:Refresh() end end)
  p.widgets[#p.widgets + 1] = c; y = y - 22
end
-- stepper: label  [<] value [>]  for numbers and choice lists
local function stepper(p, txt, get, set, fmt)
  local l = Fennick_BEAST:NewFS(p, "OVERLAY", "GameFontHighlightSmall"); l:SetPoint("TOPLEFT", p.col + 4, y - 4); l:SetText(txt)
  local v = Fennick_BEAST:NewFS(p, "OVERLAY", "GameFontNormalSmall"); v:SetPoint("TOPLEFT", p.col + 190, y - 4); v:SetWidth(90)
  local function b(t, x, d) local bt = CreateFrame("Button", nil, p, "UIPanelButtonTemplate"); bt:SetSize(22, 18); bt:SetPoint("TOPLEFT", p.col + x, y); bt:SetText(t); E.Skin:AddButton(bt, "settings")
    bt:SetScript("OnClick", function() set(d); v:SetText(fmt and fmt(get()) or tostring(get())) end) end
  b("<", 166, -1); b(">", 282, 1)
  v.refresh = function() v:SetText(fmt and fmt(get()) or tostring(get())) end
  p.widgets[#p.widgets + 1] = v; y = y - 22
end
local function num(p, key, txt, lo, hi, st, after, fmt)
  stepper(p, txt, function() return E:O(key) end,
    function(d) local x = math.floor((E:O(key) + d * st) / st + 0.5) * st; E.db.opt[key] = math.max(lo, math.min(hi, x)); if after then after() end; if E.Refresh then E:Refresh() end end, fmt)
end
local function cycle(list, cur, d) local i = 1; for k, v in ipairs(list) do if v == cur then i = k end end; return list[(i - 1 + d) % #list + 1] end
local function button(p, txt, x, w, fn) local b = CreateFrame("Button", nil, p, "UIPanelButtonTemplate"); b:SetSize(w, 20); b:SetPoint("TOPLEFT", x, y); b:SetText(txt); Fennick_BEAST:FitButton(b, w); b:SetScript("OnClick", fn); E.Skin:AddButton(b, "settings"); return b end

local function build()
  local p = CreateFrame("Frame", "Fennick_SettingsFrame", UIParent, "BackdropTemplate"); panel = p
  p:SetSize(700, 680); p:SetPoint("CENTER"); p:SetFrameStrata("DIALOG"); p:SetMovable(true); p:EnableMouse(true); p:SetClampedToScreen(true)
  p:RegisterForDrag("LeftButton"); p:SetScript("OnDragStart", p.StartMoving); p:SetScript("OnDragStop", p.StopMovingOrSizing)
  p.widgets = {}
  local t = Fennick_BEAST:NewFS(p, "OVERLAY", "GameFontNormalLarge"); t:SetPoint("TOP", 0, -14); t:SetText(TR:F("%s's Guidepost - Settings (this character)", E.brand))
  E:CloseButton(p)
  -- column 1: route
  p.col, y = 18, -44
  header(p, TR["Route"])
  stepper(p, TR["Ruleset"], function() return E.db.rules end, function(d) E:SetProfile("rules", cycle(E.RULES, E.db.rules, d)) end)
  local routes = {}; local seen = {}; for _, r in pairs(E.ROUTE or {}) do if not seen[r] then seen[r] = 1; routes[#routes + 1] = r end end; table.sort(routes)
  stepper(p, TR["Route (race start)"], function() return E.db.route end, function(d) E:SetProfile("route", cycle(routes, E.db.route, d)) end)
  local classes = { "DRUID", "HUNTER", "MAGE", "PALADIN", "PRIEST", "ROGUE", "SHAMAN", "WARLOCK", "WARRIOR" }
  stepper(p, TR["Class steps"], function() return E.db.class end, function(d) E:SetProfile("class", cycle(classes, E.db.class, d)) end)
  check(p, "autoAdvance", TR["Auto-advance steps"])
  header(p, TR["Professions (only yours; nothing is recommended)"])
  local pb = button(p, "", p.col + 4, 300, function() E:ShowProfPicker() end)
  pb.refresh = function() pb:SetText(E:ProfSummary()) end; p.widgets[#p.widgets + 1] = pb; y = y - 26
  -- the role lives in Beast Core settings; this button shows it and opens them
  local lb = button(p, "", p.col + 4, 300, function() if Fennick_BEAST.OpenSettings then Fennick_BEAST:OpenSettings() end end)
  lb.refresh = function() lb:SetText(TR:F("Role: %s", Fennick_BEAST.RoleLabel and Fennick_BEAST:RoleLabel() or TR["not known yet"])) end; p.widgets[#p.widgets + 1] = lb; y = y - 26
  header(p, TR["Hints"])
  check(p, "trainerRem", TR["Trainer reminders"])
  check(p, "questie", TR["Use Questie data when installed (optional)"], function() if E.QuestieAdapter then E.QuestieAdapter:Reset() end end)
  check(p, "rewardPick", TR["Quest reward pick"]); check(p, "profHints", TR["Profession hints"])
  check(p, "repath", TR["Skip low-value steps when ahead of the route"]); check(p, "boostTips", TR["XP boost reminders"])
  header(p, TR["Progression preferences"])
  local modes = { "off", "optimize", "force" }
  local labels = { off = TR["Off"], optimize = TR["Optimize"], force = TR["Force"] }
  for _, entry in ipairs({
    {"gear", "Equipment"}, {"dungeon", "Dungeons and quests"},
    {"secret", "Secrets"}, {"hiddenQuest", "Hidden quests"},
    {"favor", "Merchant's Favor"}, {"reputation", "Reputation"},
    {"unlock", "Attunements and unlocks"}, {"profession", "Professions"},
    {"exploration", "Exploration"}, {"raidPrep", "Raid preparation"}
  }) do
    local category, label = entry[1], entry[2]
    stepper(p, TR[label], function() return E:ContentMode(category) end,
      function(d)
        E.db.opt[E.CONTENT_OPTIONS[category]] = cycle(modes, E:ContentMode(category), d)
        if category=="secret" or category=="hiddenQuest" or category=="dungeon" then E.db.pauseForcedTrips=nil; E:Advance() end
        if E.ProgressionChanged then E:ProgressionChanged() end
      end, function(v) return labels[v] end)
  end
  -- P1-7: style preset, SharedMedia textures, external skin, sounds and the minimap button live in Beast Core's settings (/beast)
  -- column 2: display + QoL
  p.col, y = 360, -44
  header(p, TR["Display"])
  num(p, "scale", TR["Scale"], 0.5, 2, 0.05, function() E:ApplyLook() end, function(v) return string.format("%.2f", v) end)
  -- M-P2-1: background opacity is a suite-wide Beast Core setting (/beast), not a Guidepost slider
  num(p, "fontOffset", TR["Text size (font face unchanged)"], -4, 6, 1, function() Fennick_BEAST:Relook(TR["text size"]) end)
  num(p, "width", TR["Window width"], 280, 600, 10)
  num(p, "pad", TR["Padding"], 6, 30, 1)
  num(p, "rowGap", TR["Space between steps"], 2, 24, 1)
  num(p, "lineSpacing", TR["Line spacing"], 0, 10, 1)
  num(p, "patrolRadius", TR["Patrol arrival radius (yd)"], 20, 100, 5)
  check(p, "lock", TR["Lock frame position"]); check(p, "colorblind", TR["Colour-blind friendly colours"]); check(p, "stats", TR["Show XP/hour + ETA"])
  check(p, "arrow", TR["Waypoint arrow"], function() E:ResetWaypoint() end)
  check(p, "tomtom", TR["Use TomTom when installed (else built-in)"], function() E:ResetWaypoint() end)
  check(p, "hideCombat", TR["Hide guide in combat"]); check(p, "hideInstance", TR["Hide guide in dungeons/raids"])
  check(p, "hcSafeAccept", TR["Hardcore: never auto-accept escort/timed quests"])
  check(p, "variants", TR["Match Forever quest variants (verified in your quest log)"])
  header(p, TR["Automation (out of combat only; hold Shift to bypass)"])
  check(p, "autoAccept", TR["Auto-accept quests"]); check(p, "autoTurnIn", TR["Auto turn-in (never picks a reward choice)"])
  check(p, "autoGossip", TR["Auto-select quests in NPC chat"]); check(p, "routeOnly", TR["...only quests on this route"])
  y = y + 0
  local iq = button(p, TR["Instant quest text: ?"], 360, 220, function() E:ToggleInstantQuestText() ; E:RefreshSettings() end)
  iq.refresh = function() iq:SetText(TR:F("Instant quest text: %s", E:InstantQuestTextState())) end; p.widgets[#p.widgets + 1] = iq; y = y - 24
  check(p, "screenshot", TR["Screenshot on level up"]); check(p, "debug", TR["Debug log (/fennick debuglog)"])
  check(p, "blizzOptions", TR["List in Interface Options (reload; can cause taint)"])
  -- bottom: enable + profiles
  y = -620
  button(p, TR["Enable/Disable"], 18, 110, function() E:SetEnabled(E.disabled) end)
  button(p, TR["Hide/Show minimap"], 132, 130, function() local C = Fennick_BEAST; C:ToggleMinimap(); E:Print(TR:F("minimap button %s", (C.db.opt.minimap.hide and TR["hidden"] or TR["shown"]))) end)
  local pn = CreateFrame("EditBox", nil, p, "InputBoxTemplate"); pn:SetSize(110, 20); pn:SetPoint("TOPLEFT", 276, y); pn:SetAutoFocus(false); pn:SetText(TR["Default"])
  pn:SetScript("OnEscapePressed", function(self) self:ClearFocus() end); pn:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)
  button(p, TR["Save as"], 392, 64, function() E:SaveProfile(pn:GetText()) end)
  button(p, TR["Load"], 458, 50, function() E:LoadProfile(pn:GetText()); E:RefreshSettings() end)
  button(p, TR["Reset"], 510, 54, function() E:ResetSettings(); E:RefreshSettings() end)
  button(p, TR["Run setup"], 566, 80, function() p:Hide(); E:ShowSetup() end)
  y = -646
  local hint = Fennick_BEAST:NewFS(p, "OVERLAY", "GameFontDisableSmall"); hint:SetPoint("TOPLEFT", 18, y)
  hint:SetText(TR["Named profiles are shared across characters; live settings and progress are saved per character."])
  E.Skin:Add("settings", p); E.Skin:Style(p, 0.95)
  p:Hide()
end
function E:RefreshSettings() if panel then for _, w in ipairs(panel.widgets) do w.refresh() end end end
function E:OpenSettings()
  if not panel then build() end
  if panel:IsShown() then panel:Hide() else self:RefreshSettings(); panel:Show() end
end

-- Interface Options / Settings registration (guarded; a tiny launcher page, our panel is never reparented)
table.insert(E.initHooks, function()
  E:ApplyLook()
  -- OFF by default: adding a category to Blizzard's options/Settings panel is a known taint source
  if not E:O("blizzOptions") then return end
  local stub = CreateFrame("Frame"); stub.name = TR:F("%s's Guidepost", E.brand)
  local b = CreateFrame("Button", nil, stub, "UIPanelButtonTemplate"); b:SetSize(200, 24); b:SetPoint("TOPLEFT", 16, -16); b:SetText(TR:F("Open %s settings", E.brand)); Fennick_BEAST:FitButton(b, 200)
  b:SetScript("OnClick", function() if not E:InCombat() then E:OpenSettings() end end)
  if Settings and Settings.RegisterCanvasLayoutCategory and Settings.RegisterAddOnCategory then
    pcall(function() local cat = Settings.RegisterCanvasLayoutCategory(stub, stub.name); Settings.RegisterAddOnCategory(cat) end)
  elseif InterfaceOptions_AddCategory then pcall(InterfaceOptions_AddCategory, stub) end
end)

-- Shared helpers: a close button that only hides OUR frame (UIPanelCloseButton calls HideUIPanel, which
-- runs Blizzard's panel manager from add-on code - a classic taint path), and instant quest text.
function E:CloseButton(p)
  local b = CreateFrame("Button", nil, p); b:SetSize(28, 28); b:SetPoint("TOPRIGHT", -6, -6)
  b:SetNormalTexture("Interface\\Buttons\\UI-Panel-MinimizeButton-Up"); b:SetPushedTexture("Interface\\Buttons\\UI-Panel-MinimizeButton-Down")
  b:SetHighlightTexture("Interface\\Buttons\\UI-Panel-MinimizeButton-Highlight")
  b:SetScript("OnClick", function() p:Hide() end); return b
end
-- Instant quest text: the client's own option (Interface > Display). Read is harmless; we change it only
-- on an explicit click, out of combat, guarded. If the client lacks it we only explain where to find it.
function E:InstantQuestTextState()
  local ok, v = pcall(GetCVar or function() end, "instantQuestText")
  if not ok or v == nil then return "n/a" end
  return v == "1" and "ON" or "OFF"
end
function E:ToggleInstantQuestText()
  local st = self:InstantQuestTextState()
  if st == "n/a" then return self:Print(TR["this client has no instant quest text option"]) end
  if self:InCombat() then return self:Print(TR["leave combat first"]) end
  if self.RememberCVar then self:RememberCVar("instantQuestText") end   -- restorable with /fennick restore
  local ok = SetCVar and pcall(SetCVar, "instantQuestText", st == "ON" and "0" or "1")
  self:Debug("instantQuestText -> " .. (st == "ON" and "0" or "1"))
  self:Print(ok and (TR:F("instant quest text %s (same as Interface > Display > Instant Quest Text)", (st == "ON" and TR["OFF"] or "ON"))) or TR["could not change it - use Interface > Display > Instant Quest Text"])
end

-- Profession picker (settings + setup): multi-select, "Use detected", "None". Own frame, own close button.
local picker
function E:ShowProfPicker()
  if self:InCombat() then return self:Safe("profpicker", function() E:ShowProfPicker() end) end
  if not picker then
    local f = CreateFrame("Frame", "Fennick_ProfFrame", UIParent, "BackdropTemplate"); picker = f
    f:SetSize(300, 120 + math.ceil(#E.PROFS / 2) * 24); f:SetPoint("CENTER", 0, 40); f:SetFrameStrata("FULLSCREEN_DIALOG"); f:EnableMouse(true)
    local t = Fennick_BEAST:NewFS(f, "OVERLAY", "GameFontNormal"); t:SetPoint("TOP", 0, -14); t:SetText(TR["Your professions"])
    f.boxes = {}
    for i, n in ipairs(E.PROFS) do
      local c = CreateFrame("CheckButton", nil, f, "UICheckButtonTemplate"); c:SetSize(22, 22)
      c:SetPoint("TOPLEFT", 16 + ((i - 1) % 2) * 140, -36 - math.floor((i - 1) / 2) * 24)
      local l = Fennick_BEAST:NewFS(c, "OVERLAY", "GameFontHighlightSmall"); l:SetPoint("LEFT", c, "RIGHT", 2, 0); l:SetText(n)
      c:SetScript("OnClick", function(self)
        local set = {}; if E.db.profChoice then for _, x in ipairs(E.db.profChoice) do set[x] = true end else set = E:MyProfs() end
        set[n] = self:GetChecked() and true or nil
        local list = {}; for _, x in ipairs(E.PROFS) do if set[x] then list[#list + 1] = x end end
        E.db.profChoice = list; E:ProfChanged() end)
      f.boxes[n] = c
    end
    local function b(txt, point, x, fn) local bt = CreateFrame("Button", nil, f, "UIPanelButtonTemplate"); bt:SetSize(120, 20); bt:SetPoint(point, x, 12); bt:SetText(txt); Fennick_BEAST:FitButton(bt, 120); bt:SetScript("OnClick", fn); E.Skin:AddButton(bt, "settings") end
    b(TR["Use detected"], "BOTTOMLEFT", 16, function() E.db.profChoice = nil; E:ProfChanged() end)
    b("None", "BOTTOMRIGHT", -16, function() E.db.profChoice = {}; E:ProfChanged() end)
    E:CloseButton(f); E.Skin:Add("profs", f); E.Skin:Style(f, 0.95)
  end
  local mine = self:MyProfs(); for n, c in pairs(picker.boxes) do c:SetChecked(mine[n] and true or false) end
  picker:Show()
end
function E:ProfChanged()
  if picker then local mine = self:MyProfs(); for n, c in pairs(picker.boxes) do c:SetChecked(mine[n] and true or false) end end
  self:RefreshSettings(); if self.RefreshSetup then self:RefreshSetup() end; self:Advance()
end
