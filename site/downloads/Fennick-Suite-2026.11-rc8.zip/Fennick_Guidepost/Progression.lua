local E, C = Fennick_GUIDE_ENGINE, Fennick_BEAST
if not E or not C then return end
local categories = { reputation = "reputation", favor = "favor" }
function E:AtLevelCap()
  local level = UnitLevel and UnitLevel("player")
  return type(level) == "number" and level >= 60
end
function E:ProgressionObjective()
  if not self:AtLevelCap() or not C.Opportunities then self.progressionKey = nil; return end
  local best, current
  for _, row in ipairs(C:Opportunities()) do
    local category = categories[row.module]
    local mode = category and self:ContentMode(category) or "off"
    if mode ~= "off" and not (self.progressionSkipped and self.progressionSkipped[row.module .. ":" .. row.id]) then
      local candidate = { key = row.module .. ":" .. row.id, category = category,
        mode = mode, label = row.label, point = row.point, yards = row.yards }
      if candidate.key == self.progressionKey then current = candidate end
      if not best or (mode == "force" and best.mode ~= "force") then best = candidate end
    end
  end
  if current and best and current.mode == best.mode then
    local closer = best.yards and (not current.yards or
      (current.yards - best.yards >= 100 and best.yards <= current.yards / 2))
    if not closer then best = current end
  end
  self.progressionKey = best and best.key or nil
  return best
end
function E:ProgressionChanged()
  self.progressionSkipped = nil
  self.progressionKey = nil
  if self.Refresh then self:Refresh() end
end

-- Session-only deferrals never modify leveling quest completion.
function E:SkipProgression()
  if self.progressionKey then
    self.progressionSkipped = self.progressionSkipped or {}
    self.progressionSkipped[self.progressionKey] = true
    self.progressionKey = nil
  end
  if self.Refresh then self:Refresh() end
end
function E:RestoreProgression()
  self.progressionSkipped = nil
  self.progressionKey = nil
  if self.Refresh then self:Refresh() end
end
if C.On then
  C:On("BAG_UPDATE_DELAYED", function()
    if E.db and not E.disabled and E:AtLevelCap() then E:Poke() end
  end)
  C:On("UPDATE_FACTION", function()
    if E.db and not E.disabled and E:AtLevelCap() then E:Poke() end
  end)
end

-- Explicit item goals are independent of equipped gear and current role.
local purposes = { current = true, future = true, appearance = true, specific = true, utility = true, collection = true }
local function validItem(id)
  return type(id) == "number" and id > 0 and id <= 2147483647 and id % 1 == 0
end
function E:AddItemGoal(id, purpose)
  if not self.db or not validItem(id) or not purposes[purpose] then return false end
  if type(self.db.itemGoals) ~= "table" then self.db.itemGoals = {} end
  local goals = self.db.itemGoals
  if type(goals[id]) ~= "table" then goals[id] = {} end
  goals[id][purpose] = true
  return true
end
function E:RemoveItemGoal(id, purpose)
  if not self.db or not validItem(id) or not purposes[purpose] then return false end
  local goals = self.db.itemGoals
  if type(goals) ~= "table" or type(goals[id]) ~= "table" then return false end
  goals[id][purpose] = nil
  if not next(goals[id]) then goals[id] = nil end
  return true
end
function E:ItemGoals()
  local out = {}
  local goals = self.db and self.db.itemGoals
  if type(goals) ~= "table" then return out end
  for id, flags in pairs(goals) do
    if validItem(id) and type(flags) == "table" then
      local selected = {}
      for purpose in pairs(purposes) do if flags[purpose] == true then selected[#selected+1] = purpose end end
      table.sort(selected)
      if #selected > 0 then out[#out+1] = { item = id, purposes = selected } end
    end
  end
  table.sort(out, function(a,b) return a.item < b.item end)
  return out
end
