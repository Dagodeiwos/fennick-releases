local TR = (Fennick_BEAST and Fennick_BEAST.L) or setmetatable({ F = function(_, f, ...) local ok, s = pcall(string.format, f, ...); return ok and s or f end }, { __index = function(_, k) return k end })   -- l10n (Core C.L)
if not Fennick_GUIDE_ENGINE then return end   -- P1-1: Core.lua refused to load (Beast Core too old)
-- PvP ruleset helpers: escape prompt when attacked by an enemy player, contested-zone branch prompt and switching.
local E = Fennick_GUIDE_ENGINE
local ME
local seen, lastHostileHit = {}, 0
E.escapeActive = false

local function currentBlock()
  local g, s = E:Current(); if not (g and s) then return end
  if s.blk then return s.blk, s end
  for i = E.db.step, 1, -1 do local x = g.steps[i]; if x and x.blk then return x.blk, x end end
end
local function escapeOf()
  local g, s = E:Current(); if not g then return end
  for i = E.db.step, 1, -1 do local x = g.steps[i]; if x and x.esc then return x.esc end end
end

function E:ShowEscape(force)
  if self.db.rules ~= "PvP" and not force then return end
  if self.escapeActive and not force then return end
  local esc = escapeOf(); if not esc then return end
  self.escapeActive = true
  self:Debug("escape -> " .. esc[1])
  -- M-N-4: Core's cue registry (own toggle, off by default); older Cores: the legacy Sounds setting
  local C = Fennick_BEAST; if C and C.Cue then C:Cue("pvpEscape") elseif self:O("sound") and PlaySound then pcall(PlaySound, (SOUNDKIT and SOUNDKIT.RAID_WARNING) or 8959) end
  self:SetWaypoint({ z = esc[2], x = esc[3], y = esc[4] }, TR:F("ESCAPE: %s", esc[1]), true, true)   -- immediate, also in combat (arrow controller's escape path)
  if self.frame and self.frame.escape then self.frame.escape:SetText(TR:F("|cffff3333Attacked! Escape to %s|r", esc[1])); self.frame.escape:Show() end
end
function E:ClearEscape()
  if not self.escapeActive then return end
  self.escapeActive = false
  if self.frame and self.frame.escape then self.frame.escape:Hide() end
  if self.PatrolReenter then self:PatrolReenter("escape over") end
  if self.Refresh then self:Refresh() end
end

function E:BranchHint(reason)
  local bid = currentBlock(); if not bid or not (self.ALT and self.ALT[bid]) or self.db.branch then return end
  self.branchHint = reason
  if self.frame and self.frame.branchBtn then self:Safe("branchbtn", function() E.frame.branchBtn:Show() end) end
  self:Print(TR:F("This zone looks contested (%s). Click Branch or type /fennick branch to switch to %s; /fennick main returns.", reason, (self.ALT[bid].npc or TR["an alternate hub"])))
end

-- Switch: remember position, skip rest of the contested block (its quests become orphans), add the alt hub.
function E:TakeBranch()
  if self.PatrolReenter then self:PatrolReenter("branch") end
  if self:InCombat() then return self:Safe("branch", function() E:TakeBranch() end) end
  local bid = currentBlock(); local alt = bid and self.ALT and self.ALT[bid]
  if bid then -- prefer a non-contested hub matching the CURRENT level; build-time ALT is the fallback
    local L, fac, best = UnitLevel("player"), UnitFactionGroup("player")
    for _, h in ipairs(self.HUBS[fac] or {}) do
      if L >= h[1] and L < h[2] and not self.CONTESTED[h[4]] and (not best or math.abs((h[1] + h[2]) / 2 - L) < math.abs((best[1] + best[2]) / 2 - L)) then best = h end
    end
    if best then alt = { hub = 1, lo = best[1], hi = best[2], npc = best[3], z = best[4], x = best[5], y = best[6],
      n = TR:F("PvP branch: contested zone too busy. Quest at %s instead.", best[3]) } end
  end
  if not alt then return self:Print(TR["no alternate branch for this part of the route."]) end
  local g = self.chain[self.db.gi]
  self.db.branch = { gi = self.db.gi, step = self.db.step, bid = bid, key = self:StepId(g.steps[self.db.step]) }
  local endAt = self.db.step
  while g.steps[endAt + 1] and g.steps[endAt + 1].blk == bid do endAt = endAt + 1 end
  for i = self.db.step, endAt do g.steps[i].branchSkipped = true; g.steps[i].manualDone = true end
  local s = {}; for k, v in pairs(alt) do s[k] = v end; s.branch = bid
  table.insert(g.steps, endAt + 1, s)
  table.insert(g.steps, endAt + 2, { n = TR["Branch done. /fennick main (or the Main button) goes back to the skipped contested quests if you want them."], branchEnd = bid })
  if self.frame and self.frame.branchBtn then self.frame.branchBtn:Hide() end
  if self.frame and self.frame.mainBtn then self.frame.mainBtn:Show() end
  self:Print(TR:F("Branch taken: %s", (alt.npc or TR["alternate hub"]))); self:Advance()
end
function E:ReturnMain()
  if self.PatrolReenter then self:PatrolReenter("back from branch") end
  if self:InCombat() then return self:Safe("main", function() E:ReturnMain() end) end
  local b = self.db.branch; if not b then return self:Print(TR["you are on the main path."]) end
  local g = self.chain[b.gi]
  for _, s in ipairs(g.steps) do if s.branchSkipped then s.branchSkipped = nil; s.manualDone = nil end end
  self.db.gi, self.db.step, self.db.branch = b.gi, self:SeekKey(g, b.key) or b.step, nil   -- P0-1: back to the same step by id
  if self.frame and self.frame.mainBtn then self.frame.mainBtn:Hide() end
  self:Print(TR["Back on the main path."]); self:Advance()
end

local f = CreateFrame("Frame")
E:Events(f, { "UNIT_COMBAT", "PLAYER_REGEN_ENABLED", "PLAYER_DEAD", "NAME_PLATE_UNIT_ADDED", "PLAYER_TARGET_CHANGED", "UPDATE_MOUSEOVER_UNIT" })
local function noteHostile(unit)
  if not (unit and UnitExists(unit) and UnitIsPlayer(unit) and UnitIsEnemy("player", unit)) then return end
  local guid = UnitGUID(unit); local now = GetTime()
  if guid and (not seen[guid] or now - seen[guid] > 120) then seen[guid] = now end
  for g, t in pairs(seen) do if now - t > 300 then seen[g] = nil end end   -- P1-13: old sightings pruned
  local win = E:O("pvpWindow"); local n = 0; for _, t in pairs(seen) do if now - t < win then n = n + 1 end end
  if n >= E:O("pvpCount") and E.db and E.db.rules == "PvP" then E:BranchHint(TR:F("%s enemy players seen in %s s", n, win)) end
end
E.NoteHostile = noteHostile
-- P2-19: unit tokens built once (no string building per hit), one loop
-- Forever 1.60.1: nameplates have a shorter vertical range, so mobs far above or below you get no plate and are not seen here (degrades, never errors). We do not change nameplate CVars.
local TOKENS, TARGETS = { "target", "mouseover" }, {}
for i = 1, 40 do TOKENS[#TOKENS + 1] = "nameplate" .. i end
for i, u in ipairs(TOKENS) do TARGETS[i] = u .. "target" end
function E:HostileOnMe()
  for i, u in ipairs(TOKENS) do
    if UnitExists(u) and UnitIsPlayer(u) and UnitIsEnemy("player", u) and UnitIsUnit and UnitIsUnit(TARGETS[i], "player") then return true end
  end
  return false
end
f:SetScript("OnEvent", function(_, ev, unit, ...)
  if E.disabled and ev ~= "PLAYER_REGEN_ENABLED" then return end
  if not E.db or E.db.rules ~= "PvP" then if ev ~= "PLAYER_REGEN_ENABLED" then return end end
  if not E.db then return end
  ME = ME or UnitGUID("player")
  if ev == "UNIT_COMBAT" then
    -- no combat log (registering COMBAT_LOG_EVENT_UNFILTERED is forbidden on this client): we were hit
    -- (UNIT_COMBAT on "player", not a heal) while an enemy player nearby is targeting us
    local _, action = ...
    if unit == "player" and action ~= "HEAL" and E:HostileOnMe() then lastHostileHit = GetTime(); E:ShowEscape() end
  elseif ev == "PLAYER_REGEN_ENABLED" then
    if E.escapeActive then C_Timer.After(10, function() if not E:InCombat() then E:ClearEscape() end end) end
  elseif ev == "PLAYER_DEAD" then
    if GetTime() - lastHostileHit < 15 and E.db.rules == "PvP" then E:BranchHint(TR["you were killed by an enemy player"]) end
  elseif ev == "NAME_PLATE_UNIT_ADDED" then noteHostile(unit)
  elseif ev == "PLAYER_TARGET_CHANGED" then noteHostile("target")
  elseif ev == "UPDATE_MOUSEOVER_UNIT" then noteHostile("mouseover") end
end)
