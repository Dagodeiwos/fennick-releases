local TR = (Fennick_BEAST and Fennick_BEAST.L) or setmetatable({ F = function(_, f, ...) local ok, s = pcall(string.format, f, ...); return ok and s or f end }, { __index = function(_, k) return k end })   -- l10n (Core C.L)
if not Fennick_GUIDE_ENGINE then return end   -- P1-1: Core.lua refused to load (Beast Core too old)
-- Quality of life: auto accept/turn-in/quest gossip (unprotected quest APIs, out of combat, Shift bypasses,
-- never chooses between reward items), hide in combat/instances, session XP/hour + ETA, screenshot on level.
local E = Fennick_GUIDE_ENGINE
local routeQ, routeChain

-- quest IDs on the current route (accept/turn-in), rebuilt when the chain changes
local function onRoute(id)
  if not E:O("routeOnly") then return true end
  if not id or id == 0 then return false end
  local _,step=E:Current()
  if step and step.normalTrip and ((step.a and step.a[1]==id) or (step.t and step.t[1]==id)) then return true end
  if routeChain ~= E.chain then
    routeQ, routeChain = {}, E.chain
    for _, g in ipairs(E.chain or {}) do for _, s in ipairs(g.steps) do if not s.normalTrip then
      for _, q in ipairs(s.a or {}) do routeQ[q] = true end; for _, q in ipairs(s.t or {}) do routeQ[q] = true end
    end end end
  end
  return routeQ[id]
end
local function blocked() return E.disabled or E:InCombat() or (IsShiftKeyDown and IsShiftKeyDown()) end

-- session stats
local t0, gained, lastXP, lastMax = nil, 0
function E:XPPerSecond() if not t0 then return nil end; local el = GetTime() - t0; if el < 72 or gained <= 0 then return nil end; return gained / el end
function E:StatsLine(compact)
  if not t0 then return "" end
  local el = (GetTime() - t0) / 3600; if el < 0.02 or gained <= 0 then return compact and "" or TR["XP/hour: measuring..."] end
  if compact then return TR:F("%.1fk XP/h", gained / el / 1000) end
  local rate = gained / el; local need = (UnitXPMax("player") or 0) - (UnitXP("player") or 0)
  return TR:F("XP/hour: %d   next level in ~%d min   session %d min", rate, need / rate * 60, el * 60)
end

-- P1-6: one rule for showing the guide window: enabled AND Leveling owns Beast Core's focus
function E:WantShown() local C = Fennick_BEAST; return not self.disabled and (not C or C:Owner() == "leveling") end
local function visibility()
  if not E.frame then return end
  if not E:WantShown() then if E.frame:IsShown() then E.frame:Hide() end return end
  local hide = (E:O("hideCombat") and (E:InCombat() or E.inCombatNow)) or (E:O("hideInstance") and IsInInstance and select(2, IsInInstance()) ~= "none" and select(2, IsInInstance()) ~= nil)
  if hide then E.frame:Hide() else E.frame:Show() end
end
E.UpdateVisibility = visibility

local f = CreateFrame("Frame")
E:Events(f, { "QUEST_DETAIL", "QUEST_PROGRESS", "QUEST_COMPLETE", "GOSSIP_SHOW", "QUEST_GREETING", "PLAYER_XP_UPDATE",
  "PLAYER_LEVEL_UP", "PLAYER_REGEN_DISABLED", "PLAYER_REGEN_ENABLED", "PLAYER_ENTERING_WORLD" })
f:SetScript("OnEvent", function(_, ev)
  if E.disabled and ev ~= "PLAYER_REGEN_ENABLED" then return end
  if not E.db then return end
  if ev == "PLAYER_ENTERING_WORLD" then
    if not t0 then t0 = GetTime(); lastXP, lastMax = UnitXP("player"), UnitXPMax("player") end
    return visibility()
  elseif ev == "PLAYER_XP_UPDATE" then
    local x, m = UnitXP("player"), UnitXPMax("player"); if not t0 then t0 = GetTime(); lastXP, lastMax = x, m; return end
    gained = gained + ((x >= lastXP) and (x - lastXP) or (lastMax - lastXP + x)); lastXP, lastMax = x, m; return
  elseif ev == "PLAYER_LEVEL_UP" then
    if E:O("screenshot") and Screenshot then C_Timer.After(1, function() if not E:InCombat() then Screenshot() end end) end
    return
  elseif ev == "PLAYER_REGEN_DISABLED" then E.inCombatNow = true; return visibility()
  elseif ev == "PLAYER_REGEN_ENABLED" then E.inCombatNow = false; return visibility() end
  if blocked() then return end
  if ev=="QUEST_DETAIL" and E.ExplainNormalOffer then E:ExplainNormalOffer(GetQuestID and GetQuestID()) end
  if ev == "QUEST_DETAIL" and E:O("autoAccept") then
    local id = GetQuestID and GetQuestID()
    if onRoute(id) then
      local why = E:AutoBlocked(id); if why then E:Print(TR:F("not auto-accepted: %s", why)); return end
      E:Debug("auto-accept " .. tostring(id)); if AcceptQuest then AcceptQuest() end end   -- N-12 nil-safe
  elseif ev == "QUEST_PROGRESS" and E:O("autoTurnIn") then
    if (GetQuestMoneyToGet and (GetQuestMoneyToGet() or 0) > 0) then E:Print(TR["not auto-completed: this quest costs gold"]); return end
    if E:AutoBlocked(nil) then return end
    if IsQuestCompletable and CompleteQuest and IsQuestCompletable() and onRoute(GetQuestID and GetQuestID()) then CompleteQuest() end
  elseif ev == "QUEST_COMPLETE" and E:O("autoTurnIn") then
    if E:AutoBlocked(nil) then return end
    if (GetNumQuestChoices() or 0) <= 1 and onRoute(GetQuestID and GetQuestID()) then GetQuestReward(1) end -- choices: hint only
  elseif (ev == "GOSSIP_SHOW" or ev == "QUEST_GREETING") and E:AutoBlocked(nil) then return
  elseif ev == "GOSSIP_SHOW" and E:O("autoGossip") and C_GossipInfo then
    for _, q in ipairs(C_GossipInfo.GetActiveQuests and C_GossipInfo.GetActiveQuests() or {}) do
      if q.isComplete and onRoute(q.questID) then return C_GossipInfo.SelectActiveQuest(q.questID) end end
    for _, q in ipairs(C_GossipInfo.GetAvailableQuests and C_GossipInfo.GetAvailableQuests() or {}) do
      if onRoute(q.questID) then return C_GossipInfo.SelectAvailableQuest(q.questID) end end
  elseif ev == "QUEST_GREETING" and E:O("autoGossip") then
    for i = 1, (GetNumActiveQuests and GetNumActiveQuests() or 0) do
      local _, done = GetActiveTitle(i); if done and (not E:O("routeOnly") or (GetActiveQuestID and onRoute(GetActiveQuestID(i)))) then return SelectActiveQuest(i) end end
    for i = 1, (GetNumAvailableQuests and GetNumAvailableQuests() or 0) do
      if not E:O("routeOnly") or (GetAvailableQuestID and onRoute(GetAvailableQuestID(i))) then return SelectAvailableQuest(i) end end
  end
end)
