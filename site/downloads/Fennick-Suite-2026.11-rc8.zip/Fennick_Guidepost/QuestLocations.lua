-- Reviewed Forever quests. Map positions are zone percentages. Objective pins may be representative spawns.
-- Sources and point precision are documented in docs/GUIDEPOST-QUEST-LOCATIONS.md.
local E = Fennick_GUIDE_ENGINE
if not E then return end
local locations = {
  [6] = {
    name = "Bounty on Garrick Padfoot", start = {"Deputy Willem (NPC)", 1429, 48.2, 42.9},
    objectives = {{"Loot the head from Garrick Padfoot", 1429, 57, 48}}, finish = {"Deputy Willem (NPC)", 1429, 48.2, 42.9},
  },
  [7] = {
    name = "Kobold Camp Cleanup", start = {"Marshal McBride (NPC)", 1429, 48.9, 41.6},
    objectives = {{"Kill 10 Kobold Vermin", 1429, 47, 36}}, finish = {"Marshal McBride (NPC)", 1429, 48.9, 41.6},
  },
  [15] = {
    name = "Investigate Echo Ridge", start = {"Marshal McBride (NPC)", 1429, 48.9, 41.6},
    objectives = {{"Kill 10 Kobold Workers", 1429, 46, 32}}, finish = {"Marshal McBride (NPC)", 1429, 48.9, 41.6},
  },
  [18] = {
    name = "Brotherhood of Thieves", start = {"Deputy Willem (NPC)", 1429, 48.2, 42.9},
    objectives = {{"Loot 12 bandanas from Defias Cutpurses", 1429, 51, 49}}, finish = {"Deputy Willem (NPC)", 1429, 48.2, 42.9},
  },
  [21] = {
    name = "Skirmish at Echo Ridge", start = {"Marshal McBride (NPC)", 1429, 48.9, 41.6},
    objectives = {{"Kill 12 Kobold Laborers", 1429, 47, 30}}, finish = {"Marshal McBride (NPC)", 1429, 48.9, 41.6},
  },
  [33] = {
    name = "Wolves Across the Border", start = {"Eagan Peltskinner (NPC)", 1429, 48.9, 40.2},
    objectives = {{"Loot 8 Tough Wolf Meat from wolves", 1429, 47, 44}}, finish = {"Eagan Peltskinner (NPC)", 1429, 48.9, 40.2},
  },
  [54] = {
    name = "Report to Goldshire", start = {"Marshal McBride (NPC)", 1429, 48.9, 41.6},
    objectives = {{"Speak to the recipient", 1429, 42.1, 65.9}}, finish = {"Marshal Dughan (NPC)", 1429, 42.1, 65.9},
  },
  [136] = {
    name = "Captain Sander's Hidden Treasure", start = {"Read Captain Sander's Treasure Map (item 1357)"},
    drop = {"Loot the map from coastal murlocs; example Murloc Netter spawn", 1436, 34.3, 16.7}, objectives = {{"Deliver to Captain's Footlocker", 1436, 25.9, 47.8}}, finish = {"Captain's Footlocker (OBJECT)", 1436, 25.9, 47.8},
  },
  [138] = {
    name = "Captain Sander's Hidden Treasure", start = {"Captain's Footlocker (OBJECT)", 1436, 25.9, 47.8},
    objectives = {{"Search the barrel", 1436, 40.5, 47.8}}, finish = {"Broken Barrel (OBJECT)", 1436, 40.5, 47.8},
  },
  [139] = {
    name = "Captain Sander's Hidden Treasure", start = {"Broken Barrel (OBJECT)", 1436, 40.5, 47.8},
    objectives = {{"Search the jug", 1436, 40.6, 17.0}}, finish = {"Old Jug (OBJECT)", 1436, 40.6, 17.0},
  },
  [140] = {
    name = "Captain Sander's Hidden Treasure", start = {"Old Jug (OBJECT)", 1436, 40.6, 17.0},
    objectives = {{"Open the chest", 1436, 26.0, 16.9}}, finish = {"Locked Chest (OBJECT)", 1436, 26.0, 16.9},
  },
  [456] = {
    name = "The Balance of Nature", start = {"Conservator Ilthalaine (NPC)", 1438, 58.7, 44.3},
    objectives = {{"Kill 7 Young Nightsabers", 1438, 57, 45}, {"Kill 4 Young Thistle Boars", 1438, 55, 42}}, finish = {"Conservator Ilthalaine (NPC)", 1438, 58.7, 44.3},
  },
  [457] = {
    name = "The Balance of Nature", start = {"Conservator Ilthalaine (NPC)", 1438, 58.7, 44.3},
    objectives = {{"Kill 7 Mangy Nightsabers", 1438, 59, 31}, {"Kill 7 Thistle Boars", 1438, 55, 37}}, finish = {"Conservator Ilthalaine (NPC)", 1438, 58.7, 44.3},
  },
  [458] = {
    name = "The Woodland Protector", start = {"Melithar Staghelm (NPC)", 1438, 59.9, 42.5},
    objectives = {{"Speak to the recipient", 1438, 57.8, 45.2}}, finish = {"Tarindrella (NPC)", 1438, 57.8, 45.2},
  },
  [459] = {
    name = "The Woodland Protector", start = {"Tarindrella (NPC)", 1438, 57.8, 45.2},
    objectives = {{"Collect 8 Fel Moss from grell or grellkin", 1438, 54, 38}}, finish = {"Tarindrella (NPC)", 1438, 57.8, 45.2},
  },
  [783] = {
    name = "A Threat Within", start = {"Deputy Willem (NPC)", 1429, 48.2, 42.9},
    objectives = {{"Speak to the recipient", 1429, 48.9, 41.6}}, finish = {"Marshal McBride (NPC)", 1429, 48.9, 41.6},
  },
  [790] = {
    name = "Sarkoth", start = {"Hana'zua (NPC)", 1411, 40.6, 62.6},
    objectives = {{"Loot Sarkoth’s claw", 1411, 40, 67}}, finish = {"Hana'zua (NPC)", 1411, 40.6, 62.6},
  },
  [916] = {
    name = "Webwood Venom", start = {"Gilshalan Windwalker (NPC)", 1438, 57.8, 41.6},
    objectives = {{"Loot 10 venom sacs from Webwood Spiders", 1438, 57, 32}}, finish = {"Gilshalan Windwalker (NPC)", 1438, 57.8, 41.6},
  },
  [917] = {
    name = "Webwood Egg", start = {"Gilshalan Windwalker (NPC)", 1438, 57.8, 41.6},
    objectives = {{"Interact with a Webwood Eggs sac at the back of Shadowthread Cave", 1438, 56.82, 26.42}}, finish = {"Gilshalan Windwalker (NPC)", 1438, 57.8, 41.6},
  },
  [920] = {
    name = "Tenaron's Summons", start = {"Gilshalan Windwalker (NPC)", 1438, 57.8, 41.6},
    objectives = {{"Speak to Tenaron on the upper level of Aldrassil", 1438, 59.1, 39.5}}, finish = {"Tenaron Stormgrip (NPC)", 1438, 59.1, 39.5},
  },
  [921] = {
    name = "Crown of the Earth", start = {"Tenaron Stormgrip (NPC)", 1438, 59.1, 39.5},
    objectives = {{"Use the empty phial at the Shadowglen moonwell", 1438, 60, 33}}, finish = {"Tenaron Stormgrip (NPC)", 1438, 59.1, 39.5},
  },
  [928] = {
    name = "Crown of the Earth", start = {"Tenaron Stormgrip (NPC)", 1438, 59.1, 39.5},
    objectives = {{"Speak to the recipient", 1438, 56.1, 61.7}}, finish = {"Corithras Moonrage (NPC)", 1438, 56.1, 61.7},
  },
  [3519] = {
    name = "A Friend in Need", start = {"Iverron (NPC)", 1438, 54.6, 33.0},
    objectives = {{"Speak to the recipient", 1438, 60.9, 42.0}}, finish = {"Dirania Silvershine (NPC)", 1438, 60.9, 42.0},
  },
  [3521] = {
    name = "Iverron's Antidote", start = {"Dirania Silvershine (NPC)", 1438, 60.9, 42.0},
    objectives = {{"Collect 7 Hyacinth Mushrooms", 1438, 54, 38}, {"Collect 4 Moonpetal Lilies", 1438, 57, 36}, {"Loot 1 Webwood Ichor from a Webwood Spider", 1438, 56, 25}}, finish = {"Dirania Silvershine (NPC)", 1438, 60.9, 42.0},
  },
  [3522] = {
    name = "Iverron's Antidote", start = {"Dirania Silvershine (NPC)", 1438, 60.9, 42.0},
    objectives = {{"Deliver the antidote within five minutes", 1438, 54.6, 33.0}}, finish = {"Iverron (NPC)", 1438, 54.6, 33.0},
  },
  [3844] = {
    name = "It's a Secret to Everybody", start = {"A Wrecked Raft (OBJECT)", 1449, 63.0, 68.6},
    objectives = {{"Search the submerged pack next to the raft", 1449, 63.1, 69.1}}, finish = {"A Small Pack (OBJECT)", 1449, 63.1, 69.1},
  },
  [3845] = {
    name = "It's a Secret to Everybody", start = {"A Small Pack (OBJECT)", 1449, 63.1, 69.1},
    objectives = {{"Open the pack and take its contents to Linken", 1449, 44.7, 8.1}}, finish = {"Linken (NPC)", 1449, 44.7, 8.1},
  },
  [3903] = {
    name = "Milly Osworth", start = {"Deputy Willem (NPC)", 1429, 48.2, 42.9},
    objectives = {{"Speak to the recipient", 1429, 50.7, 39.4}}, finish = {"Milly Osworth (NPC)", 1429, 50.7, 39.4},
  },
  [3904] = {
    name = "Milly's Harvest", start = {"Milly Osworth (NPC)", 1429, 50.7, 39.4},
    objectives = {{"Collect 8 crates in the vineyard", 1429, 53, 48}}, finish = {"Milly Osworth (NPC)", 1429, 50.7, 39.4},
  },
  [3905] = {
    name = "Grape Manifest", start = {"Milly Osworth (NPC)", 1429, 50.7, 39.4},
    objectives = {{"Take the manifest upstairs in Northshire Abbey", 1429, 49.5, 41.6}}, finish = {"Brother Neals (NPC)", 1429, 49.5, 41.6},
  },
  [4495] = {
    name = "A Good Friend", start = {"Dirania Silvershine (NPC)", 1438, 60.9, 42.0},
    objectives = {{"Speak to the recipient", 1438, 54.6, 33.0}}, finish = {"Iverron (NPC)", 1438, 54.6, 33.0},
  },
  [5149] = {
    name = "Pamela's Doll", start = {"Pamela Redpath (NPC)", 1423, 31.1, 78.0},
    objectives = {{"Doll head, one possible spawn", 1423, 32.6, 79.6}, {"Left side, one possible spawn", 1423, 32.7, 79.1}, {"Right side, one possible spawn", 1423, 33.1, 79.7}, {"Combine the three pieces in your bags"}}, finish = {"Pamela Redpath (NPC)", 1423, 31.1, 78.0},
  },
  [5261] = {
    name = "Eagan Peltskinner", start = {"Deputy Willem (NPC)", 1429, 48.2, 42.9},
    objectives = {{"Speak to the recipient", 1429, 48.9, 40.2}}, finish = {"Eagan Peltskinner (NPC)", 1429, 48.9, 40.2},
  },
  [5842] = {
    name = "Welcome!", start = {"Use Shadowglen Gift Voucher (item 14648; Collector’s Edition entitlement)"},
    objectives = {{"Carry the voucher to Orenthil"}}, finish = {"Orenthil Whisperwind (NPC)", 1438, 58.8, 44.4},
  },
  [91746] = {
    name = "Elmpaw's Head", start = {"Use Elmpaw's Head (item 247862)"},
    drop = {"Elmpaw, roaming elite. Reported Elwynn search areas include 75, 38 and 82, 85; patrol path unverified."},
    objectives = {{"Deliver the trophy to Helene Peltskinner", 1429, 46.2, 62.2}}, finish = {"Helene Peltskinner (NPC)", 1429, 46.2, 62.2},
  },
  [92910] = {
    name = "Harvesting the Harvesters", start = {"Use Precessive Autocognition Assembly (item 255155)"},
    drop = {"Westfall harvest golems; representative Harvest Watcher spawn. Engineering reported for this drop.", 1436, 49.88, 21.29},
    objectives = {{"Deliver the assembly at Saldean's Farm", 1436, 51.5, 32.3}}, finish = {"Ozwin Ironsprocket (NPC)", 1436, 51.5, 32.3},
  },
  [98028] = {
    name = "Baron Marinous", start = {"Use Clouded Water Globe (item 279275)"},
    drop = {"Collect 20 Mathystral Amulet Fragments from Stormscale naga. Combine them at the Fathom Stone, summon the elite Baron and loot the globe.", 1439, 59.1, 22.9},
    objectives = {{"Deliver the globe at the Grove of the Ancients", 1439, 43.5, 76.3}}, finish = {"Onu (NPC)", 1439, 43.5, 76.3},
  },
  [97236] = {
    name = "Fang of Githyiss", start = {"Use Fang of Githyiss (item 277190)"},
    drop = {"Drop source: Githyiss the Vile, rear of Shadowthread Cave", 1438, 56.6, 26.3}, objectives = {{"Deliver to Gilshalan Windwalker", 1438, 57.8, 41.6}}, finish = {"Gilshalan Windwalker (NPC)", 1438, 57.8, 41.6},
  },
  [97977] = {
    name = "Nature's Call", start = {"Tarindrella (NPC)", 1438, 57.8, 45.2},
    objectives = {{"Search the abandoned furbolg camps for 4 Gnarlpine Totems", 1438, 54, 38}}, finish = {"Tarindrella (NPC)", 1438, 57.8, 45.2},
  },
  [97979] = {
    name = "The Goddess Provides", start = {"Shanda (NPC)", 1438, 59.2, 40.4},
    objectives = {{"Cast Elune's Light and Shadowmeld; no fixed objective location"}}, finish = {"Shanda (NPC)", 1438, 59.2, 40.4},
  },
}

local function describe(point)
  if not point[2] then return point[1] end
  local map = C_Map and C_Map.GetMapInfo and C_Map.GetMapInfo(point[2])
  return string.format("%s — %s (%.2f, %.2f)", point[1], map and map.name or ("Map " .. point[2]), point[3], point[4])
end

function E:PrintQuestLocations(query)
  local id = tonumber(query) or tonumber(query:match("|Hquest:(%d+)") or "")
  local matches = {}
  if id then
    if locations[id] then matches[1] = id end
  else
    local name = query:lower()
    for q, row in pairs(locations) do
      if row.name:lower() == name then matches[#matches+1] = q end
    end
    table.sort(matches)
  end
  if #matches == 0 then
    self:Print("No reviewed location entry. /fennick lvl quest <quest ID, quest link, or exact English name>")
    return
  end
  for _, q in ipairs(matches) do
    local row = locations[q]
    self:Print(row.name .. " (" .. q .. ")")
    if row.drop then self:Print("Item drop — " .. describe(row.drop)) end
    self:Print("Start — " .. describe(row.start))
    for _, point in ipairs(row.objectives) do self:Print("Objective — " .. describe(point)) end
    self:Print("Turn in — " .. describe(row.finish))
  end
end

-- Supply an endpoint only for an unambiguous quest interaction. Item starters
-- that open in the inventory have no stationary pickup waypoint.
function E:ReviewedQuestPoint(step)
  if step.hubObjective then
    local row = locations[step.hubObjective]
    local point = row and #row.objectives == 1 and row.objectives[1]
    if point and point[2] then return {z=point[2], x=point[3], y=point[4]} end
    return
  end
  if step.c or step.mob or step.act or step.hub or (step.a and step.t) then return end
  local ids = step.t or step.a
  if not ids or #ids ~= 1 then return end
  local row = locations[ids[1]]
  local point = row and (step.t and row.finish or row.start)
  if point and point[2] then return {z=point[2], x=point[3], y=point[4]} end
end

-- Normal manual hubs can follow a quest already accepted by the player.
-- Keep the authored hub as the saved step and recompute on normal UI refresh.
function E:UpdateHubLogPoint(hub)
  hub.logPoint = nil
  if self.db.rules ~= "Normal" or self:InCombat() or hub.expanded or hub.pending then return end
  local map = self:PlayerPos()
  if map ~= hub.z then return end
  if not hub.visited then
    local distance = self:Distance(hub)
    if not distance or distance >= 60 then return end
    hub.visited = true
  end
  local api = C_QuestLog
  if not api or not api.GetNumQuestLogEntries or not api.GetInfo then return end
  local best
  for i = 1, api.GetNumQuestLogEntries() do
    local info = api.GetInfo(i)
    local id = info and info.questID
    if id and not info.isHeader and not info.isHidden and self:OnQuest1(id) and not self:Done1(id) then
      local ready = self:QuestComplete(id)
      local known = locations[id]
      local z, x, y
      if api.GetNextWaypoint then z, x, y = api.GetNextWaypoint(id) end
      local point
      if z == map and type(x)=="number" and type(y)=="number" and x>=0 and x<=1 and y>=0 and y<=1 then
        point = {z=z, x=100*x, y=100*y}
      elseif not z and known then
        local step = ready and {t={id}} or {hubObjective=id}
        local reviewed = self:ReviewedQuestPoint(step)
        if reviewed and reviewed.z == map then point = reviewed end
      end
      if point then
        local d = self:Distance(point)
        if d and (not best or (ready and not best.ready) or (ready==best.ready and
            (d < best.distance or (d == best.distance and id < best.id)))) then
          point.id, point.distance, point.ready = id, d, ready
          point.label = info.title or (known and known.name) or self:QuestName(id)
          best = point
        end
      end
    end
  end
  hub.logPoint = best
  return best
end
