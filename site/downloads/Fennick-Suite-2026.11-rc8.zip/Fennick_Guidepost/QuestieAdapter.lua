if not Fennick_GUIDE_ENGINE then return end   -- P1-1: Core.lua refused to load (Beast Core too old)
-- Questie adapter (optional integration). The ONLY file that touches Questie.
-- Default is Blizzard's own UI and APIs (quest log, C_QuestLog, world map) plus our route data; Questie is used
-- only when the user turns on "Use Questie data when installed", Questie is loaded, and its public loader exposes
-- the functions we expect. Every call is pcall-wrapped; any missing function or error turns the integration off
-- for the session and everything quietly falls back to Blizzard + route data. No Questie code or data is shipped.
local E = Fennick_GUIDE_ENGINE
local A = { state = "off", errors = 0 }
E.QuestieAdapter = A
local DB, MODS = nil, {}
local MAX_ERRORS = 3

local function enabled() return E.O and E:O("questie") and true or false end
local function loader()
  local L = rawget(_G, "QuestieLoader")
  if type(L) == "table" and type(L.ImportModule) == "function" then return L end
end
function A:Fail(why)
  self.errors = self.errors + 1
  if self.errors >= MAX_ERRORS then self.state = "failed"; DB = false end
  if E.Debug then pcall(E.Debug, E, "Questie fallback: " .. tostring(why)) end
end
function A:Reset() self.state, self.errors, DB, MODS = "off", 0, nil, {} end
-- Import a Questie module by name; nil when off, missing, failed or in combat.
function A:Module(name, need)
  if not enabled() or self.state == "failed" or (E.InCombat and E:InCombat()) then return nil end
  local m = MODS[name]; if m ~= nil then return m or nil end
  local L = loader(); if not L then return nil end   -- not loaded yet: try again later
  local ok, mod = pcall(L.ImportModule, L, name)
  if ok and type(mod) == "table" then
    for _, fn in ipairs(need or {}) do if type(mod[fn]) ~= "function" then ok = false; break end end
  else ok = false end
  if not ok then MODS[name] = false; self:Fail("module " .. tostring(name)); return nil end
  MODS[name] = mod; return mod
end
function A:DB()
  if DB == false then return nil end
  local db = self:Module("QuestieDB", { "QueryQuestSingle", "QueryNPCSingle" })
  self.state = db and "on" or (self.state == "failed" and "failed" or "off")
  return db
end
-- Safe call into a Questie function: returns values, or nil (and counts an error) on failure.
function A:Call(fn, ...)
  if type(fn) ~= "function" then self:Fail("missing function"); return nil end
  local r = { pcall(fn, ...) }
  if not r[1] then self:Fail(r[2]); return nil end
  return unpack(r, 2)
end
function A:Available() return loader() ~= nil end

-- Engine-facing accessors (the rest of Guidepost calls only these)
function E:Questie() return A:DB() end
function E:QuestieModule(name, need) return A:Module(name, need) end
function E:QuestieCall(fn, ...) return A:Call(fn, ...) end
