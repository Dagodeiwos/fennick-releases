if not Fennick_GUIDE_ENGINE then return end   -- P1-1: Core.lua refused to load (Beast Core too old)
-- Look and skinning come from Fennick's Beast Core (one skin API for every Fennick window; see SKINNING.md).
local E = Fennick_GUIDE_ENGINE
local C = Fennick_BEAST
E.Skin = C.Skin
function E:ApplyPreset(name) C:ApplyPreset(name) end
