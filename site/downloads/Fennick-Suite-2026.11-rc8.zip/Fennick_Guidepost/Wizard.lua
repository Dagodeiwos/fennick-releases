local TR = (Fennick_BEAST and Fennick_BEAST.L) or setmetatable({ F = function(_, f, ...) local ok, s = pcall(string.format, f, ...); return ok and s or f end }, { __index = function(_, k) return k end })   -- l10n (Core C.L)
if not Fennick_GUIDE_ENGINE then return end   -- P1-1: Core.lua refused to load (Beast Core too old)
-- Leveling pages for the Core setup wizard (route, class, ruleset, professions, role, quest helpers).
-- The wizard frame itself belongs to Fennick's Beast Core; it shows these pages only when Leveling is installed.
local E = Fennick_GUIDE_ENGINE
local C = Fennick_BEAST
local CLASSES = { "DRUID", "HUNTER", "MAGE", "PALADIN", "PRIEST", "ROGUE", "SHAMAN", "WARLOCK", "WARRIOR" }
local function cycle(list, cur, d) local i = 1; for k, v in ipairs(list) do if v == cur then i = k end end; return list[(i - 1 + d) % #list + 1] end
local function routes() local t, seen = {}, {}; for _, r in pairs(E.ROUTE or {}) do if not seen[r] then seen[r] = 1; t[#t + 1] = r end end; table.sort(t); return t end
local function onoff(k) return E:O(k) and "|cff55ff55" .. TR["ON"] .. "|r" or "|cffff5555" .. TR["OFF"] .. "|r" end
local function toggle(k) E.db.opt[k] = not E:O(k) end

-- each page: title, body(), choices = { {label(), onClick} ... }
local PAGES = {
  { TR["Route and class"], function() return TR:F("Detected: %s route, %s.\nThe route follows your race's starting zone; class adds trainer and class-quest steps. Confirm or change:", E.db.route, E.db.class) end,
    { { function() return TR:F("Route: %s", E.db.route) end, function(d) E:SetProfile("route", cycle(routes(), E.db.route, d)) end, true },
      { function() return TR:F("Class: %s", E.db.class) end, function(d) E:SetProfile("class", cycle(CLASSES, E.db.class, d)) end, true } } },
  { TR["Ruleset"], function() return TR["Normal uses your leveling preferences. Hardcore adds safety restrictions."] end,
    { { function() return (E.db.rules == "Normal" and "> " or "") .. TR["Normal"] end, function() E:SetProfile("rules", "Normal") end },
      { function() return (E.db.rules == "HC" and "> " or "") .. TR["Hardcore"] end, function() E:SetProfile("rules", "HC") end } } },
  { TR["Professions"], function() return TR:F("Profession tips and steps are shown only for your own professions; nothing is recommended.\nNow using: %s", E:ProfSummary()) end,
    { { function() return TR["Use what I have trained"] end, function() E.db.profChoice = nil; E:ProfChanged() end },
      { function() return TR["Choose..."] end, function() E:ShowProfPicker() end },
      { function() return "None" end, function() E.db.profChoice = {}; E:ProfChanged() end } } },
  -- Role (Guidepost 4.7): Beast Core owns it; this page only shows it and offers the two ways to change it.
  { TR["Role"], function()
      local C = Fennick_BEAST
      return TR:F("Quest reward picks follow your role. Beast Core works it out from your build and gear, and you can set it yourself under Role in the Beast Core settings. Nothing is recommended.\nNow: %s", C.RoleLabel and C:RoleLabel() or TR["not known yet"]) end,
    { { function() return TR["Open Beast Core settings"] end, function() if Fennick_BEAST.OpenSettings then Fennick_BEAST:OpenSettings() end end },
      { function() return TR["Automatic"] end, function() if Fennick_BEAST.SetRoleFocus then Fennick_BEAST:SetRoleFocus(nil) end end } } },
  { TR["Quest helpers"], function() return TR["Only quests on your route, never in combat; hold Shift at an NPC to bypass.\nAuto turn-in never picks between reward items (it shows the best pick for your role).\nInstant quest text is the game's own option (Interface > Display)."] end,
    { { function() return TR:F("Auto-accept %s", onoff("autoAccept")) end, function() toggle("autoAccept") end },
      { function() return TR:F("Auto turn-in %s", onoff("autoTurnIn")) end, function() toggle("autoTurnIn") end },
      { function() return TR:F("Auto-select quest chat %s", onoff("autoGossip")) end, function() toggle("autoGossip") end },
      { function() return TR:F("Instant quest text: %s", E:InstantQuestTextState()) end, function() E:ToggleInstantQuestText() end } } },
}
C:RegisterWizardPages("leveling", PAGES)
E.SETUP_PAGES = PAGES
function E:RefreshSetup() if C.RenderSetup then C.RenderSetup() end end
function E:ShowSetup() C:ShowSetup() end
