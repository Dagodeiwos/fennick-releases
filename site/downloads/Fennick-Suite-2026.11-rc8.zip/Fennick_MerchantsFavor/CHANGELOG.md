# Fennick Merchant's Favor: changelog

All notable changes, newest first. Dates are month and year only.

## 1.2.3 (October 2026)
- /fennick favor help prints a few lines of help.

## 1.2.2 (October 2026)
- Your camp quartermaster shows on Fennick's Cartographer when installed.

## 1.2.1 (October 2026)
- New in-game icon (window header, AddOns list). Cosmetic only.

## 1.2.0 (October 2026)
- Writ customer (name and map spot) shown while you work on a writ, marked unconfirmed until checked in game; writs with no customer in the data say so instead of guessing. A delivered daily writ shows the time to the realm's daily reset. One-line summary in setup.

## 1.1.0 (October 2026)
- Multi-language: machine-translated text (labelled in Settings and setup) for German, French, Spanish, Italian, Portuguese (BR), Russian, Korean and Chinese (Simplified/Traditional); English text, fonts and slash commands unchanged; names from the game client by ID. Currency found by its translated name.

## 1.0.2 (October 2026)
- Realm daily reset, currency by ID, only own quests recorded, Unskip all, focus here-and-now.

Suite-wide notes: https://github.com/Dagodeiwos/fennick-releases/blob/main/CHANGELOG.md
