local TR = (Fennick_BEAST and Fennick_BEAST.L) or setmetatable({ F = function(_, f, ...) local ok, s = pcall(string.format, f, ...); return ok and s or f end }, { __index = function(_, k) return k end })   -- l10n (Core C.L)
if not (Fennick_BEAST and (Fennick_BEAST.API or 1) >= 3) then return end   -- P1-1 file-top guard: needs Beast Core 1.2 (API 3)
-- Fennick Merchant's Favor (module "favor" for Fennick's Beast Core). Tracks every crate, writ and label in your bags:
--   empty Waylaid Crate  -> fill it with ONE bundle (bag have/need per bundle), it becomes a Sealed crate (no quest)
--   Sealed crate         -> deliver at your camp's intake NPC (no quest item: tracked by bag contents)
--   Craftsman's Writ / Shipping Label -> starts a quest when used: "Right-click to start", then live quest objectives
--                           (have/need from the quest log, plus bag counts), then "Turn in at <NPC>"
--   sealed writ envelope -> open it to get the writ; Forged Delivery Receipts are counted.
-- Several items are tracked at once, sorted by readiness. Progress changes only from bags and quest events; a turn-in
-- counts only on QUEST_TURNED_IN, never on arriving somewhere. Missing materials read "Buy or gather" (no profession advice).
local C = Fennick_BEAST
local M = { ITEMS = {}, CAMPS = {}, FACTIONS = {}, DELIVER = {} }
Fennick_FAVOR = M
local mod = { key = "favor", label = "Merchant's Favor", priority = 30, minAPI = 3, needs = "1.2", icon = "Interface\\AddOns\\Fennick_MerchantsFavor\\Media\\Fennick_MerchantsFavor", summary = TR["crates, writs and labels from your bags to the turn-in"] }   -- M-P2-9
M.module = mod
local function side() local f = UnitFactionGroup and UnitFactionGroup("player"); return f == "Alliance" and "A" or f == "Horde" and "H" or "?" end
function M:Camp() return self.CAMPS[side()] end
function M:FactionID() return self.FACTIONS[side()] end
-- P2-13: daily writs reset with the realm's daily reset, not the PC's date
local function today() return C:DailyKey() end
-- Writ customer locations and the daily-reset reminder.
-- Customer spots come only from quest data (Questie Forever DB + datamine) and stay marked unconfirmed until checked in game
-- (Fox Trials FAV-04). A writ with no customer in the data says so; nothing is guessed.
M.WRIT_LOC_CONFIRMED = false
function M:ResetIn()   -- seconds until the realm's daily reset, or nil when the client cannot tell
  local left = C_DateAndTime and C_DateAndTime.GetSecondsUntilDailyReset and C_DateAndTime.GetSecondsUntilDailyReset()
  if not tonumber(left) and GetQuestResetTime then left = GetQuestResetTime() end
  left = tonumber(left); if left and left > 0 then return left end
end
function M:CustomerLine(it)
  if it.npc and it.z then
    return TR:F("Customer: %s%s", it.npc, C:Where({ z = it.z, x = it.x, y = it.y })) .. (self.WRIT_LOC_CONFIRMED and "" or TR["  |cff999999(unconfirmed)|r"])
  end
  return TR["|cff999999Customer: not in the data yet (see the quest text)|r"]
end
-- P2-13: the currency by ID. The ID is not in datamine 70532, so it is learned once from the currency list (English name)
-- and then read with GetCurrencyInfo(id) on any client language.
function M:Favor()
  if not C_CurrencyInfo then return end
  local d = C:ModDB("favor"); local id = tonumber(self.CURRENCY_ID or d.currencyID)
  if id and C_CurrencyInfo.GetCurrencyInfo then local info = C_CurrencyInfo.GetCurrencyInfo(id); if info and info.quantity then return info.quantity end end
  if not C_CurrencyInfo.GetCurrencyListSize then return end
  for i = 1, C_CurrencyInfo.GetCurrencyListSize() do
    local info = C_CurrencyInfo.GetCurrencyListInfo(i)
    -- l10n fix: the English name or the client's own (translated) name; the ID is remembered either way
    if info and (info.name == "Merchant's Favor" or (C.L and info.name == C.L["Merchant's Favor"])) then
      local link = C_CurrencyInfo.GetCurrencyListLink and C_CurrencyInfo.GetCurrencyListLink(i)
      local lid = link and tonumber(tostring(link):match("currency:(%d+)")); if lid then d.currencyID = lid end
      return info.quantity
    end
  end
end
-- live objectives of a started quest: { {text, have, need, done} }, and whether the quest is complete
function M:Objectives(q)
  local out = {}
  if C_QuestLog and C_QuestLog.GetQuestObjectives then
    for _, o in ipairs(C_QuestLog.GetQuestObjectives(q) or {}) do
      out[#out + 1] = { text = (o.text or ""):gsub("^%s*%d+%s*/%s*%d+%s*", ""):gsub(":%s*%d+%s*/%s*%d+%s*$", ""), have = o.numFulfilled or 0, need = o.numRequired or 1, done = o.finished }
    end
  end
  local complete = C_QuestLog and C_QuestLog.IsComplete and C_QuestLog.IsComplete(q)
  if complete == nil then complete = #out > 0; for _, o in ipairs(out) do if not o.done then complete = false end end end
  return out, complete and true or false
end
local RANK = { ready = 1, fill = 2, start = 3, open = 3, working = 4, waiting = 5, locked = 6 }
function M:Entry(it, n)
  local e = { it = it, count = n, id = it.id, name = it.n, lines = {} }
  local lvl = UnitLevel and UnitLevel("player") or 0
  if it.k == "empty" then
    if it.lvl and lvl < it.lvl then e.state = "locked"; e.line = TR:F("%s: needs level %s", it.n, it.lvl); return e end
    local best, any
    for _, b in ipairs(it.b or {}) do
      local have = b[1] and C:ItemCount(b[1]) or 0; local need = b[2] or 1
      local ok = have >= need; any = any or ok
      local r = math.min(1, have / need); if not best or r > best.r then best = { r = r, b = b, have = have } end
      
    end
    if best then
      e.bundle = best.b
      local function line(b)
        local have, need = C:ItemCount(b[1]), b[2] or 1
        local ok = have >= need
        return (ok and "|cff55ff55" or "") .. b[3] .. " " .. math.min(have, need) .. "/" .. need .. (ok and "|r" or "")
      end
      e.lines[1] = line(best.b)
      for _, b in ipairs(it.b or {}) do
        if b ~= best.b and #e.lines < 3 then e.lines[#e.lines + 1] = line(b) end
      end
    end
    if #(it.b or {}) > 3 then e.lines[#e.lines + 1] = TR:F("|cff999999or one of %s more bundles (see the crate tooltip)|r", (#it.b - 3)) end
    if any then e.state = "fill"; e.line = TR:F("Fill %s: right-click it (one bundle is enough)", it.n)
    else e.state = "working"; e.line = TR:F("%s: buy or gather one bundle", it.n); end
    return e
  elseif it.k == "sealed" then
    local camp = self:Camp()
    e.state = "ready"; e.line = TR:F("Turn in %s%s", it.n, (camp and (TR:F(" to %s at the %s", camp.npc, camp.name)) or TR[" at your camp"]))
    e.point = camp and { z = camp.z, x = camp.x, y = camp.y }; e.label = camp and camp.npc
    return e
  elseif it.k == "envelope" then
    e.state = "open"; e.line = TR:F("Right-click %s to open it (it holds a writ)", it.n); return e
  elseif it.k == "writ" or it.k == "label" then
    local q = it.q
    if q and C:OnQuest(q) then
      local objs, complete = self:Objectives(q)
      for _, o in ipairs(objs) do
        local bag = ""; for _, nd in ipairs(it.need or {}) do if o.text:find(nd[2], 1, true) then local b = C:ItemCount(nd[1]); if b ~= o.have then bag = TR:F("  (bags: %s)", b) end end end
        e.lines[#e.lines + 1] = (o.done and "|cff55ff55" or "") .. o.text .. " " .. o.have .. "/" .. o.need .. (o.done and "|r" or (o.have < o.need and TR["  - buy or gather"] or "")) .. bag
      end
      if complete then e.state = "ready"; e.line = TR:F("Turn in %s%s%s", it.n:gsub("^Craftsman's Writ: ", "writ: "), (it.npc and (TR:F(" to %s", it.npc)) or ""), (it.z and "" or TR["  |cff999999(where: see the quest)|r"]))
        e.point = it.z and { z = it.z, x = it.x, y = it.y }; e.label = it.npc
      else e.state = "working"; e.line = TR:F("%s: in progress", it.n); if it.k == "writ" then e.lines[#e.lines + 1] = self:CustomerLine(it) end end
      return e
    end
    if n <= 0 then return nil end
    local done = C:ModDB("favor").turned or {}
    local day = today()
    if it.daily and q and day and done[q] == day then e.state = "waiting"
      local left = self:ResetIn()
      e.line = left and TR:F("%s: delivered today; daily reset in %s", it.n, C:Duration(left)) or TR:F("%s: delivered today, start it again tomorrow", it.n)
      return e end
    e.state = "start"; e.line = TR:F("Right-click %s to start its quest", it.n); if it.k == "writ" then e.lines[#e.lines + 1] = self:CustomerLine(it) end; return e
  end
end
local cache, stamp
function M:Entries()
  local now = GetTime and math.floor(GetTime() / 2) or 0
  if cache and stamp == now and not M.dirty then return cache end
  stamp, M.dirty = now, false
  local out, sk = {}, C:ModDB("favor").skipped or {}
  for _, it in ipairs(self.ITEMS) do
    if it.k ~= "receipt" and (not it.s or it.s == "B" or it.s == side()) then
      local n = C:ItemCount(it.id)
      if (n > 0 or (it.q and C:OnQuest(it.q))) and not sk[it.id] then local e = self:Entry(it, n); if e then out[#out + 1] = e end end
    end
  end
  table.sort(out, function(a, b) local x, y = RANK[a.state] or 9, RANK[b.state] or 9; if x ~= y then return x < y end if a.name ~= b.name then return a.name < b.name end return a.id < b.id end)
  cache = out; return out
end
function M:Receipts() for _, it in ipairs(self.ITEMS) do if it.k == "receipt" then return C:ItemCount(it.id) end end; return 0 end
function mod:HasStep() for _, e in ipairs(M:Entries()) do if RANK[e.state] <= 4 then return true end end; return false end
function mod:StepKey() local e = M:Entries()[1]; return e and (TR:F("favor:%s:%s", e.id, e.state)) end
function M:StandingText()
  local fid = self:FactionID(); local st, v, max, name = nil
  if fid then st, v, max, name = C:Standing(fid) end
  local fav, t = self:Favor(), {}
  if st then t[#t + 1] = name .. ": " .. C.STANDING[st] .. " " .. v .. "/" .. max end
  if fav then t[#t + 1] = TR:F("Merchant's Favor: %s", fav) end
  return table.concat(t, "   ")
end
function mod:View()
  local list = M:Entries(); local e = list[1]
  local v = { title = "Merchant's Favor", sub = M:StandingText(), guidance = {} }
  local camp = M:Camp()
  if not e then
    v.line = TR["No crates, writs or labels in your bags."]
    if camp then v.guidance[#v.guidance + 1] = TR:F("Camp: %s (%s)%s", camp.name, camp.npc, C:Where(camp)) end
  else
    v.line = e.line .. (e.point and C:Where(e.point) or "")
    v.obj = #e.lines > 0 and table.concat(e.lines, "\n") or nil
    for i = 2, #list do v.guidance[#v.guidance + 1] = list[i].line .. (list[i].count > 1 and (" (x" .. list[i].count .. ")") or "") end
    v.point, v.label = e.point, e.label
  end
  local rc = M:Receipts(); if rc > 0 then v.guidance[#v.guidance + 1] = TR:F("Forged Delivery Receipts in bags: %s", rc) end
  local nsk = 0; for _ in pairs(C:ModDB("favor").skipped or {}) do nsk = nsk + 1 end   -- N-3
  if nsk > 0 then v.backLabel = TR["Unskip all"]; v.guidance[#v.guidance + 1] = TR:F("Skipped (%s)", nsk) end
  return v
end
function mod:Rider()
  local ready = 0; for _, e in ipairs(M:Entries()) do if e.state == "ready" then ready = ready + 1 end end
  if ready == 0 then return end
  local here = C:PlayerPos(); local camp = M:Camp()
  return TR:F("Merchant's Favor: %s ready to turn in%s", ready, ((camp and here == camp.z) and TR[" (camp is in this zone)"] or ""))
end
function mod:HereNow()   -- P1-5: a ready crate/writ and its turn-in is in this zone
  local here = C:PlayerPos(); if not here then return false end
  for _, e in ipairs(M:Entries()) do if e.state == "ready" and e.point and e.point.z == here then return true end end; return false end
function mod:Skip() local e = M:Entries()[1]; if e then local d = C:ModDB("favor"); d.skipped = d.skipped or {}; d.skipped[e.id] = true; M.dirty = true end end
function mod:Back() C:UnskipAll("favor"); M.dirty = true end
function mod:Status(tt) tt:AddLine(TR:F("Merchant's Favor: %s tracked  %s", #M:Entries(), M:StandingText()), 1, 1, 1) end
function mod:Toggle() C:ToggleWindow() end
-- a turn-in is recorded only from the quest event
function M:TurnedIn(q)
  if not q then return end
  -- P1-13: only our own writ/label quests are recorded, and only today's entries are kept (daily check needs nothing older)
  local mine = false; for _, it in pairs(M.ITEMS) do if type(it) == "table" and it.q == q then mine = true; break end end
  if not mine then return end
  local d = C:ModDB("favor"); d.turned = d.turned or {}; local t = today()
  for k, v in pairs(d.turned) do if v ~= t then d.turned[k] = nil end end
  d.turned[q] = t; M.dirty = true
end
