local TR = (Fennick_BEAST and Fennick_BEAST.L) or setmetatable({ F = function(_, f, ...) local ok, s = pcall(string.format, f, ...); return ok and s or f end }, { __index = function(_, k) return k end })   -- l10n (Core C.L)
if not (Fennick_BEAST and (Fennick_BEAST.API or 1) >= 3) then   -- P1-1: refuse cleanly on an older Beast Core
  if DEFAULT_CHAT_FRAME then DEFAULT_CHAT_FRAME:AddMessage(TR["|cff33ccffFennick:|r Fennick Merchant's Favor needs Fennick's Beast Core 1.2 or newer. Please update Beast Core."]) end
  return
end
local C = Fennick_BEAST
local M = Fennick_FAVOR
C:RegisterModule(M.module)
-- One crate, one alternative bundle: never sum mutually exclusive choices.
if C.RegisterMaterialProvider then C:RegisterMaterialProvider("favor", function()
  for _, entry in ipairs(M:Entries()) do
    local bundle = entry.bundle
    if (entry.state == "fill" or entry.state == "working") and bundle and bundle[1] and bundle[2] then
      return { { item = bundle[1], count = bundle[2] } }
    end
  end
  return {}
end) end
if C.RegisterHelp then C:RegisterHelp("favor", { TR["Merchant's Favor follows crates, writs and labels from your bags to the turn-in."],
  TR["The arrow points to the next hand-in when Merchant's Favor has the focus."],
  TR["/fennick why shows what it is waiting for."] }, "favor") end
C:RegisterWizardPages("favor", { { TR["Merchant's Favor"], function()
  local c = M:Camp(); return TR:F("Crates, writs and labels in your bags are tracked: what to fill, what to start, objectives, and where to turn in.%s", (c and (TR:F("\nYour camp: %s (%s).", c.name, c.npc)) or "")) end, {} } })
for _, ev in ipairs({ "BAG_UPDATE_DELAYED", "QUEST_ACCEPTED", "QUEST_TURNED_IN", "QUEST_LOG_UPDATE", "UPDATE_FACTION", "CURRENCY_DISPLAY_UPDATE" }) do   -- P2-21
  C:On(ev, function(e, a1) M.dirty = true; C.dirty = true; if e == "QUEST_TURNED_IN" then M:TurnedIn(a1) end end) end
-- map pins (Core 1.5 broker): your faction's Merchant's Favor camp quartermaster
if C.PublishMapPins then C:PublishMapPins("favor", function(map)
  local f = UnitFactionGroup and UnitFactionGroup("player"); local c = M.CAMPS and M.CAMPS[f and f:sub(1, 1) or ""]
  if c and c.z == map then return { { cat = "vendor", name = c.npc, x = c.x / 100, y = c.y / 100, note = c.name } } end
  return {} end) end

if C.RegisterOpportunityProvider then C:RegisterOpportunityProvider("favor", function()
  local out = {}
  for _, e in ipairs(M:Entries()) do
    if e.state == "ready" and e.point and (e.it.k == "sealed" or M.WRIT_LOC_CONFIRMED) then
      out[#out+1] = { id = tostring(e.id), label = e.line, point = e.point }
    end
  end
  return out
end) end
