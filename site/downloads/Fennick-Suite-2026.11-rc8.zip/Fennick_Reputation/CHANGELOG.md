# Fennick Reputation: changelog

All notable changes, newest first. Dates are month and year only.

## 1.2.3 (October 2026)
- /fennick rep help prints a few lines of help.
- The per-faction on/off switches now sit behind "More settings" in the Reputation section, so the settings list stays short.

## 1.2.2 (October 2026)
- Reputation turn-in quest givers show on Fennick's Cartographer (finished quests and low-level ones can be hidden there).

## 1.2.1 (October 2026)
- New in-game icon (window header, AddOns list). Cosmetic only.

## 1.2.0 (October 2026)
- Darkmoon Faire dates are marked "unconfirmed date" until checked in game; after the last known week it points to the in-game calendar (tested into 2027). Forever factions are no longer advertised before their data is confirmed. One-line summary in setup.

## 1.1.0 (October 2026)
- Multi-language: machine-translated text (labelled in Settings and setup) for German, French, Spanish, Italian, Portuguese (BR), Russian, Korean and Chinese (Simplified/Traditional); English text, fonts and slash commands unchanged; names from the game client by ID.

## 1.0.2 (October 2026)
- Per-item counts for multi-item turn-ins, calendar hint after the faire schedule, Unskip all, 'not confirmed' note once per quest, focus here-and-now.

Suite-wide notes: https://github.com/Dagodeiwos/fennick-releases/blob/main/CHANGELOG.md
