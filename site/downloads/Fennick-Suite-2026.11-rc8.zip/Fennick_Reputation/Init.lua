local TR = (Fennick_BEAST and Fennick_BEAST.L) or setmetatable({ F = function(_, f, ...) local ok, s = pcall(string.format, f, ...); return ok and s or f end }, { __index = function(_, k) return k end })   -- l10n (Core C.L)
if not (Fennick_BEAST and (Fennick_BEAST.API or 1) >= 3) then   -- P1-1: refuse cleanly on an older Beast Core
  if DEFAULT_CHAT_FRAME then DEFAULT_CHAT_FRAME:AddMessage(TR["|cff33ccffFennick:|r Fennick Reputation needs Fennick's Beast Core 1.2 or newer. Please update Beast Core."]) end
  return
end
-- registration and events (after Data.lua)
local C = Fennick_BEAST
local R = Fennick_REPUTATION
C:RegisterModule(R.module)
local function confirmed(turnin)
  if turnin.u then return false end
  for _, reward in ipairs(turnin.f or {}) do
    if reward[1] == 909 and not R.DMF_CONFIRMED then return false end
  end
  return true
end

if C.RegisterMaterialProvider then C:RegisterMaterialProvider("reputation", function()
  for _, row in ipairs(R:Ready()) do
    local t = row.t
    if confirmed(t) then
      local out = {}
      for k, item in ipairs(t.i or {}) do out[#out+1] = {item=item, count=R:Need(t, k)} end
      return out
    end
  end
  return {}
end) end
if C.RegisterHelp then C:RegisterHelp("reputation", { TR["Reputation lists turn-ins you can do right now with what is in your bags."],
  TR["The arrow points to the nearest turn-in when Reputation has the focus."],
  TR["Settings: switch each faction on or off in /fennick."] }, "rep") end
C:RegisterWizardPages("reputation", { { TR["Reputation"], function()
  return TR["Reputation turn-ins appear only when the items are in your bags. Darkmoon Faire turn-ins follow the faire's schedule. Factions you do not want can be switched off in Settings."] end, {} } })
for _, ev in ipairs({ "BAG_UPDATE_DELAYED", "QUEST_TURNED_IN", "QUEST_LOG_UPDATE", "UPDATE_FACTION", "PLAYER_LEVEL_UP", "ZONE_CHANGED_NEW_AREA" }) do C:On(ev, function() R.dirty = true; C.dirty = true end) end   -- P2-21
-- map pins (Core 1.5 broker): reputation turn-in quest givers; done and level let the map hide finished or low quests
if C.PublishMapPins then C:PublishMapPins("reputation", function(map)
  local f = UnitFactionGroup and UnitFactionGroup("player"); f = f and f:sub(1, 1); local out = {}
  for _, t in ipairs(R.TURNINS or {}) do if t.z == map and t.npc and (t.s == f or t.s == "B") then
    local done = not t.r and C:QuestDone(t.q) or false
    out[#out + 1] = { cat = "qturnin", name = t.npc, x = t.x / 100, y = t.y / 100, note = t.t, done = done, level = t.l } end end
  return out end) end

if C.RegisterOpportunityProvider then C:RegisterOpportunityProvider("reputation", function()
  local out = {}
  for _, s in ipairs(R:Ready()) do
    if s.p and confirmed(s.t) then
      out[#out+1] = { id = tostring(s.id), label = s.t.t, point = s.p }
    end
  end
  return out
end) end
