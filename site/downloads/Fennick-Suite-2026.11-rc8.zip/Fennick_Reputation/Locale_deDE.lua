-- Fennick_Reputation deDE strings. Machine translation draft (labelled in-game) unless the line ends with "-- reviewed".
-- Keys are the English text; keep %s/%d/%.1f, |c...|r colour codes, |T...|t icons, \n and /commands as they are.
-- Edit the right-hand side only. See CONTRIBUTING-TRANSLATIONS.md.
local C = Fennick_BEAST
if not (C and C.L and C.L.Locale and C.L:Locale() == "deDE") then return end
C:AddTranslations("deDE", {
  [" (unconfirmed date)"] = " (nicht bestätigtes Datum)",
  [" to %s"] = " bis %s",
  ["%s more turn-in(s) ready."] = "%s mehr turn-in (s) bereit.",
  ["%s: %s/%s for %s (%s)"] = "%s: %s/%s für %s (%s)",
  ["Darkmoon Faire is in %s this week."] = "Darkmoon Faire ist diese Woche in %s.",
  ["Darkmoon Faire: %s in %s days."] = "Darkmoon Faire: %s in %s Tagen.",
  ["Darkmoon Faire: check the in-game calendar for the next dates."] = "Darkmoon Faire: Überprüfen Sie den Kalender im Spiel für die nächsten Termine.",
  ["No reputation turn-ins in your bags right now."] = "Keine Reputation Turn-ins in Ihren Taschen jetzt.",
  ["Not yet confirmed on Forever: skip it if the quest giver does not offer it."] = "Noch nicht auf Forever bestätigt: Überspringen Sie es, wenn der Questgeber es nicht anbietet.",
  ["OFF"] = "AUS",
  ["ON"] = "AN",
  ["Reputation"] = "Reputation",
  ["Reputation lists turn-ins you can do right now with what is in your bags."] = "Reputation listet turn-ins auf, die sie jetzt mit dem tun können, was in ihren taschen ist.",
  ["Reputation turn-ins appear only when the items are in your bags. Darkmoon Faire turn-ins follow the faire's schedule. Factions you do not want can be switched off in Settings."] = "Reputation Turn-Ins erscheinen nur, wenn die Gegenstände in Ihren Taschen sind. Darkmoon Faire Turn-Ins folgen dem Zeitplan des Faire. Fraktionen, die Sie nicht wollen, können in Einstellungen abgeschaltet werden.",
  ["Reputation: %s turn-in(s) ready"] = "Ruf: %s turn-in(s) ready",
  ["Reputation: turn in %s%s here"] = "Reputation: hier %s%s einschalten",
  ["Settings: switch each faction on or off in /fennick."] = "Einstellungen: Schalten Sie jede Fraktion in /fennick ein oder aus.",
  ["Skipped (%s)"] = "Skipped (%s)",
  ["The arrow points to the nearest turn-in when Reputation has the focus."] = "Der Pfeil zeigt auf die nächste Wende, wenn Reputation den Fokus hat.",
  ["Turn in %s%s%s"] = "Hand in %s%s%s",
  ["Unskip all"] = "Alle wiederherstellen",
  ["rep:%s"] = "Rep:%s",
  ["turn-ins you can do with what is in your bags"] = "Turn-Ins können Sie mit dem tun, was in Ihren Taschen ist",
  ["|cff33ccffFennick:|r Fennick Reputation needs Fennick's Beast Core 1.2 or newer. Please update Beast Core."] = "|cff33ccffFennick: |r Fennick Reputation braucht Fennick's Beast Core 1.2 oder neuer. Bitte aktualisieren Sie Beast Core.",
}, true)
