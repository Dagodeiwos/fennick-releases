-- Fennick_Reputation esES strings. Machine translation draft (labelled in-game) unless the line ends with "-- reviewed".
-- Keys are the English text; keep %s/%d/%.1f, |c...|r colour codes, |T...|t icons, \n and /commands as they are.
-- Edit the right-hand side only. See CONTRIBUTING-TRANSLATIONS.md.
local C = Fennick_BEAST
if not (C and C.L and C.L.Locale and C.L:Locale() == "esES") then return end
C:AddTranslations("esES", {
  [" (unconfirmed date)"] = " (fecha no confirmada)",
  [" to %s"] = " a %s",
  ["%s more turn-in(s) ready."] = "%s más turn-in(s) listo.",
  ["%s: %s/%s for %s (%s)"] = "%s: %s/%s para %s (%s)",
  ["Darkmoon Faire is in %s this week."] = "Darkmoon Faire está en %s esta semana.",
  ["Darkmoon Faire: %s in %s days."] = "Darkmoon Faire: %s en días %s.",
  ["Darkmoon Faire: check the in-game calendar for the next dates."] = "Darkmoon Faire: verifique el calendario del juego para las próximas fechas.",
  ["No reputation turn-ins in your bags right now."] = "No hay cambios de reputación en tus bolsas ahora mismo.",
  ["Not yet confirmed on Forever: skip it if the quest giver does not offer it."] = "Aún no confirmado en Forever: sálvalo si el dador de búsqueda no lo ofrece.",
  ["OFF"] = "NO",
  ["ON"] = "SÍ",
  ["Reputation"] = "Reputación",
  ["Reputation lists turn-ins you can do right now with what is in your bags."] = "Listas de reproducción de turnos que puede hacer ahora mismo con lo que está en sus bolsas.",
  ["Reputation turn-ins appear only when the items are in your bags. Darkmoon Faire turn-ins follow the faire's schedule. Factions you do not want can be switched off in Settings."] = "Los turn-ins de reputación aparecen sólo cuando los artículos están en sus bolsas. Los turnos de Darkmoon Faire siguen el horario de la feria. Las facciones que no quieres pueden ser apagadas en Ajustes.",
  ["Reputation: %s turn-in(s) ready"] = "Reputation: %s turn-in(s) ready",
  ["Reputation: turn in %s%s here"] = "Reputación: gire en %s%s aquí",
  ["Settings: switch each faction on or off in /fennick."] = "Ajustes: cambiar cada facción encendido o apagado en /fennick.",
  ["Skipped (%s)"] = "Saltar (%s)",
  ["The arrow points to the nearest turn-in when Reputation has the focus."] = "La flecha apunta a la entrada más cercana cuando la Reputación tiene el foco.",
  ["Turn in %s%s%s"] = "Mano en %s%s%s",
  ["Unskip all"] = "Restaurar todo",
  ["rep:%s"] = "rep:%s",
  ["turn-ins you can do with what is in your bags"] = "que puedes hacer con lo que hay en tus bolsas",
  ["|cff33ccffFennick:|r Fennick Reputation needs Fennick's Beast Core 1.2 or newer. Please update Beast Core."] = "|cff33ccffFennick:|r Fennick Reputation needs Fennick's Beast Core 1.2 or newer. Por favor, actualice Beast Core.",
}, true)
