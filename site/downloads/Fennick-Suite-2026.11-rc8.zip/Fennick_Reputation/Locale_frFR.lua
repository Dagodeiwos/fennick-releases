-- Fennick_Reputation frFR strings. Machine translation draft (labelled in-game) unless the line ends with "-- reviewed".
-- Keys are the English text; keep %s/%d/%.1f, |c...|r colour codes, |T...|t icons, \n and /commands as they are.
-- Edit the right-hand side only. See CONTRIBUTING-TRANSLATIONS.md.
local C = Fennick_BEAST
if not (C and C.L and C.L.Locale and C.L:Locale() == "frFR") then return end
C:AddTranslations("frFR", {
  [" (unconfirmed date)"] = " (date non confirmée)",
  [" to %s"] = " à %s",
  ["%s more turn-in(s) ready."] = "%s plus d'arrivée(s) prête(s).",
  ["%s: %s/%s for %s (%s)"] = "%s: %s/%s pour %s (%s)",
  ["Darkmoon Faire is in %s this week."] = "Darkmoon Faire est en %s cette semaine.",
  ["Darkmoon Faire: %s in %s days."] = "Darkmoon Faire: %s en %s jours.",
  ["Darkmoon Faire: check the in-game calendar for the next dates."] = "Darkmoon Faire: vérifiez le calendrier en jeu pour les prochaines dates.",
  ["No reputation turn-ins in your bags right now."] = "Pas de réputation dans tes sacs.",
  ["Not yet confirmed on Forever: skip it if the quest giver does not offer it."] = "Pas encore confirmé sur Forever: sautez-le si le donneur de quête ne l'offre pas.",
  ["OFF"] = "DÉSACTIVÉ",
  ["ON"] = "ACTIVÉ",
  ["Reputation"] = "Réputation",
  ["Reputation lists turn-ins you can do right now with what is in your bags."] = "Les listes de réputation s'enclenchent avec ce qui est dans vos sacs.",
  ["Reputation turn-ins appear only when the items are in your bags. Darkmoon Faire turn-ins follow the faire's schedule. Factions you do not want can be switched off in Settings."] = "La réputation n'apparaît que lorsque les objets sont dans vos sacs. Les rancards de Darkmoon Faire suivent le programme de la fête. Les factions que vous ne voulez pas peuvent être désactivées dans les paramètres.",
  ["Reputation: %s turn-in(s) ready"] = "Réputation: %s activation(s) prête(s)",
  ["Reputation: turn in %s%s here"] = "Réputation : tournez %s%s ici",
  ["Settings: switch each faction on or off in /fennick."] = "Paramètres : allumer ou désactiver chaque faction dans /fennick.",
  ["Skipped (%s)"] = "Échec (%s)",
  ["The arrow points to the nearest turn-in when Reputation has the focus."] = "La flèche pointe vers le point d'arrivée le plus proche lorsque la réputation a le focus.",
  ["Turn in %s%s%s"] = "Main dans %s%s%s",
  ["Unskip all"] = "Tout rétablir",
  ["rep:%s"] = "Représentant : %s",
  ["turn-ins you can do with what is in your bags"] = "vous pouvez faire avec ce qui est dans vos sacs",
  ["|cff33ccffFennick:|r Fennick Reputation needs Fennick's Beast Core 1.2 or newer. Please update Beast Core."] = "|cff33ccffFennick:|r Fennick La réputation nécessite Fennick's Beast Core 1.2 ou plus récent. Veuillez mettre à jour Beast Core.",
}, true)
