-- Fennick_Reputation itIT strings. Machine translation draft (labelled in-game) unless the line ends with "-- reviewed".
-- Keys are the English text; keep %s/%d/%.1f, |c...|r colour codes, |T...|t icons, \n and /commands as they are.
-- Edit the right-hand side only. See CONTRIBUTING-TRANSLATIONS.md.
local C = Fennick_BEAST
if not (C and C.L and C.L.Locale and C.L:Locale() == "itIT") then return end
C:AddTranslations("itIT", {
  [" (unconfirmed date)"] = " (data non confermata)",
  [" to %s"] = " a %s",
  ["%s more turn-in(s) ready."] = "%s più turn-in(i) pronto.",
  ["%s: %s/%s for %s (%s)"] = "%s: %s/%s per %s (%s)",
  ["Darkmoon Faire is in %s this week."] = "Darkmoon Faire e' a %s questa settimana.",
  ["Darkmoon Faire: %s in %s days."] = "Darkmoon Faire: %s nei giorni %s.",
  ["Darkmoon Faire: check the in-game calendar for the next dates."] = "Darkmoon Faire: controlla il calendario di gioco per le prossime date.",
  ["No reputation turn-ins in your bags right now."] = "Non c'e' nessuna reputazione nelle tue borse in questo momento.",
  ["Not yet confirmed on Forever: skip it if the quest giver does not offer it."] = "Non ancora confermato su Forever: saltalo se il ricercatore non lo offre.",
  ["OFF"] = "OFF",
  ["ON"] = "ON",
  ["Reputation"] = "Reputazione",
  ["Reputation lists turn-ins you can do right now with what is in your bags."] = "La reputazione elenca i turn-in che puoi fare in questo momento con ciò che è nelle tue borse.",
  ["Reputation turn-ins appear only when the items are in your bags. Darkmoon Faire turn-ins follow the faire's schedule. Factions you do not want can be switched off in Settings."] = "I turn-in di reputazione appaiono solo quando gli elementi sono nelle tue borse. I turn-in di Darkmoon Faire seguono il programma del faire. Le fazioni che non vuoi possono essere disattivate in Impostazioni.",
  ["Reputation: %s turn-in(s) ready"] = "Reputazione: %s turn-in(s) pronto",
  ["Reputation: turn in %s%s here"] = "Reputazione: girare in %s%s qui",
  ["Settings: switch each faction on or off in /fennick."] = "Impostazioni: attivare o disattivare ogni fazione in /fennick.",
  ["Skipped (%s)"] = "Skipped (%s)",
  ["The arrow points to the nearest turn-in when Reputation has the focus."] = "La freccia punta al rientro più vicino quando Reputation ha il fuoco.",
  ["Turn in %s%s%s"] = "Guida in %s%s%s",
  ["Unskip all"] = "Ripristina tutti",
  ["rep:%s"] = "rep:%s",
  ["turn-ins you can do with what is in your bags"] = "si può fare con ciò che è nelle tue borse",
  ["|cff33ccffFennick:|r Fennick Reputation needs Fennick's Beast Core 1.2 or newer. Please update Beast Core."] = "|cff33ccffFennick:|r Fennick Reputazioni Fennick's Beast Core 1.2 o più recente. Si prega di aggiornare Beast Core.",
}, true)
