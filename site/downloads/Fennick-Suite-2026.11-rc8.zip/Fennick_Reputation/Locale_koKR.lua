-- Fennick_Reputation koKR strings. Machine translation draft (labelled in-game) unless the line ends with "-- reviewed".
-- Keys are the English text; keep %s/%d/%.1f, |c...|r colour codes, |T...|t icons, \n and /commands as they are.
-- Edit the right-hand side only. See CONTRIBUTING-TRANSLATIONS.md.
local C = Fennick_BEAST
if not (C and C.L and C.L.Locale and C.L:Locale() == "koKR") then return end
C:AddTranslations("koKR", {
  [" (unconfirmed date)"] = " (확인 된 날짜)",
  [" to %s"] = " %s에",
  ["%s more turn-in(s) ready."] = "%s 더 턴 인 (s) 준비.",
  ["%s: %s/%s for %s (%s)"] = "%1$s: %4$s (%5$s)를 위한 %2$s/%3$s",
  ["Darkmoon Faire is in %s this week."] = "Darkmoon Faire는 이번 주 %s에 있습니다.",
  ["Darkmoon Faire: %s in %s days."] = "Darkmoon Faire : %2$s 일 %1$s.",
  ["Darkmoon Faire: check the in-game calendar for the next dates."] = "Darkmoon Faire : 다음 날짜에 게임 캘린더를 확인하십시오.",
  ["No reputation turn-ins in your bags right now."] = "당신의 부대에 있는 명성 회전에서 지금.",
  ["Not yet confirmed on Forever: skip it if the quest giver does not offer it."] = "Forever에서 아직 확인되지 않음 : quest giver가 제공하지 않는 경우 건너뛰십시오.",
  ["OFF"] = "끔",
  ["ON"] = "켬",
  ["Reputation"] = "이름 *",
  ["Reputation lists turn-ins you can do right now with what is in your bags."] = "Reputation lists turn-ins you can do right now with what is in your bags.",
  ["Reputation turn-ins appear only when the items are in your bags. Darkmoon Faire turn-ins follow the faire's schedule. Factions you do not want can be switched off in Settings."] = "평판 턴 인은 가방에 아이템이있을 때만 나타납니다. Darkmoon Faire Turn-ins는 Faire의 일정을 따릅니다. 설정에서 전환 할 수없는 반응.",
  ["Reputation: %s turn-in(s) ready"] = "평판: %s turn-in(s) 준비",
  ["Reputation: turn in %s%s here"] = "명성: %s%s에서 여기로 돌기",
  ["Settings: switch each faction on or off in /fennick."] = "설정: /fennick에서 각 사실을 전환합니다.",
  ["Skipped (%s)"] = "스킵 (%s)",
  ["The arrow points to the nearest turn-in when Reputation has the focus."] = "Reputation이 초점이있을 때 가장 가까운 턴 인에 화살표 점.",
  ["Turn in %s%s%s"] = "%s%s%s에서 손",
  ["Unskip all"] = "모두 복원",
  ["rep:%s"] = "담당자: %s",
  ["turn-ins you can do with what is in your bags"] = "가방에 어떤 것을 할 수 있습니까?",
  ["|cff33ccffFennick:|r Fennick Reputation needs Fennick's Beast Core 1.2 or newer. Please update Beast Core."] = "|cff33ccffFennick: |r Fennick 평판은 Fennick's Beast Core 1.2 또는 더 새로운 필요. Beast Core 업데이트",
}, true)
