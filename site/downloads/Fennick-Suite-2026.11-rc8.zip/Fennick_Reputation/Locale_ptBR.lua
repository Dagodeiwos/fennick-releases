-- Fennick_Reputation ptBR strings. Machine translation draft (labelled in-game) unless the line ends with "-- reviewed".
-- Keys are the English text; keep %s/%d/%.1f, |c...|r colour codes, |T...|t icons, \n and /commands as they are.
-- Edit the right-hand side only. See CONTRIBUTING-TRANSLATIONS.md.
local C = Fennick_BEAST
if not (C and C.L and C.L.Locale and C.L:Locale() == "ptBR") then return end
C:AddTranslations("ptBR", {
  [" (unconfirmed date)"] = " (data não confirmada)",
  [" to %s"] = " Para %s",
  ["%s more turn-in(s) ready."] = "%s mais pronto.",
  ["%s: %s/%s for %s (%s)"] = "%s: %s/%s para %s (%s)",
  ["Darkmoon Faire is in %s this week."] = "Darkmoon Faire está no %s esta semana.",
  ["Darkmoon Faire: %s in %s days."] = "%s em dias %s.",
  ["Darkmoon Faire: check the in-game calendar for the next dates."] = "Darkmoon Faire: verifique o calendário do jogo para as próximas datas.",
  ["No reputation turn-ins in your bags right now."] = "Nenhuma reputação entra em suas malas agora.",
  ["Not yet confirmed on Forever: skip it if the quest giver does not offer it."] = "Ainda não confirmado em Forever: pule se o doador não oferecer.",
  ["OFF"] = "DESLIGADO",
  ["ON"] = "LIGADO",
  ["Reputation"] = "Reputação",
  ["Reputation lists turn-ins you can do right now with what is in your bags."] = "Reputação lista turnos que você pode fazer agora com o que está em suas malas.",
  ["Reputation turn-ins appear only when the items are in your bags. Darkmoon Faire turn-ins follow the faire's schedule. Factions you do not want can be switched off in Settings."] = "Reputação aparece apenas quando os itens estão em suas malas. Darkmoon Faire aparece seguindo a agenda da Fada. Fações que você não quer podem ser desligadas em Configurações.",
  ["Reputation: %s turn-in(s) ready"] = "Reputação: %s Vire-se, pronto.",
  ["Reputation: turn in %s%s here"] = "Reputação: entregue o %s%s aqui.",
  ["Settings: switch each faction on or off in /fennick."] = "Configurações: ligar ou desligar cada facção no /fennick.",
  ["Skipped (%s)"] = "Saltou (%s)",
  ["The arrow points to the nearest turn-in when Reputation has the focus."] = "A flecha aponta para a curva mais próxima quando Reputação tem o foco.",
  ["Turn in %s%s%s"] = "Mão em %s%s%s",
  ["Unskip all"] = "Restaurar todos",
  ["rep:%s"] = "REP:%s",
  ["turn-ins you can do with what is in your bags"] = "você pode fazer com o que está em suas malas",
  ["|cff33ccffFennick:|r Fennick Reputation needs Fennick's Beast Core 1.2 or newer. Please update Beast Core."] = "|cff33ccffFennick: |r Fennick A reputação precisa de Fennick's Beast Core 1.2 ou mais recente. Por favor, atualize o Beast Core.",
}, true)
