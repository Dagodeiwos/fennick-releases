-- Fennick_Reputation ruRU strings. Machine translation draft (labelled in-game) unless the line ends with "-- reviewed".
-- Keys are the English text; keep %s/%d/%.1f, |c...|r colour codes, |T...|t icons, \n and /commands as they are.
-- Edit the right-hand side only. See CONTRIBUTING-TRANSLATIONS.md.
local C = Fennick_BEAST
if not (C and C.L and C.L.Locale and C.L:Locale() == "ruRU") then return end
C:AddTranslations("ruRU", {
  [" (unconfirmed date)"] = " (неподтвержденная дата)",
  [" to %s"] = " В %s",
  ["%s more turn-in(s) ready."] = "%s более готов(ы)",
  ["%s: %s/%s for %s (%s)"] = "%s: %s/%s для %s (%s)",
  ["Darkmoon Faire is in %s this week."] = "Darkmoon Faire появится в %s на этой неделе",
  ["Darkmoon Faire: %s in %s days."] = "Darkmoon Faire: %s в дни %s",
  ["Darkmoon Faire: check the in-game calendar for the next dates."] = "Darkmoon Faire: проверьте игровой календарь на следующие даты.",
  ["No reputation turn-ins in your bags right now."] = "Никакой репутации в твоих сумках прямо сейчас.",
  ["Not yet confirmed on Forever: skip it if the quest giver does not offer it."] = "Пока не подтверждено на Forever: пропустите его, если квестодатель не предлагает его.",
  ["OFF"] = "ВЫКЛ",
  ["ON"] = "ВКЛ",
  ["Reputation"] = "репутация",
  ["Reputation lists turn-ins you can do right now with what is in your bags."] = "Список репутаций, которые вы можете сделать прямо сейчас с тем, что в ваших сумках.",
  ["Reputation turn-ins appear only when the items are in your bags. Darkmoon Faire turn-ins follow the faire's schedule. Factions you do not want can be switched off in Settings."] = "Репутационные включения появляются только тогда, когда предметы находятся в сумках. Повороты Darkmoon Faire следуют расписанию ярмарки. Фракции, которые вы не хотите, можно отключить в настройках.",
  ["Reputation: %s turn-in(s) ready"] = "Оригинальное название: %s Turn-in(s) ready",
  ["Reputation: turn in %s%s here"] = "Оригинальное название: Turn in %s%s here",
  ["Settings: switch each faction on or off in /fennick."] = "Настройки: включите или выключите каждую фракцию в /fennick.",
  ["Skipped (%s)"] = "Пропущенный (%s)",
  ["The arrow points to the nearest turn-in when Reputation has the focus."] = "Стрелка указывает на ближайший поворот, когда Репутация имеет фокус.",
  ["Turn in %s%s%s"] = "Исполнитель: %s%s%s",
  ["Unskip all"] = "Вернуть все",
  ["rep:%s"] = "Исполнитель: %s",
  ["turn-ins you can do with what is in your bags"] = "Вы можете сделать с тем, что в ваших сумках",
  ["|cff33ccffFennick:|r Fennick Reputation needs Fennick's Beast Core 1.2 or newer. Please update Beast Core."] = "|cff33ccffFennick: |r Fennick Репутация нуждается в Fennick's Beast Core 1.2 или новее. Обновление Beast Core.",
}, true)
