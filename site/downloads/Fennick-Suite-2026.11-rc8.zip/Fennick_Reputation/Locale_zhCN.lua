-- Fennick_Reputation zhCN strings. Machine translation draft (labelled in-game) unless the line ends with "-- reviewed".
-- Keys are the English text; keep %s/%d/%.1f, |c...|r colour codes, |T...|t icons, \n and /commands as they are.
-- Edit the right-hand side only. See CONTRIBUTING-TRANSLATIONS.md.
local C = Fennick_BEAST
if not (C and C.L and C.L.Locale and C.L:Locale() == "zhCN") then return end
C:AddTranslations("zhCN", {
  [" (unconfirmed date)"] = " (未确认日期)",
  [" to %s"] = " 至%s为止",
  ["%s more turn-in(s) ready."] = "%s 更多启动准备 。",
  ["%s: %s/%s for %s (%s)"] = "%s: %s/%s代表%s(%s).",
  ["Darkmoon Faire is in %s this week."] = "暗月仙女这周在%s.",
  ["Darkmoon Faire: %s in %s days."] = "暗月仙女:%2$s天下的%1$s.",
  ["Darkmoon Faire: check the in-game calendar for the next dates."] = "暗月仙人:检查下个日期的游戏中日历.",
  ["No reputation turn-ins in your bags right now."] = "你现在包里没有名声",
  ["Not yet confirmed on Forever: skip it if the quest giver does not offer it."] = "尚未确认在永远: 如果求生者不提供, 请跳过它 。",
  ["OFF"] = "关",
  ["ON"] = "开",
  ["Reputation"] = "名誉",
  ["Reputation lists turn-ins you can do right now with what is in your bags."] = "名人名单显示你现在可以用你包里的东西",
  ["Reputation turn-ins appear only when the items are in your bags. Darkmoon Faire turn-ins follow the faire's schedule. Factions you do not want can be switched off in Settings."] = "只有在包里有物品时才会出现名声 暗月仙女转身跟随仙女时刻表. 在设置中可以关闭您不希望的关联 。",
  ["Reputation: %s turn-in(s) ready"] = "代表: %s 已就绪",
  ["Reputation: turn in %s%s here"] = "信誉:自首 %s%s 这里",
  ["Settings: switch each faction on or off in /fennick."] = "设置: 在 /fennick 中切换每个派别 。",
  ["Skipped (%s)"] = "跳过( %s)",
  ["The arrow points to the nearest turn-in when Reputation has the focus."] = "箭头指向最接近的切入点,当裁量有焦点时.",
  ["Turn in %s%s%s"] = "转身 %s%s%s",
  ["Unskip all"] = "全部恢复",
  ["rep:%s"] = "代表:%s",
  ["turn-ins you can do with what is in your bags"] = "转身就可以用你包里的东西",
  ["|cff33ccffFennick:|r Fennick Reputation needs Fennick's Beast Core 1.2 or newer. Please update Beast Core."] = "|cff33ccff费尼克:|r Fennick 信誉需要 Fennick's Beast Core 1.2 或更新。 请更新 Beast Core.",
}, true)
