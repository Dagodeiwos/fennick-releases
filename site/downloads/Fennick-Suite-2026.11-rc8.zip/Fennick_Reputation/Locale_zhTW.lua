-- Fennick_Reputation zhTW strings. Machine translation draft (labelled in-game) unless the line ends with "-- reviewed".
-- Keys are the English text; keep %s/%d/%.1f, |c...|r colour codes, |T...|t icons, \n and /commands as they are.
-- Edit the right-hand side only. See CONTRIBUTING-TRANSLATIONS.md.
local C = Fennick_BEAST
if not (C and C.L and C.L.Locale and C.L:Locale() == "zhTW") then return end
C:AddTranslations("zhTW", {
  [" (unconfirmed date)"] = " (未确定日期)",
  [" to %s"] = " 至 %s",
  ["%s more turn-in(s) ready."] = "%s 更多啟動就绪 。",
  ["%s: %s/%s for %s (%s)"] = "%1$s: %4$s( %5$s)的 %2$s/ %3$s",
  ["Darkmoon Faire is in %s this week."] = "黑月仙子這周在%s",
  ["Darkmoon Faire: %s in %s days."] = "暗月仙人:%2$s天中的%1$s.",
  ["Darkmoon Faire: check the in-game calendar for the next dates."] = "暗月仙:檢查下一個日期的遊戲中行事曆 。",
  ["No reputation turn-ins in your bags right now."] = "現在你的包裡沒有名聲",
  ["Not yet confirmed on Forever: skip it if the quest giver does not offer it."] = "在 永 遠 的 日 子 上 還 沒 有 證 實 . 若 求 求 者 不 提供 、 就 跳 過 罷",
  ["OFF"] = "關",
  ["ON"] = "開",
  ["Reputation"] = "信誉",
  ["Reputation lists turn-ins you can do right now with what is in your bags."] = "名人名單上寫著你現在可以用你包裡的東西來做交換",
  ["Reputation turn-ins appear only when the items are in your bags. Darkmoon Faire turn-ins follow the faire's schedule. Factions you do not want can be switched off in Settings."] = "只有那些東西在你的包裡時 才出現聲譽轉折 黑月仙女的上場時間跟隨仙女的行程 您不想要的檔案可以在設定中關閉 。",
  ["Reputation: %s turn-in(s) ready"] = "認證: %s 已就绪",
  ["Reputation: turn in %s%s here"] = "聲望: 交換 %s%s 這裡",
  ["Settings: switch each faction on or off in /fennick."] = "設定 : 在 /fennick 中切換每一個片段 。",
  ["Skipped (%s)"] = "跳過( %s )",
  ["The arrow points to the nearest turn-in when Reputation has the focus."] = "箭頭指向最接近的轉角, 當重點是重點 。",
  ["Turn in %s%s%s"] = "轉身 %s%s%s",
  ["Unskip all"] = "全部恢復",
  ["rep:%s"] = "代表:%s",
  ["turn-ins you can do with what is in your bags"] = "你可以把包裡的東西轉進去",
  ["|cff33ccffFennick:|r Fennick Reputation needs Fennick's Beast Core 1.2 or newer. Please update Beast Core."] = "|cff33ccffFennick: |r Fennick 聲望需要 Fennick's Beast Core 1.2 或更新 。 請更新 Beast Core 。",
}, true)
