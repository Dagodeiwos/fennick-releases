local TR = (Fennick_BEAST and Fennick_BEAST.L) or setmetatable({ F = function(_, f, ...) local ok, s = pcall(string.format, f, ...); return ok and s or f end }, { __index = function(_, k) return k end })   -- l10n (Core C.L)
if not (Fennick_BEAST and (Fennick_BEAST.API or 1) >= 3) then return end   -- P1-1 file-top guard: needs Beast Core 1.2 (API 3)
-- Fennick Reputation (module "reputation" for Fennick's Beast Core). Item turn-ins only: a step appears when the items
-- are in your bags, you meet the level/standing/prerequisites, and (Darkmoon Faire) the faire is in town.
local C = Fennick_BEAST
local R = { TURNINS = {}, FACTIONS = {} }
Fennick_REPUTATION = R
local M = { key = "reputation", label = "Reputation", priority = 20, minAPI = 3, needs = "1.2", icon = "Interface\\AddOns\\Fennick_Reputation\\Media\\Fennick_Reputation", summary = TR["turn-ins you can do with what is in your bags"] }   -- M-P2-9
R.module = M
local function side() local f = UnitFactionGroup and UnitFactionGroup("player"); return f == "Alliance" and "A" or f == "Horde" and "H" or "?" end
-- Darkmoon Faire: dated weeks (foreverchanges.pro schedule, Monday-Sunday; setup starts the Friday before) and the zone.
-- M-P1-5: UNCONFIRMED in game (R.DMF_CONFIRMED=false). Forever's later weeks are not published and the two known weeks do not
-- follow one rule, so no dates are guessed: after the last dated week the window points to the in-game calendar.
R.DMF = { { 2026, 11, 9, "Elwynn Forest", 1429 }, { 2026, 12, 7, "Mulgore", 1412 } }
-- l10n: zone names from the client by map ID (the English names are only the fallback)
do local CM = C_Map; for _, w in ipairs(R.DMF) do local info = CM and CM.GetMapInfo and CM.GetMapInfo(w[5]); if type(info) == "table" and type(info.name) == "string" then w[4] = info.name end end end
R.DMF_ZONES = { [1429] = true, [1412] = true }
R.DMF_CONFIRMED = false
local function dayNum(y, m, d) return time({ year = y, month = m, day = d, hour = 12 }) / 86400 end
-- P2-12: realm date (not the PC clock). After the last dated week the window says "check the in-game calendar".
function R:Faire()
  if not (date and time) then return end
  local t = C:ServerDate(); if not t then return end; local today = dayNum(t.year, t.month, t.day)
  for _, w in ipairs(self.DMF) do local s = dayNum(w[1], w[2], w[3]); if today >= s and today <= s + 6 then return w[5], w[4], true end end
  for _, w in ipairs(self.DMF) do local s = dayNum(w[1], w[2], w[3]); if today < s then return nil, w[4], false, s - today end end
  return nil, nil, false, nil, true   -- schedule ran out
end
local function isDMF(t) for _, f in ipairs(t.f or {}) do if f[1] == 909 then return true end end end
function R:Eligible(t)
  local s = side(); if t.s ~= "B" and t.s ~= s then return false end
  if (UnitLevel("player") or 0) < (t.l or 1) then return false end
  if not t.r and C:QuestDone(t.q) then return false end
  for _, p in ipairs(t.p or {}) do if not C:QuestDone(p) then return false end end
  if t.mn then local v = C:RepValue(t.mn[1]); if v == nil or v < t.mn[2] then return false end end
  if t.mx then local v = C:RepValue(t.mx[1]); if v == nil or v >= t.mx[2] then return false end end
  local off = C:ModDB("reputation").off or {}; for _, f in ipairs(t.f or {}) do if off[f[1]] then return false end end
  return true
end
-- P2-7: every item needs its own count (t.ic, from the objective text); single-item turn-ins use t.c. A multi-item
-- turn-in whose count is not stated for an item needs at least t.c of it (never "ready" with 1 of each).
function R:Need(t, k) if t.ic and t.ic[k] then return t.ic[k] end; return t.c or 1 end
function R:Have(t)
  for k, i in ipairs(t.i or {}) do if C:ItemCount(i) < self:Need(t, k) then return false end end
  return #(t.i or {}) > 0
end
-- where to go: the faire's current zone for Darkmoon turn-ins, else the first known spot
function R:Point(t)
  if isDMF(t) then
    local z = self:Faire(); if not z then return nil end
    for _, a in ipairs(t.alt or {}) do if a[1] == z then return { z = a[1], x = a[2], y = a[3] } end end
    return nil
  end
  return t.z and { z = t.z, x = t.x, y = t.y } or nil
end
local cache, stamp = nil, -1
function R:Ready()
  local now = GetTime and math.floor(GetTime() / 2) or 0
  if cache and stamp == now and not R.dirty then return cache end
  stamp, R.dirty = now, false
  local out, here = {}, C:PlayerPos()
  for _, t in ipairs(self.TURNINS) do
    if self:Eligible(t) and self:Have(t) then local p = self:Point(t); if p or not isDMF(t) then out[#out + 1] = { t = t, p = p, id = t.q, here = p ~= nil and p.z == here } end end
  end
  table.sort(out, function(a, b) if a.here ~= b.here then return a.here end return a.t.q < b.t.q end)
  local sk = C:ModDB("reputation").skipped or {}
  local keep = {}; for _, s in ipairs(out) do if not sk[s.id] then keep[#keep + 1] = s end end
  cache = keep; return keep
end
local function fname(fid) for _, f in ipairs(R.FACTIONS) do if f[1] == fid then return f[2] end end; return (GetFactionInfoByID and GetFactionInfoByID(fid)) or "reputation" end
function R:RepText(t)
  local out = {}
  for _, f in ipairs(t.f or {}) do
    local st, v, max = C:Standing(f[1])
    out[#out + 1] = "+" .. f[2] .. " " .. fname(f[1]) .. (st and ("  (" .. C.STANDING[st] .. " " .. v .. "/" .. max .. ")") or "")
    if #out >= 2 then break end
  end
  return table.concat(out, "\n")
end
function M:HasStep() return #R:Ready() > 0 end
function M:StepKey() local s = R:Ready()[1]; return s and (TR:F("rep:%s", s.id)) end
function M:View()
  local list = R:Ready(); local s = list[1]
  local v = { title = "Reputation", guidance = {} }
  local z, zn, open, days, ended = R:Faire()
  local unc = not R.DMF_CONFIRMED and TR[" (unconfirmed date)"] or ""   -- M-P1-5: dates not yet checked in game
  if open then v.guidance[#v.guidance + 1] = TR:F("Darkmoon Faire is in %s this week.", zn) .. unc elseif zn and days then v.guidance[#v.guidance + 1] = TR:F("Darkmoon Faire: %s in %s days.", zn, math.floor(days + 0.5)) .. unc
  elseif ended then v.guidance[#v.guidance + 1] = TR["Darkmoon Faire: check the in-game calendar for the next dates."] end
  local nsk = 0; for _ in pairs(C:ModDB("reputation").skipped or {}) do nsk = nsk + 1 end
  if nsk > 0 then v.backLabel = TR["Unskip all"]; v.skippedN = nsk end   -- N-3
  if not s then
    v.line = TR["No reputation turn-ins in your bags right now."]
    local n = 0
    for _, t in ipairs(R.TURNINS) do
      if n < 2 and R:Eligible(t) and not isDMF(t) and t.c and C:ItemCount(t.i[1]) > 0 then
        n = n + 1; v.guidance[#v.guidance + 1] = TR:F("%s: %s/%s for %s (%s)", t.n[1], C:ItemCount(t.i[1]), R:Need(t, 1), t.t, (t.npc or "?"))
      end
    end
    return v
  end
  local t = s.t
  v.line = TR:F("Turn in %s%s%s", t.t, (t.npc and (TR:F(" to %s", t.npc)) or ""), C:Where(s.p))
  v.obj = R:RepText(t)
  R.toldU = R.toldU or {}   -- N-6: the "not confirmed" note shows for one turn-in session per quest, not on every view
  if t.u and (not R.toldU[t.q] or GetTime() - R.toldU[t.q] < 300) then R.toldU[t.q] = R.toldU[t.q] or GetTime(); v.guidance[#v.guidance + 1] = TR["Not yet confirmed on Forever: skip it if the quest giver does not offer it."] end
  if #list > 1 then v.guidance[#v.guidance + 1] = TR:F("%s more turn-in(s) ready.", (#list - 1)) end
  if v.skippedN then v.guidance[#v.guidance + 1] = TR:F("Skipped (%s)", v.skippedN) end
  v.point, v.label = s.p, t.npc or t.t
  return v
end
function M:Rider()
  local here = C:PlayerPos(); local list = R:Ready()
  for _, s in ipairs(list) do if here and s.p and s.p.z == here then return TR:F("Reputation: turn in %s%s here", s.t.t, (s.t.npc and (TR:F(" to %s", s.t.npc)) or "")) end end
  if #list > 0 then return TR:F("Reputation: %s turn-in(s) ready", #list) end   -- P1-5: something ready anywhere
end
-- P1-5: a turn-in in this zone can take Auto focus while you stand still
function M:HereNow() local here = C:PlayerPos(); if not here then return false end
  for _, s in ipairs(R:Ready()) do if s.p and s.p.z == here then return true end end; return false end
function M:Skip() local s = R:Ready()[1]; if s then C:SkipStep("reputation", s); R.dirty = true end end
function M:Back() C:UnskipAll("reputation"); R.dirty = true end
function M:Status(tt) tt:AddLine(TR:F("Reputation: %s turn-in(s) ready", #R:Ready()), 1, 1, 1) end
function M:Toggle() C:ToggleWindow() end
-- Settings rows (shown in the Core settings window): switch factions on or off (behind "More settings": one row per faction)
function M:SettingsRows()
  local rows = {}
  for _, f in ipairs(R.FACTIONS) do
    rows[#rows + 1] = { function() local off = C:ModDB("reputation").off or {}; return "   " .. f[2] .. " " .. (off[f[1]] and "|cffff5555" .. TR["OFF"] .. "|r" or "|cff55ff55" .. TR["ON"] .. "|r") end,
      function() local d = C:ModDB("reputation"); d.off = d.off or {}; d.off[f[1]] = not d.off[f[1]] or nil; R.dirty = true end, adv = true }
  end
  return rows
end
