# Fennick Rest: changelog

All notable changes, newest first. Dates are month and year only.

## 1.2.4 (October 2026)
- /fennick rest help prints a few lines of help.

## 1.2.3 (October 2026)
- Friendly innkeepers show on Fennick's Cartographer when installed. More translations filled in.

## 1.2.2 (October 2026)
- New in-game icon (window header, AddOns list). Cosmetic only.

## 1.2.1 (October 2026)
- The sleeping-bag reminder is a light notification (brief on-screen message and one chat line, once per opportunity, whichever module has focus). New setting to turn it off; optional sound cue, off by default.

## 1.2.0 (October 2026)
- One-line summary in setup and /beast help; sleeping-bag reminder ownership documented and tested (Guidepost shows it while it has focus, Rest otherwise).

## 1.1.0 (October 2026)
- Multi-language: machine-translated text (labelled in Settings and setup) for German, French, Spanish, Italian, Portuguese (BR), Russian, Korean and Chinese (Simplified/Traditional); English text, fonts and slash commands unchanged; names from the game client by ID.

## 1.0.1 (October 2026)
- Cached advice, keeps the hearthstone when the route uses it soon, hidden at max level, Core idle clock and events.

Suite-wide notes: https://github.com/Dagodeiwos/fennick-releases/blob/main/CHANGELOG.md
