local TR = (Fennick_BEAST and Fennick_BEAST.L) or setmetatable({ F = function(_, f, ...) local ok, s = pcall(string.format, f, ...); return ok and s or f end }, { __index = function(_, k) return k end })   -- l10n (Core C.L)
if not (Fennick_BEAST and (Fennick_BEAST.API or 1) >= 3) then   -- P1-1: refuse cleanly on an older Beast Core
  if DEFAULT_CHAT_FRAME then DEFAULT_CHAT_FRAME:AddMessage(TR["|cff33ccffFennick:|r Fennick Rest needs Fennick's Beast Core 1.2 or newer. Please update Beast Core."]) end
  return
end
-- registration and events (after Data.lua)
local C = Fennick_BEAST
local R = Fennick_REST
C:RegisterModule(R.module)
if C.RegisterHelp then C:RegisterHelp("rest", { TR["Rest shows your rested XP and reminds you to log out where you rest (inn or city)."],
  TR["Its lines appear in the focus window when nothing else needs you; /fennick why shows the rested gain measured at login."],
  TR["Settings: the sleeping bag reminder in /fennick."] }, "rest") end
if C.RegisterCue then C:RegisterCue("restBag", TR["Sleeping bag reminder"], "RAID_WARNING", 8959) end   -- off by default (Core)
-- bag notification check rides Core's 1 s owner re-check (no ticker of our own, P2-21)
local reassess = C.ReassessOwner
function C:ReassessOwner(...) local o = reassess(self, ...); pcall(R.CheckBag, R); return o end
C:RegisterWizardPages("rest", { { TR["Rest"], function()
  return TR["Shows your rested XP, how long until it is full, and where to log out: your hearthstone first, otherwise the nearest friendly inn or capital. Sleeping bag and camp tent reminders appear when they help. Nothing is used for you."] end, {} } })
-- P2-21: events through Core's shared frame (C:On); idle time comes from Core (C.idleSince), no ticker of our own
local function onEvent(ev)
  if ev == "PLAYER_LOGOUT" then pcall(R.Snapshot, R)
  elseif ev == "PLAYER_CAMPING" then R.loggingOut = true; pcall(R.Snapshot, R); pcall(R.CheckBag, R)
  elseif ev == "LOGOUT_CANCEL" or ev == "PLAYER_REGEN_DISABLED" then R.loggingOut = nil
  elseif ev == "PLAYER_ENTERING_WORLD" or ev == "UPDATE_EXHAUSTION" then if C.loaded then pcall(R.Measure, R) end end
  R.adv = nil; C.dirty = true
end
for _, ev in ipairs({ "PLAYER_ENTERING_WORLD", "UPDATE_EXHAUSTION", "PLAYER_UPDATE_RESTING", "PLAYER_LOGOUT", "PLAYER_CAMPING", "LOGOUT_CANCEL", "PLAYER_REGEN_DISABLED" }) do C:On(ev, onEvent) end
-- map pins (Core 1.5 broker): friendly innkeepers. Cartographer draws them first; nothing happens without it.
if C.PublishMapPins then C:PublishMapPins("rest", function(map)
  local f = UnitFactionGroup and UnitFactionGroup("player"); f = f and f:sub(1, 1); local out = {}
  for _, n in ipairs(R.INNS or {}) do if n.z == map and (n.s == f or n.s == "B") then out[#out + 1] = { cat = "inn", name = n.n, x = n.x / 100, y = n.y / 100, note = TR["Innkeeper"] } end end
  return out end) end
