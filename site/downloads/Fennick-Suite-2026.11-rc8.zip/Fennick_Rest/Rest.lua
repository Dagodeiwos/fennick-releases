local TR = (Fennick_BEAST and Fennick_BEAST.L) or setmetatable({ F = function(_, f, ...) local ok, s = pcall(string.format, f, ...); return ok and s or f end }, { __index = function(_, k) return k end })   -- l10n (Core C.L)
if not (Fennick_BEAST and (Fennick_BEAST.API or 1) >= 3) then return end   -- P1-1 file-top guard: needs Beast Core 1.2 (API 3)
-- Fennick Rest (module "rest" for Fennick's Beast Core). Rested XP, where to log out, sleeping bag and camp tent lines.
-- Facts (datamine 70532, cited in REST-MODULE-ASSESSMENT.md):
--   rested accrues 5% of a level per 8 h in an inn or capital (online or offline), a quarter of that logged out elsewhere;
--   cap 150% of a level; the Legacy perk Well Rested raises rate and cap by the same factor (measured here, not assumed).
--   Cozy Sleeping Bag: 1 h cooldown, +1% XP per minute lying in it, 3 stacks, buff 2 h. Camp Tent: raises rested TO 5% of
--   a level after sitting by a campfire; Boosted Rest blocks another tent for 1 h.
-- Only innkeepers friendly to your faction are ever suggested (every ruleset). Nothing is used or cast for you.
local C = Fennick_BEAST
local R = { INNS = {}, CAPITALS = {} }
Fennick_REST = R
local mod = { key = "rest", label = "Rest", priority = 40, minAPI = 3, needs = "1.2", icon = "Interface\\AddOns\\Fennick_Rest\\Media\\Fennick_Rest", summary = TR["rested XP and where to log out"] }   -- M-P2-9
R.module = mod
R.RATE_INN = 0.05 / (8 * 3600)          -- fraction of a level per second, resting
R.OUTSIDE = 0.25                        -- logged out away from an inn or capital
R.CAP = 1.5
R.HEARTH = 6948
R.BAG, R.BAG_BUFF = 211527, 429959
R.TENT, R.BOOSTED, R.CAMPFIRE = 279978, 1229451, 1229739
local function side() local f = UnitFactionGroup and UnitFactionGroup("player"); return f == "Alliance" and "A" or f == "Horde" and "H" or "?" end
function R:DB() return C:ModDB("rest") end
-- measured multiplier from the Well Rested perk (1.00-1.20); 1 until a login measurement says otherwise
function R:Mult() local m = tonumber(self:DB().mult); if m and m >= 0.95 and m <= 1.25 then return m end; return 1 end
function R:Cap() return self.CAP * self:Mult() end
function R:Pool()
  local max = UnitXPMax and UnitXPMax("player") or 0; if max <= 0 then return 0, 0, 0 end
  local ex = GetXPExhaustion and GetXPExhaustion() or 0
  return (ex or 0) / max, ex or 0, max
end
function R:Resting() return IsResting and IsResting() and true or false end
function R:Friendly(i) return i.s == "B" or i.s == side() end
function R:FriendlyInns() local t = {}; for _, i in ipairs(self.INNS) do if self:Friendly(i) then t[#t + 1] = i end end; return t end
-- nearest friendly inn; with Leveling installed, inns in the zones of the next route leg win (no wasted detour)
function R:BestInn(hint)
  self.scans = (self.scans or 0) + 1
  local here = C:PlayerPos(); local best, bd, legBest, ld
  for _, i in ipairs(self:FriendlyInns()) do
    local d = C:Yards(i.z, i.x, i.y)
    if d == nil and here == i.z then d = 1e6 end           -- same map, distance unknown: still a candidate
    if d then
      if not bd or d < bd then best, bd = i, d end
      if hint and hint.zones[i.z] and (not ld or d < ld) then legBest, ld = i, d end
    end
  end
  if legBest and (not bd or ld <= bd + 600) then return legBest, ld, true end
  return best, bd, false
end
function R:RouteHint()
  local L = C:Module("leveling"); if not (L and L.RouteHint) then return end
  local ok, h = pcall(L.RouteHint, L); if ok and type(h) == "table" and type(h.zones) == "table" then return h end
end
function R:Hearth()
  if C:ItemCount(self.HEARTH) <= 0 then return nil end
  return C:ItemCooldown(self.HEARTH), GetBindLocation and GetBindLocation() or nil
end
local function pct(f) return string.format("%d%%", math.floor(f * 100 + 0.5)) end
-- logout advice: { line, point, label }
-- P1-11: the advice (and its inn scan) is cached 2 s; StepKey/View/Rider all read the cache
function R:Advice()
  local now = GetTime and GetTime() or 0
  local cd, bind = self:Hearth()   -- cheap; part of the key so a hearth/bind change shows at once
  local key = tostring(self:Resting()) .. tostring(self.loggingOut) .. tostring(cd and (cd == 0 and 0 or 1)) .. tostring(bind) .. tostring((C:PlayerPos()))
  if self.adv and self.advKey == key and now - (self.advAt or -10) < 2 then return self.adv end
  self.adv, self.advKey, self.advAt = self:AdviceNow(), key, now
  return self.adv
end
function R:AdviceNow()
  if self:Resting() then return { line = TR["Good place to log out: you are resting here."] } end
  local cd, bind = self:Hearth()
  local h0 = self:RouteHint()
  local inn, d, onLeg = self:BestInn(h0)
  local a = {}
  if cd == 0 and bind and h0 and h0.hearthSoon then   -- P2-10: the route plans to use the hearthstone soon; don't spend it on a logout
    a.saveHearth = TR["Keep your hearthstone: your route uses it soon."]; cd = 1
  end
  if cd == 0 and bind then
    a.line = TR:F("Hearth to %s and log out (no travel).", bind)
  elseif cd and cd > 0 then
    a.line = TR:F("Hearthstone ready in %s%s.", C:Duration(cd), (bind and (" (" .. bind .. ")") or ""))
  end
  if inn and not (cd == 0 and bind) then
    a.inn = TR:F("Nearest friendly inn: %s%s%s", (inn.town or inn.n), (onLeg and TR[" (on your next leg)"] or ""), C:Where(inn))
    a.point, a.label = { z = inn.z, x = inn.x, y = inn.y }, inn.town or inn.n
  end
  local h = h0
  if h and not h.nextBind and inn and onLeg and bind and not (inn.town and bind:find(inn.town, 1, true)) then
    a.rebind = TR:F("Bind at %s on your next leg: hearth logouts there cost no travel.", (inn.town or inn.n))
  end
  if not a.line then a.line = a.inn or TR["Log out in a friendly inn or capital for 4x the rested XP."]; a.inn = nil end
  if a.saveHearth then a.rebind = a.saveHearth .. (a.rebind and (" " .. a.rebind) or "") end
  return a
end
-- bag reminder: owned, ready, outside a rest area, out of combat; buff missing or < 15 min; idle or about to log out
function R:BagLine()
  if C:ItemCount(self.BAG) <= 0 or self:Resting() or C:InCombat() then return end
  if (C:ItemCooldown(self.BAG) or 1) > 0 then return end
  local left = C:AuraLeft(self.BAG_BUFF); if left and left >= 900 then return end
  local idle = C.idleSince or self.idleSince   -- P2-21: Core's idle clock (one ticker for every module)
  if not (self.loggingOut or (idle and (GetTime() - idle) >= 60)) then return end
  return TR["Unroll your Cozy Sleeping Bag: lie in it 3 min for +3% XP (2 h)."]
end
-- Sleeping-bag notification (Rest 1.2.1): a light reminder, not a prompt.
-- Rest is the single owner. Not part of any Focus window or rider: a brief on-screen message plus one chat line, whichever
-- module has focus (Guidepost included). Once per eligible opportunity: re-armed only after the conditions lapse.
-- Sound only through Core's "restBag" cue (off by default). Nothing is used for you. Setting: Rest "Sleeping bag reminder".
function R:BagNoteOn() return self:DB().bagNote ~= false end
-- brief on-screen message: one gold line near the top of the screen, gone after 5 s; click-through
function R:Toast(text)
  if not (CreateFrame and UIParent) then return end
  local f = self.toast
  if not f then
    f = CreateFrame("Frame", "Fennick_RestToast", UIParent); f:SetSize(600, 30); f:SetPoint("TOP", UIParent, "TOP", 0, -170)
    f:SetFrameStrata("HIGH"); if f.EnableMouse then f:EnableMouse(false) end
    f.text = C:NewFS(f, "OVERLAY", "GameFontNormalLarge"); f.text:SetPoint("CENTER"); self.toast = f
  end
  f.text:SetText(text); f:SetAlpha(1); f:Show(); self.toastText = text
  local id = (self.toastId or 0) + 1; self.toastId = id
  if C_Timer and C_Timer.After then C_Timer.After(5, function() if R.toastId == id then f:Hide() end end) end
end
function R:CheckBag()
  if R:MaxLevel() or not self:BagNoteOn() then self.bagShown = nil; return false end
  local line = self:BagLine()
  if not line then self.bagShown = nil; return false end
  if self.bagShown then return false end
  self.bagShown = true; self.bagNotes = (self.bagNotes or 0) + 1
  C:Safe("rest bag toast", function() R:Toast(line) end)   -- own small toast (no Blizzard frames touched; taint-free)
  C:Print(line)
  if C.Cue then C:Cue("restBag") end
  return true
end
function R:TentLine()
  local f = self:Pool()
  if f >= 0.05 or C:AuraLeft(self.BOOSTED) then return end
  if not C:AuraLeft(self.CAMPFIRE) then return end
  if C:ItemCount(self.TENT) > 0 and (C:ItemCooldown(self.TENT) or 1) == 0 then return TR["Place your Camp Tent by the campfire and sit 1 min: rested rises to 5% of a level."] end
  return TR["Campfire buff detected; nearby tent availability is unknown."]
end
function R:Lines()
  local f = self:Pool(); local cap = self:Cap(); local rest = self:Resting()
  local t = { head = TR:F("Rested %s of a level (cap %s)", pct(f), pct(cap)), guide = {} }
  local rate = self.RATE_INN * self:Mult()
  if f >= cap - 0.001 then t.guide[#t.guide + 1] = TR["Rested is full."]
  elseif rest then t.guide[#t.guide + 1] = TR:F("Resting here: full in %s.", C:Duration((cap - f) / rate))
  else
    -- N-8: two short lines instead of one dense one
    t.guide[#t.guide + 1] = TR:F("Logged out here: +%s a day, full in %s.", string.format("%.1f%%", rate * self.OUTSIDE * 86400 * 100), C:Duration((cap - f) / (rate * self.OUTSIDE)))
    t.guide[#t.guide + 1] = TR:F("In an inn: +%s a day, full in %s.", string.format("%.0f%%", rate * 86400 * 100), C:Duration((cap - f) / rate))
  end
  return t
end
function R:MaxLevel() local max = (GetMaxPlayerLevel and GetMaxPlayerLevel()) or 60; return (UnitLevel and UnitLevel("player") or 0) >= max end
function mod:HasStep() return not R:MaxLevel() end   -- P2-10: nothing to do at max level
function mod:StepKey() local a = R:Advice(); return TR:F("rest:%s", (a.point and (a.point.z .. ":" .. a.point.x) or a.line)) end
function R:CampLines()
  local out = {}
  if C:AuraLeft(self.CAMPFIRE) then out[#out+1] = TR["Campfire buff detected."] end
  if C.CampObservations then
    local n = 0
    local here = C:PlayerPos()
    for _, r in ipairs(C:CampObservations()) do if here and r.point.z == here then n = n + 1 end end
    if n > 0 then out[#out+1] = TR:F("Group campsite reports in this zone: %d (unverified).", n) end
  end
  return out
end
function mod:View()
  if R:MaxLevel() then return { title = "Rest", line = TR["Max level: rested XP no longer applies."], guidance = R:CampLines(), nav = false } end
  local f = R:Pool(); local L = R:Lines(); local a = R:Advice()
  local v = { title = "Rest", sub = L.head, bar = { value = R:Cap() > 0 and f / R:Cap() or 0, color = { 0.35, 0.55, 1 } }, line = a.line, guidance = {}, nav = false }
  if a.inn then v.obj = a.inn end
  for _, g in ipairs(L.guide) do v.guidance[#v.guidance + 1] = g end
  if a.rebind then v.guidance[#v.guidance + 1] = a.rebind end
  local t = R:TentLine()   -- the sleeping bag is a notification (R:CheckBag), not Focus window guidance
  if t then v.guidance[#v.guidance + 1] = t end
  for _, g in ipairs(R:CampLines()) do v.guidance[#v.guidance+1] = g end
  if C:Owner() == "rest" and a.point then v.point, v.label = a.point, a.label end
  return v
end
-- one line while another module has focus (Auto). The sleeping bag is not a rider: R:CheckBag notifies once (Rest 1.2.1).
function mod:Rider()
  if R:MaxLevel() then return end
  local t = R:TentLine(); if t then return TR:F("Rest: %s", t) end
  if R.loggingOut then local a = R:Advice(); return TR:F("Rest: %s", a.line) end
  -- P2-10: before you log out - idle a minute in a town/inn, or idle with the hearthstone ready
  local idle = C.idleSince or R.idleSince
  if idle and GetTime() - idle >= 60 and not C:InCombat() then
    local cd = R:Hearth(); if R:Resting() or cd == 0 then local a = R:Advice(); return TR:F("Rest: if you log out now: %s", a.line) end
  end
end
-- P1-5 / K-8 (after the P1-11 cache): Rest takes Auto focus temporarily while you are logging out
function mod:HereNow() return R.loggingOut and not R:MaxLevel() or false end
function mod:Status(tt) if R:MaxLevel() then for _, g in ipairs(R:CampLines()) do tt:AddLine(g, 1, 1, 1) end; return end; local L = R:Lines(); tt:AddLine(TR:F("Rest: %s", L.head), 1, 1, 1) end
function mod:Toggle() C:ToggleWindow() end
function mod:WhyLines()
  local d = R:DB(); local t = {}
  if d.lastMeasure then t[#t + 1] = TR:F("Rest: %s", d.lastMeasure) end
  if R:Mult() ~= 1 then t[#t + 1] = TR:F("Rest: measured rested rate x%.2f (Well Rested perk?); cap %s of a level.", R:Mult(), pct(R:Cap())) end
  return t
end
function mod:SettingsRows()
  local function onoff(v) return v and "|cff55ff55" .. TR["ON"] .. "|r" or "|cffff5555" .. TR["OFF"] .. "|r" end
  return { { function() return TR:F("   Sleeping bag reminder %s", onoff(R:BagNoteOn())) end, function() local d = R:DB(); d.bagNote = not R:BagNoteOn(); if d.bagNote then d.bagNote = nil end; R.bagShown = nil end },
    { function() return TR["   Rested gain is measured at each login (see /beast why)"] end, function() end, nil, true } }   -- N-5: plain text
end
-- logout snapshot and the login measurement (shown only in /beast why and debug)
function R:Snapshot()
  local f = self:Pool(); local d = self:DB()
  d.out = { t = time and time() or 0, f = f, rest = self:Resting(), lvl = UnitLevel and UnitLevel("player") or 0 }
end
function R:Measure()
  local d = self:DB(); local o = d.out; if not o or self.measured then return end
  local max = UnitXPMax and UnitXPMax("player") or 0; if max <= 0 then return end
  self.measured = true; d.out = nil
  local now = time and time() or 0; local hrs = (now - (o.t or now)) / 3600
  if (UnitLevel("player") or 0) ~= o.lvl or hrs < 0.25 then return end
  local f = self:Pool(); local got = f - (o.f or 0)
  local base = self.RATE_INN * (o.rest and 1 or self.OUTSIDE) * hrs * 3600
  local capped = f >= self.CAP * 0.99
  d.lastMeasure = TR:F("offline %.1f h %s: rested +%.1f%% of a level (expected %.1f%%)%s.", hrs, o.rest and TR["resting"] or TR["outside"], got * 100, base * 100, capped and TR[", at the cap"] or "")
  if not capped and base > 0.005 and got > 0 then
    local m = got / base; if m < 0.95 or m > 1.25 then return end; d.samples = (d.samples or 0) + 1
    d.mult = ((tonumber(d.mult) or m) * (d.samples - 1) + m) / d.samples
  end
  C:Debug("rest: " .. d.lastMeasure)
end
