local TR = (Fennick_BEAST and Fennick_BEAST.L) or setmetatable({ F = function(_, f, ...) local ok, s = pcall(string.format, f, ...); return ok and s or f end }, { __index = function(_, k) return k end })   -- l10n (Core C.L)
if not (Fennick_BEAST and (Fennick_BEAST.API or 1) >= 3) then return end   -- file-top guard
-- Map adapters, in order: Fennick's Cartographer (when present), then Blizzard's world map and minimap (Map.lua),
-- then any other map add-on that registers through TM:RegisterAdapter. Every adapter is checked for existence and
-- every call is pcall-guarded; an adapter that errors is switched off for the session and the next one is used.
-- Read API (TM.API) lets Cartographer pull Trailmarks points and show them as its own saved pins.
local TM = Fennick_TRAILMARKS; if not TM then return end
TM.adapters = {}
function TM:RegisterAdapter(a)
  if type(a) ~= "table" or type(a.key) ~= "string" or type(a.Available) ~= "function" or type(a.Draw) ~= "function" then return false end
  self.adapters[#self.adapters + 1] = a; table.sort(self.adapters, function(x, y) return (x.order or 50) < (y.order or 50) end); return true
end
-- Cartographer contract (its side): Fennick_CARTOGRAPHER:SetSourcePins(source, list) and :ClearSourcePins(source),
-- list entries { kind, name, x, y, seen, area, map, color = {r,g,b}, label, last, tip }. Names only, never IDs shown.
TM:RegisterAdapter({ key = "cartographer", order = 10,
  -- Cartographer is used only while it is switched on: its own "enabled" setting (it also removes SetSourcePins when off)
  Available = function()
    local K = _G.Fennick_CARTOGRAPHER; if type(K) ~= "table" or type(K.SetSourcePins) ~= "function" then return false end
    if type(K.O) == "function" then local ok, on = pcall(K.O, K, "enabled"); if ok and on == false then return false end end
    return true
  end,
  Draw = function(_, map)
    local K = _G.Fennick_CARTOGRAPHER; local list = {}
    if map then for _, e in ipairs(TM:DrawList(map, "f")) do list[#list + 1] = { kind = e[1], name = e[2], x = e[3], y = e[4], seen = e[5], area = e[6], diameter = e[9], opacity = TM:AreaOpacity(), shade = TM.SHADE[e[1]], map = map, color = TM.COLOR[e[1]], label = TM.LABEL[e[1]], icon = TM:Icon(TM:PinKey(e[1], e[2])), sub = TM:SubFor(e[1], e[2]), last = e[7], tip = TM.EntryOf and TM.EntryOf(e[1], e[2], e[5], e[7], e[6] and e[8] or nil) } end end
    K:SetSourcePins("trailmarks", list)
    if TM:OwnMinimap() then pcall(TM.DrawMinimap, TM) elseif TM.mpins then for _, f in ipairs(TM.mpins) do f:Hide() end end
    return #list
  end,
  Clear = function() local K = _G.Fennick_CARTOGRAPHER; if K and type(K.ClearSourcePins) == "function" then K:ClearSourcePins("trailmarks") end end })
TM:RegisterAdapter({ key = "blizzard", order = 20,
  Available = function() return WorldMapFrame ~= nil or Minimap ~= nil end,
  Draw = function() local a = TM:DrawWorld() or 0; local b = TM:DrawMinimap() or 0; return a + b end,
  Clear = function() for _, f in ipairs(TM.wpins or {}) do f:Hide() end; for _, f in ipairs(TM.mpins or {}) do f:Hide() end end })
-- Cartographer on but its minimap off (or no minimap drawing): Trailmarks keeps drawing its own minimap pins
function TM:OwnMinimap()
  local K = _G.Fennick_CARTOGRAPHER; if type(K) ~= "table" or type(K.MinimapActive) ~= "function" then return true end
  local ok, on = pcall(K.MinimapActive, K); return not (ok and on)
end
TM.failed = {}
function TM:ActiveAdapter()
  for _, a in ipairs(self.adapters) do
    if not self.failed[a.key] then local ok, yes = pcall(a.Available); if ok and yes then return a end end
  end
end
function TM:DrawAll(map)
  for _ = 1, #self.adapters do
    local a = self:ActiveAdapter(); if not a then return 0, nil end
    if self.lastAdapter and self.lastAdapter ~= a and self.lastAdapter.Clear then pcall(self.lastAdapter.Clear) end
    self.lastAdapter = a
    local ok, n = pcall(a.Draw, a, map)
    if ok then return n or 0, a.key end
    self.failed[a.key] = true; if Fennick_BEAST.Debug then Fennick_BEAST:Debug("trailmarks adapter off: " .. a.key .. ": " .. tostring(n)) end
  end
  return 0, nil
end
-- read API for Cartographer and other Fennick add-ons (copies; callers cannot change our saved data)
TM.API = {
  version = 1,
  Kinds = function() local t = {}; for i, k in ipairs(TM.TYPES) do t[i] = k end; return t end,
  Label = function(kind) return TM.LABEL[kind] end,
  Color = function(kind) local c = TM.COLOR[kind]; return c and c[1], c and c[2], c and c[3] end,
  Enabled = function(kind) return TM:Shown(kind, "f") end,
  -- Questie-style filter categories for Cartographer's filter UI (Cartographer owns the UI; we keep the state)
  -- six point types, then every specific ore and herb (parent = "ore"/"herb"), each with its pin
  Categories = function()
    local t = {}
    for _, k in ipairs(TM.TYPES) do local c = TM.COLOR[k]; t[#t + 1] = { key = k, label = TM.LABEL[k], icon = TM:Icon(TM.KIND_ICON[k]), color = { c[1], c[2], c[3] }, on = TM:O("f_" .. k) and true or false } end
    for _, list in ipairs({ TM.ORES, TM.HERBS }) do for _, e in ipairs(list) do local sub = e[1]
      t[#t + 1] = { key = sub, parent = TM.SUB[sub].kind, label = TM:SubLabel(sub), icon = TM:Icon(sub), on = TM:O("s_" .. sub) ~= false } end end
    return t
  end,
  SetCategory = function(kind, on) if TM.LABEL[kind] then TM:SetO("f_" .. kind, on and true or false); return true elseif TM.SUB[kind] then TM:SetO("s_" .. kind, on and true or false); return true end; return false end,
  Points = function(map, kind)
    local out = {}
    for name, list in pairs(TM:Points(map, kind)) do for _, p in ipairs(list) do out[#out + 1] = { name = name, x = p[1], y = p[2], seen = p[3] or 1, last = p[4] } end end
    return out
  end,
  -- last = newest find (time()), tip = the aggregate-tooltip entry (names/counts/sub labels; merged areas list top 3 names)
  DrawList = function(map) local t = {}; for i, e in ipairs(TM:DrawList(map, "f")) do t[i] = { kind = e[1], name = e[2], x = e[3], y = e[4], seen = e[5], area = e[6], diameter = e[9], opacity = TM:AreaOpacity(), shade = TM.SHADE[e[1]], sub = TM:SubFor(e[1], e[2]), last = e[7], tip = TM.EntryOf and TM.EntryOf(e[1], e[2], e[5], e[7], e[6] and e[8] or nil) } end; return t end,
  Icon = function(key) return TM:Icon(key) end,
  Icons = function() return TM:IconList() end,
  KindIcon = function(kind) return TM:Icon(TM.KIND_ICON[kind]) end,
  PinFor = function(kind, name, size) return TM:Icon(TM:PinKey(kind, name), size) end,
  Changed = function() return TM.version or 0 end,
}
