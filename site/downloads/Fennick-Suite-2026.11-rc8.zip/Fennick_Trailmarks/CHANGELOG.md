# Fennick's Trailmarks: changelog

All notable changes, newest first. Dates are month and year only.

## 1.1.3 (November 2026)
- Nearby recorded ore and herb pins yield to the corresponding active gathering tracker on the minimap. The display uses a 100-yard horizontal radius.

## 1.1.2 (October 2026)
- Optional compatibility with OpenMap (MIT; CurseForge project 1735937): with OpenMap's seamless world map showing, your finds are placed by world position on its view (above its map art) instead of by zone fraction. Uses OpenMap's public API only; any error turns the link off for the session. With Cartographer on, Cartographer draws them. Without OpenMap nothing changes.

## 1.1.1 (October 2026)
- Rotating minimap: pins are hidden during encounters while the game hides your facing (Beast Core C:Facing()).
- Finds keyed by creature: works with Forever 1.60.1's obfuscated creature IDs (only the NPC ID is read).
- Forever 1.60.1 note: nameplates now have a shorter vertical range, so mobs far above or below you get no nameplate and are not seen until you are closer (no error; I don't change nameplate settings).

## 1.1.0 (October 2026)
- Needs Fennick's Beast Core 1.6.
- Tooltips on your Blizzard world map and minimap now list every find under the cursor, grouped and counted, with last seen (Beast Core's map tooltip; Shift for detail).
- The small Trailmarks logo now lives in Beast Core (one copy).
- Shaded areas are merged: one area per spot per type (for example one herb area listing Peacebloom x8 and Silverleaf x8) instead of one stacked area per target. Busy zones are clearer.
- The pin and area art now comes from Beast Core (no duplicate files).
- Settings: the per-map type toggles, icon sizes and shading opacity are under "More settings"; /fennick trail help.
- Hovering near the Fennick waypoint on the world map or minimap adds it to the tooltip.

## 1.0.2 (October 2026)
- Share my finds shows target names only: finds stored by number now print their name, and finds without a known name are left out (never a number).
- Kills by other players nearby are no longer recorded: a kill counts only when you fought it (your target in combat within the last minute) or the client says you tapped it.

## 1.0.1 (October 2026)
- Safety: no longer listens to the combat log, which this client forbids for add-ons. Kills are now noticed when a mob you can see dies (target, mouseover or nameplate).
- Finds are stored by the game's own creature and object numbers when known, so the same target merges across client languages. Numbers are never shown; you always see names.
- Rich and small thorium veins are told apart by the node itself in any language.
- One map redraw after a fight instead of one per find; quest progress is only compared after the quest log settles following a loading screen; a saved-data version step for future changes.
- Minimap pins and shaded areas stay inside the minimap's shape (square with Fennick's Cartographer, round otherwise). Trailmarks uses Cartographer only while Cartographer is switched on.
- Note: before you first loot a node, its specific ore or herb type is guessed from the English node name, so other languages show the plain ore or herb pin until then.

## 1.0.0 (October 2026)
- First release. Records mining and herb nodes, treasure chests, quest targets and quest givers where you find them, and shows them on the world map and minimap (teal, gold and amber pins). A target with many finds in a zone shows as shaded areas.
- Six types (ore, herb, chest, quest mob, quest object, quest giver); 13 specific ores and 28 specific herbs with their own pins and filters.
- Settings: world map and minimap pins, per-type toggles for each map, icon size per map, shaded area opacity, and "Share my finds" (copy text only, no import).
- Draws on Fennick's Cartographer first when installed, then Blizzard's maps; read API, filter categories and icon list for Cartographer. The icon and pins (16 px on the minimap) through one icon table.
- Nothing is stored or drawn during combat; finds made in combat are saved after it. Never shows IDs. 9 languages.

Suite-wide notes: https://github.com/Dagodeiwos/fennick-releases/blob/main/CHANGELOG.md
