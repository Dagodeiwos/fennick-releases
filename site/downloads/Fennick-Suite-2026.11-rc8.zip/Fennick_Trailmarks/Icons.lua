local TR = (Fennick_BEAST and Fennick_BEAST.L) or setmetatable({ F = function(_, f, ...) local ok, s = pcall(string.format, f, ...); return ok and s or f end }, { __index = function(_, k) return k end })   -- l10n (Core C.L)
if not (Fennick_BEAST and (Fennick_BEAST.API or 1) >= 3) then return end   -- file-top guard
-- ONE icon path table for Trailmarks: its own logo here; the shared pins and the area texture come from Beast Core's one
-- pin table (C:PinBase, Fennick_BeastCore/Media; Core 1.6). Nothing else in Trailmarks names a texture.
local TM = Fennick_TRAILMARKS; if not TM then return end
local M = "Interface\\AddOns\\Fennick_Trailmarks\\Media\\"
local C = Fennick_BEAST
local function pin(k) return C.PinBase and C:PinBase(k) or ("Interface\\AddOns\\Fennick_BeastCore\\Media\\Pin_" .. k) end
-- specific ore and herb types: pin key -> the item it drops (item numbers are only used to recognise loot and to get
-- the item's name in the client language; they are never shown). Datamine 70532 ItemSparse.
TM.ORES = { { "ore_copper", 2770 }, { "ore_tin", 2771 }, { "ore_silver", 2775 }, { "ore_iron", 2772 }, { "ore_gold", 2776 },
  { "ore_incendicite", 3340 }, { "ore_lesser_bloodstone", 4278 }, { "ore_indurium", 5833 }, { "ore_mithril", 3858 }, { "ore_truesilver", 7911 },
  { "ore_dark_iron", 11370 }, { "ore_small_thorium", 10620 }, { "ore_rich_thorium", 10620 } }
TM.HERBS = { { "herb_peacebloom", 2447 }, { "herb_silverleaf", 765 }, { "herb_earthroot", 2449 }, { "herb_mageroyal", 785 }, { "herb_briarthorn", 2450 },
  { "herb_stranglekelp", 3820 }, { "herb_bruiseweed", 2453 }, { "herb_wild_steelbloom", 3355 }, { "herb_grave_moss", 3369 }, { "herb_kingsblood", 3356 },
  { "herb_liferoot", 3357 }, { "herb_fadeleaf", 3818 }, { "herb_goldthorn", 3821 }, { "herb_khadgars_whisker", 3358 }, { "herb_wintersbite", 3819 },
  { "herb_firebloom", 4625 }, { "herb_purple_lotus", 8831 }, { "herb_arthas_tears", 8836 }, { "herb_sungrass", 8838 }, { "herb_blindweed", 8839 },
  { "herb_ghost_mushroom", 8845 }, { "herb_gromsblood", 8846 }, { "herb_golden_sansam", 13464 }, { "herb_dreamfoil", 13463 },
  { "herb_mountain_silversage", 13465 }, { "herb_plaguebloom", 13466 }, { "herb_icecap", 13467 }, { "herb_black_lotus", 13468 } }
local PINS = { "ore", "herb", "chest", "quest", "user", "flight", "portal", "ship", "zeppelin" }
TM.ICONS = { logo = M .. "Fennick_Trailmarks", logo_small = (C.LogoPath and C:LogoPath("Trailmarks")) or "Interface\\AddOns\\Fennick_BeastCore\\Media\\Fennick_Trailmarks_32", area = C.PIN_AREA or "Interface\\AddOns\\Fennick_BeastCore\\Media\\Area" }
TM.SUB, TM.ITEM_SUB = {}, {}
for _, k in ipairs(PINS) do TM.ICONS[k] = pin(k) end
for _, list in ipairs({ TM.ORES, TM.HERBS }) do for _, e in ipairs(list) do
  TM.ICONS[e[1]] = pin(e[1]); TM.SUB[e[1]] = { kind = list == TM.ORES and "ore" or "herb", item = e[2] }
  if e[1] ~= "ore_rich_thorium" then TM.ITEM_SUB[e[2]] = e[1] end
end end
-- which pin each point type uses when no specific type is known
TM.KIND_ICON = { ore = "ore", herb = "herb", chest = "chest", mob = "quest", object = "quest", npc = "user" }
TM.SIZED = {}; for k in pairs(TM.ICONS) do TM.SIZED[k] = not (k == "logo" or k == "logo_small" or k == "area") end
-- path for a key at a drawn size (16 px art on the minimap and small pins, 32 px otherwise); unknown keys -> user pin
function TM:Icon(key, size)
  if not self.ICONS[key] then key = "user" end
  if not self.SIZED[key] then return self.ICONS[key] end
  return self.ICONS[key] .. (((size or 32) <= 16) and "_16" or "_32")
end
-- every pickable icon (Cartographer's manual-pin picker): { key, path, small }, sorted; logo/area excluded
function TM:IconList()
  local t = {}
  for k in pairs(self.ICONS) do if self.SIZED[k] then t[#t + 1] = { key = k, path = self:Icon(k, 32), small = self:Icon(k, 16) } end end
  table.sort(t, function(a, b) return a.key < b.key end); return t
end
-- name of a specific type in the client language (the item's own name); thorium veins say rich/small
function TM:SubLabel(sub)
  local s = self.SUB[sub]; if not s then return self.LABEL and self.LABEL[sub] end
  if sub == "ore_rich_thorium" then return TR["Rich Thorium Vein"] elseif sub == "ore_small_thorium" then return TR["Small Thorium Vein"] end
  local n = GetItemInfo and GetItemInfo(s.item)
  if n then return n end
  return (sub:gsub("^%a+_", ""):gsub("_", " "):gsub("(%a)(%w*)", function(a, b) return a:upper() .. b end))
end
-- specific type for a gathered node: learned from loot or the node number (any language). Before the first loot it is
-- a guess from the English node name, so non-English clients show the generic ore/herb pin until then (documented).
local function slug(s) return (s:lower():gsub("'", ""):gsub("[^%w]+", "_"):gsub("^_+", ""):gsub("_+$", "")) end
function TM:SubFor(kind, name)
  if kind ~= "ore" and kind ~= "herb" or type(name) ~= "string" then return nil end
  local learned = self:DB().sub[name]; if learned and self.SUB[learned] then return learned end
  local s = slug(name)
  if kind == "ore" then
    s = s:gsub("^ooze_covered_", ""):gsub("_mineral_vein$", ""):gsub("_vein$", ""):gsub("_deposit$", "")
    if s == "thorium" then s = "small_thorium" end
  end
  local key = kind .. "_" .. s
  return self.SUB[key] and key or nil
end
-- node numbers that decide rich vs small thorium (both drop the same ore); any client language
TM.OBJECT_SUB = { [324] = "ore_small_thorium", [175404] = "ore_rich_thorium", [177388] = "ore_rich_thorium" }
-- after a gather, the loot source (node number) and the loot (item number) name the type: remember it for this node
function TM:LearnFromLoot(kind, name, guid)
  if type(name) ~= "string" then return nil end
  local d = self:DB(); local key, oid = self:IdFromGUID(guid)
  local bynode = oid and self.OBJECT_SUB[oid]
  if bynode and self.SUB[bynode].kind == kind then d.sub[name] = bynode; if key then d.sub[key] = bynode end; return bynode end
  if not (GetNumLootItems and GetLootSlotLink) then return nil end
  for i = 1, math.min(GetNumLootItems() or 0, 8) do
    local link = GetLootSlotLink(i); local id = link and tonumber(link:match("item:(%d+)"))
    local sub = id and self.ITEM_SUB[id]
    if sub and self.SUB[sub].kind == kind then
      -- thorium without a node number: the English name is the only hint left (documented guess)
      if sub == "ore_small_thorium" and name:find("Rich", 1, true) then sub = "ore_rich_thorium" end
      d.sub[name] = sub; if key then d.sub[key] = sub end; return sub
    end
  end
end
