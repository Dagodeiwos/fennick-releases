local TR = (Fennick_BEAST and Fennick_BEAST.L) or setmetatable({ F = function(_, f, ...) local ok, s = pcall(string.format, f, ...); return ok and s or f end }, { __index = function(_, k) return k end })   -- l10n (Core C.L)
if not (Fennick_BEAST and (Fennick_BEAST.API or 1) >= 3) then return end   -- file-top guard
-- registration, settings and events (after Data.lua). Never takes focus; one settings block; /fennick trail.
local C = Fennick_BEAST
local TM = Fennick_TRAILMARKS; if not TM then return end
local M = { key = "trailmarks", label = TR["Trailmarks"], priority = 85, minAPI = 5, needs = "1.6", icon = TM.ICONS and TM.ICONS.logo_small, summary = TR["records nodes, chests and quest spots on your maps"] }
function M:HasStep() return false end
function M:Finished() return true end
function M:View()
  local _, total = TM:Counts()
  return { title = TR["Trailmarks"], line = TR:F("%d places recorded", total), guidance = { TR["/fennick trail share copies your finds."] }, nav = false }
end
local function onoff(v) return v and "|cff55ff55" .. TR["ON"] .. "|r" or "|cffff5555" .. TR["OFF"] .. "|r" end
local SIZE = { TR["small"], TR["medium"], TR["large"] }
local ALPHA = { "15%", "22%", "28%" }
function M:SettingsRows()
  local r = {
    { function() return TR:F("   World map pins %s", onoff(TM:O("worldmap"))) end, function() TM:SetO("worldmap", not TM:O("worldmap")) end },
    { function() return TR:F("   Minimap pins %s", onoff(TM:O("minimap"))) end, function() TM:SetO("minimap", not TM:O("minimap")) end },
  }
  for _, k in ipairs(TM.TYPES) do
    r[#r + 1] = { adv = true, function() return TR:F("   World map: %s %s", TM.LABEL[k], onoff(TM:O("w_" .. k))) end, function() TM:SetO("w_" .. k, not TM:O("w_" .. k)) end }
  end
  for _, k in ipairs(TM.TYPES) do
    r[#r + 1] = { adv = true, function() return TR:F("   Minimap: %s %s", TM.LABEL[k], onoff(TM:O("m_" .. k))) end, function() TM:SetO("m_" .. k, not TM:O("m_" .. k)) end }
  end
  r[#r + 1] = { adv = true, function() return TR:F("   World map icon size: %s", SIZE[TM:O("wsize")] or SIZE[2]) end, function() TM:SetO("wsize", TM:O("wsize") % 3 + 1) end }
  r[#r + 1] = { adv = true, function() return TR:F("   Minimap icon size: %s", SIZE[TM:O("msize")] or SIZE[2]) end, function() TM:SetO("msize", TM:O("msize") % 3 + 1) end }
  r[#r + 1] = { adv = true, function() return TR:F("   Heat-map radius: %.1f%%", TM:ClusterRadius()*100) end, function() TM:SetO("clusterRadius",(tonumber(TM:O("clusterRadius")) or 2)%#TM.CLUSTER_RADII+1) end }
  r[#r + 1] = { adv = true, function() return TR:F("   Heat-map minimum locations: %d", TM:ClusterMinimum()) end, function() TM:SetO("clusterMinimum",(tonumber(TM:O("clusterMinimum")) or 2)%#TM.CLUSTER_MINIMUMS+1) end }
  r[#r + 1] = { adv = true, function() return TR:F("   Heat-map opacity: %d%%", math.floor(TM:AreaOpacity()*100+0.5)) end, function() TM:SetO("alpha", (tonumber(TM:O("alpha")) or 2) % #TM.ALPHAS + 1) end }
  r[#r + 1] = { function() return TR["   Share my finds (copy text)"] end, function() TM:ShowShare() end }
  return r
end
function M:WhyLines() local _, total = TM:Counts(); return { TR:F("Trailmarks: %d places recorded", total) } end
TM.module = C:RegisterModule(M)
if C.RegisterHelp then C:RegisterHelp("trailmarks", { TR["Trailmarks records ore, herbs, chests, quest mobs, quest objects and quest givers where you find them."],
  TR["Finds show as pins on your maps; busy spots become shaded areas. Hover for what is there, Shift for detail."],
  TR["With Cartographer on, finds show on Cartographer's map; otherwise on Blizzard's world map and minimap."],
  TR["Settings: /fennick trail. Share my finds (copy text) is the last Trailmarks row in settings."] }, "trail") end
C:RegisterSlash("trail", function(arg) if (arg or ""):lower():find("^share") then TM:ShowShare() else C:OpenSettings() end end,
  TR["Trailmarks: /fennick trail share copies your finds"])
-- events through Core's shared frame. Combat: only cheap captures; storing and drawing wait for PLAYER_REGEN_ENABLED.
local function ev(e, a1, a2, a3, a4)
  if e == "UNIT_SPELLCAST_SENT" then TM:OnCastSent(a1, a2, a3, a4)
  elseif e == "UNIT_SPELLCAST_SUCCEEDED" then TM:OnCastDone(a1, a2, a3)
  elseif e == "UNIT_SPELLCAST_FAILED" or e == "UNIT_SPELLCAST_INTERRUPTED" then if a1 == "player" then TM.cast = nil end
  elseif e == "UNIT_HEALTH" then TM:OnHealth(a1)
  elseif e == "QUEST_LOG_UPDATE" or e == "QUEST_WATCH_UPDATE" or e == "UNIT_QUEST_LOG_CHANGED" then
    if not TM.qPending then TM.qPending = true; C_Timer.After(0.5, function() TM.qPending = nil; TM:OnQuestLog() end) end
  elseif e == "LOOT_OPENED" then TM:OnLoot()
  elseif e == "PLAYER_TARGET_CHANGED" then TM:OnUnit("target")
  elseif e == "UPDATE_MOUSEOVER_UNIT" then TM:OnUnit("mouseover")
  elseif e == "QUEST_DETAIL" or e == "QUEST_PROGRESS" or e == "QUEST_COMPLETE" then TM:OnQuestNPC()
  elseif e == "PLAYER_REGEN_ENABLED" then
    TM:Flush(); if TM.questDirty then TM:OnQuestLog() end
    if TM.redrawAfterCombat then TM.redrawAfterCombat = nil; TM:Redraw() end
  elseif e == "PLAYER_ENTERING_WORLD" then TM:QuestLogReset()
  elseif e == "PLAYER_LOGIN" then TM:DB(); TM:StartDriver() end
end
for _, e in ipairs({ "UNIT_SPELLCAST_SENT", "UNIT_SPELLCAST_SUCCEEDED", "UNIT_SPELLCAST_FAILED", "UNIT_SPELLCAST_INTERRUPTED", "UNIT_HEALTH", "PLAYER_ENTERING_WORLD",
  "QUEST_LOG_UPDATE", "QUEST_WATCH_UPDATE", "UNIT_QUEST_LOG_CHANGED", "PLAYER_TARGET_CHANGED", "UPDATE_MOUSEOVER_UNIT", "QUEST_DETAIL", "QUEST_PROGRESS", "LOOT_OPENED",
  "QUEST_COMPLETE", "PLAYER_REGEN_ENABLED", "PLAYER_LOGIN" }) do C:On(e, ev) end
