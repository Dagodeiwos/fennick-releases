local TR = (Fennick_BEAST and Fennick_BEAST.L) or setmetatable({ F = function(_, f, ...) local ok, s = pcall(string.format, f, ...); return ok and s or f end }, { __index = function(_, k) return k end })   -- l10n (Core C.L)
if not (Fennick_BEAST and (Fennick_BEAST.API or 1) >= 3) then return end   -- file-top guard
-- World map and minimap pins. Own frames over the map canvas (no data providers, no Blizzard functions replaced).
-- Connected local discoveries of the same target form adaptive shaded areas.
-- Tooltips: Core C:MapTip aggregates everything under the cursor (names, counts, last seen; never IDs).
local C = Fennick_BEAST
local TM = Fennick_TRAILMARKS; if not TM then return end
-- minimap view radius in yards per zoom level (outdoor / indoor); used only when the client has no C_Minimap.GetViewRadius
local OUT_R = { [0] = 233.3, 200, 166.7, 133.3, 100, 66.7 }
local IN_R = { [0] = 150, 120, 90, 60, 40, 25 }
-- aggregate tooltip (Core C:MapTip): every pin or shaded area under the cursor in this pool, grouped and counted.
-- Ore and herb lines use the node's own client-language name ("Copper Vein", "Rich Thorium Vein"), which is already the
-- specific type; the generic type label is used only when no name is known. The specific pin icon comes from SubFor.
local function label(kind, name) if name == TR["Unknown target"] then return TM.LABEL[kind] end end
local function entryOf(kind, name, n, last, names)
  local e = { kind = kind, name = name, seen = n, last = last, icon = TM:Icon(TM:PinKey(kind, name), 16), label = label(kind, name) }
  if names then e.names = {}; for i, nn in ipairs(names) do
    e.names[i] = { nn[1], nn[2], label = label(kind, nn[1]), icon = TM:Icon(TM:PinKey(kind, nn[1]), 16), last = nn[3] } end end
  return e
end
TM.EntryOf = entryOf
local function tip(self)
  if not GameTooltip then return end
  if C.MapTipNear then C:MapTipNear(self, self.pool); return end
  GameTooltip:SetOwner(self, "ANCHOR_RIGHT"); GameTooltip:AddLine(self.name or "", 1, 0.82, 0.3); GameTooltip:Show()
end
local function untip() if GameTooltip then GameTooltip:Hide() end end
local function newPin(parent, pool)
  local f = CreateFrame("Frame", nil, parent)
  f.tex = f:CreateTexture(nil, "OVERLAY"); f.tex:SetAllPoints(f)
  if f.EnableMouse then f:EnableMouse(true) end
  f:SetScript("OnEnter", tip); f:SetScript("OnLeave", untip); f.pool = pool
  pool[#pool + 1] = f; return f
end
local function place(f, kind, name, n, area, size, last, names)
  f.kind, f.name, f.n = kind, name, n
  f.entry = entryOf(kind, name, n, last, area and names or nil)
  if area then local c = TM.SHADE[kind] or TM.SHADE.npc; f.tex:SetTexture(TM:Icon("area")); f.tex:SetVertexColor(c[1], c[2], c[3], 1)
  else f.tex:SetTexture(TM:Icon(TM:PinKey(kind, name), size)); f.tex:SetVertexColor(1, 1, 1, 1) end
  f:SetAlpha(area and TM:AreaOpacity() or 1)
end
-- what to draw for one map: list of { kind, name, x, y, n, area, last, names }. Targets with few finds are pins; busy
-- targets are shaded, and the shading is MERGED: one area per grid cell per kind (weights summed, top 3 names kept,
-- names = { {name, finds, last} }), so overlapping targets of one type never stack frames.
local function buildDrawList(self,map,where)
  local out = {}
  local radius = self:ClusterRadius()
  local minimum = self:ClusterMinimum()
  for _, kind in ipairs(self.TYPES) do if self:Shown(kind, where or "w") then
    local points = self:Points(map, kind)
    local names = {}; for name in pairs(points) do names[#names+1]=name end; table.sort(names)
    for _, name in ipairs(names) do if self:Shown(kind, where or "w", name) then
      -- Collapse exact duplicate locations from shipped and personal observations.
      local list, unique = {}, {}
      for _,p in ipairs(points[name]) do
        local key=string.format("%.8f:%.8f",p[1],p[2])
        local q=unique[key]
        if q then q[3]=q[3]+(p[3] or 1); q[4]=math.max(q[4],p[4] or 0)
        else q={p[1],p[2],p[3] or 1,p[4] or 0}; unique[key]=q; list[#list+1]=q end
      end
      table.sort(list,function(a,b) if a[1]~=b[1] then return a[1]<b[1] end; return a[2]<b[2] end)
      local grid, used = {}, {}
      for i,p in ipairs(list) do
        local key = math.floor(p[1]/radius)..":"..math.floor(p[2]/radius)
        local cell=grid[key] or {}; grid[key]=cell; cell[#cell+1]=i
      end
      for i,p in ipairs(list) do if not used[i] then
        local group={i}; used[i]=true
        local cursor=1
        while cursor<=#group do
          local seed=list[group[cursor]]; cursor=cursor+1
          local ix,iy=math.floor(seed[1]/radius),math.floor(seed[2]/radius)
          for dx=-1,1 do for dy=-1,1 do
            for _,j in ipairs(grid[(ix+dx)..":"..(iy+dy)] or {}) do
              local q=list[j]
              if not used[j] and (q[1]-seed[1])^2+(q[2]-seed[2])^2 <= radius^2 then
                used[j]=true; group[#group+1]=j
              end
            end
          end end
        end
        if #group>=minimum then
          -- Partition long connected chains into bounded local lobes.
          local pending={}
          for _,j in ipairs(group) do pending[j]=true end
          for _,j in ipairs(group) do if pending[j] then
            local seed=list[j]; local lobe={}
            for _,k in ipairs(group) do if pending[k] then
              local q=list[k]
              if (q[1]-seed[1])^2+(q[2]-seed[2])^2 <= (radius*1.5)^2 then
                pending[k]=nil; lobe[#lobe+1]=k
              end
            end end
            local x,y,w,last=0,0,0,0
            for _,k in ipairs(lobe) do local q=list[k]; x=x+q[1]; y=y+q[2]; w=w+q[3]; last=math.max(last,q[4]) end
            x,y=x/#lobe,y/#lobe
            local extent=0
            for _,k in ipairs(lobe) do local q=list[k]; extent=math.max(extent,math.sqrt((q[1]-x)^2+(q[2]-y)^2)) end
            if #lobe>=minimum then
              out[#out+1]={kind,name,x,y,w,true,last,{{name,w,last}},2*(extent+0.008)}
            else
              for _,k in ipairs(lobe) do local q=list[k]; out[#out+1]={kind,name,q[1],q[2],q[3],false,q[4]} end
            end
            if #out>=600 then for k=#out,601,-1 do out[k]=nil end; return out end
          end end
        else
          for _,j in ipairs(group) do local q=list[j]; out[#out+1]={kind,name,q[1],q[2],q[3] or 1,false,q[4]} end
        end
        if #out>=600 then for k=#out,601,-1 do out[k]=nil end; return out end
      end end
    end end
  end end
  return out
end
-- Bounded per-view geometry cache, invalidated by discovery/settings version.
local geometry, geometryVersion, geometryCount={},nil,0
function TM:DrawList(map,where)
  if not map then return {} end
  if geometryVersion~=self.version then geometry={}; geometryCount=0; geometryVersion=self.version end
  local key=tostring(map)..":"..(where or "w")
  if geometry[key] then return geometry[key] end
  local rows=buildDrawList(self,map,where)
  if geometryCount>=12 then geometry={}; geometryCount=0 end
  geometry[key]=rows; geometryCount=geometryCount+1
  return rows
end
-- ---------- world map ----------
function TM:WorldCanvas() local w = WorldMapFrame; return w and w.ScrollContainer and w.ScrollContainer.Child end
function TM:DrawWorld()
  local canvas = self:WorldCanvas(); if not canvas then return end
  self.wpins = self.wpins or {}
  for _, f in ipairs(self.wpins) do f:Hide() end
  if not self:O("worldmap") or not (WorldMapFrame.IsShown and WorldMapFrame:IsShown()) then return 0 end
  local map = WorldMapFrame.GetMapID and WorldMapFrame:GetMapID(); if not map then return 0 end
  local W, H = tonumber(canvas:GetWidth()) or 0, tonumber(canvas:GetHeight()) or 0; if W <= 0 or H <= 0 then return 0 end; local scale = tonumber(canvas.GetScale and canvas:GetScale()) or 1; if scale <= 0 then scale = 1 end
  local size = TM.SIZES[self:O("wsize")] / scale
  local list = self:DrawList(map, "w")
  local om = self:OpenMapStitched()   -- OpenMap's stitched view: place by world position (its public API), not by map fraction
  local n = 0
  for _, e in ipairs(list) do
    local ex, ey = e[3], e[4]
    if om then ex, ey = self:OpenMapXY(map, ex, ey) end
    if ex then n = n + 1; local i = n
    local f = self.wpins[i] or newPin(canvas, self.wpins)
    place(f, e[1], e[2], e[5], e[6], 32, e[7], e[8])
    local s = e[6] and ((e[9] or self.CELL * 1.6) * math.max(W,H)) or size
    f.cx, f.cy, f.r = ex * W, -ey * H, s / 2
    f:SetSize(s, s); f:SetFrameLevel((e[6] and 2000 or 2010) + (om and self:OpenMapArtTop() or 0))
    f:ClearAllPoints(); f:SetPoint("CENTER", canvas, "TOPLEFT", ex * W, -ey * H); f:Show()
  end end
  local w = C.Waypoint and C:Waypoint()   -- the Core waypoint joins the aggregate tooltip (P2-1)
  local wx, wy = w and w.z == map and w.x and w.x / 100, w and w.z == map and w.y and w.y / 100
  if wx and om then wx, wy = self:OpenMapXY(map, wx, wy) end
  self.wpins.wp = (wx and wy) and { cx = wx * W, cy = -wy * H } or nil
  self.worldMap, self.worldDrawn = map, n
  return n
end
-- ---------- minimap ----------
local function world(map, x, y)
  if C.MapWorldPosition then return C:MapWorldPosition(map,x,y,false) end
  if not (C_Map and C_Map.GetWorldPosFromMapPos and CreateVector2D) then return nil end
  local ok, cont, v = pcall(C_Map.GetWorldPosFromMapPos, map, CreateVector2D(x, y))
  if not ok or not v then return nil end
  local wx, wy = v.x, v.y; if v.GetXY then wx, wy = v:GetXY() end
  return cont, wx, wy
end
TM.wcache = {}
local function worldCached(map, x, y)
  if C.MapWorldPosition then local a,b,d=C:MapWorldPosition(map,x,y,true); if a then return {a,b,d} end; return end
  local k = map .. ":" .. x .. ":" .. y; local c = TM.wcache[k]
  if c == nil then local a, b, d = world(map, x, y); c = a and { a, b, d } or false; TM.wcache[k] = c end
  return c or nil
end
function TM:MinimapRadius()
  if C_Minimap and C_Minimap.GetViewRadius then local ok, r = pcall(C_Minimap.GetViewRadius); if ok and r and r > 0 then return r end end
  local z = Minimap.GetZoom and Minimap:GetZoom() or 0
  return ((IsIndoors and IsIndoors()) and IN_R[z] or OUT_R[z]) or 150
end
-- minimap shape: GetMinimapShape() when an add-on provides it (Cartographer: SQUARE by default), else round
function TM:MinimapShape()
  local fn = rawget(_G, "GetMinimapShape"); if type(fn) ~= "function" then return "ROUND" end
  local ok, s = pcall(fn); return (ok and type(s) == "string") and s or "ROUND"
end
local EDGE = 0.92
local function inside(shape, x, y, half)
  local lim = half * EDGE
  if shape == "ROUND" then return x * x + y * y < lim * lim end
  return math.abs(x) < lim and math.abs(y) < lim   -- SQUARE and corner/side shapes: clamp to the square
end
local function room(shape, x, y, half)
  local lim = half * EDGE
  if shape == "ROUND" then return math.max(0, lim - math.sqrt(x * x + y * y)) end
  return math.max(0, lim - math.max(math.abs(x), math.abs(y)))
end
function TM:DrawMinimap(snapshot)
  self.mpins = self.mpins or {}
  local shown = 0
  if not (Minimap and self:O("minimap")) then self.miniSignature = nil; for _, f in ipairs(self.mpins) do f:Hide() end; return 0 end
  local map,px,py
  if snapshot then map,px,py=snapshot.map,snapshot.x,snapshot.y else map,px,py=self:PlayerPos() end
  local cont, wx, wy
  if map then cont, wx, wy = world(map, px, py) end
  local me = cont and {cont, wx, wy}
  if map ~= self.mmMap or self.version ~= self.mmVer then self.mmList, self.mmMap, self.mmVer = map and self:DrawList(map, "m") or {}, map, self.version end
  if me then
    local r = self:MinimapRadius(); local half = (Minimap:GetWidth() or 140) / 2
    local rot = snapshot and snapshot.rotating or (not snapshot and C.MinimapRotates and C:MinimapRotates()) or false; local face = 0
    if rot then if snapshot then face=snapshot.facing else face=C.Facing and C:Facing() end; if not face then self.miniSignature = nil; for _, f in ipairs(self.mpins) do f:Hide() end; return 0 end end   -- facing hidden (encounter): no pins rather than wrong ones
    local cs, sn = math.cos(face), math.sin(face)
    local shape = self:MinimapShape()
    local w = C.Waypoint and C:Waypoint()
    local tracking = C.GatheringTracking and C:GatheringTracking() or 0
    local signature = table.concat({tracking, map, px, py, face, r, half, shape, self.version or 0,
      w and w.z or "", w and w.x or "", w and w.y or ""}, ":")
    if self.miniSignature == signature then return self.miniShown or 0 end
    self.mpins.wp = nil
    local ww = w and w.z and w.x and worldCached(w.z, w.x / 100, w.y / 100)
    if ww and ww[1] == me[1] then
      local east, north = -(ww[3] - me[3]), ww[2] - me[2]
      if rot then east, north = east * cs - north * sn, east * sn + north * cs end
      self.mpins.wp = { cx = east / r * half, cy = north / r * half }
    end
    for _, e in ipairs(self.mmList) do
      local w = worldCached(map, e[3], e[4])
      if w and w[1] == me[1] then
        local east, north = -(w[3] - me[3]), w[2] - me[2]
        if rot then east, north = east * cs - north * sn, east * sn + north * cs end
        local px, py = east / r * half, north / r * half
        if inside(shape, px, py, half) and not (tracking ~= 0 and C:TrackedResourceNearby(e[1], east*east + north*north)) then
          shown = shown + 1
          local f = self.mpins[shown] or newPin(Minimap, self.mpins)
          if f.renderEntry~=e then place(f, e[1], e[2], e[5], e[6], 16, e[7], e[8]); f.renderEntry=e end
          local s = e[6] and math.max(16, (e[9] or self.CELL) * 900 / r * half * 0.5) or TM.SIZES[self:O("msize")]
          if e[6] then s = math.max(6, math.min(s, 2 * room(shape, px, py, half))) end   -- shading never spills past the edge
          f.cx, f.cy, f.r = px, py, s / 2
          f:SetSize(s, s); f:ClearAllPoints(); f:SetPoint("CENTER", Minimap, "CENTER", px, py); f:Show()
        end
      end
    end
    self.miniSignature=signature
  end
  if not me then self.miniSignature = nil; self.mpins.wp=nil end
  for i = shown + 1, #self.mpins do self.mpins[i]:Hide() end
  self.miniShown = shown
  return shown
end
function TM:Redraw()
  if C:InCombat() and (self.worldDrawn or 0) > 0 then self.redrawAfterCombat = true end
  self.mmVer = nil; self.worldMap = nil; self.miniSignature = nil
  if not C:InCombat() then pcall(self.Tick, self) end
end
-- one tick: the first available adapter draws (Cartographer, else Blizzard map + minimap, else others)
function TM:Tick()
  local map = (WorldMapFrame and WorldMapFrame.IsShown and WorldMapFrame:IsShown() and WorldMapFrame.GetMapID and WorldMapFrame:GetMapID()) or (self:PlayerPos())
  if self.DrawAll then return self:DrawAll(map) end
  return (self:DrawWorld() or 0) + (self:DrawMinimap() or 0)
end
-- light driver: world map redraws only when the shown map changes; minimap every 0.5 s (1 s in combat)
function TM:StartDriver()
  if self.driver or not CreateFrame then return end
  local f = CreateFrame("Frame"); self.driver = f; local acc = 0
  local function miniUpdate(snapshot)
    local adapter=TM.ActiveAdapter and TM:ActiveAdapter()
    if not adapter or adapter.key=="blizzard" or (adapter.key=="cartographer" and TM:OwnMinimap()) then
      if Minimap and Minimap:IsVisible() then TM:DrawMinimap(snapshot) end
    elseif TM.miniSignature then
      TM.miniSignature=nil; for _,p in ipairs(TM.mpins or {}) do p:Hide() end
    end
  end
  local shared=C.RegisterMinimapUpdate and C:RegisterMinimapUpdate("trailmarks",miniUpdate)
  f:SetScript("OnUpdate", function(_, el)
    local dt = el or 0
    acc = acc + dt
    if not shared then
      TM.miniAcc=(TM.miniAcc or 0)+dt
      if TM.miniAcc>=0.033 then TM.miniAcc=0; pcall(miniUpdate) end
    end
    if acc < (C:InCombat() and 1 or 0.5) then return end; acc = 0
    local a = TM.ActiveAdapter and TM:ActiveAdapter()
    if a and a.key ~= "blizzard" then
      local wm = WorldMapFrame and WorldMapFrame.IsShown and WorldMapFrame:IsShown() and WorldMapFrame.GetMapID and WorldMapFrame:GetMapID() or nil   -- (OpenMap's view: the map under it)
      if (TM.cartVer ~= TM.version or TM.cartMap ~= (TM:PlayerPos()) or TM.cartWM ~= wm) and not C:InCombat() then TM.cartVer, TM.cartMap, TM.cartWM = TM.version, TM:PlayerPos(), wm; pcall(TM.Tick, TM) end
      return
    end
    if WorldMapFrame and WorldMapFrame.IsShown and WorldMapFrame:IsShown() then
      local m = WorldMapFrame.GetMapID and WorldMapFrame:GetMapID()
      local om = TM:OpenMapStitched()
      if (m ~= TM.worldMap or om ~= TM.worldOM) and not C:InCombat() then TM.worldOM = om; pcall(TM.DrawWorld, TM) end
    elseif TM.worldMap then TM.worldMap = nil; pcall(TM.DrawWorld, TM) end
  end)
end
-- ---------- optional OpenMap (MIT, CurseForge 1735937): public API only, pcall-guarded, off for the session on any error ----------
local function omAPI()
  if TM.omFailed then return nil end
  local A = rawget(_G, "OpenMapAPI")
  if type(A) ~= "table" or A.major ~= 1 or type(A.IsStitched) ~= "function" or type(A.CanvasFromWorldPos) ~= "function" then return nil end
  return A
end
function TM:OpenMapArtTop()   -- OpenMap's stitched art reaches this frame level on the canvas: our pins go above it
  local A = omAPI(); if not (A and type(A.ArtTopLevel) == "function") then return 0 end
  local ok, t = pcall(A.ArtTopLevel); return (ok and type(t) == "number") and math.min(t, 6000) or 0
end
function TM:OpenMapStitched()
  local A = omAPI(); if not A then return false end
  local ok, on = pcall(A.IsStitched); if not ok then TM.omFailed = true; return false end
  return on == true
end
-- a point on a uiMap (0..1) -> x, y on the world map canvas (0..1) while OpenMap's stitched map shows; nil when it can't be placed
function TM:OpenMapXY(map, x, y)
  local A = omAPI(); if not A then return nil end
  local w = worldCached(map, x, y); if not w then return nil end
  local ok, cx, cy = pcall(A.CanvasFromWorldPos, w[1], w[2], w[3]); if not ok then TM.omFailed = true; return nil end
  if type(cx) == "number" and type(cy) == "number" then return cx, cy end
end
