# Fennick's Trailmarks

Records where you find ore and herb nodes, treasure chests, quest targets and quest givers, and shows them on your world map and minimap.

| | |
|---|---|
| Version | 1.1.2 |
| Game | WoW Forever (Interface 16001) |
| Requires | Fennick_BeastCore 1.6 or newer |
| Works with (optional) | Fennick's Cartographer, OpenMap, Fennick's Guidepost |
| License | PolyForm Noncommercial 1.0.0 (`LICENSE.md`) |

## What it does
- **What it records:** mining and herb nodes when you gather, chests when you open them, the spot where a quest mob died when your quest count goes up, quest objects you use, and quest givers and turn-ins when you talk to them.
- **Where it shows them:** pins on the world map and minimap. A target with many finds in a zone becomes a shaded area. Hover for the name, the count and when it was last seen.
- **Types:** ore, herb, chest, quest mob, quest object and quest giver, plus 13 specific ores and 28 specific herbs with their own pins and filters. Until you first loot a node, its kind is guessed from the English node name, so other languages show the plain ore or herb pin until then.
- **Share my finds:** `/fennick trail share` opens a copy box with the text selected. Paste it into a new issue at https://github.com/Dagodeiwos/fennick-releases/issues. Nothing can be imported.
- Nothing is recorded in dungeons or raids, and nothing is stored or drawn during combat. No IDs are ever shown.

## Install
Unzip `Fennick_Trailmarks` into `World of Warcraft/_forever_/Interface/AddOns/` next to `Fennick_BeastCore`.

## Use
- `/fennick trail share` copies your finds as text.
- `/fennick trail help` prints a short help.

## Settings
Fennick in the game's Settings, section Trailmarks: world map pins, minimap pins, and under "More settings" the per-type switches for each map, icon sizes and shading opacity.

## Compatibility
- **Fennick's Cartographer:** when it is on, Trailmarks draws on Cartographer's maps; otherwise on Blizzard's.
- **OpenMap** (MIT, optional, not bundled): with its seamless world map showing, your finds are placed on its view through OpenMap's public API. Any error turns the link off for the session.
- **Fennick's Guidepost:** uses your finds for hunting loops once a hunt has at least 3.
- Forever nameplates have a shorter vertical range, so mobs far above or below you are seen only once you are closer. I do not change nameplate settings.

## How it works (for developers)
- `Trailmarks.lua` records finds; `Map.lua` and `Adapters.lua` draw them on whichever map is present; `Icons.lua` is the one table of icon paths.
- Kills are noticed with `UNIT_HEALTH` and `UnitIsDead` on units you can see, not the combat log, which this client forbids to add-ons.
- Finds are keyed by the game's creature or object number, read from the GUID (a string such as `Creature-0-...-<npcID>-...`; only the NPC ID part is used), so the same target merges across client languages.
- Shipped finds live in `Data.lua`; `tools/trailmarks_merge.py` merges shared text into it offline.

## Support
Bug reports and questions: https://github.com/Dagodeiwos/fennick-releases/issues

## License
PolyForm Noncommercial 1.0.0. See `LICENSE.md` in this folder. The add-ons are free; they are not for sale.
