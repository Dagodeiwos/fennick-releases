local TR = (Fennick_BEAST and Fennick_BEAST.L) or setmetatable({ F = function(_, f, ...) local ok, s = pcall(string.format, f, ...); return ok and s or f end }, { __index = function(_, k) return k end })   -- l10n (Core C.L)
-- Fennick's Trailmarks.
-- Records where you find mining and herb nodes, treasure chests, quest objective mobs and objects, and quest givers,
-- then shows them on the world map and minimap. Our own code: no libraries, nothing taken from other add-ons.
-- Data: Fennick_TrailmarksDB (account-wide). Positions are the client's own normalized map positions (C_Map).
-- Never shows IDs. Copy-out only ("Share my finds"), never import. Heavy work never runs in combat.
if not (Fennick_BEAST and (Fennick_BEAST.API or 1) >= 3) then
  if DEFAULT_CHAT_FRAME then DEFAULT_CHAT_FRAME:AddMessage(TR["|cff33ccffFennick:|r Fennick's Trailmarks needs Fennick's Beast Core 1.2 or newer. Please update Beast Core."]) end
  return
end
local C = Fennick_BEAST
local TM = {
  NAME = "Trailmarks",
  TYPES = { "ore", "herb", "chest", "mob", "object", "npc" },
  MERGE = 0.006,                             -- points closer than this (normalized map units, about 0.6% of a zone) merge
  MAXPTS = 80,                               -- per target per zone (least-seen point is replaced when full)
  AREA_MIN = 6,                              -- a target with this many points in a zone is drawn as shaded areas
  CELL = 0.035,                              -- shaded area grid (normalized)
  PENDING_MAX = 200,
  SHIPPED = {},                              -- Data.lua (built offline from shared finds); same layout as the saved data
  -- spell IDs only decide what a cast was; never shown. Datamine 70532 SpellName.
  CAST = { [2575] = "ore", [2576] = "ore", [3564] = "ore", [10248] = "ore",
           [2366] = "herb", [2368] = "herb", [3570] = "herb", [11993] = "herb",
           [3365] = "chest", [3366] = "chest", [6247] = "chest", [6249] = "chest", [6477] = "chest", [6478] = "chest",
           [6658] = "chest", [6802] = "chest", [8917] = "chest", [21651] = "chest", [22810] = "chest" },
  pending = {}, kills = {}, objText = {}, seenAt = {},
}
Fennick_TRAILMARKS = TM
TM.LABEL = { ore = TR["Mining nodes"], herb = TR["Herbs"], chest = TR["Treasure chests"], mob = TR["Quest mobs"], object = TR["Quest objects"], npc = TR["Quest givers"] }
-- The Fennick palette: category colours from Core (C.CAT_COL, Core 1.6); this table is only the fallback
TM.COLOR = C.CAT_COL or { ore = { 0.83, 0.55, 0.20 }, herb = { 0.16, 0.70, 0.64 }, chest = { 0.95, 0.78, 0.30 }, mob = { 1.00, 0.62, 0.15 }, object = { 0.98, 0.70, 0.40 }, npc = { 0.55, 0.88, 0.82 } }
TM.SIZES = { 10, 14, 18 }
-- zone shading : per-resource tint at 0.22 by default, never above 0.5
TM.SHADE = { ore = { 0.70, 0.73, 0.77 }, herb = { 0.38, 0.75, 0.35 }, chest = { 0.83, 0.65, 0.29 }, mob = { 0.98, 0.84, 0.24 }, object = { 0.98, 0.84, 0.24 }, npc = { 0.05, 0.29, 0.33 } }
TM.ALPHAS = { 0.15, 0.22, 0.28, 0.40, 0.55, 0.70, 0.85 }
TM.CLUSTER_RADII={0.015,0.025,0.04}
TM.CLUSTER_MINIMUMS={3,4,6,8}
function TM:ClusterRadius() return self.CLUSTER_RADII[self:O("clusterRadius")] or 0.025 end
function TM:ClusterMinimum() return self.CLUSTER_MINIMUMS[self:O("clusterMinimum")] or 4 end
function TM:AreaOpacity() return self.ALPHAS[self:O("alpha")] or self.ALPHAS[2] end

function TM:DB()
  Fennick_TrailmarksDB = type(Fennick_TrailmarksDB) == "table" and Fennick_TrailmarksDB or {}
  local d = Fennick_TrailmarksDB
  d.p = type(d.p) == "table" and d.p or {}; d.sub = type(d.sub) == "table" and d.sub or {}; d.opt = type(d.opt) == "table" and d.opt or {}
  d.names = type(d.names) == "table" and d.names or {}; d.alias = type(d.alias) == "table" and d.alias or {}
  if (tonumber(d.v) or 1) < TM.DBV then TM:Migrate(d) end
  return d
end
-- saved-data format. v1: finds keyed by the target's name. v2: keyed by the client's creature/object number when known
-- (internal only, never shown), with the name kept for display (names) and name->key links (alias). v1 data stays
-- valid as-is (name keys); add later steps here: if d.v < 3 then ... end
TM.DBV = 2
function TM:Migrate(d)
  local v = tonumber(d.v) or 1
  if v < 2 then d.names = type(d.names) == "table" and d.names or {}; d.alias = type(d.alias) == "table" and d.alias or {} end
  d.v = TM.DBV; return v
end
local DEF = { worldmap = true, minimap = true, wsize = 2, msize = 2, alpha = 2, clusterRadius = 2, clusterMinimum = 2 }
for _, k in ipairs(TM.TYPES) do DEF["w_" .. k] = true; DEF["m_" .. k] = true; DEF["f_" .. k] = true end
function TM:O(k) local v = self:DB().opt[k]; if v == nil then return DEF[k] end; return v end
function TM:SetO(k, v) self:DB().opt[k] = v; self:Changed() end
-- batched: many finds in one frame (for example the after-combat flush) cause one redraw
function TM:Changed()
  self.version = (self.version or 0) + 1
  if self.batching or self.redrawQueued or not self.Redraw then return end
  self.redrawQueued = true
  local function go() TM.redrawQueued = nil; pcall(TM.Redraw, TM) end
  if C_Timer and C_Timer.After then C_Timer.After(0, go) else go() end
end
-- ---------- target keys: creature/object number when the client gives one, else the name ----------
local function isIdKey(k) return type(k) == "string" and k:find("^[no]%d+$") ~= nil end
TM.IsIdKey = isIdKey
function TM:IdFromGUID(guid)
  if type(guid) ~= "string" then return nil end
  local kind, id = guid:match("^(%a+)%-[^%-]+%-[^%-]+%-[^%-]+%-[^%-]+%-(%d+)")   -- 1.60.1: server/spawn fields are obfuscated; only the NPC ID (field 6) is read
  id = tonumber(id); if not id or id == 0 then return nil end
  if kind == "Creature" or kind == "Vehicle" then return "n" .. id, id elseif kind == "GameObject" then return "o" .. id, id end
end
function TM:Key(name, guid)
  local d = self:DB(); local key = self:IdFromGUID(guid)
  if key then if type(name) == "string" and name ~= "" and not isIdKey(name) then d.names[key] = name; d.alias[name] = key end; return key end
  return (type(name) == "string" and d.alias[name]) or name
end
-- what a key shows: the name seen on this client, else the shipped name; an unnamed number shows as unknown, never the number
function TM:Display(key)
  if not isIdKey(key) then return key end
  return self:DB().names[key] or (self.SHIPPED_NAMES and self.SHIPPED_NAMES[key]) or TR["Unknown target"]
end
-- fold finds stored under a plain name into the numbered key (after loot or a GUID tells us which target it was)
function TM:Rekey(map, kind, name, key)
  if not key or key == name then return end
  local m = self:DB().p[map]; local k = type(m) == "table" and m[kind]; local list = type(k) == "table" and k[name]
  if type(list) ~= "table" then return end
  k[name] = nil; local was = self.batching; self.batching = true
  for _, p in ipairs(list) do if type(p) == "table" then self:Add(map, kind, key, p[1], p[2], p[4], p[3]) end end
  self.batching = was; self:Changed()
end
local function now() return time and time() or 0 end
local function valid(x, y) return type(x) == "number" and type(y) == "number" and x > 0 and x < 1 and y > 0 and y < 1 end
local function round(v) return math.floor(v * 10000 + 0.5) / 10000 end

-- ---------- storing and merging ----------
-- Merge rule: a point within MERGE of an existing point of the same target becomes part of it (weighted average,
-- count + 1, last seen updated). Otherwise a new point; when a target is full the least-seen, oldest point is replaced.
function TM:Add(map, kind, name, x, y, t, n, guid)
  if type(map) ~= "number" or not self.LABEL[kind] or type(name) ~= "string" or name == "" or not valid(x, y) then return nil end
  local key = self:Key(name, guid); if key ~= name and not isIdKey(name) then self:Rekey(map, kind, name, key) end; name = key
  local d = self:DB().p
  d[map] = type(d[map]) == "table" and d[map] or {}; local m = d[map]
  m[kind] = type(m[kind]) == "table" and m[kind] or {}; local k = m[kind]
  k[name] = type(k[name]) == "table" and k[name] or {}; local list = k[name]
  n = n or 1; t = t or now()
  local best, bd
  for _, p in ipairs(list) do local dd = math.sqrt((p[1] - x) ^ 2 + (p[2] - y) ^ 2); if dd < self.MERGE and (not bd or dd < bd) then best, bd = p, dd end end
  if best then
    local c = best[3] or 1
    best[1] = round((best[1] * c + x * n) / (c + n)); best[2] = round((best[2] * c + y * n) / (c + n))
    best[3] = c + n; best[4] = math.max(best[4] or 0, t)
    self:Changed(); return "merged", best
  end
  local p = { round(x), round(y), n, t }
  if #list >= self.MAXPTS then
    local wi = 1; for i, q in ipairs(list) do local w = list[wi]; if (q[3] or 1) < (w[3] or 1) or ((q[3] or 1) == (w[3] or 1) and (q[4] or 0) < (w[4] or 0)) then wi = i end end
    list[wi] = p
  else list[#list + 1] = p end
  self:Changed(); return "new", p
end
-- Record at a known position. In combat the find is queued (position already captured) and stored after combat.
function TM:Record(kind, name, map, x, y, guid)
  if not (map and x) then map, x, y = self:PlayerPos() end
  if not map then return nil end
  if C:InCombat() then
    if #self.pending < self.PENDING_MAX then self.pending[#self.pending + 1] = { kind, name, map, x, y, now(), guid } end
    return "queued"
  end
  return self:Add(map, kind, name, x, y, nil, nil, guid)
end
function TM:Flush()
  local q = self.pending; self.pending = {}
  self.batching = true
  for _, e in ipairs(q) do pcall(self.Add, self, e[3], e[1], e[2], e[4], e[5], e[6], nil, e[7]) end
  self.batching = nil; if #q > 0 then self:Changed() end
  return #q
end
function TM:PlayerPos()
  if not (C_Map and C_Map.GetBestMapForUnit and C_Map.GetPlayerMapPosition) then return nil end
  local ok, map = pcall(C_Map.GetBestMapForUnit, "player"); if not ok or not map then return nil end
  local ok2, p = pcall(C_Map.GetPlayerMapPosition, map, "player"); if not ok2 or not p then return nil end   -- nil in dungeons/raids
  local x, y = p.x, p.y; if p.GetXY then x, y = p:GetXY() end
  if not valid(x, y) then return nil end
  return map, x, y
end
-- every point for a zone: your own finds plus the shipped data, per type and target
function TM:Points(map, kind)
  local out = {}
  for _, src in ipairs({ self.SHIPPED, self:DB().p }) do
    local m = type(src[map]) == "table" and src[map][kind]
    if type(m) == "table" then for key, list in pairs(m) do local name = self:Display(key)
      if type(list) == "table" then out[name] = out[name] or {}; for _, p in ipairs(list) do if type(p) == "table" and valid(p[1], p[2]) then table.insert(out[name], p) end end end end end
  end
  return out
end
-- zone shading: occupied grid cells for one target (cell centre, number of finds), biggest first
function TM:Areas(list)
  local cells, out = {}, {}
  for _, p in ipairs(list) do
    local cx, cy = math.floor(p[1] / self.CELL), math.floor(p[2] / self.CELL); local key = cx * 1000 + cy
    local c = cells[key]; if not c then c = { x = 0, y = 0, n = 0, w = 0 }; cells[key] = c end
    local w = p[3] or 1; c.x = c.x + p[1] * w; c.y = c.y + p[2] * w; c.w = c.w + w; c.n = c.n + 1
  end
  for _, c in pairs(cells) do out[#out + 1] = { c.x / c.w, c.y / c.w, c.w, n = c.n } end
  table.sort(out, function(a, b) return a[3] > b[3] end)
  return out
end
function TM:PointsAny(map, kinds)
  local out = {}; for _, k in ipairs(kinds) do for name, list in pairs(self:Points(map, k)) do out[name] = out[name] or {}; for _, p in ipairs(list) do table.insert(out[name], p) end end end
  return out
end
-- which map draws a kind: "w" Blizzard world map, "m" minimap (own toggles), "c" Cartographer (its filter categories)
function TM:Shown(kind, where, name)
  if not self:O((where or "w") .. "_" .. kind) then return false end
  local sub = name and self.SubFor and self:SubFor(kind, name)
  if sub and self:O("s_" .. sub) == false then return false end   -- specific ore/herb filter (shared by every map)
  return true
end
function TM:PinKey(kind, name) local sub = self.SubFor and self:SubFor(kind, name); return sub or self.KIND_ICON[kind] end
function TM:Shaded(list) return #list >= self.AREA_MIN end
-- Guidepost link (optional): hunt spots (0-100 coordinates, like Guidepost's plan) for targets whose name is given or
-- appears in one of the objective texts. Nil when fewer than 3 recorded finds; Guidepost then uses its own data.
function TM:HuntSpots(map, names, texts)
  if C:InCombat() or type(map) ~= "number" then return nil end
  local all = {}
  for name, list in pairs(self:PointsAny(map, { "mob", "object" })) do
    local hit = false
    for _, n in ipairs(names or {}) do if n == name then hit = true end end
    for _, t in ipairs(texts or {}) do if type(t) == "string" and t:find(name, 1, true) then hit = true end end
    if hit then for _, p in ipairs(list) do all[#all + 1] = p end end
  end
  local finds = 0; for _, p in ipairs(all) do finds = finds + (p[3] or 1) end
  if finds < 3 then return nil end
  local out = {}
  for i, a in ipairs(self:Areas(all)) do if i > 4 then break end; out[i] = { a[1] * 100, a[2] * 100 } end
  return out
end
function TM:Counts()
  local t, total = {}, 0
  for _, m in pairs(self:DB().p) do if type(m) == "table" then for kind, k in pairs(m) do if type(k) == "table" then for _, list in pairs(k) do
    if type(list) == "table" then t[kind] = (t[kind] or 0) + #list; total = total + #list end end end end end end
  return t, total
end

-- ---------- hooks ----------
-- quest objective texts (out of combat, on quest log changes); used to tell quest targets from other mobs
function TM:ReadObjectives()
  local texts, fulfilled = {}, {}
  if not (GetNumQuestLogEntries and GetQuestLogTitle and C_QuestLog and C_QuestLog.GetQuestObjectives) then return texts, fulfilled end
  local n = GetNumQuestLogEntries() or 0
  for i = 1, math.min(n, 60) do
    local ok, _, _, _, header, _, _, _, qid = pcall(GetQuestLogTitle, i)
    if ok and not header and qid then
      local ok2, objs = pcall(C_QuestLog.GetQuestObjectives, qid)
      for j, o in ipairs(ok2 and type(objs) == "table" and objs or {}) do
        if type(o.text) == "string" and o.text ~= "" then texts[#texts + 1] = o.text; fulfilled[qid .. ":" .. j] = { o.numFulfilled or 0, o.text, o.type } end
      end
    end
  end
  return texts, fulfilled
end
function TM:IsObjective(name)
  if type(name) ~= "string" or name == "" then return false end
  for _, t in ipairs(self.objText) do if t:find(name, 1, true) then return true end end
  return false
end
-- progress: an objective count went up -> the matching recent kill (name in the objective text, else the last kill
-- within 30 s for item objectives) is a quest target at the spot where it died
-- RC-33 gate: after a loading screen the quest log is re-read once it has settled (2 s); until then nothing is compared
function TM:QuestLogReset()
  self.qReady = false; self.fulfilled = nil
  local function ready() TM.qReady = true; TM:OnQuestLog() end
  if C_Timer and C_Timer.After then C_Timer.After(2, ready) else ready() end
end
function TM:OnQuestLog()
  if C:InCombat() or not self.qReady then self.questDirty = true; return end
  self.questDirty = nil
  local texts, ful = self:ReadObjectives(); local prev = self.fulfilled; self.objText = texts; self.fulfilled = ful
  if not prev then return end
  for key, v in pairs(ful) do
    local old = prev[key]
    if old and v[1] > old[1] then
      local hit
      for i = #self.kills, 1, -1 do local k = self.kills[i]; if v[2]:find(k.name, 1, true) then hit = k; break end end
      if not hit then local k = self.kills[#self.kills]; if k and (GetTime() - k.at) < 30 and v[3] ~= "monster" then hit = k end end
      if not hit and self.lastOpen and (GetTime() - self.lastOpen.at) < 30 then hit = self.lastOpen end
      if hit then self:Add(hit.map, hit.obj and "object" or "mob", hit.name, hit.x, hit.y, nil, nil, hit.guid); hit.used = true end
    end
  end
end
function TM:OnKill(name, guid)
  if type(name) ~= "string" then return end
  local map, x, y = self:PlayerPos(); if not map then return end
  self.kills[#self.kills + 1] = { name = name, guid = guid, map = map, x = x, y = y, at = GetTime() }
  if #self.kills > 8 then table.remove(self.kills, 1) end
end
-- kills without the combat log (forbidden on this client): UNIT_HEALTH for a unit we can see that is now dead and was
-- tapped by us (not tap-denied). One capture per creature (bounded); cheap enough to run in combat.
-- Kills by other players nearby: they are tap-denied for us, and we also require that we fought it ourselves
-- (it was our target/focus while we were in combat within the last 60 s) or the client says we tapped it.
TM.deadSeen, TM.deadCount = {}, 0
TM.engaged, TM.engagedCount = {}, 0
function TM:Engaged(unit, guid)
  if UnitIsTappedByPlayer then local ok, yes = pcall(UnitIsTappedByPlayer, unit); if ok and yes then return true end end
  local t = self.engaged[guid]; return t ~= nil and GetTime and (GetTime() - t) <= 60
end
-- Forever 1.60.1: nameplates have a shorter vertical range, so mobs far above or below you get no plate and are not seen here (degrades, never errors). We do not change nameplate CVars.
function TM:OnHealth(unit)
  if type(unit) ~= "string" then return end
  if not (unit == "target" or unit == "mouseover" or unit == "focus" or unit:find("^nameplate%d+$")) then return end
  if not (UnitIsDead and UnitIsDead(unit)) then
    -- alive: remember what we are fighting (our target/focus while we are in combat)
    if (unit == "target" or unit == "focus") and UnitAffectingCombat and UnitAffectingCombat("player") and UnitGUID and GetTime then
      local g = UnitGUID(unit)
      if g then if self.engagedCount > 200 then self.engaged, self.engagedCount = {}, 0 end
        if not self.engaged[g] then self.engagedCount = self.engagedCount + 1 end; self.engaged[g] = GetTime() end
    end
    return
  end
  if (UnitIsPlayer and UnitIsPlayer(unit)) or (UnitIsTapDenied and UnitIsTapDenied(unit)) then return end
  local guid = UnitGUID and UnitGUID(unit); if not guid or self.deadSeen[guid] then return end
  if not self:Engaged(unit, guid) then return end
  if self.deadCount > 100 then self.deadSeen, self.deadCount = {}, 0 end
  self.deadSeen[guid] = true; self.deadCount = self.deadCount + 1
  return self:OnKill(UnitName(unit), guid)
end
function TM:OnCastSent(unit, target, guid, spell)
  if unit ~= "player" then return end
  local kind = self.CAST[spell]
  if not kind and GetSpellInfo and spell then
    local nm = GetSpellInfo(spell)
    if nm and nm == GetSpellInfo(2575) then kind = "ore" elseif nm and nm == GetSpellInfo(2366) then kind = "herb" elseif nm and nm == GetSpellInfo(3365) then kind = "chest" end
  end
  if not kind or type(target) ~= "string" or target == "" then self.cast = nil; return end
  local map, x, y = self:PlayerPos()
  self.cast = map and { kind = kind, name = target, map = map, x = x, y = y, guid = guid, spell = spell } or nil
end
function TM:OnCastDone(unit, guid, spell)
  local c = self.cast; if unit ~= "player" or not c then return end
  if (c.guid and guid and c.guid ~= guid) or (not c.guid and c.spell ~= spell) then return end
  self.cast = nil
  local kind = c.kind
  if kind == "chest" and self:IsObjective(c.name) then kind = "object" end   -- quest objects are opened too
  self.lootFor = { kind = kind, name = c.name, map = c.map, at = GetTime() }
  self.lastOpen = { name = c.name, map = c.map, x = c.x, y = c.y, at = GetTime(), obj = true }
  return self:Record(kind, c.name, c.map, c.x, c.y)
end
-- target / mouseover: a living, nearby non-player unit named in an active objective (out of combat; 15 s per name)
function TM:OnUnit(unit)
  if C:InCombat() or not (UnitExists and UnitExists(unit)) then return end
  if UnitIsPlayer and UnitIsPlayer(unit) then return end
  if UnitIsDead and UnitIsDead(unit) then return end
  local name = UnitName and UnitName(unit); if not self:IsObjective(name) then return end
  if CheckInteractDistance then local ok, near = pcall(CheckInteractDistance, unit, 4); if ok and not near then return end end
  local t = GetTime(); if self.seenAt[name] and t - self.seenAt[name] < 15 then return end
  self.seenAt[name] = t
  return self:Record("mob", name, nil, nil, nil, UnitGUID and UnitGUID(unit))
end
function TM:OnLoot()
  local l = self.lootFor; self.lootFor = nil
  if not (l and GetTime() - l.at < 5) then return end
  local guid; if GetLootSourceInfo then local ok, g = pcall(GetLootSourceInfo, 1); if ok then guid = g end end
  if guid and l.map then self:Rekey(l.map, l.kind, l.name, self:Key(l.name, guid)) end
  if l.kind == "ore" or l.kind == "herb" then return self:LearnFromLoot(l.kind, l.name, guid) end
end
function TM:OnQuestNPC()
  if not (UnitExists and UnitExists("npc")) or (UnitIsPlayer and UnitIsPlayer("npc")) then return end
  local name = UnitName("npc"); if type(name) ~= "string" or name == "" then return end
  return self:Record("npc", name, nil, nil, nil, UnitGUID and UnitGUID("npc"))
end

-- ---------- Share my finds (copy-out only; no import) ----------
-- Plain text, one find per line: zone | kind | target | x | y | times seen. Zone names, never IDs.
TM.KIND_CODE = { ore = "ore", herb = "herb", chest = "chest", mob = "mob", object = "object", npc = "npc" }
function TM:ZoneName(map)
  local ok, info = pcall(C_Map.GetMapInfo, map); return ok and info and info.name or nil
end
function TM:ShareText(limit)
  limit = limit or 4000
  local lines = { "Fennick Trailmarks finds v1 | " .. ((GetLocale and GetLocale()) or "enUS") .. " | " .. date("%Y-%m-%d") }
  local rows = {}
  for map, m in pairs(self:DB().p) do
    local zn = type(m) == "table" and self:ZoneName(map)
    if zn then for kind, k in pairs(m) do if self.KIND_CODE[kind] and type(k) == "table" then
      for name, list in pairs(k) do for _, p in ipairs(type(list) == "table" and list or {}) do
        if valid(p[1], p[2]) and self:Display(name) ~= TR["Unknown target"] then rows[#rows + 1] = string.format("%s | %s | %s | %.1f | %.1f | %d", zn, kind, (self:Display(name):gsub("|", "/")), p[1] * 100, p[2] * 100, p[3] or 1) end
      end end end end end
  end
  table.sort(rows)
  for i = 1, math.min(#rows, limit) do lines[#lines + 1] = rows[i] end
  if #rows > limit then lines[#lines + 1] = TR:F("(%d more finds not shown)", #rows - limit) end
  return table.concat(lines, "\n"), #rows
end
