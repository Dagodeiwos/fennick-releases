local TR = (Fennick_BEAST and Fennick_BEAST.L) or setmetatable({ F = function(_, f, ...) local ok, s = pcall(string.format, f, ...); return ok and s or f end }, { __index = function(_, k) return k end })   -- l10n (Core C.L)
if not (Fennick_BEAST and (Fennick_BEAST.API or 1) >= 3) then return end   -- file-top guard
-- "Share my finds": read-only multi-line box, text pre-selected for Ctrl+C; typing resets it, Escape closes. No import.
local C = Fennick_BEAST
local TM = Fennick_TRAILMARKS; if not TM then return end
function TM:ShowShare()
  local cf = self.share
  if not cf then
    cf = CreateFrame("Frame", "Fennick_TrailmarksShare", UIParent, BackdropTemplateMixin and "BackdropTemplate" or nil); self.share = cf
    cf:SetSize(560, 380); cf:SetPoint("CENTER"); cf:SetFrameStrata("DIALOG")
    if C.Skin and C.Skin.Add then C.Skin:Add("trailShare", cf); C.Skin:Style(cf, 0.97) end
    cf.title = C:NewFS(cf, "OVERLAY", "GameFontNormal"); cf.title:SetPoint("TOPLEFT", 14, -12)
    cf.title:SetText(TR["Share my finds: press Ctrl+C to copy, then paste it to Fennick"])
    local sf = CreateFrame("ScrollFrame", "Fennick_TrailmarksShareScroll", cf, "UIPanelScrollFrameTemplate"); sf:SetPoint("TOPLEFT", 14, -36); sf:SetPoint("BOTTOMRIGHT", -34, 44)
    local eb = CreateFrame("EditBox", nil, sf); eb:SetMultiLine(true); eb:SetAutoFocus(false); eb:SetFontObject(C:FontObj("GameFontHighlightSmall")); eb:SetWidth(500)
    sf:SetScrollChild(eb); cf.eb = eb
    eb:SetScript("OnTextChanged", function(self, user) if user then self:SetText(cf.text or ""); self:HighlightText() end end)
    eb:SetScript("OnEscapePressed", function() cf:Hide() end)
    eb:SetScript("OnEditFocusGained", function(self) self:HighlightText() end)
    local close = CreateFrame("Button", nil, cf, "UIPanelButtonTemplate"); close:SetSize(100, 22); close:SetPoint("BOTTOMRIGHT", -14, 12)
    close:SetText(TR["Close"]); close:SetScript("OnClick", function() cf:Hide() end)
  end
  local text, n = self:ShareText(); cf.text = text; cf.count = n
  cf:Show(); cf.eb:SetText(text); cf.eb:SetFocus(); cf.eb:HighlightText()
  return cf
end
